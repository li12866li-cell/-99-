import React, { useEffect, useState } from 'react';
import { X, Save, RotateCcw } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { InteractivePreferenceTab } from '../FoodPreferenceEntryCards.tsx';
import {
  DEFAULT_FOOD_EMOJI,
  FOOD_EMOJI_PALETTE,
  matchFoodEmoji,
} from '../../lib/foodEmojiMatcher.ts';
import { FoodScanCopy } from '../../lib/foodScanI18n.ts';
import { PetFoodPreferenceItem } from '../../services/localStore.ts';

interface FoodPreferenceModalProps {
  isOpen: boolean;
  mode: 'add' | 'edit';
  category: InteractivePreferenceTab;
  petName: string;
  initialItem?: PetFoodPreferenceItem | null;
  onClose: () => void;
  onSubmit: (payload: { name: string; icon: string; note?: string }) => void;
  errorMessage?: string | null;
  onClearError?: () => void;
  copy: FoodScanCopy;
}

const CATEGORY_ACCENT: Record<
  InteractivePreferenceTab,
  { headerBg: string; badgeText: string; submitBtn: string }
> = {
  likes: {
    headerBg: 'bg-[#e6f7f1]/75',
    badgeText: 'text-[#1f5c4b]',
    submitBtn: 'bg-[#2f9e7e] hover:bg-[#258267]',
  },
  dislikes: {
    headerBg: 'bg-[#fff3e6]/85',
    badgeText: 'text-[#9a4d12]',
    submitBtn: 'bg-[#ea7d2b] hover:bg-[#cf6a1e]',
  },
  allergies: {
    headerBg: 'bg-[#fff0f4]/85',
    badgeText: 'text-[#9c2341]',
    submitBtn: 'bg-[#d9385a] hover:bg-[#bd2a49]',
  },
};

export function FoodPreferenceModal({
  isOpen,
  mode,
  category,
  petName,
  initialItem,
  onClose,
  onSubmit,
  errorMessage,
  onClearError,
  copy,
}: FoodPreferenceModalProps) {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState(DEFAULT_FOOD_EMOJI);
  const [isManualIcon, setIsManualIcon] = useState(false);
  const [note, setNote] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (mode === 'edit' && initialItem) {
      setName(initialItem.name);
      const resolved = initialItem.icon || matchFoodEmoji(initialItem.name);
      setIcon(resolved);
      setIsManualIcon(
        Boolean(initialItem.icon && initialItem.icon !== matchFoodEmoji(initialItem.name))
      );
      setNote(initialItem.note || '');
    } else {
      setName('');
      setIcon(DEFAULT_FOOD_EMOJI);
      setIsManualIcon(false);
      setNote('');
    }
  }, [isOpen, mode, initialItem]);

  // Auto-match Emoji as user types unless manually overridden
  const handleNameChange = (val: string) => {
    setName(val);
    if (errorMessage) onClearError?.();
    if (!isManualIcon) {
      setIcon(matchFoodEmoji(val));
    }
  };

  const handleManualIconPick = (emoji: string) => {
    setIcon(emoji);
    setIsManualIcon(true);
  };

  const handleResetAutoIcon = () => {
    setIsManualIcon(false);
    setIcon(matchFoodEmoji(name));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, icon, note });
  };

  const accent = CATEGORY_ACCENT[category];
  const categoryTitle = copy.categories[category].title;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#1f2e28]/45 backdrop-blur-xs"
          />
          <motion.form
            role="dialog"
            aria-modal="true"
            onSubmit={handleSubmit}
            initial={{ opacity: 0, scale: 0.95, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ duration: 0.2 }}
            className="relative z-10 w-full max-w-lg bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div
              className={`px-5 py-4 border-b border-[#e9e4d8] ${accent.headerBg} flex items-center justify-between gap-3`}
            >
              <div className="min-w-0">
                <div className={`text-xs font-semibold ${accent.badgeText}`}>
                  {petName} · {categoryTitle}
                </div>
                <h3 className="text-base sm:text-lg font-bold text-[#1f2e28] mt-0.5">
                  {mode === 'edit' ? copy.editModalTitle : copy.addModalTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl bg-white/80 hover:bg-white border border-[#e9e4d8] text-[#4c5e56] shrink-0"
                aria-label={copy.cancelBtn}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 overflow-y-auto">
              {/* Food Name + Live Matched Icon Preview */}
              <div className="space-y-1.5">
                <label
                  htmlFor="pref-food-name"
                  className="block text-xs font-semibold text-[#1f2e28]"
                >
                  {copy.foodNameLabel}
                </label>
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] flex items-center justify-center text-2xl shrink-0 select-none"
                    aria-hidden="true"
                  >
                    {icon}
                  </div>
                  <input
                    id="pref-food-name"
                    type="text"
                    autoFocus
                    value={name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder={copy.foodNamePlaceholder}
                    className="flex-1 min-w-0 h-11 rounded-xl border border-[#e9e4d8] bg-white px-3.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                  />
                </div>
              </div>

              {errorMessage && (
                <div className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2">
                  {errorMessage}
                </div>
              )}

              {/* Emoji Icon Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold text-[#1f2e28]">{copy.foodIconLabel}</span>
                    <span className="text-[#72847c]">·</span>
                    <span className="text-[#2f9e7e] font-medium">
                      {isManualIcon ? copy.manualSelectedBadge : copy.autoMatchedBadge}
                    </span>
                  </div>
                  {isManualIcon && (
                    <button
                      type="button"
                      onClick={handleResetAutoIcon}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#2f9e7e] hover:underline"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>{copy.resetAutoIconBtn}</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-7 gap-1.5 rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/75 p-2.5">
                  {FOOD_EMOJI_PALETTE.map((emoji) => {
                    const selected = icon === emoji;
                    return (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => handleManualIconPick(emoji)}
                        className={`h-10 rounded-xl text-xl flex items-center justify-center transition-all cursor-pointer select-none ${
                          selected
                            ? 'bg-[#e6f7f1] border-2 border-[#2f9e7e] scale-105 shadow-2xs'
                            : 'bg-white/80 border border-transparent hover:border-[#e9e4d8] hover:bg-white'
                        }`}
                        aria-label={emoji}
                        aria-pressed={selected}
                      >
                        {emoji}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Optional Note */}
              <div className="space-y-1.5">
                <label
                  htmlFor="pref-food-note"
                  className="block text-xs font-semibold text-[#1f2e28]"
                >
                  {copy.foodNoteLabel}
                </label>
                <input
                  id="pref-food-note"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder={copy.foodNotePlaceholder}
                  className="w-full h-10 rounded-xl border border-[#e9e4d8] bg-white px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#2f9e7e]"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 py-3.5 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#e9e4d8] bg-white text-xs font-semibold text-[#4c5e56] hover:bg-[#f7f1e5] min-h-[40px]"
              >
                {copy.cancelBtn}
              </button>
              <button
                type="submit"
                disabled={!name.trim()}
                className={`btn-press px-5 py-2 rounded-xl disabled:opacity-45 text-white text-xs font-semibold inline-flex items-center gap-1.5 min-h-[40px] ${accent.submitBtn}`}
              >
                <Save className="w-3.5 h-3.5" />
                <span>{mode === 'edit' ? copy.saveChangesBtn : copy.saveBtn}</span>
              </button>
            </div>
          </motion.form>
        </div>
      )}
    </AnimatePresence>
  );
}
