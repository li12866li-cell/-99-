import React, { useMemo, useState } from 'react';
import { Sparkles, ChevronDown, Utensils, Activity, Droplets, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Pet } from '../types/pet.ts';

interface CareAdviceCardProps {
  pet: Pet | null;
  dietTotal: number;
}

export function CareAdviceCard({ pet, dietTotal }: CareAdviceCardProps) {
  const [expanded, setExpanded] = useState(false);

  const adviceData = useMemo(() => {
    if (!pet) {
      return {
        tag: '待选择宠物',
        summary: '请在上方选择或新增一只宠物，即可根据物种与当前体重生成今日专属呵护建议。',
        feedingFrequency: '完善宠物档案后自动计算每日分餐次数与干粮参考量',
        exerciseDuration: '完善物种与体重后推荐每日户外或室内活动时长',
        hydrationTarget: '通用参考：每日洁净饮水约 50–60 ml/kg',
        checkpoints: [
          '观察进食速度与食盆残留情况',
          '检查每日排便成型度与尿量变化',
          '坚持每周称重一次，持续跟踪体况趋势',
        ],
      };
    }

    const w = Number(pet.weight) || 0;
    const waterLow = w > 0 ? Math.round(w * 50) : 250;
    const waterHigh = w > 0 ? Math.round(w * 65) : 350;

    if (pet.species === 'dog') {
      if (w > 25) {
        return {
          tag: `狗狗 · ${w}kg · 关节呵护`,
          summary: `${pet.name} 当前体重 ${w}kg 属于大体型犬，注意今天的气温，建议减少户外剧烈奔跑，改在早晚阴凉时段慢走并分次补充适量水分。`,
          feedingFrequency: `每日 2 餐定时定量（早晚各一餐，饭后静休 45 分钟防胃扭转；参考干粮约 ${Math.round(w * 15)}–${Math.round(w * 18)}g/天）`,
          exerciseDuration: '每日 35–50 分钟低冲击慢走（分早晚 2 次，减少跳跃保护髋膝关节）',
          hydrationTarget: `目标饮水约 ${waterLow}–${waterHigh} ml/天（运动休息 10 分钟后少量多次饮水）`,
          checkpoints: [
            '监测静息呼吸频率与散步归来后的喘息恢复速度',
            '观察起身时后肢与髋/膝关节是否有僵硬或步态迟疑',
            '零食热量控制在全天摄入 10% 以内，避免加重关节负荷',
          ],
        };
      }
      if (w > 0 && w < 5) {
        return {
          tag: `狗狗 · ${w}kg · 轻巧护胃`,
          summary: `${pet.name} 当前体重 ${w}kg 较为轻巧，今天适合带它去公园短途散步 15–20 分钟，注意防风保暖并及时补充适量水分。`,
          feedingFrequency: `每日 3 餐少食多餐防低血糖（参考干粮约 ${Math.round(w * 24)}–${Math.round(w * 30)}g/天）`,
          exerciseDuration: '每日 15–25 分钟轻度散步 + 10 分钟室内嗅闻互动（避免高处跳落）',
          hydrationTarget: `目标饮水约 ${waterLow}–${waterHigh} ml/天（温差较大时提供常温洁净水）`,
          checkpoints: [
            '外出优先使用胸背带保护气管，留意耳尖与脚垫体温',
            '小型犬易积聚牙结石，建议每周检查牙龈与口腔气味',
            '留意餐前活力状态，避免空腹时间过长',
          ],
        };
      }
      return {
        tag: `狗狗 · ${w || '--'}kg · 活力户外`,
        summary: `${pet.name} 目前体重 ${w || '--'}kg 状态良好，今天适合带它去公园散步，补充适量水分。`,
        feedingFrequency: `每日 2 餐定时定量（早晚均衡喂食，参考干粮约 ${w > 0 ? `${Math.round(w * 18)}–${Math.round(w * 22)}g` : '按包装推荐'}/天）`,
        exerciseDuration: '每日 40–60 分钟活力散步与适度嗅闻奔跑（早晚分段更佳）',
        hydrationTarget: `目标饮水约 ${waterLow}–${waterHigh} ml/天（外出散步随身携带便携水杯）`,
        checkpoints: [
          '草地活动回家后检查脚垫擦伤及毛发中是否有草籽或寄生虫',
          '观察每日排便成型度与饮水后排尿清亮程度',
          '保持每周记录一次体重，维持理想体况',
        ],
      };
    }

    if (pet.species === 'cat') {
      if (w > 6) {
        return {
          tag: `猫咪 · ${w}kg · 控重互动`,
          summary: `${pet.name} 体重 ${w}kg 略偏重，注意今天的气温并避免室内闷热，建议用逗猫棒分两次陪玩 10 分钟消耗热量，同时多补充适量水分。`,
          feedingFrequency: `每日 3–4 餐定量分餐（建议搭配高水分主食罐头，干粮参考约 ${Math.round(w * 12)}–${Math.round(w * 15)}g/天）`,
          exerciseDuration: '每日 2 次 × 10–15 分钟逗猫棒模拟狩猎互动（循序渐进不伤关节）',
          hydrationTarget: `目标饮水约 ${Math.round(w * 48)}–${Math.round(w * 60)} ml/天（流动饮水机可提升饮水意愿）`,
          checkpoints: [
            '切忌突然断食，每周减重控制在体重 1%–2% 以内防脂肪肝',
            '每日清理猫砂时留意尿团大小与次数，预防下泌尿道异常',
            '每周轻触肋骨两侧确认体脂变化',
          ],
        };
      }
      return {
        tag: `猫咪 · ${w || '--'}kg · 居家舒缓`,
        summary: `${pet.name} 体重 ${w || '--'}kg 处于平稳区间，今天适合在室内窗边晒太阳、梳理浮毛，并及时更换洁净饮水补充适量水分。`,
        feedingFrequency: `每日 2–3 餐定时干湿搭配（参考干粮约 ${w > 0 ? `${Math.round(w * 15)}–${Math.round(w * 18)}g` : '按标准定量'}/天）`,
        exerciseDuration: '每日 20–30 分钟分次逗猫互动 + 猫爬架垂直攀爬（餐前互动更助消化）',
        hydrationTarget: `目标饮水约 ${waterLow}–${waterHigh} ml/天（远离猫砂盆多点摆放水碗）`,
        checkpoints: [
          '每日梳理被毛减少舔毛吞咽，配合化毛护理减少吐毛球',
          '利用放松晒太阳时段轻查眼周分泌物、耳道与牙龈色泽',
          '观察每日饮水与猫砂尿团规律，守护泌尿系统健康',
        ],
      };
    }

    return {
      tag: `爱宠 · ${w || '--'}kg`,
      summary: `${pet.name} 当前体重 ${w || '--'}kg，注意今天的气温变化，在温和环境下适度活动并及时补充适量水分。`,
      feedingFrequency: '每日 2 餐定时定量投喂，保持专属食材新鲜洁净',
      exerciseDuration: '每日 15–25 分钟安全温和活动与环境探索',
      hydrationTarget: `参考饮水约 ${waterLow}–${waterHigh} ml/天，每日早晚各换水一次`,
      checkpoints: [
        '留意静息呼吸节奏与毛发皮肤光泽度',
        '每日核对采食量与排泄形态是否规律稳定',
        '每周记录体重追踪细致健康趋势',
      ],
    };
  }, [pet]);

  return (
    <section className="wellness-card rounded-3xl overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((prev) => !prev)}
        aria-expanded={expanded}
        className="w-full p-5 text-left flex items-start gap-3.5 hover:bg-[#fffbf2]/75 transition-colors cursor-pointer"
      >
        <div className="w-10 h-10 rounded-2xl bg-[#e6f7f1] text-[#2f9e7e] flex items-center justify-center flex-shrink-0">
          <Sparkles className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0 space-y-1.5">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2 text-sm sm:text-base font-bold text-[#1f2e28]">
              <span>今日专属呵护建议</span>
              <span className="text-xs font-normal text-[#72847c]">· {adviceData.tag}</span>
            </div>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#2f9e7e] whitespace-nowrap">
              {expanded ? '收起详细监测' : '展开监测建议'}
              <motion.span
                animate={{ rotate: expanded ? 180 : 0 }}
                transition={{ duration: 0.22 }}
                className="inline-flex"
              >
                <ChevronDown className="w-4 h-4" />
              </motion.span>
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#4c5e56] leading-relaxed">{adviceData.summary}</p>
        </div>
      </button>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-4 border-t border-[#e9e4d8] bg-[#fffbf2]/75 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="bg-white rounded-2xl border border-[#e9e4d8] p-3.5 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1f2e28]">
                    <Utensils className="w-3.5 h-3.5 text-[#ea7d2b]" />
                    <span>推荐喂食频次</span>
                  </div>
                  <p className="text-xs text-[#4c5e56] leading-relaxed">{adviceData.feedingFrequency}</p>
                </div>

                <div className="bg-white rounded-2xl border border-[#e9e4d8] p-3.5 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1f2e28]">
                    <Activity className="w-3.5 h-3.5 text-[#2f9e7e]" />
                    <span>推荐运动时长</span>
                  </div>
                  <p className="text-xs text-[#4c5e56] leading-relaxed">{adviceData.exerciseDuration}</p>
                </div>

                <div className="bg-white rounded-2xl border border-[#e9e4d8] p-3.5 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1f2e28]">
                    <Droplets className="w-3.5 h-3.5 text-sky-600" />
                    <span>每日饮水目标</span>
                  </div>
                  <p className="text-xs text-[#4c5e56] leading-relaxed">{adviceData.hydrationTarget}</p>
                </div>
              </div>

              <div className="bg-white rounded-2xl border border-[#e9e4d8] p-3.5 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs font-semibold text-[#1f2e28]">今日健康指标监测清单</span>
                  {pet && (
                    <span className="text-xs text-[#72847c] font-mono tabular-nums">
                      今日已记：饮食 {dietTotal}g · 饮水 {pet.water || '0ml'} · 体重 {pet.weight || '--'}kg
                    </span>
                  )}
                </div>
                <ul className="space-y-1.5">
                  {adviceData.checkpoints.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-[#4c5e56] leading-relaxed">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#2f9e7e] flex-shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
