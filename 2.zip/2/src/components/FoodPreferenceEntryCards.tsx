import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { PetFoodPreferences } from '../services/localStore.ts';
import { FoodScanCopy, foodScanTranslations } from '../lib/foodScanI18n.ts';

export type InteractivePreferenceTab = 'likes' | 'dislikes' | 'allergies';

interface FoodPreferenceEntryCardsProps {
  prefs: PetFoodPreferences;
  activeTab: InteractivePreferenceTab | null;
  onSelectTab: (tab: InteractivePreferenceTab) => void;
  onAddFood?: (tab: InteractivePreferenceTab) => void;
  copy?: FoodScanCopy;
}

function CuteLovePuppySvg({ reduced }: { reduced: boolean }) {
  return (
    <svg
      viewBox="0 0 120 92"
      className="w-24 h-20 sm:w-28 sm:h-22 shrink-0 select-none overflow-visible"
      aria-hidden="true"
    >
      {/* Floating Hearts */}
      <motion.path
        d="M88 22 C88 18 93 16 95 20 C97 16 102 18 102 22 C102 27 95 31 95 31 C95 31 88 27 88 22 Z"
        fill="#f48ca3"
        animate={
          reduced
            ? undefined
            : { y: [0, -7, 0], scale: [0.92, 1.14, 0.92], opacity: [0.85, 1, 0.85] }
        }
        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.path
        d="M17 28 C17 25 21 23.5 22.5 26.5 C24 23.5 28 25 28 28 C28 31.5 22.5 34.5 22.5 34.5 C22.5 34.5 17 31.5 17 28 Z"
        fill="#ff8fa8"
        animate={
          reduced
            ? undefined
            : { y: [0, -5, 0], scale: [0.88, 1.1, 0.88], opacity: [0.7, 1, 0.7] }
        }
        transition={{ duration: 2.6, delay: 0.5, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Soft Shadow */}
      <ellipse cx="60" cy="83" rx="28" ry="5" fill="#2f9e7e" fillOpacity="0.12" />

      {/* Puppy Body + Wagging Tail */}
      <motion.g
        animate={reduced ? undefined : { y: [0, -2, 0] }}
        transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
      >
        {/* Tail */}
        <motion.path
          d="M82 65 Q96 54 92 43"
          fill="none"
          stroke="#e5a358"
          strokeWidth="6"
          strokeLinecap="round"
          style={{ transformOrigin: '82px 65px' }}
          animate={reduced ? undefined : { rotate: [-10, 16, -10] }}
          transition={{ duration: 0.75, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Body */}
        <ellipse cx="60" cy="68" rx="22" ry="14" fill="#f7c886" />
        <ellipse cx="60" cy="69" rx="13" ry="9" fill="#fff7e8" />

        {/* Front Paws */}
        <ellipse cx="48" cy="79" rx="6" ry="4" fill="#fbd8a4" />
        <ellipse cx="72" cy="79" rx="6" ry="4" fill="#fbd8a4" />

        {/* Head */}
        <g>
          {/* Left & Right Floppy Ears */}
          <motion.ellipse
            cx="37"
            cy="41"
            rx="8.5"
            ry="14"
            fill="#d99145"
            style={{ transformOrigin: '41px 32px' }}
            animate={reduced ? undefined : { rotate: [-4, 6, -4] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.ellipse
            cx="83"
            cy="41"
            rx="8.5"
            ry="14"
            fill="#d99145"
            style={{ transformOrigin: '79px 32px' }}
            animate={reduced ? undefined : { rotate: [4, -6, 4] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          />

          {/* Face Circle */}
          <circle cx="60" cy="40" r="21" fill="#fbd8a4" />
          {/* Cheeks */}
          <ellipse cx="46" cy="44" rx="4.2" ry="2.6" fill="#f48ca3" fillOpacity="0.55" />
          <ellipse cx="74" cy="44" rx="4.2" ry="2.6" fill="#f48ca3" fillOpacity="0.55" />

          {/* Happy Curved Eyes */}
          <path
            d="M47 37 Q51 33 55 37"
            fill="none"
            stroke="#2c241d"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <path
            d="M65 37 Q69 33 73 37"
            fill="none"
            stroke="#2c241d"
            strokeWidth="2.4"
            strokeLinecap="round"
          />

          {/* Muzzle & Nose & Happy Tongue */}
          <ellipse cx="60" cy="46" rx="8.5" ry="6.2" fill="#fff7e8" />
          <ellipse cx="60" cy="43.5" rx="3.4" ry="2.3" fill="#3a2a1e" />
          <path
            d="M55.5 47.5 Q60 51.5 64.5 47.5"
            fill="none"
            stroke="#3a2a1e"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path d="M58 49.5 Q60 55 62 49.5 Z" fill="#f48ca3" />
        </g>
      </motion.g>
    </svg>
  );
}

function CuteRefusePuppySvg({ reduced }: { reduced: boolean }) {
  return (
    <svg
      viewBox="0 0 120 92"
      className="w-24 h-20 sm:w-28 sm:h-22 shrink-0 select-none overflow-visible"
      aria-hidden="true"
    >
      {/* Soft Ground Shadow */}
      <ellipse cx="56" cy="83" rx="28" ry="5" fill="#ea7d2b" fillOpacity="0.12" />

      {/* Little Food Bowl Being Refused */}
      <g transform="translate(82, 64)">
        <path d="M2 10 L26 10 L23 18 L5 18 Z" fill="#ffb074" />
        <ellipse cx="14" cy="10" rx="12" ry="3.5" fill="#ffd9b8" />
        {/* Tiny refusal cross */}
        <motion.g
          animate={reduced ? undefined : { scale: [0.9, 1.08, 0.9], opacity: [0.75, 1, 0.75] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        >
          <circle cx="14" cy="-1" r="7" fill="#fff3e6" stroke="#ea7d2b" strokeWidth="1.5" />
          <path
            d="M11 -4 L17 2 M17 -4 L11 2"
            stroke="#ea7d2b"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </motion.g>
      </g>

      {/* Puppy Body */}
      <ellipse cx="52" cy="68" rx="20" ry="13.5" fill="#eec284" />
      <ellipse cx="52" cy="69" rx="11.5" ry="8.5" fill="#fff7e8" />
      <ellipse cx="42" cy="79" rx="5.5" ry="3.6" fill="#f7d39c" />
      <ellipse cx="62" cy="79" rx="5.5" ry="3.6" fill="#f7d39c" />

      {/* Head Shaking Side-to-Side */}
      <motion.g
        style={{ transformOrigin: '52px 54px' }}
        animate={
          reduced
            ? undefined
            : {
                rotate: [-7, 7, -7],
                x: [-2.5, 2.5, -2.5],
              }
        }
        transition={{ duration: 1.7, repeat: Infinity, ease: 'easeInOut' }}
      >
        <ellipse cx="30" cy="40" rx="8" ry="13.5" fill="#c98542" />
        <ellipse cx="74" cy="40" rx="8" ry="13.5" fill="#c98542" />
        <circle cx="52" cy="39" r="20" fill="#f7d39c" />

        {/* Furrowed Cute Brows + Squinted Refusing Eyes */}
        <path
          d="M40 34 L47 36.5 M64 34 L57 36.5"
          stroke="#4a3525"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <path
          d="M41 39 L47 41 L41 43"
          fill="none"
          stroke="#2c241d"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M63 39 L57 41 L63 43"
          fill="none"
          stroke="#2c241d"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Muzzle + Wavy Refusal Mouth */}
        <ellipse cx="52" cy="46.5" rx="8" ry="5.5" fill="#fff7e8" />
        <ellipse cx="52" cy="43.5" rx="3.2" ry="2.2" fill="#3a2a1e" />
        <path
          d="M47 48.5 Q49.5 46.5 52 48.5 Q54.5 50.5 57 48.5"
          fill="none"
          stroke="#3a2a1e"
          strokeWidth="1.7"
          strokeLinecap="round"
        />
      </motion.g>
    </svg>
  );
}

function AllergyAlertSvg({ reduced }: { reduced: boolean }) {
  return (
    <svg
      viewBox="0 0 120 92"
      className="w-24 h-20 sm:w-28 sm:h-22 shrink-0 select-none overflow-visible"
      aria-hidden="true"
    >
      {/* Gentle Pulsing Alert Rings */}
      <motion.circle
        cx="60"
        cy="47"
        r="28"
        fill="none"
        stroke="#f48ca3"
        strokeWidth="2"
        animate={
          reduced
            ? undefined
            : { scale: [0.92, 1.18, 0.92], opacity: [0.5, 0.08, 0.5] }
        }
        transition={{ duration: 2.3, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.circle
        cx="60"
        cy="47"
        r="21"
        fill="#fff0f4"
        stroke="#f48ca3"
        strokeOpacity="0.45"
        strokeWidth="1.5"
      />

      {/* Warning Triangle */}
      <motion.g
        style={{ transformOrigin: '60px 48px' }}
        animate={
          reduced
            ? undefined
            : { scale: [1, 1.05, 1], rotate: [0, -1.8, 1.8, 0] }
        }
        transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
      >
        <path
          d="M60 22 L87 67 Q89 71 84 71 L36 71 Q31 71 33 67 Z"
          fill="#f45b7c"
          stroke="#d9385a"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <path
          d="M60 28 L81 65 L39 65 Z"
          fill="#ff7a96"
          fillOpacity="0.35"
        />
        {/* Exclamation Mark */}
        <rect x="57.7" y="38" width="4.6" height="15" rx="2.3" fill="#ffffff" />
        <circle cx="60" cy="59.5" r="2.7" fill="#ffffff" />
      </motion.g>
    </svg>
  );
}

export function FoodPreferenceEntryCards({
  prefs,
  activeTab,
  onSelectTab,
  onAddFood,
  copy = foodScanTranslations.zh,
}: FoodPreferenceEntryCardsProps) {
  const prefersReducedMotion = Boolean(useReducedMotion());

  const cards: Array<{
    key: InteractivePreferenceTab;
    title: string;
    count: number;
    bgClass: string;
    borderClass: string;
    activeRingClass: string;
    titleColor: string;
    countColor: string;
    addBtnClass: string;
    renderArt: () => React.ReactNode;
  }> = [
    {
      key: 'likes',
      title: copy.categories.likes.title,
      count: prefs.likes?.length || 0,
      bgClass: 'bg-gradient-to-br from-[#e6f7f1]/90 via-white to-[#fff0f4]/60',
      borderClass: 'border-[#2f9e7e]/35 hover:border-[#2f9e7e]/65',
      activeRingClass: 'ring-2 ring-[#2f9e7e]/45 border-[#2f9e7e]',
      titleColor: 'text-[#1f5c4b]',
      countColor: 'text-[#2f9e7e]',
      addBtnClass:
        'bg-white hover:bg-[#e6f7f1] border-[#2f9e7e]/45 text-[#1f5c4b]',
      renderArt: () => <CuteLovePuppySvg reduced={prefersReducedMotion} />,
    },
    {
      key: 'dislikes',
      title: copy.categories.dislikes.title,
      count: prefs.dislikes?.length || 0,
      bgClass: 'bg-gradient-to-br from-[#fff3e6]/90 via-white to-[#fffbf2]',
      borderClass: 'border-[#ffb074]/55 hover:border-[#ea7d2b]/75',
      activeRingClass: 'ring-2 ring-[#ffb074]/60 border-[#ea7d2b]',
      titleColor: 'text-[#7c3b0b]',
      countColor: 'text-[#9a4d12]',
      addBtnClass:
        'bg-white hover:bg-[#fff3e6] border-[#ffb074]/70 text-[#9a4d12]',
      renderArt: () => <CuteRefusePuppySvg reduced={prefersReducedMotion} />,
    },
    {
      key: 'allergies',
      title: copy.categories.allergies.title,
      count: prefs.allergies?.length || 0,
      bgClass: 'bg-gradient-to-br from-[#fff0f4]/90 via-white to-[#fff5f7]',
      borderClass: 'border-[#f48ca3]/60 hover:border-[#d9385a]/75',
      activeRingClass: 'ring-2 ring-[#f48ca3]/65 border-[#d9385a]',
      titleColor: 'text-[#9c2341]',
      countColor: 'text-[#d9385a]',
      addBtnClass:
        'bg-white hover:bg-[#fff0f4] border-[#f48ca3]/65 text-[#9c2341]',
      renderArt: () => <AllergyAlertSvg reduced={prefersReducedMotion} />,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {cards.map((card) => {
        const isActive = activeTab === card.key;
        return (
          <motion.div
            key={card.key}
            role="button"
            tabIndex={0}
            onClick={() => onSelectTab(card.key)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelectTab(card.key);
              }
            }}
            whileHover={
              prefersReducedMotion
                ? undefined
                : { y: -5, scale: 1.015, transition: { duration: 0.22 } }
            }
            whileTap={prefersReducedMotion ? undefined : { scale: 0.99 }}
            aria-expanded={isActive}
            className={`group food-card-interactive relative rounded-3xl border p-4 sm:p-5 text-left flex flex-col items-center justify-between gap-2.5 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2f9e7e] ${
              card.bgClass
            } ${isActive ? card.activeRingClass : card.borderClass}`}
          >
            <div className="w-full flex items-center justify-center pt-1">
              {card.renderArt()}
            </div>

            <div className="w-full flex items-center justify-between gap-2 pt-1">
              <div className="min-w-0">
                <div className={`text-sm sm:text-base font-bold truncate ${card.titleColor}`}>
                  {card.title}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#72847c] tabular-nums mt-0.5">
                  <span className={`font-semibold ${card.countColor}`}>
                    {card.count} {copy.countUnit}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{isActive ? copy.clickCollapse : copy.clickExpand}</span>
                </div>
              </div>

              <span
                className={`w-8 h-8 rounded-full flex items-center justify-center bg-white/85 border border-[#e9e4d8] shrink-0 transition-transform duration-200 ${
                  isActive ? 'rotate-180 text-[#1f5c4b]' : 'text-[#72847c]'
                }`}
              >
                <ChevronDown className="w-4 h-4" />
              </span>
            </div>

            {onAddFood && (
              <div className="w-full pt-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddFood(card.key);
                  }}
                  className={`btn-press w-full py-2 px-3 rounded-xl border text-xs font-semibold inline-flex items-center justify-center transition-colors whitespace-nowrap ${card.addBtnClass}`}
                >
                  <span>{copy.addFoodBtn}</span>
                </button>
              </div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}

