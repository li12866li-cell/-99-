import React from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export interface ToastState {
  message: string;
  type: 'success' | 'error';
}

export function ToastBanner({ toast }: { toast: ToastState | null }) {
  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: 0.2 }}
          className="fixed top-5 left-1/2 -translate-x-1/2 z-[100] px-4 py-2.5 rounded-full bg-white shadow-lg border border-slate-200 flex items-center gap-2 max-w-[92vw]"
        >
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-[#2f7d71] flex-shrink-0" />
          )}
          <span className="text-xs sm:text-sm font-semibold text-slate-800 truncate">
            {toast.message}
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
