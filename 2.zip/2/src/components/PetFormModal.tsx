import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Pet, PetFormInput, PetGender, PetSpecies } from '../types/pet.ts';

interface PetFormModalProps {
  isOpen: boolean;
  editingPet: Pet | null;
  onClose: () => void;
  onSubmit: (data: PetFormInput, editingId?: string) => Promise<void>;
}

export function PetFormModal({ isOpen, editingPet, onClose, onSubmit }: PetFormModalProps) {
  const todayStr = new Date().toISOString().split('T')[0];
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState<PetFormInput>({
    name: '',
    species: 'dog',
    breed: '',
    gender: 'male',
    age: undefined,
    weight: undefined,
    isNeutered: false,
    companionStartDate: todayStr,
    water: '500ml',
    vaccineStatus: '',
  });

  useEffect(() => {
    if (!isOpen) return;
    if (editingPet) {
      setForm({
        name: editingPet.name,
        species: editingPet.species,
        breed: editingPet.breed || '',
        gender: editingPet.gender,
        age: editingPet.age,
        weight: editingPet.weight,
        isNeutered: editingPet.isNeutered,
        companionStartDate: editingPet.companionStartDate || todayStr,
        water: editingPet.water || '500ml',
        vaccineStatus: editingPet.vaccineStatus || '',
      });
    } else {
      setForm({
        name: '',
        species: 'dog',
        breed: '',
        gender: 'male',
        age: undefined,
        weight: undefined,
        isNeutered: false,
        companionStartDate: todayStr,
        water: '500ml',
        vaccineStatus: '',
      });
    }
  }, [isOpen, editingPet, todayStr]);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || submitting) return;
    setSubmitting(true);
    try {
      await onSubmit(
        {
          ...form,
          name: form.name.trim(),
          breed: form.breed?.trim() || '',
        },
        editingPet?.id
      );
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/45 backdrop-blur-xs"
          />
          <motion.form
            onSubmit={handleFormSubmit}
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.2 }}
            className="relative z-10 w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden max-h-[90vh] flex flex-col"
          >
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900">
                {editingPet ? `编辑宠物档案 · ${editingPet.name}` : '新增宠物档案'}
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">宠物名称 *</label>
                  <input
                    required
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="例如：金豆 / 糯米"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f7d71]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">品种</label>
                  <input
                    type="text"
                    value={form.breed || ''}
                    onChange={(e) => setForm({ ...form, breed: e.target.value })}
                    placeholder="例如：金毛寻回犬 / 英短"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f7d71]"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600">物种分类</label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { id: 'dog', label: '狗狗' },
                      { id: 'cat', label: '猫咪' },
                      { id: 'bunny', label: '兔子' },
                    ] as { id: PetSpecies; label: string }[]
                  ).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setForm({ ...form, species: item.id })}
                      className={`py-2 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                        form.species === item.id
                          ? 'bg-[#2f7d71] text-white border-[#2f7d71]'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">性别</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        { id: 'male', label: '公' },
                        { id: 'female', label: '母' },
                      ] as { id: PetGender; label: string }[]
                    ).map((g) => (
                      <button
                        key={g.id}
                        type="button"
                        onClick={() => setForm({ ...form, gender: g.id })}
                        className={`py-2 rounded-xl text-xs font-semibold border transition-colors ${
                          form.gender === g.id
                            ? 'bg-[#2f7d71] text-white border-[#2f7d71]'
                            : 'bg-slate-50 text-slate-600 border-slate-200'
                        }`}
                      >
                        {g.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">是否绝育</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { val: true, label: '已绝育' },
                      { val: false, label: '未绝育' },
                    ].map((n) => (
                      <button
                        key={String(n.val)}
                        type="button"
                        onClick={() => setForm({ ...form, isNeutered: n.val })}
                        className={`py-2 rounded-xl text-xs font-semibold border transition-colors ${
                          form.isNeutered === n.val
                            ? 'bg-[#2f7d71] text-white border-[#2f7d71]'
                            : 'bg-slate-50 text-slate-600 border-slate-200'
                        }`}
                      >
                        {n.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">年龄（岁）</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    value={form.age ?? ''}
                    onChange={(e) =>
                      setForm({ ...form, age: e.target.value ? Number(e.target.value) : undefined })
                    }
                    placeholder="2"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm tabular-nums focus:outline-none focus:border-[#2f7d71]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">体重（kg）</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={form.weight ?? ''}
                    onChange={(e) =>
                      setForm({ ...form, weight: e.target.value ? Number(e.target.value) : undefined })
                    }
                    placeholder="5.5"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm tabular-nums focus:outline-none focus:border-[#2f7d71]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">陪伴起始日</label>
                  <input
                    type="date"
                    max={todayStr}
                    value={form.companionStartDate || todayStr}
                    onChange={(e) => setForm({ ...form, companionStartDate: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#2f7d71]"
                  />
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-100 flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={!form.name.trim() || submitting}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#2f7d71] hover:bg-[#25645b] disabled:opacity-50 transition-colors"
              >
                {submitting ? '保存中...' : editingPet ? '保存修改' : '创建档案'}
              </button>
            </div>
          </motion.form>
        </div>
      )}
    </AnimatePresence>
  );
}
