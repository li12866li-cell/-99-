import React, { useEffect, useState } from 'react';
import {
  X,
  FileText,
  Download,
  Eye,
  Building2,
  Calendar,
  Pencil,
  Upload,
  Loader2,
  Save,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  MedicalAttachment,
  MedicalRecord,
  MedicalRecordCategory,
} from '../../types/medicalRecord.ts';
import { MedicalRecordsCopy } from '../../lib/medicalRecordsI18n.ts';
import { compressImage } from '../../lib/image.ts';

export function formatFileBytes(bytes: number): string {
  if (!bytes || bytes < 1024) return `${bytes || 0} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function getAttachmentTypeLabel(att: MedicalAttachment, copy: MedicalRecordsCopy): string {
  if (att.mimeType === 'application/pdf' || att.name.toLowerCase().endsWith('.pdf')) {
    return copy.fileTypePdf;
  }
  if (att.mimeType === 'image/png' || att.name.toLowerCase().endsWith('.png')) {
    return 'PNG';
  }
  if (
    att.mimeType === 'image/jpeg' ||
    att.name.toLowerCase().endsWith('.jpg') ||
    att.name.toLowerCase().endsWith('.jpeg')
  ) {
    return 'JPG';
  }
  return copy.fileTypeImage;
}

export function triggerMedicalAttachmentDownload(att: MedicalAttachment) {
  const a = document.createElement('a');
  a.href = att.dataUrl;
  a.download = att.name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('read failed'));
    reader.readAsDataURL(file);
  });
}

export async function processUploadedMedicalFiles(
  files: FileList | File[] | null,
  existingCount: number,
  copy: MedicalRecordsCopy,
  showToast: (msg: string, type?: 'success' | 'error') => void
): Promise<MedicalAttachment[]> {
  if (!files || files.length === 0) return [];
  const fileArray = Array.from(files);
  if (existingCount >= 6) {
    showToast(copy.fileLimitErrorCount, 'error');
    return [];
  }

  const remainingSlots = Math.max(0, 6 - existingCount);
  const added: MedicalAttachment[] = [];

  for (const file of fileArray) {
    if (added.length >= remainingSlots) {
      showToast(copy.fileLimitErrorCount, 'error');
      break;
    }
    const lowerName = file.name.toLowerCase();
    const isPdf = file.type === 'application/pdf' || lowerName.endsWith('.pdf');
    const isAllowedImage =
      file.type === 'image/jpeg' ||
      file.type === 'image/png' ||
      file.type.startsWith('image/') ||
      /\.(jpe?g|png)$/i.test(lowerName);

    if (!isPdf && !isAllowedImage) {
      showToast(copy.fileLimitErrorType(file.name), 'error');
      continue;
    }

    if (file.size > 8 * 1024 * 1024) {
      showToast(copy.fileLimitErrorSize(file.name), 'error');
      continue;
    }

    const dataUrl = isPdf
      ? await readFileAsDataUrl(file)
      : await compressImage(file, { maxDimension: 1400, quality: 0.85 });

    added.push({
      id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: file.name,
      mimeType: isPdf ? 'application/pdf' : file.type || 'image/jpeg',
      sizeBytes: file.size,
      dataUrl,
    });
  }

  return added;
}

interface DetailModalProps {
  record: MedicalRecord | null;
  petName: string;
  onClose: () => void;
  onEdit: (record: MedicalRecord) => void;
  onPreviewAttachment: (att: MedicalAttachment) => void;
  copy: MedicalRecordsCopy;
}

export function MedicalRecordDetailModal({
  record,
  petName,
  onClose,
  onEdit,
  onPreviewAttachment,
  copy,
}: DetailModalProps) {
  return (
    <AnimatePresence>
      {record && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.2 }}
            className="relative z-10 w-full max-w-2xl max-h-[88vh] bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs text-[#2f9e7e] font-semibold">
                  {petName} · {copy.detailModalTitle}
                </div>
                <h3 className="text-base sm:text-lg font-bold text-[#1f2e28] truncate mt-0.5">
                  {record.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-[#72847c] hover:bg-white min-h-[40px] min-w-[40px] flex items-center justify-center"
                aria-label={copy.closeBtn}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-4">
                <div>
                  <div className="text-[11px] text-[#72847c]">{copy.detailCheckupDate}</div>
                  <div className="text-sm font-semibold text-[#1f2e28] font-mono tabular-nums mt-0.5 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-[#2f9e7e]" />
                    <span>{record.date}</span>
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-[#72847c]">{copy.detailCategory}</div>
                  <div className="text-sm font-semibold text-[#1f5c4b] mt-0.5">
                    {copy.categories[record.category] || record.category}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-[#72847c]">{copy.detailHospital}</div>
                  <div className="text-sm font-semibold text-[#1f2e28] mt-0.5 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-[#72847c]" />
                    <span className="truncate">
                      {record.hospitalName || copy.detailHospitalEmpty}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="text-xs font-semibold text-[#4c5e56]">{copy.detailResults}</div>
                <div className="rounded-2xl border border-[#e9e4d8] bg-white p-4 text-sm text-[#1f2e28] whitespace-pre-wrap leading-relaxed">
                  {record.results || copy.detailResultsEmpty}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-[#4c5e56] tabular-nums">
                  {copy.detailAttachments} ({record.attachments.length})
                </div>
                {record.attachments.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-[#e9e4d8] bg-[#fffbf2]/60 p-4 text-xs text-[#72847c] text-center">
                    {copy.detailNoAttachments}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {record.attachments.map((att) => {
                      const isPdf = att.mimeType === 'application/pdf';
                      return (
                        <div
                          key={att.id}
                          className="flex items-center gap-3 p-2.5 rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/60"
                        >
                          {isPdf ? (
                            <div className="w-11 h-11 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center shrink-0">
                              <FileText className="w-5 h-5" />
                            </div>
                          ) : (
                            <img
                              src={att.dataUrl}
                              alt={att.name}
                              className="w-11 h-11 rounded-xl object-cover border border-[#e9e4d8] shrink-0 bg-white"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="text-xs font-semibold text-[#1f2e28] truncate">
                              {att.name}
                            </div>
                            <div className="text-[11px] text-[#72847c] tabular-nums">
                              {getAttachmentTypeLabel(att, copy)} · {formatFileBytes(att.sizeBytes)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => onPreviewAttachment(att)}
                            className="p-2 rounded-xl text-[#2f9e7e] hover:bg-white shrink-0 min-h-[36px] min-w-[36px] flex items-center justify-center"
                            title={copy.previewFileTooltip}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => triggerMedicalAttachmentDownload(att)}
                            className="p-2 rounded-xl text-[#4c5e56] hover:bg-white shrink-0 min-h-[36px] min-w-[36px] flex items-center justify-center"
                            title={copy.downloadBtn}
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => {
                  const target = record;
                  onClose();
                  onEdit(target);
                }}
                className="px-4 py-2 rounded-xl border border-[#2f9e7e]/45 bg-[#e6f7f1] hover:bg-[#d5f1e6] text-[#1f5c4b] text-xs font-semibold flex items-center gap-1.5 min-h-[40px]"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>{copy.editAction}</span>
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold min-h-[40px]"
              >
                {copy.closeBtn}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

interface EditModalProps {
  record: MedicalRecord | null;
  petName: string;
  onClose: () => void;
  onSave: (
    id: string,
    patch: Partial<Omit<MedicalRecord, 'id' | 'petId' | 'createdAt'>>
  ) => Promise<MedicalRecord>;
  onPreviewAttachment: (att: MedicalAttachment) => void;
  copy: MedicalRecordsCopy;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

const CATEGORY_ORDER: MedicalRecordCategory[] = [
  'lab',
  'imaging',
  'vaccine',
  'prescription',
  'checkup',
  'other',
];

export function MedicalRecordEditModal({
  record,
  petName,
  onClose,
  onSave,
  onPreviewAttachment,
  copy,
  showToast,
}: EditModalProps) {
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState<MedicalRecordCategory>('lab');
  const [hospitalName, setHospitalName] = useState('');
  const [results, setResults] = useState('');
  const [attachments, setAttachments] = useState<MedicalAttachment[]>([]);
  const [processingUpload, setProcessingUpload] = useState(false);
  const [saving, setSaving] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    if (record) {
      setTitle(record.title);
      setDate(record.date);
      setCategory(record.category);
      setHospitalName(record.hospitalName || '');
      setResults(record.results || '');
      setAttachments(record.attachments || []);
    }
  }, [record]);

  const handleFiles = async (files: FileList | File[] | null) => {
    if (!files || files.length === 0) return;
    setProcessingUpload(true);
    try {
      const added = await processUploadedMedicalFiles(files, attachments.length, copy, showToast);
      if (added.length > 0) {
        setAttachments((prev) => [...prev, ...added].slice(0, 6));
      }
    } catch {
      showToast(copy.fileReadError, 'error');
    } finally {
      setProcessingUpload(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!record) return;
    if (!title.trim()) {
      showToast(copy.errEnterTitle, 'error');
      return;
    }
    setSaving(true);
    try {
      await onSave(record.id, {
        title: title.trim(),
        date,
        category,
        hospitalName: hospitalName.trim(),
        results: results.trim(),
        attachments,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {record && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
          />
          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.2 }}
            className="relative z-10 w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-3">
              <div>
                <div className="text-xs text-[#2f9e7e] font-semibold">{petName}</div>
                <h3 className="text-base sm:text-lg font-bold text-[#1f2e28]">
                  {copy.editModalTitle}
                </h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-[#72847c] hover:bg-white min-h-[40px] min-w-[40px] flex items-center justify-center"
                aria-label={copy.cancelBtn}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-semibold text-[#1f2e28]">
                    {copy.titleLabel}
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-[#1f2e28]">
                    {copy.dateLabel}
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-semibold text-[#1f2e28]">
                    {copy.categoryLabel}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as MedicalRecordCategory)}
                    className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                  >
                    {CATEGORY_ORDER.map((catId) => (
                      <option key={catId} value={catId}>
                        {copy.categories[catId]}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-semibold text-[#1f2e28]">
                    {copy.hospitalLabel}
                  </label>
                  <input
                    type="text"
                    value={hospitalName}
                    onChange={(e) => setHospitalName(e.target.value)}
                    placeholder={copy.hospitalPlaceholder}
                    className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                  />
                </div>

                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-semibold text-[#1f2e28]">
                    {copy.resultsLabel}
                  </label>
                  <textarea
                    rows={3}
                    value={results}
                    onChange={(e) => setResults(e.target.value)}
                    placeholder={copy.resultsPlaceholder}
                    className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                  />
                </div>
              </div>

              {/* Drag-and-drop attachment editor */}
              <div className="space-y-2.5">
                <label
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                    handleFiles(e.dataTransfer.files);
                  }}
                  className={`flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border-2 border-dashed px-4 py-3.5 cursor-pointer transition-colors ${
                    isDragging
                      ? 'border-[#2f9e7e] bg-[#e6f7f1]/70'
                      : 'border-[#2f9e7e]/55 bg-[#faf4e8]/75 hover:border-[#2f9e7e]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-[#e6f7f1] text-[#2f9e7e] flex items-center justify-center shrink-0">
                      {processingUpload ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-[#1f2e28]">
                        {isDragging ? copy.dropZoneDragActive : copy.dropZoneTitle}
                      </div>
                      <div className="text-[11px] text-[#72847c]">{copy.dropZoneDesc}</div>
                    </div>
                  </div>
                  <span className="px-3 py-1.5 rounded-xl bg-white border border-[#e9e4d8] text-xs font-semibold text-[#1f5c4b] shrink-0">
                    {copy.browseFilesBtn}
                  </span>
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/*,application/pdf,.pdf"
                    className="hidden"
                    onChange={(e) => {
                      handleFiles(e.target.files);
                      e.target.value = '';
                    }}
                  />
                </label>

                {attachments.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {attachments.map((att) => {
                      const isPdf = att.mimeType === 'application/pdf';
                      return (
                        <div
                          key={att.id}
                          className="flex items-center gap-2.5 p-2 rounded-xl border border-[#e9e4d8] bg-[#fffbf2]"
                        >
                          {isPdf ? (
                            <div className="w-9 h-9 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center shrink-0">
                              <FileText className="w-4 h-4" />
                            </div>
                          ) : (
                            <img
                              src={att.dataUrl}
                              alt={att.name}
                              className="w-9 h-9 rounded-lg object-cover border border-[#e9e4d8] shrink-0 bg-white"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="text-xs font-semibold text-[#1f2e28] truncate">
                              {att.name}
                            </div>
                            <div className="text-[10px] text-[#72847c] tabular-nums">
                              {getAttachmentTypeLabel(att, copy)} · {formatFileBytes(att.sizeBytes)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => onPreviewAttachment(att)}
                            className="p-1.5 rounded-lg text-[#2f9e7e] hover:bg-white shrink-0"
                            title={copy.previewFileTooltip}
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setAttachments((prev) => prev.filter((item) => item.id !== att.id))
                            }
                            className="p-1.5 rounded-lg text-[#72847c] hover:text-rose-600 hover:bg-white shrink-0"
                            title={copy.removeFileTooltip}
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#e9e4d8] bg-white text-xs font-semibold text-[#4c5e56] min-h-[40px]"
              >
                {copy.cancelBtn}
              </button>
              <button
                type="submit"
                disabled={saving || processingUpload || !title.trim()}
                className="px-5 py-2 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 min-h-[40px]"
              >
                {saving ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Save className="w-3.5 h-3.5" />
                )}
                <span>{saving ? copy.savingBtn : copy.saveChangesBtn}</span>
              </button>
            </div>
          </motion.form>
        </div>
      )}
    </AnimatePresence>
  );
}
