import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Check } from 'lucide-react';
import { Pet } from '../../types/pet.ts';
import { MedicalRecordsCopy } from '../../lib/medicalRecordsI18n.ts';

interface PetDuoSelectorProps {
  pets: Pet[];
  activePet: Pet;
  recordCounts: Record<string, number>;
  onSelectPet: (pet: Pet | string) => void;
  copy: MedicalRecordsCopy;
}

function BellaGoldenMascot({ isSelected }: { isSelected: boolean }) {
  return (
    <svg
      viewBox="0 0 180 156"
      className={`w-24 h-22 sm:w-28 sm:h-24 select-none overflow-visible transition-transform duration-300 ${
        isSelected ? 'mascot-float' : ''
      }`}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="medBellaHeadGrad" cx="40%" cy="32%" r="68%">
          <stop offset="0%" stopColor="#fff7e2" />
          <stop offset="58%" stopColor="#ffe1a8" />
          <stop offset="100%" stopColor="#efb664" />
        </radialGradient>
        <radialGradient id="medBellaBodyGrad" cx="44%" cy="30%" r="72%">
          <stop offset="0%" stopColor="#fff8e8" />
          <stop offset="65%" stopColor="#ffe4b5" />
          <stop offset="100%" stopColor="#ebb15e" />
        </radialGradient>
        <linearGradient id="medBellaEarGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#eeb360" />
          <stop offset="100%" stopColor="#c98434" />
        </linearGradient>
      </defs>

      {/* Soft ground shadow */}
      <ellipse
        cx="90"
        cy="144"
        rx={isSelected ? '44' : '38'}
        ry="7"
        fill="#d8d2c3"
        opacity={isSelected ? '0.65' : '0.4'}
      />

      {/* Wagging Golden Tail */}
      <g className={isSelected ? 'mascot-dog-tail' : ''}>
        <path
          d="M120 119 C144 109, 152 86, 138 78"
          fill="none"
          stroke="#ebb15e"
          strokeWidth="12"
          strokeLinecap="round"
        />
        <path
          d="M122 117 C142 108, 149 89, 138 80"
          fill="none"
          stroke="#ffe5b4"
          strokeWidth="4.5"
          strokeLinecap="round"
          opacity="0.7"
        />
      </g>

      {/* Body */}
      <ellipse
        cx="90"
        cy="112"
        rx="36"
        ry="27"
        fill="url(#medBellaBodyGrad)"
        stroke="#c98434"
        strokeWidth="2.2"
      />
      {/* Fluffy Cream Chest */}
      <path
        d="M72 95 Q90 128 108 95 Q100 105 90 106 Q80 105 72 95 Z"
        fill="#fffaf0"
      />
      <ellipse cx="90" cy="116" rx="19" ry="15" fill="#fffaf0" />

      {/* Mint Medical Collar & Tag */}
      <path
        d="M62 91 Q90 102 118 91 Q115 99 90 104 Q65 99 62 91 Z"
        fill="#2f9e7e"
      />
      <circle
        cx="90"
        cy="102"
        r="5.2"
        fill="#ffb074"
        stroke="#ffffff"
        strokeWidth="1.6"
      />

      {/* Floppy Golden Ears */}
      <ellipse
        cx="50"
        cy="68"
        rx="12.5"
        ry="23"
        transform="rotate(14 50 68)"
        fill="url(#medBellaEarGrad)"
        stroke="#b8772b"
        strokeWidth="2.1"
      />
      <ellipse
        cx="130"
        cy="68"
        rx="12.5"
        ry="23"
        transform="rotate(-14 130 68)"
        fill="url(#medBellaEarGrad)"
        stroke="#b8772b"
        strokeWidth="2.1"
      />

      {/* Rounded 3D Head */}
      <ellipse
        cx="90"
        cy="66"
        rx="38"
        ry="31.5"
        fill="url(#medBellaHeadGrad)"
        stroke="#c98434"
        strokeWidth="2.2"
      />
      {/* Soft top highlight */}
      <ellipse cx="77" cy="46" rx="14" ry="6.5" fill="#ffffff" opacity="0.42" />

      {/* Cream Muzzle */}
      <ellipse cx="90" cy="77" rx="18" ry="12.5" fill="#fffaf0" />

      {/* Blinking Eyes */}
      <g className="pet-blink">
        <circle cx="74" cy="61" r="4.8" fill="#1f2e28" />
        <circle cx="72.3" cy="59.2" r="1.8" fill="#ffffff" />
        <circle cx="75.8" cy="62.5" r="0.8" fill="#ffffff" opacity="0.7" />
        <circle cx="106" cy="61" r="4.8" fill="#1f2e28" />
        <circle cx="104.3" cy="59.2" r="1.8" fill="#ffffff" />
        <circle cx="107.8" cy="62.5" r="0.8" fill="#ffffff" opacity="0.7" />
      </g>

      {/* Soft Rosy Cheeks */}
      <ellipse
        cx="61"
        cy="71"
        rx="5.8"
        ry="3.2"
        fill="#f48ca3"
        opacity={isSelected ? '0.78' : '0.45'}
      />
      <ellipse
        cx="119"
        cy="71"
        rx="5.8"
        ry="3.2"
        fill="#f48ca3"
        opacity={isSelected ? '0.78' : '0.45'}
      />

      {/* Nose & Smile */}
      <ellipse cx="90" cy="73" rx="5.4" ry="3.9" fill="#1f2e28" />
      <ellipse cx="88.5" cy="71.8" rx="1.6" ry="0.9" fill="#ffffff" opacity="0.55" />
      <path
        d="M84 80 Q87 84 90 79 Q93 84 96 80"
        fill="none"
        stroke="#4c5e56"
        strokeWidth="2"
        strokeLinecap="round"
      />
      {isSelected && (
        <path d="M86.5 82 Q90 89.5 93.5 82 Z" fill="#f48ca3" opacity="0.9" />
      )}

      {/* Front Paws */}
      <ellipse cx="71" cy="137" rx="9.5" ry="5.8" fill="#fffaf0" stroke="#c98434" strokeWidth="2" />
      <ellipse cx="109" cy="137" rx="9.5" ry="5.8" fill="#fffaf0" stroke="#c98434" strokeWidth="2" />
    </svg>
  );
}

function MochiCatMascot({ isSelected }: { isSelected: boolean }) {
  return (
    <svg
      viewBox="0 0 180 156"
      className={`w-24 h-22 sm:w-28 sm:h-24 select-none overflow-visible transition-transform duration-300 ${
        isSelected ? 'mascot-float' : ''
      }`}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="medMochiHeadGrad" cx="40%" cy="32%" r="68%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="58%" stopColor="#f3efe9" />
          <stop offset="100%" stopColor="#d8d1c7" />
        </radialGradient>
        <radialGradient id="medMochiBodyGrad" cx="44%" cy="32%" r="72%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="68%" stopColor="#f4f0ea" />
          <stop offset="100%" stopColor="#dad3c9" />
        </radialGradient>
      </defs>

      {/* Soft ground shadow */}
      <ellipse
        cx="90"
        cy="144"
        rx={isSelected ? '42' : '36'}
        ry="7"
        fill="#d8d2c3"
        opacity={isSelected ? '0.65' : '0.4'}
      />

      {/* Swaying Plush Cat Tail */}
      <g className={isSelected ? 'mascot-cat-tail' : ''}>
        <path
          d="M120 123 C148 119, 158 92, 144 80 C136 74, 129 83, 135 91 C141 99, 134 112, 118 114"
          fill="none"
          stroke="#d5cec4"
          strokeWidth="10.5"
          strokeLinecap="round"
        />
        <path
          d="M122 121 C145 117, 154 94, 144 83"
          fill="none"
          stroke="#ffffff"
          strokeWidth="3.5"
          strokeLinecap="round"
          opacity="0.65"
        />
      </g>

      {/* Rounded Cat Body */}
      <ellipse
        cx="90"
        cy="112"
        rx="34.5"
        ry="27.5"
        fill="url(#medMochiBodyGrad)"
        stroke="#b7afa4"
        strokeWidth="2.2"
      />
      <ellipse cx="90" cy="116" rx="20" ry="16" fill="#ffffff" />

      {/* Mint Collar & Bell */}
      <path
        d="M63 91 Q90 101 117 91 Q113 98 90 103 Q67 98 63 91 Z"
        fill="#2f9e7e"
      />
      <circle
        cx="90"
        cy="101"
        r="5"
        fill="#ffb074"
        stroke="#ffffff"
        strokeWidth="1.5"
      />

      {/* Wiggling Cat Ears */}
      <g className="mascot-ear-left">
        <polygon
          points="51,60 45,24 76,43"
          fill="#e7e1d8"
          stroke="#b7afa4"
          strokeWidth="2.2"
          strokeLinejoin="round"
        />
        <polygon points="55,53 51,32 69,44" fill="#f48ca3" opacity="0.72" />
      </g>
      <g className="mascot-ear-right">
        <polygon
          points="129,60 135,24 104,43"
          fill="#e7e1d8"
          stroke="#b7afa4"
          strokeWidth="2.2"
          strokeLinejoin="round"
        />
        <polygon points="125,53 129,32 111,44" fill="#f48ca3" opacity="0.72" />
      </g>

      {/* Chubby 3D Cat Head */}
      <ellipse
        cx="90"
        cy="68"
        rx="39"
        ry="31"
        fill="url(#medMochiHeadGrad)"
        stroke="#b7afa4"
        strokeWidth="2.2"
      />
      {/* Top shine & subtle forehead markings */}
      <ellipse cx="76" cy="49" rx="13" ry="6" fill="#ffffff" opacity="0.5" />
      <path
        d="M84 41 L84 48 M90 39 L90 49 M96 41 L96 48"
        stroke="#c5bdb2"
        strokeWidth="2.2"
        strokeLinecap="round"
      />

      {/* Blinking Cat Eyes */}
      <g className="pet-blink">
        <ellipse cx="73" cy="67" rx="4.6" ry="5.5" fill="#1f2e28" />
        <circle cx="71.4" cy="64.8" r="1.8" fill="#ffffff" />
        <ellipse cx="107" cy="67" rx="4.6" ry="5.5" fill="#1f2e28" />
        <circle cx="105.4" cy="64.8" r="1.8" fill="#ffffff" />
      </g>

      {/* Blush */}
      <ellipse
        cx="61"
        cy="75"
        rx="5.8"
        ry="3.2"
        fill="#f48ca3"
        opacity={isSelected ? '0.8' : '0.45'}
      />
      <ellipse
        cx="119"
        cy="75"
        rx="5.8"
        ry="3.2"
        fill="#f48ca3"
        opacity={isSelected ? '0.8' : '0.45'}
      />

      {/* Pink Nose & Mouth */}
      <polygon points="87,73 93,73 90,77" fill="#f48ca3" />
      <path
        d="M83 80 Q86.5 84 90 79 Q93.5 84 97 80"
        fill="none"
        stroke="#4c5e56"
        strokeWidth="2"
        strokeLinecap="round"
      />

      {/* Whiskers */}
      <path
        d="M44 70 L58 72 M43 77 L58 77 M122 72 L136 70 M122 77 L137 77"
        stroke="#b7afa4"
        strokeWidth="1.8"
        strokeLinecap="round"
      />

      {/* Front Paws */}
      <ellipse cx="72" cy="137" rx="8.8" ry="5.5" fill="#ffffff" stroke="#b7afa4" strokeWidth="2" />
      <ellipse cx="108" cy="137" rx="8.8" ry="5.5" fill="#ffffff" stroke="#b7afa4" strokeWidth="2" />
    </svg>
  );
}

export function PetDuoSelector({
  pets,
  activePet,
  recordCounts,
  onSelectPet,
  copy,
}: PetDuoSelectorProps) {
  const prefersReducedMotion = useReducedMotion();

  // Prioritize Bella and Mochi side-by-side; fall back gracefully if custom names/pets exist
  const bellaPet =
    pets.find((p) => p.id === 'pet_demo_bella' || p.name.toLowerCase() === 'bella') ||
    pets.find((p) => p.species === 'dog') ||
    pets[0];

  const mochiPet =
    pets.find(
      (p) =>
        p.id !== bellaPet?.id &&
        (p.id === 'pet_demo_mochi' || p.name.toLowerCase() === 'mochi')
    ) ||
    pets.find((p) => p.id !== bellaPet?.id && p.species === 'cat') ||
    pets.find((p) => p.id !== bellaPet?.id);

  const duoPets = [bellaPet, mochiPet].filter((p): p is Pet => Boolean(p));
  const extraPets = pets.filter((p) => !duoPets.some((d) => d.id === p.id));

  return (
    <section className="space-y-3" aria-label={copy.choosePetHint}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {duoPets.map((pet) => {
          const isSelected = pet.id === activePet.id;
          const isCat = pet.species === 'cat';
          const count = recordCounts[pet.id] ?? 0;
          const speciesText = isCat
            ? copy.catLabel
            : pet.species === 'dog'
            ? copy.dogLabel
            : copy.otherPetLabel;

          return (
            <motion.button
              key={pet.id}
              type="button"
              onClick={() => onSelectPet(pet)}
              whileHover={prefersReducedMotion ? undefined : { y: -2 }}
              whileTap={prefersReducedMotion ? undefined : { scale: 0.99 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              aria-pressed={isSelected}
              className={`relative text-left rounded-3xl px-4 py-3 sm:px-5 sm:py-3.5 transition-all cursor-pointer flex items-center gap-3.5 sm:gap-4 min-h-[112px] ${
                isSelected
                  ? 'bg-[#e6f7f1] border-2 border-[#2f9e7e] shadow-[0_10px_24px_-10px_rgba(47,158,126,0.28)] opacity-100'
                  : 'bg-white/85 border border-[#e9e4d8] opacity-75 hover:opacity-100 hover:border-[#2f9e7e]/45 shadow-xs'
              }`}
            >
              {/* Animated Mascot Container */}
              <div className="shrink-0 flex items-center justify-center">
                {isCat ? (
                  <MochiCatMascot isSelected={isSelected} />
                ) : (
                  <BellaGoldenMascot isSelected={isSelected} />
                )}
              </div>

              {/* Pet Name & Clean Unboxed Metadata */}
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <h2
                    className={`text-base sm:text-lg font-bold tracking-tight truncate ${
                      isSelected ? 'text-[#1f5c4b]' : 'text-[#1f2e28]'
                    }`}
                  >
                    {pet.name}
                  </h2>

                  {isSelected ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#1f5c4b] whitespace-nowrap shrink-0">
                      <Check className="w-3.5 h-3.5 text-[#2f9e7e]" />
                      {copy.selectedLabel}
                    </span>
                  ) : (
                    <span className="text-xs font-medium text-[#72847c] whitespace-nowrap shrink-0">
                      {copy.clickToSwitch}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5 flex-wrap text-xs text-[#4c5e56]">
                  <span>{pet.breed || speciesText}</span>
                  {typeof pet.age === 'number' && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        {pet.age} {copy.yearsOld}
                      </span>
                    </>
                  )}
                </div>

                <div className="text-xs font-medium text-[#2f9e7e] tabular-nums">
                  {count} {copy.recordsCountUnit}
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Fallback strip only if user created more than 2 pets */}
      {extraPets.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap pt-0.5">
          <span className="text-xs text-[#72847c]">{copy.morePetsLabel}:</span>
          {extraPets.map((pet) => {
            const active = pet.id === activePet.id;
            return (
              <button
                key={pet.id}
                type="button"
                onClick={() => onSelectPet(pet)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors min-h-[36px] whitespace-nowrap ${
                  active
                    ? 'bg-[#e6f7f1] border-[#2f9e7e] text-[#1f5c4b]'
                    : 'bg-white border-[#e9e4d8] text-[#4c5e56] hover:border-[#2f9e7e]/50'
                }`}
              >
                {pet.name} ({recordCounts[pet.id] ?? 0})
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
