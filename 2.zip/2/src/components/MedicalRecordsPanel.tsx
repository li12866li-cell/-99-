import React, { useEffect, useMemo, useState } from 'react';
import {
  FileText,
  Upload,
  Calendar,
  Building2,
  ClipboardCheck,
  Save,
  Trash2,
  Eye,
  X,
  Search,
  Image as ImageIcon,
  FileCheck2,
  Download,
  Loader2,
  PawPrint,
  Pencil,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { HealthRecord, Pet } from '../types/pet.ts';
import { Reminder } from '../types/reminder.ts';
import {
  MedicalAttachment,
  MedicalRecord,
  MedicalRecordCategory,
} from '../types/medicalRecord.ts';
import { useMedicalRecords } from '../hooks/useMedicalRecords.ts';
import { localStore } from '../services/localStore.ts';
import { Language } from '../lib/i18n.ts';
import { medicalRecordsTranslations } from '../lib/medicalRecordsI18n.ts';
import { MedicalReportExportModal } from './MedicalReportExportModal.tsx';
import { WeeklyReportModal } from './WeeklyReportModal.tsx';
import { PawLoader } from './PawLoader.tsx';
import { PetDuoSelector } from './medical/PetDuoSelector.tsx';
import {
  formatFileBytes,
  getAttachmentTypeLabel,
  MedicalRecordDetailModal,
  MedicalRecordEditModal,
  processUploadedMedicalFiles,
  triggerMedicalAttachmentDownload,
} from './medical/MedicalRecordModals.tsx';

interface MedicalRecordsPanelProps {
  pets: Pet[];
  selectedPet: Pet | null;
  onSelectPet?: (pet: Pet | string) => void;
  healthRecords?: HealthRecord[];
  reminders?: Reminder[];
  showToast: (msg: string, type?: 'success' | 'error') => void;
  lang?: Language;
  weeklyModalOpen?: boolean;
  onWeeklyModalOpenChange?: (open: boolean) => void;
  exportModalOpen?: boolean;
  onExportModalOpenChange?: (open: boolean) => void;
}

const CATEGORY_ORDER: MedicalRecordCategory[] = [
  'lab',
  'imaging',
  'vaccine',
  'prescription',
  'checkup',
  'other',
];

export function MedicalRecordsPanel({
  pets,
  selectedPet,
  onSelectPet,
  healthRecords = [],
  reminders = [],
  showToast,
  lang = 'zh',
  weeklyModalOpen: controlledWeeklyOpen,
  onWeeklyModalOpenChange,
  exportModalOpen: controlledExportOpen,
  onExportModalOpenChange,
}: MedicalRecordsPanelProps) {
  const prefersReducedMotion = useReducedMotion();
  const copy = medicalRecordsTranslations[lang] || medicalRecordsTranslations.zh;
  const activePet = selectedPet || pets[0] || null;

  const {
    medicalRecords,
    loading,
    addMedicalRecord,
    updateMedicalRecord,
    deleteMedicalRecord,
  } = useMedicalRecords('default_pet_owner', activePet?.id, showToast);

  const todayStr = new Date().toISOString().split('T')[0];

  // Form state (Sections A, B, C, D)
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(todayStr);
  const [hospitalName, setHospitalName] = useState('');
  const [category, setCategory] = useState<MedicalRecordCategory>('lab');
  const [results, setResults] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<MedicalAttachment[]>([]);
  const [processingUpload, setProcessingUpload] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [saving, setSaving] = useState(false);

  // History list filters & modals
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | MedicalRecordCategory>('all');
  const [previewAttachment, setPreviewAttachment] = useState<MedicalAttachment | null>(null);
  const [detailRecord, setDetailRecord] = useState<MedicalRecord | null>(null);
  const [editingRecord, setEditingRecord] = useState<MedicalRecord | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [internalExportOpen, setInternalExportOpen] = useState(false);
  const [internalWeeklyOpen, setInternalWeeklyOpen] = useState(false);

  const exportModalOpen = controlledExportOpen ?? internalExportOpen;
  const setExportModalOpen = onExportModalOpenChange ?? setInternalExportOpen;
  const weeklyModalOpen = controlledWeeklyOpen ?? internalWeeklyOpen;
  const setWeeklyModalOpen = onWeeklyModalOpenChange ?? setInternalWeeklyOpen;

  // Reset transient draft & open modals when switching between Bella & Mochi so records never mix
  useEffect(() => {
    setTitle('');
    setDate(new Date().toISOString().split('T')[0]);
    setHospitalName('');
    setCategory('lab');
    setResults('');
    setPendingAttachments([]);
    setDetailRecord(null);
    setEditingRecord(null);
    setConfirmDeleteId(null);
    setPreviewAttachment(null);
  }, [activePet?.id]);

  // Compute independent record counts per pet from localStore
  const recordCountsByPet = useMemo(() => {
    const all = localStore.listMedicalRecords();
    const counts: Record<string, number> = {};
    for (const p of pets) {
      counts[p.id] = 0;
    }
    for (const rec of all) {
      counts[rec.petId] = (counts[rec.petId] || 0) + 1;
    }
    return counts;
  }, [pets, medicalRecords]);

  const symptomHistory = useMemo(
    () => (activePet ? localStore.listSymptomHistory(activePet.id) : []),
    [activePet, weeklyModalOpen]
  );

  const handleFilesSelected = async (files: FileList | File[] | null) => {
    if (!files || files.length === 0) return;
    setProcessingUpload(true);
    try {
      const added = await processUploadedMedicalFiles(
        files,
        pendingAttachments.length,
        copy,
        showToast
      );
      if (added.length > 0) {
        setPendingAttachments((prev) => [...prev, ...added].slice(0, 6));
        if (!title.trim() && added[0]?.name) {
          const baseName = added[0].name.replace(/\.[^/.]+$/, '');
          setTitle(baseName);
        }
      }
    } catch {
      showToast(copy.fileReadError, 'error');
    } finally {
      setProcessingUpload(false);
    }
  };

  const handleSaveRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePet) {
      showToast(copy.errSelectPet, 'error');
      return;
    }
    if (!title.trim()) {
      showToast(copy.errEnterTitle, 'error');
      return;
    }

    setSaving(true);
    try {
      await addMedicalRecord({
        petId: activePet.id,
        title: title.trim(),
        date: date || todayStr,
        hospitalName: hospitalName.trim(),
        category,
        results: results.trim(),
        attachments: pendingAttachments,
      });
      setTitle('');
      setHospitalName('');
      setResults('');
      setPendingAttachments([]);
      setDate(todayStr);
    } finally {
      setSaving(false);
    }
  };

  const filteredRecords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return medicalRecords.filter((rec) => {
      if (categoryFilter !== 'all' && rec.category !== categoryFilter) return false;
      if (!q) return true;
      return (
        rec.title.toLowerCase().includes(q) ||
        rec.hospitalName.toLowerCase().includes(q) ||
        rec.results.toLowerCase().includes(q) ||
        rec.attachments.some((a) => a.name.toLowerCase().includes(q))
      );
    });
  }, [medicalRecords, categoryFilter, searchQuery]);

  if (!activePet) {
    return (
      <div className="wellness-card rounded-3xl p-10 text-center space-y-2">
        <PawPrint className="w-8 h-8 text-[#72847c] mx-auto" />
        <p className="text-sm font-semibold text-[#1f2e28]">{copy.noPetTitle}</p>
        <p className="text-xs text-[#72847c]">{copy.noPetDesc}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Section 2: Dual Pet Selector with Bella & Mochi Animated Mascots */}
      <PetDuoSelector
        pets={pets}
        activePet={activePet}
        recordCounts={recordCountsByPet}
        onSelectPet={(pet) => onSelectPet?.(pet)}
        copy={copy}
      />

      {/* Active Pet Workspace with Smooth Transition */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activePet.id}
          initial={prefersReducedMotion ? false : { opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={prefersReducedMotion ? undefined : { opacity: 0, y: -6 }}
          transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          className="space-y-6"
        >
          {/* Section 3: Medical Checkup Record Form (Grouped A / B / C / D) */}
          <form onSubmit={handleSaveRecord} className="wellness-card rounded-3xl overflow-hidden">
            <div className="px-5 py-3.5 bg-[#fffbf2] border-b border-[#e9e4d8] flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ClipboardCheck className="w-4 h-4 text-[#2f9e7e]" />
                <h2 className="font-bold text-sm sm:text-base text-[#1f2e28]">
                  {copy.formTitle} · {activePet.name}
                </h2>
              </div>
              <span className="text-[11px] text-[#72847c] tabular-nums">{copy.formLimitNote}</span>
            </div>

            <div className="p-5 sm:p-6 space-y-6">
              {/* Group A: 检查基本信息 */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-[#1f5c4b] tracking-wide">
                  {copy.sectionATitle}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-6 space-y-1.5">
                    <label
                      htmlFor="med-title"
                      className="block text-xs font-semibold text-[#1f2e28]"
                    >
                      {copy.titleLabel}
                    </label>
                    <input
                      id="med-title"
                      type="text"
                      required
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder={copy.titlePlaceholder}
                      className="w-full h-11 rounded-xl border border-[#e9e4d8] bg-white px-3.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                    />
                  </div>

                  <div className="md:col-span-3 space-y-1.5">
                    <label
                      htmlFor="med-date"
                      className="block text-xs font-semibold text-[#1f2e28]"
                    >
                      {copy.dateLabel}
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 text-[#72847c] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="med-date"
                        type="date"
                        required
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full h-11 rounded-xl border border-[#e9e4d8] bg-white pl-9 pr-3 text-sm tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-3 space-y-1.5">
                    <label
                      htmlFor="med-category"
                      className="block text-xs font-semibold text-[#1f2e28]"
                    >
                      {copy.categoryLabel}
                    </label>
                    <select
                      id="med-category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value as MedicalRecordCategory)}
                      className="w-full h-11 rounded-xl border border-[#e9e4d8] bg-white px-3 text-sm focus:outline-none focus:border-[#2f9e7e]"
                    >
                      {CATEGORY_ORDER.map((catId) => (
                        <option key={catId} value={catId}>
                          {copy.categories[catId]}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="border-t border-[#e9e4d8]/80" />

              {/* Group B: 医疗信息 */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-[#1f5c4b] tracking-wide">
                  {copy.sectionBTitle}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-5 space-y-1.5">
                    <label
                      htmlFor="med-hospital"
                      className="block text-xs font-semibold text-[#1f2e28]"
                    >
                      {copy.hospitalLabel}
                    </label>
                    <div className="relative">
                      <Building2 className="w-4 h-4 text-[#72847c] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        id="med-hospital"
                        type="text"
                        value={hospitalName}
                        onChange={(e) => setHospitalName(e.target.value)}
                        placeholder={copy.hospitalPlaceholder}
                        className="w-full h-11 rounded-xl border border-[#e9e4d8] bg-white pl-9 pr-3.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-7 space-y-1.5">
                    <label
                      htmlFor="med-results"
                      className="block text-xs font-semibold text-[#1f2e28]"
                    >
                      {copy.resultsLabel}
                    </label>
                    <textarea
                      id="med-results"
                      rows={3}
                      value={results}
                      onChange={(e) => setResults(e.target.value)}
                      placeholder={copy.resultsPlaceholder}
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
                    />
                  </div>
                </div>
              </div>

              <div className="border-t border-[#e9e4d8]/80" />

              {/* Group C: 检查报告上传 (Light Beige + Green Dashed Drag & Drop Zone) */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-[#1f5c4b] tracking-wide">
                  {copy.sectionCTitle}
                </h3>

                <label
                  onDragEnter={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                  }}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                    handleFilesSelected(e.dataTransfer.files);
                  }}
                  className={`flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border-2 border-dashed px-5 py-5 cursor-pointer transition-colors ${
                    isDragging
                      ? 'border-[#2f9e7e] bg-[#e6f7f1]/70'
                      : 'border-[#2f9e7e]/60 bg-[#faf4e8]/80 hover:border-[#2f9e7e] hover:bg-[#faf4e8]'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-11 h-11 rounded-2xl bg-[#e6f7f1] text-[#2f9e7e] flex items-center justify-center shrink-0">
                      {processingUpload ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Upload className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#1f2e28]">
                        {isDragging ? copy.dropZoneDragActive : copy.dropZoneTitle}
                      </div>
                      <div className="text-xs text-[#72847c] mt-0.5">{copy.dropZoneDesc}</div>
                    </div>
                  </div>
                  <span className="px-4 py-2 rounded-xl bg-white border border-[#2f9e7e]/35 text-xs font-semibold text-[#1f5c4b] shrink-0 whitespace-nowrap shadow-xs">
                    {copy.browseFilesBtn}
                  </span>
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/*,application/pdf,.pdf"
                    className="hidden"
                    onChange={(e) => {
                      handleFilesSelected(e.target.files);
                      e.target.value = '';
                    }}
                  />
                </label>

                {pendingAttachments.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {pendingAttachments.map((att) => {
                      const isPdf = att.mimeType === 'application/pdf';
                      return (
                        <div
                          key={att.id}
                          className="flex items-center gap-3 p-2.5 rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]"
                        >
                          {isPdf ? (
                            <div className="w-11 h-11 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center shrink-0">
                              <FileText className="w-5 h-5" />
                            </div>
                          ) : (
                            <img
                              src={att.dataUrl}
                              alt={att.name}
                              className="w-11 h-11 rounded-xl object-cover border border-[#e9e4d8] shrink-0 bg-white"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <div className="text-xs font-semibold text-[#1f2e28] truncate">
                              {att.name}
                            </div>
                            <div className="text-[11px] text-[#72847c] tabular-nums">
                              {getAttachmentTypeLabel(att, copy)} · {formatFileBytes(att.sizeBytes)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => setPreviewAttachment(att)}
                            className="p-1.5 rounded-lg text-[#2f9e7e] hover:bg-white shrink-0"
                            title={copy.previewFileTooltip}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setPendingAttachments((prev) =>
                                prev.filter((item) => item.id !== att.id)
                              )
                            }
                            className="p-1.5 rounded-lg text-[#72847c] hover:text-rose-600 hover:bg-white shrink-0"
                            title={copy.removeFileTooltip}
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Group D: 保存医疗记录按钮 */}
              <div className="flex items-center justify-end pt-1">
                <motion.button
                  type="submit"
                  disabled={saving || processingUpload || !title.trim()}
                  whileHover={prefersReducedMotion ? undefined : { y: -1, scale: 1.01 }}
                  whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
                  transition={{ duration: 0.16 }}
                  className="px-6 py-2.5 min-h-[44px] rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-50 text-white text-sm font-semibold flex items-center gap-2 transition-colors shadow-xs cursor-pointer whitespace-nowrap"
                >
                  {saving ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  <span>{saving ? copy.savingBtn : copy.saveBtn}</span>
                </motion.button>
              </div>
            </div>
          </form>

          {/* Section 4: Historical Medical Records for Active Pet */}
          <section className="wellness-card rounded-3xl p-5 sm:p-6 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-[#2f9e7e]" />
                <h2 className="font-bold text-base text-[#1f2e28] tabular-nums">
                  {activePet.name} · {copy.historyTitle} ({filteredRecords.length})
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-[#72847c] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={copy.searchPlaceholder}
                    className="rounded-xl border border-[#e9e4d8] bg-[#fffbf2] pl-8 pr-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e] w-56"
                  />
                </div>

                <div className="flex items-center gap-1 overflow-x-auto">
                  <button
                    type="button"
                    onClick={() => setCategoryFilter('all')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      categoryFilter === 'all'
                        ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold'
                        : 'text-[#72847c] hover:bg-[#fffbf2]'
                    }`}
                  >
                    {copy.filterAll}
                  </button>
                  {CATEGORY_ORDER.slice(0, 5).map((catId) => (
                    <button
                      key={catId}
                      type="button"
                      onClick={() => setCategoryFilter(catId)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                        categoryFilter === catId
                          ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold'
                          : 'text-[#72847c] hover:bg-[#fffbf2]'
                      }`}
                    >
                      {copy.categories[catId]}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {loading ? (
              <PawLoader label={copy.loadingHistory} />
            ) : filteredRecords.length === 0 ? (
              <div className="py-10 text-center rounded-2xl border border-dashed border-[#e9e4d8] bg-[#fffbf2] text-xs text-[#72847c]">
                {copy.emptyHistory}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredRecords.map((rec: MedicalRecord) => {
                  const catLabel = copy.categories[rec.category] || rec.category;
                  const isConfirmingDelete = confirmDeleteId === rec.id;

                  return (
                    <article
                      key={rec.id}
                      onClick={() => setDetailRecord(rec)}
                      className="rounded-2xl border border-[#e9e4d8] bg-white p-4 space-y-3 hover:border-[#2f9e7e]/55 hover:shadow-xs transition-all cursor-pointer"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap text-xs text-[#72847c]">
                            <span className="font-mono tabular-nums font-semibold text-[#1f5c4b]">
                              {rec.date}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-medium text-[#2f9e7e]">{catLabel}</span>
                            {rec.hospitalName && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="inline-flex items-center gap-1 text-[#4c5e56]">
                                  <Building2 className="w-3 h-3" />
                                  {rec.hospitalName}
                                </span>
                              </>
                            )}
                            {rec.attachments.length > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="tabular-nums text-[#4c5e56]">
                                  {copy.attachmentsCount(rec.attachments.length)}
                                </span>
                              </>
                            )}
                          </div>
                          <h3 className="text-sm sm:text-base font-bold text-[#1f2e28]">
                            {rec.title}
                          </h3>
                        </div>

                        {/* Record Actions: View / Edit / Delete */}
                        <div
                          className="flex items-center gap-1.5 shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() => setDetailRecord(rec)}
                            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-[#1f5c4b] bg-[#e6f7f1]/70 hover:bg-[#e6f7f1] flex items-center gap-1 whitespace-nowrap min-h-[34px]"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{copy.viewAction}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setEditingRecord(rec)}
                            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-[#4c5e56] bg-[#fffbf2] border border-[#e9e4d8] hover:border-[#2f9e7e]/50 flex items-center gap-1 whitespace-nowrap min-h-[34px]"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>{copy.editAction}</span>
                          </button>

                          {isConfirmingDelete ? (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  deleteMedicalRecord(rec.id);
                                  setConfirmDeleteId(null);
                                }}
                                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 whitespace-nowrap min-h-[34px]"
                              >
                                {copy.confirmDeleteBtn}
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(null)}
                                className="px-2 py-1.5 rounded-xl text-xs font-medium text-[#72847c] hover:bg-[#fffbf2] whitespace-nowrap min-h-[34px]"
                              >
                                {copy.cancelDeleteBtn}
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(rec.id)}
                              className="p-2 rounded-xl text-[#72847c] hover:text-rose-600 hover:bg-rose-50 min-h-[34px] min-w-[34px] flex items-center justify-center"
                              title={copy.deleteAction}
                              aria-label={copy.deleteAction}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {rec.results && (
                        <div className="rounded-xl bg-[#fffbf2] border border-[#e9e4d8]/80 px-3.5 py-2.5 text-xs sm:text-sm text-[#1f2e28] whitespace-pre-wrap leading-relaxed line-clamp-3">
                          {rec.results}
                        </div>
                      )}

                      {rec.attachments.length > 0 && (
                        <div
                          className="flex flex-wrap gap-2.5 pt-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {rec.attachments.map((att) => {
                            const isPdf = att.mimeType === 'application/pdf';
                            return (
                              <div
                                key={att.id}
                                className="flex items-center gap-2.5 p-2 rounded-xl border border-[#e9e4d8] bg-[#fffbf2]/50 max-w-xs"
                              >
                                {isPdf ? (
                                  <div className="w-9 h-9 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center shrink-0">
                                    <FileText className="w-4 h-4" />
                                  </div>
                                ) : (
                                  <img
                                    src={att.dataUrl}
                                    alt={att.name}
                                    className="w-9 h-9 rounded-lg object-cover border border-[#e9e4d8] shrink-0 bg-white"
                                  />
                                )}
                                <div className="min-w-0 flex-1">
                                  <div className="text-xs font-semibold text-[#1f2e28] truncate">
                                    {att.name}
                                  </div>
                                  <div className="text-[10px] text-[#72847c] tabular-nums">
                                    {getAttachmentTypeLabel(att, copy)} ·{' '}
                                    {formatFileBytes(att.sizeBytes)}
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setPreviewAttachment(att)}
                                  className="p-1.5 rounded-lg text-[#2f9e7e] hover:bg-white shrink-0"
                                  title={copy.previewFileTooltip}
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => triggerMedicalAttachmentDownload(att)}
                                  className="p-1.5 rounded-lg text-[#4c5e56] hover:bg-white shrink-0"
                                  title={copy.downloadBtn}
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </motion.div>
      </AnimatePresence>

      {/* Detail Modal */}
      <MedicalRecordDetailModal
        record={detailRecord}
        petName={activePet.name}
        onClose={() => setDetailRecord(null)}
        onEdit={(rec) => setEditingRecord(rec)}
        onPreviewAttachment={(att) => setPreviewAttachment(att)}
        copy={copy}
      />

      {/* Edit Modal */}
      <MedicalRecordEditModal
        record={editingRecord}
        petName={activePet.name}
        onClose={() => setEditingRecord(null)}
        onSave={updateMedicalRecord}
        onPreviewAttachment={(att) => setPreviewAttachment(att)}
        copy={copy}
        showToast={showToast}
      />

      {/* Attachment Lightbox / PDF Viewer Modal */}
      <AnimatePresence>
        {previewAttachment && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPreviewAttachment(null)}
              className="fixed inset-0 bg-black/65 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="relative z-10 w-full max-w-4xl h-[85vh] bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl flex flex-col overflow-hidden"
            >
              <div className="px-4 py-3 border-b border-[#e9e4d8] flex items-center justify-between gap-3 bg-[#fffbf2]">
                <div className="flex items-center gap-2 min-w-0">
                  {previewAttachment.mimeType === 'application/pdf' ? (
                    <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                  ) : (
                    <ImageIcon className="w-4 h-4 text-[#2f9e7e] shrink-0" />
                  )}
                  <span className="text-sm font-bold text-[#1f2e28] truncate">
                    {previewAttachment.name}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => triggerMedicalAttachmentDownload(previewAttachment)}
                    className="px-3 py-1.5 rounded-xl bg-[#2f9e7e] text-white text-xs font-semibold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{copy.downloadBtn}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewAttachment(null)}
                    className="p-1.5 rounded-lg text-[#72847c] hover:bg-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="flex-1 bg-[#1f2e28]/5 overflow-auto flex items-center justify-center p-4">
                {previewAttachment.mimeType === 'application/pdf' ? (
                  <iframe
                    src={previewAttachment.dataUrl}
                    title={previewAttachment.name}
                    className="w-full h-full rounded-xl bg-white border border-[#e9e4d8]"
                  />
                ) : (
                  <img
                    src={previewAttachment.dataUrl}
                    alt={previewAttachment.name}
                    className="max-w-full max-h-full object-contain rounded-xl shadow-sm bg-white"
                  />
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pre-Vet Export Report Modal */}
      <MedicalReportExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        pet={activePet}
        records={medicalRecords}
        onExportSuccess={(msg) => showToast(msg, 'success')}
      />

      {/* Date-Range Weekly Health Summary PDF Modal */}
      <WeeklyReportModal
        isOpen={weeklyModalOpen}
        onClose={() => setWeeklyModalOpen(false)}
        pet={activePet}
        medicalRecords={medicalRecords}
        healthRecords={healthRecords}
        reminders={reminders}
        symptomHistory={symptomHistory}
        onExportSuccess={(msg) => showToast(msg, 'success')}
      />
    </div>
  );
}
