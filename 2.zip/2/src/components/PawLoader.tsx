import React from 'react';

interface PawLoaderProps {
  label?: string;
}

export function PawLoader({ label = '正在整理健康数据...' }: PawLoaderProps) {
  return (
    <div className="py-10 flex flex-col items-center justify-center gap-3 text-[#4c5e56]">
      <div className="flex items-center gap-3" aria-hidden="true">
        {(['paw-step-1', 'paw-step-2', 'paw-step-3'] as const).map((cls, idx) => (
          <svg
            key={cls}
            viewBox="0 0 36 36"
            className={`w-6 h-6 ${cls} ${
              idx === 0
                ? 'text-[#2f9e7e]'
                : idx === 1
                ? 'text-[#ffb074]'
                : 'text-[#f48ca3]'
            }`}
            fill="currentColor"
          >
            <ellipse cx="18" cy="23" rx="7.2" ry="6" />
            <circle cx="9.5" cy="14.5" r="2.7" />
            <circle cx="15" cy="10.8" r="2.7" />
            <circle cx="21" cy="10.8" r="2.7" />
            <circle cx="26.5" cy="14.5" r="2.7" />
          </svg>
        ))}
      </div>
      <span className="text-xs font-medium text-[#72847c]">{label}</span>
    </div>
  );
}
