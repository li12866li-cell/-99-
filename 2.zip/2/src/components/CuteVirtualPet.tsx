import React, { useMemo, useState } from 'react';
import { Heart, Cookie, CalendarCheck2, Sparkles } from 'lucide-react';
import { Pet } from '../types/pet.ts';
import { VirtualPetInteractionLog, VirtualPetState } from '../services/localStore.ts';
import { AnimatedNumber } from './HealthProgressRing.tsx';

interface CuteVirtualPetProps {
  pet: Pet | null;
  state: VirtualPetState | null;
  onInteract: (
    action: VirtualPetInteractionLog['action'],
    label: string,
    points: number
  ) => { state: VirtualPetState; alreadyCheckedIn?: boolean } | null;
}

interface BurstParticle {
  id: number;
  kind: 'heart' | 'star' | 'note';
  tx: string;
  tx2: string;
  left: string;
}

function getMoodText(
  petName: string,
  actionText: string | null,
  isHovered: boolean,
  checkedInToday: boolean
): string {
  if (actionText) return actionText;
  if (isHovered) return `${petName} 竖起耳朵蹭了蹭你的手心~`;
  if (checkedInToday) return `今日已陪伴打卡，${petName} 心情超级愉悦！`;
  return `摸摸头或投喂小零食，提升与 ${petName} 的亲密度吧`;
}

function renderSvgPet(species: Pet['species'], isHovered: boolean, isHappy: boolean) {
  if (species === 'cat') {
    return (
      <svg viewBox="0 0 180 160" className="w-40 h-36 select-none overflow-visible" aria-hidden="true">
        {/* Soft Shadow */}
        <ellipse cx="90" cy="144" rx="44" ry="8" fill="#e9e4d8" opacity="0.7" />
        {/* Tail */}
        <g className={isHappy || isHovered ? 'pet-tail-wag-fast' : 'pet-tail-wag'}>
          <path
            d="M124 126 C152 122, 160 92, 144 82 C136 77, 130 86, 136 94 C142 102, 134 114, 120 116"
            fill="none"
            stroke="#ffb074"
            strokeWidth="11"
            strokeLinecap="round"
          />
        </g>
        {/* Body + Head */}
        <g className={`pet-breathe ${isHappy ? 'pet-happy-hop' : ''}`}>
          {/* Ears */}
          <g className={isHovered ? 'pet-ear-perk' : ''}>
            <polygon points="52,58 46,24 76,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.5" strokeLinejoin="round" />
            <polygon points="56,52 52,32 70,45" fill="#f48ca3" opacity="0.75" />
            <polygon points="128,58 134,24 104,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.5" strokeLinejoin="round" />
            <polygon points="124,52 128,32 110,45" fill="#f48ca3" opacity="0.75" />
          </g>
          {/* Body */}
          <ellipse cx="90" cy="112" rx="38" ry="30" fill="#fff6eb" stroke="#e48f50" strokeWidth="2.5" />
          <ellipse cx="90" cy="115" rx="22" ry="18" fill="#ffffff" />
          {/* Cute Mint Scarf */}
          <path d="M62 90 Q90 102 118 90 Q114 99 90 105 Q66 99 62 90 Z" fill="#2f9e7e" />
          <circle cx="90" cy="102" r="5" fill="#ffb074" stroke="#fff" strokeWidth="1.5" />
          {/* Head */}
          <ellipse cx="90" cy="68" rx="40" ry="32" fill="#ffe1c4" stroke="#e48f50" strokeWidth="2.5" />
          {/* Forehead Stripes */}
          <path d="M84 40 L84 49 M90 38 L90 50 M96 40 L96 49" stroke="#e48f50" strokeWidth="2.6" strokeLinecap="round" />
          {/* Eyes */}
          <g className="pet-blink">
            <ellipse cx="73" cy="67" rx="4.5" ry="5.5" fill="#1f2e28" />
            <circle cx="71.5" cy="65" r="1.6" fill="#ffffff" />
            <ellipse cx="107" cy="67" rx="4.5" ry="5.5" fill="#1f2e28" />
            <circle cx="105.5" cy="65" r="1.6" fill="#ffffff" />
          </g>
          {/* Blush */}
          <ellipse cx="62" cy="75" rx="6" ry="3.4" fill="#f48ca3" opacity={isHovered || isHappy ? '0.85' : '0.45'} />
          <ellipse cx="118" cy="75" rx="6" ry="3.4" fill="#f48ca3" opacity={isHovered || isHappy ? '0.85' : '0.45'} />
          {/* Nose & Mouth */}
          <polygon points="87,73 93,73 90,77" fill="#f48ca3" />
          <path d="M83 80 Q86.5 84 90 79 Q93.5 84 97 80" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
          {/* Whiskers */}
          <path d="M44 70 L58 72 M43 77 L58 77 M122 72 L136 70 M122 77 L137 77" stroke="#c7a98d" strokeWidth="1.8" strokeLinecap="round" />
          {/* Paws */}
          <ellipse cx="72" cy="137" rx="9" ry="6" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
          <ellipse cx="108" cy="137" rx="9" ry="6" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
        </g>
      </svg>
    );
  }

  if (species === 'bunny') {
    return (
      <svg viewBox="0 0 180 160" className="w-40 h-36 select-none overflow-visible" aria-hidden="true">
        <ellipse cx="90" cy="144" rx="40" ry="8" fill="#e9e4d8" opacity="0.7" />
        <g className={isHappy || isHovered ? 'pet-tail-wag-fast' : 'pet-tail-wag'}>
          <circle cx="128" cy="126" r="9" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2" />
        </g>
        <g className={`pet-breathe ${isHappy ? 'pet-happy-hop' : ''}`}>
          <g className={isHovered ? 'pet-ear-perk' : ''}>
            <ellipse cx="73" cy="30" rx="9" ry="24" transform="rotate(-10 73 30)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.5" />
            <ellipse cx="73" cy="32" rx="4.5" ry="15" transform="rotate(-10 73 32)" fill="#f48ca3" opacity="0.6" />
            <ellipse cx="107" cy="30" rx="9" ry="24" transform="rotate(10 107 30)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.5" />
            <ellipse cx="107" cy="32" rx="4.5" ry="15" transform="rotate(10 107 32)" fill="#f48ca3" opacity="0.6" />
          </g>
          <ellipse cx="90" cy="114" rx="35" ry="29" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.5" />
          <path d="M64 93 Q90 104 116 93 Q112 101 90 106 Q68 101 64 93 Z" fill="#2f9e7e" />
          <ellipse cx="90" cy="72" rx="36" ry="30" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.5" />
          <g className="pet-blink">
            <ellipse cx="75" cy="70" rx="4.2" ry="5.2" fill="#1f2e28" />
            <circle cx="73.5" cy="68" r="1.5" fill="#ffffff" />
            <ellipse cx="105" cy="70" rx="4.2" ry="5.2" fill="#1f2e28" />
            <circle cx="103.5" cy="68" r="1.5" fill="#ffffff" />
          </g>
          <ellipse cx="64" cy="78" rx="6" ry="3.5" fill="#f48ca3" opacity={isHovered || isHappy ? '0.9' : '0.5'} />
          <ellipse cx="116" cy="78" rx="6" ry="3.5" fill="#f48ca3" opacity={isHovered || isHappy ? '0.9' : '0.5'} />
          <ellipse cx="90" cy="76" rx="3.2" ry="2.4" fill="#f48ca3" />
          <path d="M84 82 Q87 86 90 81 Q93 86 96 82" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
          <ellipse cx="73" cy="138" rx="9" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
          <ellipse cx="107" cy="138" rx="9" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
        </g>
      </svg>
    );
  }

  // Cute Golden Puppy (default)
  return (
    <svg viewBox="0 0 180 160" className="w-40 h-36 select-none overflow-visible" aria-hidden="true">
      <ellipse cx="90" cy="144" rx="44" ry="8" fill="#e9e4d8" opacity="0.7" />
      {/* Tail */}
      <g className={isHappy || isHovered ? 'pet-tail-wag-fast' : 'pet-tail-wag'}>
        <path
          d="M123 122 C145 112, 152 88, 139 82"
          fill="none"
          stroke="#f6c478"
          strokeWidth="12"
          strokeLinecap="round"
        />
      </g>
      {/* Body + Head */}
      <g className={`pet-breathe ${isHappy ? 'pet-happy-hop' : ''}`}>
        {/* Floppy Ears */}
        <g className={isHovered ? 'pet-ear-perk' : ''}>
          <ellipse cx="50" cy="68" rx="13" ry="24" transform="rotate(14 50 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.4" />
          <ellipse cx="130" cy="68" rx="13" ry="24" transform="rotate(-14 130 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.4" />
        </g>
        {/* Body */}
        <ellipse cx="90" cy="113" rx="38" ry="29" fill="#ffe6bd" stroke="#c98636" strokeWidth="2.4" />
        <ellipse cx="90" cy="117" rx="22" ry="18" fill="#fffaf1" />
        {/* Mint Collar + Tag */}
        <path d="M62 91 Q90 102 118 91 Q115 99 90 105 Q65 99 62 91 Z" fill="#2f9e7e" />
        <circle cx="90" cy="103" r="5.5" fill="#ffb074" stroke="#ffffff" strokeWidth="1.6" />
        {/* Head */}
        <ellipse cx="90" cy="66" rx="39" ry="33" fill="#ffe6bd" stroke="#c98636" strokeWidth="2.4" />
        {/* Muzzle */}
        <ellipse cx="90" cy="77" rx="18" ry="13" fill="#fffaf1" />
        {/* Eyes */}
        <g className="pet-blink">
          <circle cx="74" cy="62" r="4.8" fill="#1f2e28" />
          <circle cx="72.4" cy="60.2" r="1.7" fill="#ffffff" />
          <circle cx="106" cy="62" r="4.8" fill="#1f2e28" />
          <circle cx="104.4" cy="60.2" r="1.7" fill="#ffffff" />
        </g>
        {/* Blush */}
        <ellipse cx="62" cy="72" rx="6" ry="3.4" fill="#f48ca3" opacity={isHovered || isHappy ? '0.88' : '0.45'} />
        <ellipse cx="118" cy="72" rx="6" ry="3.4" fill="#f48ca3" opacity={isHovered || isHappy ? '0.88' : '0.45'} />
        {/* Nose & Happy Tongue */}
        <ellipse cx="90" cy="73" rx="5.5" ry="4" fill="#1f2e28" />
        <path d="M84 80 Q87 84 90 79 Q93 84 96 80" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
        {(isHappy || isHovered) && (
          <path d="M86 82 Q90 92 94 82 Z" fill="#f48ca3" />
        )}
        {/* Paws */}
        <ellipse cx="71" cy="138" rx="10" ry="6" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
        <ellipse cx="109" cy="138" rx="10" ry="6" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
      </g>
    </svg>
  );
}

export function CuteVirtualPet({ pet, state, onInteract }: CuteVirtualPetProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isHappy, setIsHappy] = useState(false);
  const [actionBubble, setActionBubble] = useState<string | null>(null);
  const [particles, setParticles] = useState<BurstParticle[]>([]);

  const todayStr = new Date().toISOString().split('T')[0];
  const checkedInToday = state?.lastCheckInDate === todayStr;

  const intimacyLevel = useMemo(() => {
    const score = state?.intimacy ?? 0;
    const level = Math.floor(score / 50) + 1;
    const progress = score % 50;
    const pct = Math.min(100, Math.round((progress / 50) * 100));
    return { score, level, pct };
  }, [state?.intimacy]);

  const spawnBurst = () => {
    const now = Date.now();
    const created: BurstParticle[] = [
      { id: now + 1, kind: 'heart', tx: '-14px', tx2: '-26px', left: '40%' },
      { id: now + 2, kind: 'star', tx: '12px', tx2: '24px', left: '54%' },
      { id: now + 3, kind: 'heart', tx: '0px', tx2: '-6px', left: '48%' },
    ];
    setParticles((prev) => [...prev.slice(-6), ...created]);
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => !created.some((c) => c.id === p.id)));
    }, 1050);
  };

  const triggerReaction = (message: string) => {
    setIsHappy(true);
    setActionBubble(message);
    spawnBurst();
    setTimeout(() => setIsHappy(false), 520);
    setTimeout(() => setActionBubble((prev) => (prev === message ? null : prev)), 2400);
  };

  if (!pet) return null;

  const handlePetClick = () => {
    onInteract('pet', `抚摸 ${pet.name}`, 3);
    triggerReaction(`${pet.name} 开心得摇起了尾巴！+3 亲密度`);
  };

  const handleFeedClick = () => {
    onInteract('feed', `投喂 ${pet.name} 营养零食`, 5);
    triggerReaction(`嚼嚼嚼~ 美味小零食！+5 亲密度`);
  };

  const handleCheckIn = () => {
    const res = onInteract('checkin', `完成 ${pet.name} 每日陪伴打卡`, 10);
    if (res?.alreadyCheckedIn) {
      triggerReaction(`今天已经打卡过啦，明天再来哦`);
    } else {
      triggerReaction(`打卡成功！连续陪伴又多一天，+10 亲密度`);
    }
  };

  return (
    <section className="wellness-card rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-[#fffbf2] via-white to-[#e6f7f1]/55">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        {/* Left Interactive SVG Pet */}
        <div className="md:col-span-5 flex flex-col items-center justify-center relative py-2">
          <div className="relative">
            {/* Floating Burst Particles */}
            <div className="pointer-events-none absolute inset-x-0 top-4 h-12 z-20">
              {particles.map((p) => (
                <span
                  key={p.id}
                  style={
                    {
                      left: p.left,
                      '--tx': p.tx,
                      '--tx2': p.tx2,
                    } as React.CSSProperties
                  }
                  className="float-burst-item absolute top-0 inline-flex items-center justify-center"
                >
                  {p.kind === 'heart' ? (
                    <Heart className="w-4 h-4 fill-[#f48ca3] text-[#f48ca3]" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-[#ffb074]" />
                  )}
                </span>
              ))}
            </div>

            <button
              type="button"
              onClick={handlePetClick}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              className="group relative rounded-3xl p-2 focus:outline-none cursor-pointer transition-transform hover:scale-[1.02]"
              aria-label={`点击抚摸虚拟宠物 ${pet.name}`}
              title={`点击抚摸 ${pet.name}`}
            >
              {renderSvgPet(pet.species, isHovered, isHappy)}
            </button>
          </div>

          <div className="mt-1 px-3 py-1 rounded-full bg-white/90 border border-[#e9e4d8] text-xs text-[#4c5e56] text-center max-w-xs">
            {getMoodText(pet.name, actionBubble, isHovered, checkedInToday)}
          </div>
        </div>

        {/* Right Companion Stats & Actions */}
        <div className="md:col-span-7 space-y-4">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <div className="flex items-center gap-2 text-xs text-[#2f9e7e] font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>虚拟治愈伙伴 · 本地互动陪伴</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-[#1f2e28] mt-0.5">
                {pet.name} 的元气小窝 · Lv.<AnimatedNumber value={intimacyLevel.level} />
              </h2>
            </div>

            <div className="text-right tabular-nums">
              <div className="text-xs text-[#72847c]">亲密值</div>
              <div className="text-lg font-bold text-[#2f9e7e]">
                <AnimatedNumber value={intimacyLevel.score} /> pt
              </div>
            </div>
          </div>

          {/* Intimacy Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-[#4c5e56] tabular-nums">
              <span>距离下一陪伴等级</span>
              <span>
                {intimacyLevel.pct}% · 连续打卡 {state?.streakDays ?? 0} 天 · 今日投喂{' '}
                {state?.feedCountToday ?? 0} 次
              </span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-[#e6f7f1] overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#2f9e7e] to-[#ffb074]"
                style={{
                  width: `${Math.max(8, intimacyLevel.pct)}%`,
                  transition: 'width 0.55s cubic-bezier(0.22, 1, 0.36, 1)',
                }}
              />
            </div>
          </div>

          {/* Interactive Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handlePetClick}
              className="btn-press px-3.5 py-2 rounded-2xl bg-[#fff0f4] hover:bg-[#ffe3eb] border border-[#f48ca3]/40 text-[#9c3651] text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Heart className="w-3.5 h-3.5 text-[#f48ca3] shrink-0" />
              <span>摸摸头 (+3)</span>
            </button>

            <button
              type="button"
              onClick={handleFeedClick}
              className="btn-press px-3.5 py-2 rounded-2xl bg-[#fff3e6] hover:bg-[#ffe8cf] border border-[#ffb074]/50 text-[#9a4d12] text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Cookie className="w-3.5 h-3.5 text-[#ea7d2b] shrink-0" />
              <span>投喂零食 (+5)</span>
            </button>

            <button
              type="button"
              onClick={handleCheckIn}
              className={`btn-press px-3.5 py-2 rounded-2xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                checkedInToday
                  ? 'bg-[#e6f7f1] text-[#1f5c4b] border border-[#2f9e7e]/35'
                  : 'bg-[#2f9e7e] hover:bg-[#258267] text-white'
              }`}
            >
              <CalendarCheck2 className="w-3.5 h-3.5 shrink-0" />
              <span>{checkedInToday ? '今日已打卡' : '每日健康打卡 (+10)'}</span>
            </button>
          </div>

          {/* Recent Interaction History */}
          {state && state.interactions.length > 0 && (
            <div className="pt-2 border-t border-[#e9e4d8]/80 space-y-1">
              <div className="text-[11px] font-semibold text-[#72847c]">最近互动足迹</div>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-[#4c5e56]">
                {state.interactions.slice(0, 3).map((item) => (
                  <span key={item.id} className="tabular-nums">
                    {item.label} (+{item.points}) ·{' '}
                    {new Date(item.timestamp).toLocaleTimeString('zh-CN', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
