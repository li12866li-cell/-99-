import React, { useMemo, useState } from 'react';
import { X, CalendarRange, Printer, Sparkles, CheckCircle2, FileText } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { HealthRecord, Pet } from '../types/pet.ts';
import { MedicalRecord } from '../types/medicalRecord.ts';
import { Reminder } from '../types/reminder.ts';
import { SymptomCheckHistoryItem } from '../services/localStore.ts';
import {
  buildWeeklyHealthSummary,
  buildWeeklyReportHtml,
  printHtmlToPdf,
} from '../lib/weeklyReportSummarizer.ts';

interface WeeklyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  pet: Pet;
  medicalRecords: MedicalRecord[];
  healthRecords: HealthRecord[];
  reminders: Reminder[];
  symptomHistory: SymptomCheckHistoryItem[];
  onExportSuccess: (msg: string) => void;
}

function daysAgoStr(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().split('T')[0];
}

export function WeeklyReportModal({
  isOpen,
  onClose,
  pet,
  medicalRecords,
  healthRecords,
  reminders,
  symptomHistory,
  onExportSuccess,
}: WeeklyReportModalProps) {
  const todayStr = new Date().toISOString().split('T')[0];
  const [startDate, setStartDate] = useState<string>(() => daysAgoStr(6));
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [ownerNotes, setOwnerNotes] = useState('');

  const normalizedRange = useMemo(() => {
    if (startDate <= endDate) return { start: startDate, end: endDate };
    return { start: endDate, end: startDate };
  }, [startDate, endDate]);

  const summary = useMemo(
    () =>
      buildWeeklyHealthSummary({
        pet,
        startDate: normalizedRange.start,
        endDate: normalizedRange.end,
        medicalRecords,
        healthRecords,
        reminders,
        symptomHistory,
      }),
    [pet, normalizedRange, medicalRecords, healthRecords, reminders, symptomHistory]
  );

  const handlePrintPdf = () => {
    const html = buildWeeklyReportHtml(pet, summary, ownerNotes);
    printHtmlToPdf(html);
    onExportSuccess('已生成健康总结周报并调起打印/PDF 另存为面板');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            className="relative z-10 w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-[#2f9e7e] text-white flex items-center justify-center">
                  <CalendarRange className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#1f2e28]">
                    生成健康总结周报 (PDF) · {pet.name}
                  </h3>
                  <p className="text-xs text-[#72847c]">
                    选择起止日期后，本地规则引擎自动聚合检查记录、体重趋势与护理完成率
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-[#72847c] hover:bg-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {/* Date Range Picker + Quick Presets */}
              <div className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/70 p-4 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-xs font-bold text-[#1f2e28]">1. 选择统计日期范围</span>
                  <div className="flex items-center gap-1.5">
                    {[
                      { label: '近 7 天', days: 6 },
                      { label: '近 14 天', days: 13 },
                      { label: '近 30 天', days: 29 },
                    ].map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => {
                          setStartDate(daysAgoStr(preset.days));
                          setEndDate(todayStr);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-white border border-[#e9e4d8] hover:border-[#2f9e7e] text-[11px] font-semibold text-[#4c5e56]"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-[#72847c]">开始日期</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs sm:text-sm tabular-nums"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-[#72847c]">结束日期</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs sm:text-sm tabular-nums"
                    />
                  </div>
                </div>
              </div>

              {/* Aggregated Local Metrics Preview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="rounded-2xl border border-[#e9e4d8] p-3 bg-white">
                  <div className="text-[11px] text-[#72847c]">医疗检查单</div>
                  <div className="text-lg font-bold text-[#1f5c4b] tabular-nums mt-0.5">
                    {summary.medicalInPeriod.length} 份
                  </div>
                </div>
                <div className="rounded-2xl border border-[#e9e4d8] p-3 bg-white">
                  <div className="text-[11px] text-[#72847c]">健康日志/称重</div>
                  <div className="text-lg font-bold text-[#2f9e7e] tabular-nums mt-0.5">
                    {summary.healthRecordsInPeriod.length} 条
                  </div>
                </div>
                <div className="rounded-2xl border border-[#e9e4d8] p-3 bg-white">
                  <div className="text-[11px] text-[#72847c]">护理已完成</div>
                  <div className="text-lg font-bold text-[#1f5c4b] tabular-nums mt-0.5">
                    {summary.careStats.completedReminders} 项
                  </div>
                </div>
                <div className="rounded-2xl border border-[#e9e4d8] p-3 bg-white">
                  <div className="text-[11px] text-[#72847c]">待执行提醒</div>
                  <div className="text-lg font-bold text-[#ea7d2b] tabular-nums mt-0.5">
                    {summary.careStats.pendingReminders} 项
                  </div>
                </div>
              </div>

              {/* Local Rule-Based Narrative Preview */}
              <div className="rounded-2xl border border-[#2f9e7e]/30 bg-[#e6f7f1]/55 p-4 space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#1f5c4b]">
                  <Sparkles className="w-4 h-4 text-[#2f9e7e]" />
                  <span>本地汇总摘要预览（无外部 AI 接口调用）</span>
                </div>
                <ul className="space-y-1.5 text-xs text-[#1f2e28] leading-relaxed">
                  {summary.narrativeSummary.map((line, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#2f9e7e] shrink-0 mt-0.5" />
                      <span>{line}</span>
                    </li>
                  ))}
                  {summary.careRecommendations.map((line, idx) => (
                    <li key={`rec_${idx}`} className="flex items-start gap-2 text-[#4c5e56]">
                      <FileText className="w-3.5 h-3.5 text-[#ffb074] shrink-0 mt-0.5" />
                      <span>{line}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Optional Owner Note */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#1f2e28]">
                  2. 补充本周精神/饮食备注（可选，会写入 PDF 周报）
                </label>
                <textarea
                  rows={2}
                  value={ownerNotes}
                  onChange={(e) => setOwnerNotes(e.target.value)}
                  placeholder="例如：本周食欲稳定，早晚散步状态很好，下周准备去复查..."
                  className="w-full rounded-xl border border-[#e9e4d8] bg-[#fffbf2]/50 focus:bg-white px-3.5 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
                />
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#e9e4d8] bg-white text-xs font-semibold text-[#4c5e56]"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handlePrintPdf}
                className="btn-press px-5 py-2.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>导出周报 (另存为 PDF)</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
