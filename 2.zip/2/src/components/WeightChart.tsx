import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Info } from 'lucide-react';

export interface WeightPoint {
  recordId?: string;
  date: string;
  fullDate: string;
  weight: number;
  title: string;
  content?: string;
}

export function WeightChart({ data }: { data: WeightPoint[] }) {
  if (!data || data.length === 0) {
    return (
      <div className="space-y-2.5">
        <div className="h-56 sm:h-64 flex items-center justify-center rounded-2xl bg-[#fffbf2] border border-dashed border-[#e9e4d8] text-xs text-[#72847c] px-4 text-center">
          当前时间范围内暂无体重记录，可根据实际称重情况随时添加
        </div>
        <div className="flex items-start gap-1.5 text-[11px] text-[#72847c]">
          <Info className="w-3.5 h-3.5 text-[#2f9e7e] shrink-0 mt-0.5" />
          <span>不根据单一体重数据直接判断宠物是否患病，建议结合连续变化趋势、食欲与精神状态综合观察。</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      <div className="h-56 sm:h-64 md:h-72 w-full min-w-0">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 12, right: 16, left: 4, bottom: 6 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#efe9dc" />
            <XAxis
              dataKey="date"
              minTickGap={22}
              interval="preserveStartEnd"
              tick={{ fontSize: 11, fill: '#72847c' }}
              axisLine={{ stroke: '#e9e4d8' }}
              tickLine={false}
            />
            <YAxis
              width={44}
              tick={{ fontSize: 11, fill: '#72847c' }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `${v}`}
              domain={[
                (dataMin: number) => Math.max(0, Number((dataMin - 0.5).toFixed(1))),
                (dataMax: number) => Number((dataMax + 0.5).toFixed(1)),
              ]}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload || payload.length === 0) return null;
                const pt = payload[0].payload as WeightPoint;
                return (
                  <div className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/95 px-3.5 py-2.5 shadow-md text-xs space-y-1 max-w-[230px]">
                    <div className="font-mono tabular-nums font-bold text-[#1f5c4b]">
                      {pt.fullDate}
                    </div>
                    <div className="font-bold text-sm text-[#1f2e28] tabular-nums">
                      体重：{pt.weight} kg
                    </div>
                    {(pt.content || pt.title) && (
                      <div className="text-[11px] text-[#4c5e56] leading-snug line-clamp-2">
                        {pt.content || pt.title}
                      </div>
                    )}
                  </div>
                );
              }}
            />
            <Line
              type="monotone"
              dataKey="weight"
              stroke="#2f9e7e"
              strokeWidth={2.8}
              animationDuration={520}
              dot={{ r: 4.5, fill: '#2f9e7e', stroke: '#ffffff', strokeWidth: 2 }}
              activeDot={{ r: 6.5, fill: '#ffb074', stroke: '#ffffff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="flex items-start gap-1.5 text-[11px] text-[#72847c]">
        <Info className="w-3.5 h-3.5 text-[#2f9e7e] shrink-0 mt-0.5" />
        <span>不根据单一体重数据直接判断宠物是否患病，建议结合连续多日变化曲线与专业兽医评估综合观察。</span>
      </div>
    </div>
  );
}
