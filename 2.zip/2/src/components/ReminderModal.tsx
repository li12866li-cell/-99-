import React, { useState } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ReminderCategory, ReminderInput, ReminderRepeat } from '../types/reminder.ts';

interface ReminderModalProps {
  isOpen: boolean;
  petId: string;
  onClose: () => void;
  onSubmit: (input: ReminderInput) => Promise<void>;
}

export function ReminderModal({ isOpen, petId, onClose, onSubmit }: ReminderModalProps) {
  const todayStr = new Date().toISOString().split('T')[0];
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ReminderCategory>('vaccine');
  const [dueDate, setDueDate] = useState(todayStr);
  const [dueTime, setDueTime] = useState('09:30');
  const [repeat, setRepeat] = useState<ReminderRepeat>('once');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !petId || submitting) return;
    setSubmitting(true);
    try {
      await onSubmit({
        petId,
        title: title.trim(),
        category,
        dueDate,
        dueTime,
        repeat,
        notes: notes.trim() || undefined,
      });
      setTitle('');
      setNotes('');
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/45 backdrop-blur-xs"
          />
          <motion.form
            onSubmit={handleSubmit}
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            className="relative z-10 w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900">新建护理提醒</h3>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600">提醒事项 *</label>
                <input
                  required
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="例如：体外驱虫滴剂 / 狂犬疫苗加强针"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#2f7d71]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600">提醒类别</label>
                <div className="grid grid-cols-5 gap-1.5">
                  {(
                    [
                      { id: 'vaccine', label: '疫苗' },
                      { id: 'deworming', label: '驱虫' },
                      { id: 'medication', label: '用药' },
                      { id: 'checkup', label: '体检' },
                      { id: 'grooming', label: '洗护' },
                    ] as { id: ReminderCategory; label: string }[]
                  ).map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCategory(c.id)}
                      className={`py-2 rounded-lg text-xs font-semibold border transition-colors ${
                        category === c.id
                          ? 'bg-[#2f7d71] text-white border-[#2f7d71]'
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">计划日期</label>
                  <input
                    required
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600">时间</label>
                  <input
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600">重复周期</label>
                <select
                  value={repeat}
                  onChange={(e) => setRepeat(e.target.value as ReminderRepeat)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                >
                  <option value="once">仅一次</option>
                  <option value="daily">每天</option>
                  <option value="weekly">每周</option>
                  <option value="monthly">每月</option>
                  <option value="yearly">每年</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-600">备注说明（可选）</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="记录剂量、品牌或注意事项"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-[#2f7d71]"
                />
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-100 flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={!title.trim() || submitting}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#2f7d71] hover:bg-[#25645b] disabled:opacity-50"
              >
                {submitting ? '创建中...' : '保存提醒'}
              </button>
            </div>
          </motion.form>
        </div>
      )}
    </AnimatePresence>
  );
}
