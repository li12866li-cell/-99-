import React, { useMemo, useState } from 'react';
import {
  X,
  FileDown,
  Printer,
  FileCode2,
  FileText,
  Braces,
  CheckSquare,
  Square,
  Stethoscope,
  FileSpreadsheet,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { Pet } from '../types/pet.ts';
import {
  MedicalRecord,
  MedicalRecordCategory,
  ReportExportFormat,
  ReportScopeMode,
} from '../types/medicalRecord.ts';

interface MedicalReportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  pet: Pet;
  records: MedicalRecord[];
  ownerName?: string;
  onExportSuccess: (msg: string) => void;
}

const CATEGORY_LABELS: Record<MedicalRecordCategory, string> = {
  lab: '血检与化验',
  imaging: '影像检查 (X光/B超)',
  vaccine: '疫苗与免疫',
  prescription: '处方与病历',
  checkup: '常规体检',
  other: '其他医疗文档',
};

function escapeHtml(text: string): string {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function downloadTextBlob(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function printHtmlViaHiddenIframe(htmlContent: string) {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.setAttribute('aria-hidden', 'true');
  document.body.appendChild(iframe);

  const cleanup = () => {
    setTimeout(() => {
      if (iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
      }
    }, 1500);
  };

  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } finally {
      cleanup();
    }
  };
  iframe.srcdoc = htmlContent;
}

export function MedicalReportExportModal({
  isOpen,
  onClose,
  pet,
  records,
  ownerName,
  onExportSuccess,
}: MedicalReportExportModalProps) {
  const [format, setFormat] = useState<ReportExportFormat>('pdf-print');
  const [scope, setScope] = useState<ReportScopeMode>('full');
  const [selectedIds, setSelectedIds] = useState<string[]>(() => records.map((r) => r.id));
  const [visitComplaint, setVisitComplaint] = useState('');

  React.useEffect(() => {
    if (isOpen) {
      setSelectedIds(records.map((r) => r.id));
    }
  }, [isOpen, records]);

  const chosenRecords = useMemo(() => {
    const idSet = new Set(selectedIds);
    return records.filter((r) => idSet.has(r.id));
  }, [records, selectedIds]);

  const toggleId = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    if (selectedIds.length === records.length) setSelectedIds([]);
    else setSelectedIds(records.map((r) => r.id));
  };

  const buildReportHtml = () => {
    const generatedAt = new Date().toLocaleString('zh-CN');
    const speciesLabel =
      pet.species === 'dog' ? '犬' : pet.species === 'cat' ? '猫' : pet.species === 'bunny' ? '兔' : '其他';

    const recordsHtml = chosenRecords
      .map((rec, index) => {
        const imageAttachments =
          scope === 'full'
            ? rec.attachments.filter((a) => a.mimeType.startsWith('image/'))
            : [];
        const pdfAttachments = rec.attachments.filter((a) => a.mimeType === 'application/pdf');

        return `
          <section class="record-card">
            <div class="record-meta">
              <span>#${index + 1}</span>
              <span>${escapeHtml(rec.date)}</span>
              <span>${escapeHtml(CATEGORY_LABELS[rec.category] || rec.category)}</span>
              ${rec.hospitalName ? `<span>医院：${escapeHtml(rec.hospitalName)}</span>` : ''}
            </div>
            <h3>${escapeHtml(rec.title)}</h3>
            <div class="results-box">
              <strong>检查结果与医嘱：</strong>
              <p>${escapeHtml(rec.results || '未填写文字说明').replace(/\n/g, '<br/>')}</p>
            </div>
            ${
              pdfAttachments.length > 0
                ? `<div class="pdf-list"><strong>随附 PDF 文档：</strong>${pdfAttachments
                    .map(
                      (p) =>
                        `<span class="att-chip">${escapeHtml(p.name)} (${Math.max(
                          1,
                          Math.round(p.sizeBytes / 1024)
                        )} KB)</span>`
                    )
                    .join(' ')}</div>`
                : ''
            }
            ${
              imageAttachments.length > 0
                ? `<div class="img-grid">${imageAttachments
                    .map(
                      (img) => `
                        <figure>
                          <img src="${img.dataUrl}" alt="${escapeHtml(img.name)}" />
                          <figcaption>${escapeHtml(img.name)}</figcaption>
                        </figure>
                      `
                    )
                    .join('')}</div>`
                : ''
            }
          </section>
        `;
      })
      .join('');

    return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(pet.name)} - 就医前医疗记录报告</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif; color: #17211c; background: #ffffff; margin: 0; padding: 28px; line-height: 1.55; }
    .header { border-bottom: 2px solid #1b4332; padding-bottom: 14px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; }
    .header h1 { margin: 0; font-size: 22px; color: #1b4332; }
    .header .sub { font-size: 12px; color: #48564f; margin-top: 4px; }
    .pet-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; background: #faf7f2; border: 1px solid #e4ded1; border-radius: 10px; padding: 12px 14px; margin-bottom: 18px; font-size: 12px; }
    .pet-grid .label { color: #6c7972; display: block; font-size: 11px; }
    .pet-grid .val { font-weight: 700; color: #17211c; }
    .complaint { background: #eaf4f1; border: 1px solid #cce3dc; border-radius: 10px; padding: 12px 14px; margin-bottom: 18px; font-size: 13px; }
    .record-card { border: 1px solid #e4ded1; border-radius: 10px; padding: 14px 16px; margin-bottom: 14px; page-break-inside: avoid; }
    .record-meta { font-size: 11px; color: #48564f; display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 6px; }
    .record-card h3 { margin: 0 0 8px 0; font-size: 15px; color: #1b4332; }
    .results-box { font-size: 13px; background: #faf7f2; padding: 10px 12px; border-radius: 8px; }
    .results-box p { margin: 4px 0 0 0; }
    .pdf-list { margin-top: 10px; font-size: 12px; color: #48564f; }
    .att-chip { display: inline-block; background: #f3eee4; border: 1px solid #e4ded1; padding: 2px 8px; border-radius: 6px; margin-right: 6px; font-size: 11px; }
    .img-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; margin-top: 12px; }
    .img-grid figure { margin: 0; border: 1px solid #e4ded1; border-radius: 8px; padding: 6px; background: #fff; }
    .img-grid img { width: 100%; max-height: 240px; object-fit: contain; display: block; }
    .img-grid figcaption { font-size: 11px; color: #6c7972; margin-top: 4px; text-align: center; }
    .footer { margin-top: 24px; padding-top: 12px; border-top: 1px solid #e4ded1; font-size: 11px; color: #6c7972; display: flex; justify-content: space-between; }
    @media print { body { padding: 12px; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>PetCare AI · 宠物就诊前医疗档案报告</h1>
      <div class="sub">报告模式：${scope === 'full' ? '完整图文诊疗报告' : '精简就医速览'} · 导出时间：${escapeHtml(generatedAt)}</div>
    </div>
    <div class="sub">${ownerName ? `宠主：${escapeHtml(ownerName)}` : ''}</div>
  </div>

  <div class="pet-grid">
    <div><span class="label">宠物姓名</span><span class="val">${escapeHtml(pet.name)}</span></div>
    <div><span class="label">物种与品种</span><span class="val">${speciesLabel} · ${escapeHtml(pet.breed || '未填写')}</span></div>
    <div><span class="label">年龄 / 性别</span><span class="val">${pet.age ?? '--'} 岁 · ${pet.gender === 'female' ? '母' : '公'}${pet.isNeutered ? '（已绝育）' : ''}</span></div>
    <div><span class="label">当前体重 / 疫苗</span><span class="val">${pet.weight ?? '--'} kg · ${escapeHtml(pet.vaccineStatus || '未记录')}</span></div>
  </div>

  ${
    visitComplaint.trim()
      ? `<div class="complaint"><strong>本次就诊主诉 / 宠主备注：</strong><br/>${escapeHtml(
          visitComplaint.trim()
        ).replace(/\n/g, '<br/>')}</div>`
      : ''
  }

  ${recordsHtml || '<p>未选择任何医疗记录。</p>'}

  <div class="footer">
    <span>由 PetCare AI 医疗记录中心生成</span>
    <span>共包含 ${chosenRecords.length} 条医疗记录 · 仅供兽医接诊参考</span>
  </div>
</body>
</html>`;
  };

  const buildMarkdown = () => {
    const lines: string[] = [
      `# PetCare AI 宠物就诊前医疗报告 — ${pet.name}`,
      `- 导出时间：${new Date().toLocaleString('zh-CN')}`,
      `- 报告模式：${scope === 'full' ? '完整医疗档案' : '精简就医速览'}`,
      `- 宠物资料：${pet.name}（${pet.breed || pet.species} · ${pet.age ?? '--'}岁 · ${
        pet.weight ?? '--'
      } kg · ${pet.isNeutered ? '已绝育' : '未绝育'}）`,
    ];
    if (visitComplaint.trim()) {
      lines.push('', `## 本次就诊主诉`, visitComplaint.trim());
    }
    lines.push('', `## 历史医疗检查记录 (${chosenRecords.length} 项)`);
    chosenRecords.forEach((rec, i) => {
      lines.push(
        '',
        `### ${i + 1}. ${rec.title}`,
        `- 日期：${rec.date}`,
        `- 类型：${CATEGORY_LABELS[rec.category] || rec.category}`,
        `- 就诊医院：${rec.hospitalName || '未填写'}`,
        `- 检查结果：${rec.results || '未填写'}`
      );
      if (scope === 'full' && rec.attachments.length > 0) {
        lines.push(
          `- 附件清单：${rec.attachments.map((a) => `${a.name} (${a.mimeType})`).join('；')}`
        );
      }
    });
    return lines.join('\n');
  };

  const handleExport = () => {
    const safeName = (pet.name || 'pet').replace(/[^a-zA-Z0-9\u4e00-\u9fa5_-]/g, '_');
    const dateTag = new Date().toISOString().slice(0, 10);

    if (format === 'pdf-print') {
      printHtmlViaHiddenIframe(buildReportHtml());
      onExportSuccess('已调起诊疗报告打印预览，可在目标打印机中选择「另存为 PDF」');
      onClose();
      return;
    }

    if (format === 'word-doc') {
      downloadTextBlob(
        `${safeName}_就诊医疗报告_${dateTag}.doc`,
        buildReportHtml(),
        'application/msword;charset=utf-8'
      );
      onExportSuccess('已导出 Word (.doc) 就诊医疗报告');
      onClose();
      return;
    }

    if (format === 'html') {
      downloadTextBlob(
        `${safeName}_医疗报告_${dateTag}.html`,
        buildReportHtml(),
        'text/html;charset=utf-8'
      );
      onExportSuccess('已导出 HTML 离线图文诊疗报告');
      onClose();
      return;
    }

    if (format === 'markdown') {
      downloadTextBlob(
        `${safeName}_就诊摘要_${dateTag}.md`,
        buildMarkdown(),
        'text/markdown;charset=utf-8'
      );
      onExportSuccess('已导出 Markdown 就诊摘要文件');
      onClose();
      return;
    }

    const jsonPayload = {
      exportedAt: new Date().toISOString(),
      scope,
      visitComplaint: visitComplaint.trim() || undefined,
      pet: {
        id: pet.id,
        name: pet.name,
        species: pet.species,
        breed: pet.breed,
        age: pet.age,
        weight: pet.weight,
        gender: pet.gender,
        isNeutered: pet.isNeutered,
        vaccineStatus: pet.vaccineStatus,
      },
      records:
        scope === 'summary'
          ? chosenRecords.map(({ attachments, ...rest }) => ({
              ...rest,
              attachmentNames: attachments.map((a) => a.name),
            }))
          : chosenRecords,
    };
    downloadTextBlob(
      `${safeName}_医疗档案_${dateTag}.json`,
      JSON.stringify(jsonPayload, null, 2),
      'application/json;charset=utf-8'
    );
    onExportSuccess('已导出 JSON 结构化医疗档案');
    onClose();
  };

  const formatOptions: Array<{
    id: ReportExportFormat;
    title: string;
    desc: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      id: 'pdf-print',
      title: 'PDF 打印版报告',
      desc: 'A4 排版，支持直接另存为 PDF 或纸质打印带去医院',
      icon: Printer,
    },
    {
      id: 'word-doc',
      title: 'Word 病历文档 (.doc)',
      desc: '导出可编辑的 Word 格式就诊单，方便医生或个人补充批注',
      icon: FileSpreadsheet,
    },
    {
      id: 'html',
      title: 'HTML 离线图文病例',
      desc: '单文件内嵌检查图片与文字，任何电脑/手机浏览器直接打开',
      icon: FileCode2,
    },
    {
      id: 'markdown',
      title: 'Markdown / 文本摘要',
      desc: '精简清晰文字时间轴，方便微信/Kakao 发送给接诊兽医',
      icon: FileText,
    },
    {
      id: 'json',
      title: 'JSON 结构化归档',
      desc: '完整保留字段与附件数据，用于长期备份或系统迁移',
      icon: Braces,
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            className="relative z-10 w-full max-w-2xl max-h-[90vh] bg-white rounded-2xl border border-[#e4ded1] shadow-2xl flex flex-col overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-[#e4ded1] flex items-center justify-between gap-3 bg-[#faf7f2]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#1b4332] text-white flex items-center justify-center">
                  <Stethoscope className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-[#17211c]">
                    就诊前导出医疗报告 · {pet.name}
                  </h3>
                  <p className="text-xs text-[#6c7972]">
                    选择导出文件类型、报告详细程度与需要提交给兽医的检查记录
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-[#6c7972] hover:bg-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {/* 1. Export Format Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#17211c]">
                  1. 选择导出报告类型
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {formatOptions.map((opt) => {
                    const active = format === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setFormat(opt.id)}
                        className={`p-3 rounded-xl border text-left transition-all flex items-start gap-3 ${
                          active
                            ? 'bg-[#eaf4f1] border-[#1b4332] text-[#17211c]'
                            : 'bg-white border-[#e4ded1] hover:bg-[#faf7f2] text-[#48564f]'
                        }`}
                      >
                        <opt.icon
                          className={`w-4 h-4 mt-0.5 shrink-0 ${
                            active ? 'text-[#1b4332]' : 'text-[#6c7972]'
                          }`}
                        />
                        <div className="space-y-0.5">
                          <div className="text-xs font-bold text-[#17211c]">{opt.title}</div>
                          <div className="text-[11px] text-[#6c7972] leading-snug">{opt.desc}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Content Scope Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#17211c]">
                  2. 选择报告内容详略
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setScope('full')}
                    className={`px-3.5 py-2.5 rounded-xl border text-xs font-semibold text-left transition-colors ${
                      scope === 'full'
                        ? 'bg-[#eaf4f1] border-[#1b4332] text-[#1b4332]'
                        : 'bg-[#faf7f2]/60 border-[#e4ded1] text-[#48564f]'
                    }`}
                  >
                    完整图文医疗报告（含上传图片与附件索引）
                  </button>
                  <button
                    type="button"
                    onClick={() => setScope('summary')}
                    className={`px-3.5 py-2.5 rounded-xl border text-xs font-semibold text-left transition-colors ${
                      scope === 'summary'
                        ? 'bg-[#eaf4f1] border-[#1b4332] text-[#1b4332]'
                        : 'bg-[#faf7f2]/60 border-[#e4ded1] text-[#48564f]'
                    }`}
                  >
                    精简就医速览（仅日期、医院与检查结论）
                  </button>
                </div>
              </div>

              {/* 3. Visit Chief Complaint */}
              <div className="space-y-1.5">
                <label htmlFor="visit-complaint" className="block text-xs font-bold text-[#17211c]">
                  3. 本次就医主诉 / 给接诊兽医的补充备注（可选）
                </label>
                <textarea
                  id="visit-complaint"
                  rows={2}
                  value={visitComplaint}
                  onChange={(e) => setVisitComplaint(e.target.value)}
                  placeholder="例如：近 3 天轻微咳嗽、食欲略降，附上上月血检单供医生对比..."
                  className="w-full rounded-xl border border-[#e4ded1] bg-[#faf7f2]/60 focus:bg-white px-3.5 py-2 text-xs focus:outline-none focus:border-[#2f7d71]"
                />
              </div>

              {/* 4. Records Checklist */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#17211c] tabular-nums">
                    4. 勾选纳入报告的医疗记录 ({chosenRecords.length}/{records.length})
                  </span>
                  <button
                    type="button"
                    onClick={toggleAll}
                    className="text-xs font-semibold text-[#2f7d71] hover:underline"
                  >
                    {selectedIds.length === records.length ? '取消全选' : '全选全部'}
                  </button>
                </div>
                {records.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-[#e4ded1] bg-[#faf7f2] px-3.5 py-3 text-xs text-[#6c7972]">
                    当前暂无已保存的医疗记录；仍可导出包含 {pet.name} 基础档案与本次就诊主诉的就诊概览报告。
                  </div>
                ) : (
                  <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
                    {records.map((rec) => {
                      const checked = selectedIds.includes(rec.id);
                      return (
                        <button
                          key={rec.id}
                          type="button"
                          onClick={() => toggleId(rec.id)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl border text-left text-xs transition-colors ${
                            checked
                              ? 'bg-[#eaf4f1]/60 border-[#2f7d71]/40 text-[#17211c]'
                              : 'bg-white border-[#e4ded1] text-[#6c7972]'
                          }`}
                        >
                          {checked ? (
                            <CheckSquare className="w-4 h-4 text-[#1b4332] shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 shrink-0" />
                          )}
                          <span className="font-mono tabular-nums text-[11px] shrink-0">
                            {rec.date}
                          </span>
                          <span className="font-semibold truncate flex-1">{rec.title}</span>
                          {rec.hospitalName && (
                            <span className="text-[11px] text-[#6c7972] truncate max-w-[140px]">
                              {rec.hospitalName}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-[#e4ded1] bg-[#faf7f2] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-[#e4ded1] bg-white text-xs font-semibold text-[#48564f] hover:bg-[#f3eee4]"
              >
                取消
              </button>
              <button
                type="button"
                disabled={records.length > 0 && chosenRecords.length === 0}
                onClick={handleExport}
                className="px-5 py-2 rounded-xl bg-[#1b4332] hover:bg-[#143326] disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <FileDown className="w-4 h-4" />
                <span>
                  {format === 'pdf-print' ? '生成并打印 / 存为 PDF' : '立即导出报告'}
                </span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
