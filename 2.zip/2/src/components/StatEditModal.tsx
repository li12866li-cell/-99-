import React, { useEffect, useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { PetDietItem } from '../types/pet.ts';

export interface StatEditTarget {
  id: 'diet' | 'weight' | 'water' | 'vaccine' | 'companion';
  label: string;
  initial: string;
}

interface StatEditModalProps {
  stat: StatEditTarget | null;
  onClose: () => void;
  onSave: (value: string) => Promise<void>;
}

export function StatEditModal({ stat, onClose, onSave }: StatEditModalProps) {
  const [val, setVal] = useState('');
  const [dietItems, setDietItems] = useState<PetDietItem[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!stat) return;
    if (stat.id === 'diet') {
      try {
        const parsed = JSON.parse(stat.initial);
        setDietItems(Array.isArray(parsed) ? parsed : [{ name: '', amount: '' }]);
      } catch {
        setDietItems([{ name: '主粮', amount: stat.initial || '' }]);
      }
    } else {
      setVal(stat.initial || '');
    }
  }, [stat]);

  const handleSave = async () => {
    if (!stat || saving) return;
    setSaving(true);
    try {
      if (stat.id === 'diet') {
        await onSave(JSON.stringify(dietItems.filter((item) => item.name.trim() || item.amount.trim())));
      } else {
        await onSave(val);
      }
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {stat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/45 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            className="relative z-10 w-full max-w-md bg-white rounded-2xl border border-slate-200 p-5 shadow-xl space-y-4 max-h-[88vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900">更新{stat.label}</h3>
                <p className="text-xs text-slate-500">修改后会立即同步至宠物档案</p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {stat.id === 'diet' ? (
              <div className="space-y-3">
                {dietItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => {
                        const next = [...dietItems];
                        next[idx] = { ...next[idx], name: e.target.value };
                        setDietItems(next);
                      }}
                      placeholder="食物名称（如犬粮）"
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm"
                    />
                    <input
                      type="number"
                      value={item.amount}
                      onChange={(e) => {
                        const next = [...dietItems];
                        next[idx] = { ...next[idx], amount: e.target.value };
                        setDietItems(next);
                      }}
                      placeholder="克数"
                      className="w-24 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm tabular-nums"
                    />
                    <button
                      type="button"
                      onClick={() => setDietItems(dietItems.filter((_, i) => i !== idx))}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setDietItems([...dietItems, { name: '', amount: '' }])}
                  className="w-full py-2.5 border border-dashed border-slate-300 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" /> 添加饮食条目
                </button>
              </div>
            ) : stat.id === 'vaccine' || stat.id === 'companion' ? (
              <input
                type="date"
                max={stat.id === 'companion' ? new Date().toISOString().split('T')[0] : undefined}
                value={val}
                onChange={(e) => setVal(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#2f7d71]"
              />
            ) : (
              <input
                autoFocus
                type={stat.id === 'weight' ? 'number' : 'text'}
                step={stat.id === 'weight' ? '0.1' : undefined}
                value={val}
                onChange={(e) => setVal(e.target.value)}
                placeholder={stat.id === 'weight' ? '输入体重 (kg)' : '例如：650ml'}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm tabular-nums focus:outline-none focus:border-[#2f7d71]"
              />
            )}

            <div className="flex gap-3 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#2f7d71] hover:bg-[#25645b] disabled:opacity-50"
              >
                {saving ? '保存中...' : '保存'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
