import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { ArrowRight, Download, RotateCcw, Sparkles } from 'lucide-react';
import {
  PetState,
  EnterAppSignal,
  GOLDEN_RETRIEVER_DATA,
  buildGoldenHeadPointCloud,
  buildInfoElements,
  exportGoldenRetrieverJson,
} from '../lib/goldenRetrieverCover.ts';

interface GoldenRetrieverCoverProps {
  /** 用户在 PET_SHAPE 成型后第二次点击时触发，返回跳转信号给主应用 */
  onEnterApp: (signal: EnterAppSignal) => void;
  /** 可选：跳过开场直接进入首页 */
  onSkipToHome?: () => void;
  /** 可选：导出 JSON 后提示回调 */
  onExportJson?: (jsonText: string) => void;
}

// 预分配复用向量，避免动画循环中产生 GC 垃圾
const _scratchTarget = new THREE.Vector3();

/** 检测当前是否运行在软件光栅化 WebGL 环境（如 headless SwiftShader/llvmpipe） */
function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

/** 绘制柔和光晕背景纹理 */
function createHaloTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(128, 128, 8, 128, 128, 126);
  grad.addColorStop(0, 'rgba(255, 232, 178, 0.85)');
  grad.addColorStop(0.45, 'rgba(247, 200, 120, 0.36)');
  grad.addColorStop(0.8, 'rgba(242, 168, 92, 0.10)');
  grad.addColorStop(1, 'rgba(251, 242, 223, 0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** 程序化绘制圆角矩形辅助函数 */
function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

/** 程序化生成信息卡片与标签的 CanvasTexture（零外部文件依赖） */
function createInfoCardTexture(
  kind: 'card' | 'tag',
  title: string,
  subtitle: string | undefined,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = kind === 'card' ? 680 : 540;
  canvas.height = kind === 'card' ? 210 : 150;
  const ctx = canvas.getContext('2d')!;

  const pad = 16;
  const w = canvas.width - pad * 2;
  const h = canvas.height - pad * 2;

  // 柔和阴影 + 暖奶白卡片背景
  ctx.save();
  ctx.shadowColor = 'rgba(156, 107, 59, 0.18)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  drawRoundedRect(ctx, pad, pad, w, h, kind === 'card' ? 32 : 26);
  ctx.fillStyle = kind === 'card' ? 'rgba(255, 251, 242, 0.96)' : 'rgba(255, 253, 247, 0.93)';
  ctx.fill();
  ctx.restore();

  // 浅暖金细边框
  drawRoundedRect(ctx, pad, pad, w, h, kind === 'card' ? 32 : 26);
  ctx.lineWidth = kind === 'card' ? 3 : 2.5;
  ctx.strokeStyle = kind === 'card' ? 'rgba(227, 168, 87, 0.65)' : 'rgba(196, 146, 84, 0.45)';
  ctx.stroke();

  if (kind === 'card') {
    // 左侧小暖金徽章圆点
    ctx.fillStyle = '#E8A849';
    ctx.beginPath();
    ctx.arc(pad + 44, pad + 64, 14, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#5C3A1E';
    ctx.font = 'bold 34px "Plus Jakarta Sans", "PingFang SC", "Microsoft YaHei", sans-serif';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, pad + 76, pad + 64);

    if (subtitle) {
      ctx.fillStyle = '#8F6239';
      ctx.font = '600 24px "Plus Jakarta Sans", "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.fillText(subtitle, pad + 36, pad + 126);
    }
  } else {
    ctx.fillStyle = '#5C3A1E';
    ctx.font = 'bold 28px "Plus Jakarta Sans", "PingFang SC", "Microsoft YaHei", sans-serif';
    ctx.textBaseline = 'middle';
    ctx.fillText(title, pad + 30, pad + (subtitle ? 44 : h / 2));

    if (subtitle) {
      ctx.fillStyle = '#9C6B3B';
      ctx.font = '500 21px "Plus Jakarta Sans", "PingFang SC", "Microsoft YaHei", sans-serif';
      ctx.fillText(subtitle, pad + 30, pad + 86);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

/** 程序化生成爪印或爱心装饰小粒子纹理 */
function createDecorTexture(kind: 'paw' | 'heart', maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  if (kind === 'paw') {
    ctx.fillStyle = 'rgba(196, 134, 68, 0.85)';
    // 主肉垫
    ctx.beginPath();
    ctx.ellipse(64, 78, 22, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    // 四个小脚趾垫
    const toes = [
      { x: 38, y: 50, r: 9 },
      { x: 54, y: 38, r: 9.5 },
      { x: 74, y: 38, r: 9.5 },
      { x: 90, y: 50, r: 9 },
    ];
    for (const toe of toes) {
      ctx.beginPath();
      ctx.arc(toe.x, toe.y, toe.r, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    // 暖珊瑚金爱心
    ctx.fillStyle = 'rgba(235, 138, 102, 0.86)';
    ctx.beginPath();
    ctx.moveTo(64, 96);
    ctx.bezierCurveTo(22, 68, 24, 34, 48, 34);
    ctx.bezierCurveTo(59, 34, 64, 43, 64, 48);
    ctx.bezierCurveTo(64, 43, 69, 34, 80, 34);
    ctx.bezierCurveTo(104, 34, 106, 68, 64, 96);
    ctx.closePath();
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function GoldenRetrieverCover({
  onEnterApp,
  onSkipToHome,
  onExportJson,
}: GoldenRetrieverCoverProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // React 状态用于轻量 UI 文本与提示控制；核心 3D 状态同步存在 Ref 中防止重建 WebGL 画布
  const [petState, setPetState] = useState<PetState>(PetState.SCATTERED);
  const [isShapeFormed, setIsShapeFormed] = useState(false);
  const [webglUnavailable, setWebglUnavailable] = useState(false);

  const petStateRef = useRef<PetState>(PetState.SCATTERED);
  const isShapeFormedRef = useRef<boolean>(false);
  const onEnterAppRef = useRef(onEnterApp);
  onEnterAppRef.current = onEnterApp;

  const triggerEnterSignal = () => {
    const signalPayload: EnterAppSignal = {
      signal: 'ENTER_PET_MAIN_APP',
      state: PetState.PET_SHAPE,
      breedId: GOLDEN_RETRIEVER_DATA.id,
      targetTab: 'home',
      timestamp: new Date().toISOString(),
    };
    window.dispatchEvent(new CustomEvent('petpal:golden-cover-enter', { detail: signalPayload }));
    onEnterAppRef.current(signalPayload);
  };

  /** 画布点击状态机：第一次点击 SCATTERED -> PET_SHAPE；聚合完成后第二次点击 -> 跳转主页面 */
  const handleCanvasClick = () => {
    if (petStateRef.current === PetState.SCATTERED) {
      petStateRef.current = PetState.PET_SHAPE;
      isShapeFormedRef.current = false;
      setPetState(PetState.PET_SHAPE);
      setIsShapeFormed(false);
      return;
    }

    if (petStateRef.current === PetState.PET_SHAPE && isShapeFormedRef.current) {
      triggerEnterSignal();
    }
  };

  const handleResetToScattered = (e: React.MouseEvent) => {
    e.stopPropagation();
    petStateRef.current = PetState.SCATTERED;
    isShapeFormedRef.current = false;
    setPetState(PetState.SCATTERED);
    setIsShapeFormed(false);
  };

  const handleExportData = (e: React.MouseEvent) => {
    e.stopPropagation();
    const jsonText = exportGoldenRetrieverJson();
    if (onExportJson) {
      onExportJson(jsonText);
    }
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const isSoftwareGl = detectSoftwareWebGL();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglUnavailable(true);
      return;
    }

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglUnavailable(true);
    };
    const handleContextRestored = () => {
      setWebglUnavailable(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', handleContextRestored);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0xfbf2df, 0.042);

    // 工作室柔和环境光反射
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 60);
    camera.position.set(0, 0.12, 6.4);

    // 暖冷对比柔光照明
    const hemiLight = new THREE.HemisphereLight(0xfff8e7, 0xd8b894, 0.95);
    scene.add(hemiLight);
    const keyLight = new THREE.DirectionalLight(0xffe6b8, 1.15);
    keyLight.position.set(3, 5, 4);
    scene.add(keyLight);

    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const texturesToDispose: THREE.Texture[] = [];
    const materialsToDispose: THREE.Material[] = [];
    const geometriesToDispose: THREE.BufferGeometry[] = [];

    // 1. 背景柔和奶金光晕面板
    const haloTexture = createHaloTexture();
    texturesToDispose.push(haloTexture);
    const haloMat = new THREE.SpriteMaterial({
      map: haloTexture,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    });
    materialsToDispose.push(haloMat);
    const haloSprite = new THREE.Sprite(haloMat);
    haloSprite.position.set(0, 0.05, -0.8);
    haloSprite.scale.set(5.6, 5.6, 1);
    rootGroup.add(haloSprite);

    // 2. 金毛特征点云层 (Dual Position System + GLSL 呼吸抖动与暖橙柔光光晕)
    const cloudData = buildGoldenHeadPointCloud(1650);
    const cloudGeo = new THREE.BufferGeometry();
    cloudGeo.setAttribute('position', new THREE.BufferAttribute(cloudData.scatterPositions, 3));
    cloudGeo.setAttribute('aScatterPos', new THREE.BufferAttribute(cloudData.scatterPositions, 3));
    cloudGeo.setAttribute('aPetPos', new THREE.BufferAttribute(cloudData.petPositions, 3));
    cloudGeo.setAttribute('aColor', new THREE.BufferAttribute(cloudData.colors, 3));
    cloudGeo.setAttribute('aSize', new THREE.BufferAttribute(cloudData.sizes, 1));
    cloudGeo.setAttribute('aPhase', new THREE.BufferAttribute(cloudData.phases, 1));
    cloudGeo.setAttribute('aWeight', new THREE.BufferAttribute(cloudData.weights, 1));
    geometriesToDispose.push(cloudGeo);

    const cloudMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uMorph: { value: 0 },
        uPixelRatio: { value: renderer.getPixelRatio() },
        uMotionScale: { value: prefersReducedMotion ? 0.15 : 1.0 },
      },
      vertexShader: `
        attribute vec3 aScatterPos;
        attribute vec3 aPetPos;
        attribute vec3 aColor;
        attribute float aSize;
        attribute float aPhase;
        attribute float aWeight;

        uniform float uTime;
        uniform float uMorph;
        uniform float uPixelRatio;
        uniform float uMotionScale;

        varying vec3 vColor;
        varying float vMorph;
        varying float vAlphaPulse;

        void main() {
          vColor = aColor;
          vMorph = uMorph;

          // 五次缓动曲线，柔和收敛无生硬跳变
          float m = uMorph;
          float eased = m * m * m * (m * (m * 6.0 - 15.0) + 10.0);

          // 散开状态拥有更大球形飘动，成形状时保留轻柔呼吸微颤
          float scatterAmp = mix(0.24, 0.022, eased) * aWeight * uMotionScale;
          vec3 drift = vec3(
            sin(uTime * 0.85 + aPhase) * scatterAmp,
            cos(uTime * 0.72 + aPhase * 1.3) * scatterAmp,
            sin(uTime * 0.65 + aPhase * 0.7) * scatterAmp * 0.75
          );

          // 过渡中段加入微弱旋转汇聚螺旋感
          float swirlAngle = (1.0 - eased) * eased * 1.15 * sin(aPhase);
          vec3 basePos = mix(aScatterPos, aPetPos, eased);
          float c = cos(swirlAngle);
          float s = sin(swirlAngle);
          basePos.xz = mat2(c, -s, s, c) * basePos.xz;

          vec3 finalPos = basePos + drift;
          vec4 mvPosition = modelViewMatrix * vec4(finalPos, 1.0);
          gl_Position = projectionMatrix * mvPosition;

          float breath = 1.0 + 0.14 * sin(uTime * 2.1 + aPhase) * uMotionScale;
          gl_PointSize = aSize * breath * uPixelRatio * (390.0 / max(1.2, -mvPosition.z));
          vAlphaPulse = 0.86 + 0.14 * sin(uTime * 1.6 + aPhase);
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vMorph;
        varying float vAlphaPulse;

        void main() {
          vec2 uv = gl_PointCoord - vec2(0.5);
          float dist = length(uv);
          if (dist > 0.5) discard;

          // 中心奶金/特征色实心光核 + 边缘暖橙柔光光晕
          float core = 1.0 - smoothstep(0.0, 0.27, dist);
          float halo = (1.0 - smoothstep(0.15, 0.5, dist)) * 0.62;

          vec3 warmOrangeGlow = vec3(0.95, 0.60, 0.26);
          vec3 rgb = mix(warmOrangeGlow, vColor, smoothstep(0.05, 0.36, core));
          float alpha = clamp(core + halo * 0.65, 0.0, 1.0) * vAlphaPulse;

          gl_FragColor = vec4(rgb, alpha * 0.94);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });
    materialsToDispose.push(cloudMat);

    const pointCloud = new THREE.Points(cloudGeo, cloudMat);
    pointCloud.frustumCulled = false;
    rootGroup.add(pointCloud);

    // 3. 实例化信息组件（重型卡片 / 轻型标签 / 极轻爪印与爱心小粒子）
    const infoSpecs = buildInfoElements();
    const pawTex = createDecorTexture('paw', maxAnisotropy);
    const heartTex = createDecorTexture('heart', maxAnisotropy);
    texturesToDispose.push(pawTex, heartTex);

    const infoEntries = infoSpecs.map((spec) => {
      let tex: THREE.CanvasTexture;
      if (spec.kind === 'card' || spec.kind === 'tag') {
        tex = createInfoCardTexture(spec.kind, spec.title, spec.subtitle, maxAnisotropy);
        texturesToDispose.push(tex);
      } else {
        tex = spec.kind === 'paw' ? pawTex : heartTex;
      }

      const mat = new THREE.SpriteMaterial({
        map: tex,
        transparent: true,
        opacity: spec.kind === 'card' || spec.kind === 'tag' ? 0.96 : 0.85,
        depthWrite: false,
      });
      materialsToDispose.push(mat);

      const sprite = new THREE.Sprite(mat);
      sprite.position.copy(spec.scatterPosition);

      if (spec.kind === 'card') {
        sprite.scale.set(2.05 * spec.scale, 0.64 * spec.scale, 1);
      } else if (spec.kind === 'tag') {
        sprite.scale.set(1.62 * spec.scale, 0.46 * spec.scale, 1);
      } else {
        sprite.scale.set(spec.scale, spec.scale, 1);
      }

      rootGroup.add(sprite);
      return { spec, sprite, mat };
    });

    // 鼠标微视差（指针移动温和倾转视角）
    let pointerX = 0;
    let pointerY = 0;
    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      pointerX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      pointerY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    container.addEventListener('pointermove', handlePointerMove, { passive: true });

    // 自适应画布尺寸
    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      // 窄屏设备稍微拉远相机，保证金毛轮廓及四周标签完整可见
      camera.position.z = w < 640 ? 8.2 : w < 1024 ? 7.2 : 6.4;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
      renderer.setSize(w, h);
      cloudMat.uniforms.uPixelRatio.value = renderer.getPixelRatio();
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    // 动画主循环（遵循 Software-WebGL afterDraw 节流与阻尼插值）
    const clock = new THREE.Clock();
    let morphProgress = 0;
    let frameId = 0;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl?.fenceSync) {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (disposed) return;

      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      const targetMorph = petStateRef.current === PetState.PET_SHAPE ? 1 : 0;
      morphProgress = THREE.MathUtils.damp(
        morphProgress,
        targetMorph,
        prefersReducedMotion ? 10 : 2.35,
        delta
      );

      // 检测聚合动画是否已完成，通知 UI 浮现【点击此处，进入宠物百科主页面】
      if (
        petStateRef.current === PetState.PET_SHAPE &&
        morphProgress > 0.965 &&
        !isShapeFormedRef.current
      ) {
        isShapeFormedRef.current = true;
        setIsShapeFormed(true);
      }

      cloudMat.uniforms.uTime.value = elapsed;
      cloudMat.uniforms.uMorph.value = morphProgress;

      // 光晕随状态柔和呼吸变化
      const haloScale = THREE.MathUtils.lerp(4.4, 5.8, morphProgress) + Math.sin(elapsed * 1.4) * 0.12;
      haloSprite.scale.set(haloScale, haloScale, 1);
      haloMat.opacity = THREE.MathUtils.lerp(0.45, 0.78, morphProgress);

      // 更新所有双位置信息组件与装饰粒子（按各自权重独立飘动）
      const motionScale = prefersReducedMotion ? 0.15 : 1.0;
      const easedMorph =
        morphProgress * morphProgress * morphProgress * (morphProgress * (morphProgress * 6 - 15) + 10);

      for (const { spec, sprite } of infoEntries) {
        _scratchTarget.lerpVectors(spec.scatterPosition, spec.petPosition, easedMorph);
        const amp =
          THREE.MathUtils.lerp(0.32, 0.085, easedMorph) * spec.floatWeight * motionScale;
        const speed = 0.65 + spec.floatWeight * 0.4;

        sprite.position.set(
          _scratchTarget.x + Math.sin(elapsed * speed + spec.phase) * amp,
          _scratchTarget.y + Math.cos(elapsed * speed * 0.85 + spec.phase * 1.2) * amp,
          _scratchTarget.z + Math.sin(elapsed * speed * 0.7 + spec.phase * 0.5) * amp * 0.5
        );
      }

      // 整体轻柔视差响应
      const targetRotY = (prefersReducedMotion ? 0 : pointerX * 0.16) + Math.sin(elapsed * 0.35) * 0.05;
      const targetRotX = prefersReducedMotion ? 0 : -pointerY * 0.09;
      rootGroup.rotation.y = THREE.MathUtils.damp(rootGroup.rotation.y, targetRotY, 4.0, delta);
      rootGroup.rotation.x = THREE.MathUtils.damp(rootGroup.rotation.x, targetRotX, 4.0, delta);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', handleContextRestored);

      geometriesToDispose.forEach((g) => g.dispose());
      materialsToDispose.forEach((m) => m.dispose());
      texturesToDispose.forEach((t) => t.dispose());
      envTarget.dispose();
      renderer.dispose();

      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      className="relative w-full h-screen min-h-[580px] overflow-hidden select-none"
      style={{
        background:
          'radial-gradient(circle at 50% 44%, #FFFDF7 0%, #FBF2DF 52%, #F3DEC0 100%)',
      }}
    >
      {/* 独立 3D WebGL 画布容器：点击触发状态机流转 */}
      <div
        ref={mountRef}
        onClick={handleCanvasClick}
        role="button"
        tabIndex={0}
        aria-label={
          petState === PetState.SCATTERED
            ? '点击画布聚合生成金毛 3D 轮廓'
            : isShapeFormed
              ? '点击此处，进入宠物健康主页面'
              : '金毛轮廓聚合中'
        }
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleCanvasClick();
          }
        }}
        className="absolute inset-0 w-full h-full cursor-pointer focus:outline-none"
      />

      {/* WebGL 不可用时的温暖静态兜底层 */}
      {webglUnavailable && (
        <div
          onClick={handleCanvasClick}
          className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center cursor-pointer"
        >
          <div className="w-40 h-40 rounded-full bg-amber-100/90 border border-amber-300/60 flex items-center justify-center shadow-lg mb-5">
            <Sparkles className="w-16 h-16 text-amber-600" />
          </div>
          <h2 className="text-2xl font-bold text-[#5C3A1E]">{GOLDEN_RETRIEVER_DATA.name}</h2>
          <p className="text-sm text-[#8F6239] mt-1">{GOLDEN_RETRIEVER_DATA.englishName} · {GOLDEN_RETRIEVER_DATA.tagline}</p>
        </div>
      )}

      {/* 顶部左上角极简品牌与标题层（绝不遮挡画面中央 3D 金毛） */}
      <header className="pointer-events-none absolute top-0 left-0 right-0 z-10 flex items-start justify-between p-5 sm:p-7">
        <div className="space-y-1">
          <div className="text-xs font-semibold tracking-wide text-[#9C6B3B]">
            PetPal Health · 宠爱脉动开场互动封面
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#4E3118] tracking-tight">
            Golden Retriever 金毛启动首页
          </h1>
          <div className="text-xs text-[#8C5E35]">
            <span>{GOLDEN_RETRIEVER_DATA.name}</span>
            <span className="mx-1.5" aria-hidden="true">·</span>
            <span>{GOLDEN_RETRIEVER_DATA.tagline}</span>
            <span className="mx-1.5" aria-hidden="true">·</span>
            <span>状态：{petState}</span>
          </div>
        </div>

        {onSkipToHome && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSkipToHome();
            }}
            className="pointer-events-auto px-3.5 py-2 rounded-xl text-xs font-semibold text-[#6E4521] bg-[#FFFDF8]/90 hover:bg-white border border-[#D9B382]/50 shadow-xs transition-colors whitespace-nowrap shrink-0"
          >
            跳过封面进入首页
          </button>
        )}
      </header>

      {/* 中央偏下提示浮层：聚合完成时浮现【点击此处，进入宠物百科主页面】 */}
      <div className="pointer-events-none absolute inset-x-0 bottom-24 z-10 flex justify-center px-4">
        {petState === PetState.SCATTERED && (
          <div
            className="px-5 py-2.5 rounded-2xl border border-[#DFB985]/60 text-xs sm:text-sm font-semibold text-[#6E4521] shadow-sm"
            style={{ backgroundColor: 'rgba(255, 251, 242, 0.88)' }}
          >
            轻触画布任意位置，将星尘粒子聚合为金毛轮廓
          </div>
        )}

        {petState === PetState.PET_SHAPE && !isShapeFormed && (
          <div
            className="px-5 py-2.5 rounded-2xl border border-[#DFB985]/60 text-xs sm:text-sm font-semibold text-[#8A5B2F] shadow-sm"
            style={{ backgroundColor: 'rgba(255, 251, 242, 0.88)' }}
          >
            金毛轮廓暖光聚合中，请稍候...
          </div>
        )}

        {petState === PetState.PET_SHAPE && isShapeFormed && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              triggerEnterSignal();
            }}
            className="pointer-events-auto group flex items-center gap-2.5 px-6 py-3 rounded-2xl text-sm sm:text-base font-bold text-white shadow-lg transition-transform hover:scale-[1.02] active:scale-[0.98]"
            style={{
              background: 'linear-gradient(135deg, #D98A3C 0%, #B86B2B 100%)',
              boxShadow: '0 10px 28px rgba(184, 107, 43, 0.28)',
            }}
          >
            <span>【点击此处，进入系统主页面】</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
        )}
      </div>

      {/* 底部居中精简功能栏（无 backdrop-filter，保证 WebGL 零卡顿） */}
      <div className="pointer-events-none absolute inset-x-0 bottom-5 z-10 flex justify-center px-4">
        <div
          className="pointer-events-auto flex items-center gap-2 px-3 py-2 rounded-2xl border border-[#DFB985]/55 shadow-sm"
          style={{ backgroundColor: 'rgba(255, 251, 242, 0.92)' }}
        >
          {petState === PetState.PET_SHAPE && (
            <button
              type="button"
              onClick={handleResetToScattered}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6E4521] hover:bg-[#F5E5CB]/70 transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>重播散开状态</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleExportData}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-[#6E4521] hover:bg-[#F5E5CB]/70 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>导出金毛百科 JSON</span>
          </button>
        </div>
      </div>
    </div>
  );
}
