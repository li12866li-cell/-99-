import React from 'react';
import { AlertCircle, Check, RotateCcw, ArrowLeft } from 'lucide-react';
import { Pet } from '../../types/pet.ts';
import { SymptomRuleItem } from '../../lib/symptomMatcher.ts';
import { AnimatedCompanionSvg, PawPrintIcon } from './SymptomIllustrations.tsx';

export const CHECK_STAGES = [
  '正在整理症状信息',
  '正在匹配本地健康知识库',
  '正在分析症状风险',
  '正在生成健康提示',
] as const;

interface PetCheckAnimationProps {
  pet: Pet | null;
  stageIndex: number;
  progress: number;
  selectedSymptoms: SymptomRuleItem[];
  errorMessage: string | null;
  onRetry: () => void;
  onBackToEdit: () => void;
}

export function PetCheckAnimation({
  pet,
  stageIndex,
  progress,
  selectedSymptoms,
  errorMessage,
  onRetry,
  onBackToEdit,
}: PetCheckAnimationProps) {
  if (errorMessage) {
    return (
      <section className="wellness-card rounded-3xl p-6 sm:p-8 border-[#f48ca3] bg-[#fff0f4]/60 space-y-5 animate-card-enter">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[#d9385a] text-white flex items-center justify-center shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div className="space-y-1.5 flex-1">
            <h2 className="text-lg font-bold text-[#9c2341]">
              健康检查请求未能完成（后端分析服务未就绪）
            </h2>
            <p className="text-sm text-[#4c5e56] leading-relaxed">{errorMessage}</p>
            <p className="text-xs text-[#72847c] leading-relaxed">
              请确认已启动 Python FastAPI 服务（或当前 Node/Python 服务运行正常），系统不会在服务未响应时伪造分析结果。
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            type="button"
            onClick={onRetry}
            className="btn-press min-h-[44px] px-5 py-2.5 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>重试检查</span>
          </button>
          <button
            type="button"
            onClick={onBackToEdit}
            className="btn-press min-h-[44px] px-5 py-2.5 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#fffbf2] text-[#1f2e28] text-sm font-semibold flex items-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>返回修改症状</span>
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="wellness-card rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-[#fffbf2] via-white to-[#e6f7f1]/55 space-y-6 animate-card-enter">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Left Doctor Pet + Stethoscope Heartbeat + Bouncing Paws */}
        <div className="md:col-span-5 flex flex-col items-center justify-center space-y-3">
          <div className="relative rounded-3xl bg-white border border-[#e9e4d8] px-6 py-4 flex flex-col items-center">
            <AnimatedCompanionSvg
              species={pet?.species || 'dog'}
              mode="doctor"
              className="w-36 h-32 sm:w-40 sm:h-36"
            />

            {/* ECG Heartbeat Wave SVG */}
            <svg viewBox="0 0 160 28" className="w-36 h-7 mt-1" aria-hidden="true">
              <path
                d="M0 14 H42 L52 14 L58 4 L66 24 L74 8 L80 18 L86 14 H160"
                fill="none"
                stroke="#e9e4d8"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M0 14 H42 L52 14 L58 4 L66 24 L74 8 L80 18 L86 14 H160"
                fill="none"
                stroke="#2f9e7e"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="ecg-wave-line"
              />
            </svg>
          </div>

          {/* 3 Sequential Bouncing Paw Prints */}
          <div className="flex items-center gap-2.5 text-[#2f9e7e]" aria-hidden="true">
            <span className="paw-step-1 inline-flex">
              <PawPrintIcon className="w-4 h-4" />
            </span>
            <span className="paw-step-2 inline-flex text-[#ffb074]">
              <PawPrintIcon className="w-4 h-4" />
            </span>
            <span className="paw-step-3 inline-flex text-[#f48ca3]">
              <PawPrintIcon className="w-4 h-4" />
            </span>
          </div>
        </div>

        {/* Right Progress & Real Execution Stages */}
        <div className="md:col-span-7 space-y-4">
          <div className="space-y-1">
            <div className="text-xs font-semibold text-[#2f9e7e]">
              正在执行 Python 本地分诊规则引擎
            </div>
            <h2 className="text-xl font-bold text-[#1f2e28]">
              {pet?.name ? `正在为 ${pet.name} 进行健康排查` : '正在进行症状风险排查'}
            </h2>
            <p className="text-xs text-[#72847c]">
              本次核对症状：{selectedSymptoms.map((s) => s.name).join('、')}
            </p>
          </div>

          {/* Smooth Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold text-[#4c5e56] tabular-nums">
              <span>{CHECK_STAGES[Math.min(stageIndex, CHECK_STAGES.length - 1)]}</span>
              <span className="font-mono text-[#2f9e7e]">{progress}%</span>
            </div>
            <div className="h-3 w-full rounded-full bg-[#e6f7f1] overflow-hidden border border-[#2f9e7e]/15">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#2f9e7e] to-[#ffb074]"
                style={{
                  width: `${Math.max(8, progress)}%`,
                  transition: 'width 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
                }}
              />
            </div>
          </div>

          {/* 4 Stage Steps */}
          <ol className="space-y-2 pt-1">
            {CHECK_STAGES.map((label, idx) => {
              const isDone = idx < stageIndex;
              const isActive = idx === stageIndex;
              return (
                <li
                  key={label}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-2xl border text-xs sm:text-sm transition-all duration-200 ${
                    isActive
                      ? 'bg-[#e6f7f1] border-[#2f9e7e]/50 text-[#1f5c4b] font-semibold'
                      : isDone
                      ? 'bg-white border-[#e9e4d8] text-[#4c5e56]'
                      : 'bg-[#fffbf2]/60 border-[#e9e4d8]/70 text-[#72847c]'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 ${
                      isDone
                        ? 'bg-[#2f9e7e] text-white'
                        : isActive
                        ? 'bg-[#ffb074] text-white'
                        : 'bg-[#e9e4d8] text-[#72847c]'
                    }`}
                  >
                    {isDone ? <Check className="w-3 h-3" /> : idx + 1}
                  </span>
                  <span>{label}</span>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
