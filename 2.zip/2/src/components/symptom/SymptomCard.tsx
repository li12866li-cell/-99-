import React from 'react';
import { Check } from 'lucide-react';
import { SymptomRuleItem } from '../../lib/symptomMatcher.ts';
import { SymptomIconIllustration } from './SymptomIllustrations.tsx';

interface SymptomCardProps {
  symptom: SymptomRuleItem;
  selected: boolean;
  onToggle: (id: string) => void;
}

export function SymptomCard({ symptom, selected, onToggle }: SymptomCardProps) {
  const badgeMeta = symptom.isBaselineNormal
    ? { label: '日常状态', textClass: 'text-[#2f9e7e]' }
    : symptom.severity === 'emergency'
    ? { label: '高危急症信号', textClass: 'text-[#d9385a]' }
    : symptom.severity === 'urgent'
    ? { label: '建议尽早就医', textClass: 'text-[#ea7d2b]' }
    : { label: '居家观察项', textClass: 'text-[#2f9e7e]' };

  return (
    <button
      type="button"
      onClick={() => onToggle(symptom.id)}
      aria-pressed={selected}
      className={`group relative w-full min-w-0 min-h-[76px] p-4 rounded-2xl border-2 text-left flex items-start gap-3.5 cursor-pointer touch-manipulation select-none transition-all duration-200 hover:scale-[1.012] active:scale-[0.985] ${
        selected
          ? 'bg-[#e6f7f1]/80 border-[#2f9e7e] text-[#1f2e28] shadow-sm symptom-card-selected'
          : 'bg-[#fffbf2]/80 border-[#e9e4d8] hover:border-[#2f9e7e]/55 hover:bg-white text-[#4c5e56]'
      }`}
    >
      <SymptomIconIllustration
        symptomId={symptom.id}
        severity={symptom.severity}
        selected={selected}
      />

      <div className="flex-1 min-w-0 space-y-1.5">
        <div className="flex items-start justify-between gap-2">
          <span className="text-[16px] font-semibold text-[#1f2e28] leading-[1.45] break-words">
            {symptom.name}
          </span>

          {/* Clear Selected Status Indicator */}
          <span
            className={`shrink-0 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[12px] font-medium whitespace-nowrap transition-colors ${
              selected
                ? 'bg-[#2f9e7e] text-white'
                : 'bg-white border border-[#d6d0c2] text-[#72847c] group-hover:border-[#2f9e7e]/60'
            }`}
          >
            {selected ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>已选</span>
              </>
            ) : (
              <span>选择</span>
            )}
          </span>
        </div>

        <div className="flex items-center gap-2 text-[13px] font-normal flex-wrap">
          <span className={`font-medium ${badgeMeta.textClass}`}>{badgeMeta.label}</span>
          <span aria-hidden="true" className="text-[#c5beb0]">
            ·
          </span>
          <span className="text-[#72847c]">{symptom.category}</span>
        </div>

        <p className="text-[14px] text-[#4c5e56] leading-[1.6] font-normal break-words">
          {symptom.hint}
        </p>
      </div>
    </button>
  );
}
