import React, { useState } from 'react';
import { ArrowRight, Clock, Sparkles } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { Pet } from '../../types/pet.ts';
import { PetMascot } from './PetMascot.tsx';

interface PetWelcomeProps {
  pet: Pet | null;
  historyCount: number;
  onStartCheck: () => void;
  onOpenHistory: () => void;
}

export function PetWelcome({
  pet,
  historyCount,
  onStartCheck,
  onOpenHistory,
}: PetWelcomeProps) {
  const prefersReducedMotion = useReducedMotion();
  const [pettedCount, setPettedCount] = useState(0);

  const speciesLabel =
    pet?.species === 'cat'
      ? '猫咪'
      : pet?.species === 'bunny'
      ? '兔子'
      : pet?.species === 'dog'
      ? '狗狗'
      : '爱宠';

  return (
    <section className="wellness-card rounded-3xl p-6 sm:p-10 bg-gradient-to-br from-[#fffbf2] via-white to-[#e6f7f1]/60 overflow-hidden">
      <div className="max-w-3xl mx-auto flex flex-col items-center text-center space-y-6">
        {/* Current Pet Identity Pill */}
        {pet && (
          <motion.div
            initial={prefersReducedMotion ? false : { opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-white border border-[#e9e4d8] shadow-xs"
          >
            {pet.avatar ? (
              <img
                src={pet.avatar}
                alt={pet.name}
                className="w-10 h-10 rounded-full object-cover border border-[#2f9e7e]/35 shrink-0"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[#e6f7f1] text-[#1f5c4b] flex items-center justify-center font-bold text-sm shrink-0">
                {pet.name.slice(0, 1)}
              </div>
            )}
            <div className="text-left min-w-0">
              <div className="text-sm font-semibold text-[#1f2e28] truncate">
                当前检查对象：{pet.name}
              </div>
              <div className="text-[13px] text-[#72847c] tabular-nums">
                {speciesLabel}
                {pet.breed ? ` · ${pet.breed}` : ''}
                {pet.weight ? ` · ${pet.weight} kg` : ''}
              </div>
            </div>
          </motion.div>
        )}

        {/* Stage 1 Pet Entrance from Bottom + Interactive Tilt & Hearts */}
        <div className="pet-slide-enter-bottom relative flex flex-col items-center pt-2">
          <div className="relative rounded-full bg-gradient-to-b from-[#e6f7f1]/70 to-[#fff3e6]/60 p-6 sm:p-8 border border-[#2f9e7e]/20 shadow-inner">
            <PetMascot
              species={pet?.species || 'dog'}
              mood="welcome"
              interactive
              className="w-40 h-36 sm:w-48 sm:h-44"
              onInteract={() => setPettedCount((c) => c + 1)}
            />
          </div>
          <span className="mt-2.5 inline-flex items-center gap-1.5 text-[14px] text-[#72847c]">
            <Sparkles className="w-4 h-4 text-[#ffb074]" />
            <span>
              {pettedCount > 0
                ? `${pet?.name || '宝贝'} 感受到你的安抚啦（已轻抚 ${pettedCount} 次）`
                : '鼠标悬停会轻轻歪头，点击宠物还能触发爱心陪伴粒子'}
            </span>
          </span>
        </div>

        {/* Welcome Copy with Fade-in Animation */}
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.48, delay: 0.18 }}
          className="space-y-3 max-w-2xl"
        >
          <h2 className="text-[24px] font-semibold text-[#1f2e28] leading-[1.35]">
            你好呀！今天宝贝感觉怎么样？
          </h2>
          <p className="text-[16px] text-[#4c5e56] leading-[1.7] font-normal">
            让我们一起了解宝贝的健康状况，给它多一点关爱。
          </p>
        </motion.div>

        {/* Primary CTA + Optional History Button */}
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.48, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2 w-full sm:w-auto"
        >
          <button
            type="button"
            onClick={onStartCheck}
            className="btn-press w-full sm:w-auto min-h-[50px] px-7 py-3 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-[16px] font-semibold inline-flex items-center justify-center gap-2.5 shadow-sm cursor-pointer whitespace-nowrap shrink-0"
          >
            <span>开始健康自查</span>
            <ArrowRight className="w-5 h-5" />
          </button>

          {historyCount > 0 && (
            <button
              type="button"
              onClick={onOpenHistory}
              className="btn-press w-full sm:w-auto min-h-[50px] px-5 py-3 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#fffbf2] text-[#4c5e56] text-[16px] font-medium inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Clock className="w-4 h-4 text-[#2f9e7e]" />
              <span>查看历史记录 ({historyCount})</span>
            </button>
          )}
        </motion.div>
      </div>
    </section>
  );
}
