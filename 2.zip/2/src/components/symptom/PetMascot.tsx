import React, { useState } from 'react';
import { Heart, ShieldAlert } from 'lucide-react';
import { Pet } from '../../types/pet.ts';

export type PetMascotMood =
  | 'welcome'
  | 'companion'
  | 'doctor'
  | 'watch'
  | 'urgent'
  | 'emergency'
  | 'comfort-happy'
  | 'comfort-gentle';

interface HeartParticle {
  id: number;
  left: string;
  tx: string;
  tx2: string;
  size: number;
}

interface PetMascotProps {
  species?: Pet['species'] | string;
  mood?: PetMascotMood;
  interactive?: boolean;
  className?: string;
  onInteract?: () => void;
}

export function PetMascot({
  species = 'dog',
  mood = 'welcome',
  interactive = true,
  className = 'w-40 h-36 sm:w-48 sm:h-44',
  onInteract,
}: PetMascotProps) {
  const [particles, setParticles] = useState<HeartParticle[]>([]);
  const [hopKey, setHopKey] = useState(0);

  const isDoctor = mood === 'doctor';
  const isEmergency = mood === 'emergency';
  const isUrgent = mood === 'urgent';
  const isHappy = mood === 'comfort-happy' || mood === 'watch';
  const isGentle = mood === 'comfort-gentle' || mood === 'companion';
  const allowPlayful = interactive && !isEmergency;

  // Tail behavior strictly matches clinical mood (never wagging happily on emergency!)
  const tailClass = isEmergency
    ? ''
    : isUrgent
    ? ''
    : isHappy
    ? 'pet-tail-wag-fast'
    : 'pet-tail-wag';

  const bodyClass = isEmergency
    ? ''
    : isUrgent
    ? 'pet-breathe'
    : isDoctor
    ? 'pet-breathe pet-doctor-observe'
    : 'pet-breathe';

  const handleClick = () => {
    if (!allowPlayful) return;
    setHopKey((k) => k + 1);
    const now = Date.now();
    const burst: HeartParticle[] = [
      { id: now + 1, left: '26%', tx: '-14px', tx2: '-24px', size: 16 },
      { id: now + 2, left: '50%', tx: '2px', tx2: '-4px', size: 18 },
      { id: now + 3, left: '72%', tx: '14px', tx2: '24px', size: 15 },
    ];
    setParticles((prev) => [...prev.slice(-6), ...burst]);
    setTimeout(() => {
      setParticles((prev) => prev.filter((p) => p.id < now));
    }, 1050);
    onInteract?.();
  };

  const renderDoctorAccessory = () => {
    if (!isDoctor) return null;
    return (
      <g>
        {/* 3D-styled Nurse/Doctor Cap */}
        <path
          d="M65 36 C67 21, 113 21, 115 36 Z"
          fill="#ffffff"
          stroke="#2f9e7e"
          strokeWidth="2.2"
          strokeLinejoin="round"
        />
        <rect
          x="62"
          y="33"
          width="56"
          height="9"
          rx="4.5"
          fill="#e6f7f1"
          stroke="#2f9e7e"
          strokeWidth="2"
        />
        <path d="M90 25 V33 M86 29 H94" stroke="#2f9e7e" strokeWidth="2.2" strokeLinecap="round" />

        {/* Stethoscope */}
        <path
          d="M66 96 C64 114, 78 122, 90 122 C102 122, 116 114, 114 96"
          fill="none"
          stroke="#1f5c4b"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path d="M90 122 L90 131" stroke="#1f5c4b" strokeWidth="3" strokeLinecap="round" />
        <circle
          cx="90"
          cy="134"
          r="9"
          fill="none"
          stroke="#2f9e7e"
          strokeWidth="1.8"
          className="stethoscope-ripple-1"
        />
        <circle
          cx="90"
          cy="134"
          r="9"
          fill="none"
          stroke="#f48ca3"
          strokeWidth="1.6"
          className="stethoscope-ripple-2"
        />
        <circle cx="90" cy="134" r="6.5" fill="#ffffff" stroke="#1f5c4b" strokeWidth="2.2" />
        <circle cx="90" cy="134" r="2.8" fill="#2f9e7e" />
      </g>
    );
  };

  const renderConcernedBrows = () => {
    if (!isUrgent && !isEmergency) return null;
    const stroke = isEmergency ? '#9c2341' : '#8a420d';
    return (
      <g>
        <path
          d="M66 54 Q73 51 79 55"
          fill="none"
          stroke={stroke}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <path
          d="M114 54 Q107 51 101 55"
          fill="none"
          stroke={stroke}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
      </g>
    );
  };

  const renderExpressionMouth = () => {
    if (isEmergency) {
      return (
        <path
          d="M84 84 Q90 80 96 84"
          fill="none"
          stroke="#9c2341"
          strokeWidth="2.2"
          strokeLinecap="round"
        />
      );
    }
    if (isUrgent) {
      return (
        <path
          d="M85 83 Q90 82 95 83"
          fill="none"
          stroke="#4c5e56"
          strokeWidth="2"
          strokeLinecap="round"
        />
      );
    }
    return (
      <>
        <path
          d="M84 81 Q87 85 90 80 Q93 85 96 81"
          fill="none"
          stroke="#4c5e56"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {(isHappy || isGentle || mood === 'welcome') && (
          <path d="M86.5 83 Q90 90 93.5 83 Z" fill="#f48ca3" opacity="0.9" />
        )}
      </>
    );
  };

  const renderPetSvg = () => {
    if (species === 'cat') {
      return (
        <svg
          viewBox="0 0 180 160"
          className={`${className} select-none overflow-visible drop-shadow-[0_10px_18px_rgba(47,158,126,0.14)]`}
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="catHead3d" cx="42%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#fff4e6" />
              <stop offset="65%" stopColor="#ffe1c4" />
              <stop offset="100%" stopColor="#f7c494" />
            </radialGradient>
            <radialGradient id="catBody3d" cx="45%" cy="35%" r="70%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="70%" stopColor="#fff3e4" />
              <stop offset="100%" stopColor="#f5cfa6" />
            </radialGradient>
          </defs>
          <ellipse cx="90" cy="146" rx="44" ry="8" fill="#dfd7c8" opacity="0.7" />
          <g className={tailClass}>
            <path
              d="M124 126 C152 122, 160 92, 144 82 C136 77, 130 86, 136 94 C142 102, 134 114, 120 116"
              fill="none"
              stroke="#ffb074"
              strokeWidth="10.5"
              strokeLinecap="round"
            />
          </g>
          <g className={bodyClass}>
            <ellipse cx="90" cy="113" rx="37" ry="29" fill="url(#catBody3d)" stroke="#e48f50" strokeWidth="2.3" />
            <ellipse cx="90" cy="116" rx="21" ry="17" fill="#ffffff" />
            <path d="M62 91 Q90 102 118 91 Q114 99 90 104 Q66 99 62 91 Z" fill={isEmergency ? '#d9385a' : '#2f9e7e'} />
            <circle cx="90" cy="102" r="4.8" fill="#ffb074" stroke="#fff" strokeWidth="1.4" />
            <g className={allowPlayful ? 'pet-head-tilt' : ''}>
              <g className={isHappy ? 'pet-ear-perk' : ''}>
                <polygon points="52,58 46,24 76,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.3" strokeLinejoin="round" />
                <polygon points="56,52 52,32 70,45" fill="#f48ca3" opacity="0.75" />
                <polygon points="128,58 134,24 104,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.3" strokeLinejoin="round" />
                <polygon points="124,52 128,32 110,45" fill="#f48ca3" opacity="0.75" />
              </g>
              <ellipse cx="90" cy="69" rx="39" ry="31" fill="url(#catHead3d)" stroke="#e48f50" strokeWidth="2.3" />
              <ellipse cx="75" cy="52" rx="14" ry="7" fill="#ffffff" opacity="0.35" />
              <path d="M84 42 L84 50 M90 40 L90 51 M96 42 L96 50" stroke="#e48f50" strokeWidth="2.3" strokeLinecap="round" />
              <g className={isEmergency ? '' : 'pet-blink'}>
                <ellipse cx="73" cy="68" rx="4.5" ry="5.4" fill="#1f2e28" />
                <circle cx="71.5" cy="66" r="1.7" fill="#ffffff" />
                <ellipse cx="107" cy="68" rx="4.5" ry="5.4" fill="#1f2e28" />
                <circle cx="105.5" cy="66" r="1.7" fill="#ffffff" />
              </g>
              {renderConcernedBrows()}
              {!isEmergency && (
                <>
                  <ellipse cx="62" cy="76" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.85' : '0.5'} />
                  <ellipse cx="118" cy="76" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.85' : '0.5'} />
                </>
              )}
              <polygon points="87,74 93,74 90,78" fill="#f48ca3" />
              {renderExpressionMouth()}
              <path d="M45 71 L58 73 M44 78 L58 78 M122 73 L135 71 M122 78 L136 78" stroke="#c7a98d" strokeWidth="1.8" strokeLinecap="round" />
            </g>
            <ellipse cx="72" cy="138" rx="8.5" ry="5.5" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
            <ellipse cx="108" cy="138" rx="8.5" ry="5.5" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
            {renderDoctorAccessory()}
          </g>
        </svg>
      );
    }

    if (species === 'bunny') {
      return (
        <svg
          viewBox="0 0 180 160"
          className={`${className} select-none overflow-visible drop-shadow-[0_10px_18px_rgba(47,158,126,0.14)]`}
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="bunny3d" cx="42%" cy="32%" r="68%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="72%" stopColor="#fff8fa" />
              <stop offset="100%" stopColor="#f7dde5" />
            </radialGradient>
          </defs>
          <ellipse cx="90" cy="146" rx="38" ry="7.5" fill="#dfd7c8" opacity="0.7" />
          <g className={tailClass}>
            <circle cx="128" cy="126" r="8.5" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2" />
          </g>
          <g className={bodyClass}>
            <ellipse cx="90" cy="115" rx="34" ry="28" fill="url(#bunny3d)" stroke="#e9b7c4" strokeWidth="2.3" />
            <path d="M64 94 Q90 104 116 94 Q112 101 90 106 Q68 101 64 94 Z" fill={isEmergency ? '#d9385a' : '#2f9e7e'} />
            <g className={allowPlayful ? 'pet-head-tilt' : ''}>
              <g className={isHappy ? 'pet-ear-perk' : ''}>
                <ellipse cx="73" cy="31" rx="8.5" ry="22" transform="rotate(-10 73 31)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.3" />
                <ellipse cx="73" cy="33" rx="4.2" ry="13.5" transform="rotate(-10 73 33)" fill="#f48ca3" opacity="0.6" />
                <ellipse cx="107" cy="31" rx="8.5" ry="22" transform="rotate(10 107 31)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.3" />
                <ellipse cx="107" cy="33" rx="4.2" ry="13.5" transform="rotate(10 107 33)" fill="#f48ca3" opacity="0.6" />
              </g>
              <ellipse cx="90" cy="73" rx="35" ry="29" fill="url(#bunny3d)" stroke="#e9b7c4" strokeWidth="2.3" />
              <g className={isEmergency ? '' : 'pet-blink'}>
                <ellipse cx="75" cy="71" rx="4.2" ry="5.1" fill="#1f2e28" />
                <circle cx="73.5" cy="69" r="1.5" fill="#ffffff" />
                <ellipse cx="105" cy="71" rx="4.2" ry="5.1" fill="#1f2e28" />
                <circle cx="103.5" cy="69" r="1.5" fill="#ffffff" />
              </g>
              {renderConcernedBrows()}
              {!isEmergency && (
                <>
                  <ellipse cx="64" cy="79" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.5'} />
                  <ellipse cx="116" cy="79" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.5'} />
                </>
              )}
              <ellipse cx="90" cy="77" rx="3" ry="2.2" fill="#f48ca3" />
              {renderExpressionMouth()}
            </g>
            <ellipse cx="73" cy="138" rx="8.5" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
            <ellipse cx="107" cy="138" rx="8.5" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
            {renderDoctorAccessory()}
          </g>
        </svg>
      );
    }

    // Default: 3D-styled Golden Dog Mascot
    return (
      <svg
        viewBox="0 0 180 160"
        className={`${className} select-none overflow-visible drop-shadow-[0_10px_18px_rgba(47,158,126,0.14)]`}
        aria-hidden="true"
      >
        <defs>
          <radialGradient id="dogHead3d" cx="40%" cy="32%" r="68%">
            <stop offset="0%" stopColor="#fff4dc" />
            <stop offset="65%" stopColor="#ffe3b3" />
            <stop offset="100%" stopColor="#f3c47b" />
          </radialGradient>
          <radialGradient id="dogBody3d" cx="45%" cy="35%" r="68%">
            <stop offset="0%" stopColor="#fff5df" />
            <stop offset="70%" stopColor="#ffe3b3" />
            <stop offset="100%" stopColor="#f2c175" />
          </radialGradient>
        </defs>
        <ellipse cx="90" cy="146" rx="44" ry="8" fill="#dfd7c8" opacity="0.7" />
        <g className={tailClass}>
          <path
            d="M123 122 C145 112, 152 88, 139 82"
            fill="none"
            stroke="#f6c478"
            strokeWidth="11.5"
            strokeLinecap="round"
          />
        </g>
        <g className={bodyClass}>
          <ellipse cx="90" cy="113" rx="37" ry="28.5" fill="url(#dogBody3d)" stroke="#c98636" strokeWidth="2.3" />
          <ellipse cx="90" cy="117" rx="21.5" ry="17.5" fill="#fffaf1" />
          <path d="M62 92 Q90 102 118 92 Q115 99 90 105 Q65 99 62 92 Z" fill={isEmergency ? '#d9385a' : '#2f9e7e'} />
          <circle cx="90" cy="103" r="5" fill="#ffb074" stroke="#ffffff" strokeWidth="1.5" />

          <g className={allowPlayful ? 'pet-head-tilt' : ''}>
            <g className={isHappy ? 'pet-ear-perk' : ''}>
              <ellipse cx="50" cy="68" rx="12.5" ry="23" transform="rotate(14 50 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.3" />
              <ellipse cx="130" cy="68" rx="12.5" ry="23" transform="rotate(-14 130 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.3" />
            </g>
            <ellipse cx="90" cy="67" rx="38" ry="32" fill="url(#dogHead3d)" stroke="#c98636" strokeWidth="2.3" />
            <ellipse cx="75" cy="48" rx="14" ry="7" fill="#ffffff" opacity="0.38" />
            <ellipse cx="90" cy="78" rx="17.5" ry="12.5" fill="#fffaf1" />
            <g className={isEmergency ? '' : 'pet-blink'}>
              <circle cx="74" cy="63" r="4.6" fill="#1f2e28" />
              <circle cx="72.4" cy="61.2" r="1.6" fill="#ffffff" />
              <circle cx="106" cy="63" r="4.6" fill="#1f2e28" />
              <circle cx="104.4" cy="61.2" r="1.6" fill="#ffffff" />
            </g>
            {renderConcernedBrows()}
            {!isEmergency && (
              <>
                <ellipse cx="62" cy="73" rx="5.8" ry="3.3" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.48'} />
                <ellipse cx="118" cy="73" rx="5.8" ry="3.3" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.48'} />
              </>
            )}
            <ellipse cx="90" cy="74" rx="5.3" ry="3.8" fill="#1f2e28" />
            {renderExpressionMouth()}
          </g>

          <ellipse cx="71" cy="138" rx="9.5" ry="5.8" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
          <ellipse cx="109" cy="138" rx="9.5" ry="5.8" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
          {renderDoctorAccessory()}
        </g>
      </svg>
    );
  };

  return (
    <div
      key={hopKey}
      onClick={handleClick}
      role={allowPlayful ? 'button' : undefined}
      tabIndex={allowPlayful ? 0 : undefined}
      onKeyDown={
        allowPlayful
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleClick();
              }
            }
          : undefined
      }
      aria-label={allowPlayful ? '轻触或悬停与宠物互动' : '宠物健康状态形象'}
      className={`group relative inline-flex items-center justify-center focus:outline-none ${
        allowPlayful ? 'cursor-pointer select-none' : ''
      } ${hopKey > 0 && allowPlayful ? 'pet-happy-hop' : ''}`}
    >
      {/* Floating Heart Particles on Click */}
      {particles.length > 0 && (
        <div
          className="pointer-events-none absolute inset-x-0 -top-2 h-14 z-20"
          aria-hidden="true"
        >
          {particles.map((p) => (
            <span
              key={p.id}
              style={
                {
                  left: p.left,
                  '--tx': p.tx,
                  '--tx2': p.tx2,
                } as React.CSSProperties
              }
              className="float-burst-item absolute top-3"
            >
              <Heart
                style={{ width: p.size, height: p.size }}
                className="fill-[#f48ca3] text-[#f48ca3]"
              />
            </span>
          ))}
        </div>
      )}

      {/* Emergency badge indicator when mood is emergency */}
      {isEmergency && (
        <div className="absolute -top-1 -right-1 z-20 w-8 h-8 rounded-full bg-[#d9385a] text-white flex items-center justify-center shadow-md border-2 border-white">
          <ShieldAlert className="w-4 h-4" />
        </div>
      )}

      {renderPetSvg()}
    </div>
  );
}
