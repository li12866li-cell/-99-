import React from 'react';
import { AlertTriangle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { Pet } from '../../types/pet.ts';
import { SymptomMatchResult } from '../../lib/symptomMatcher.ts';
import { PetMascot, PetMascotMood } from './PetMascot.tsx';

interface RiskLevelCardProps {
  result: SymptomMatchResult;
  pet: Pet | null;
}

export function RiskLevelCard({ result, pet }: RiskLevelCardProps) {
  const prefersReducedMotion = useReducedMotion();

  const meta =
    result.level === 'emergency'
      ? {
          label: '紧急就医',
          badgeBg: 'bg-[#d9385a] text-white',
          cardBg: 'bg-[#fff0f4]/80',
          border: 'border-[#f48ca3]',
          titleColor: 'text-[#9c2341]',
          mascotMood: 'emergency' as PetMascotMood,
          mascotCaption: '检测到高危急症信号，请停止等待并立刻前往 24 小时宠物医院急诊。',
          Icon: ShieldAlert,
        }
      : result.level === 'urgent'
      ? {
          label: '需要尽快就医',
          badgeBg: 'bg-[#ea7d2b] text-white',
          cardBg: 'bg-[#fff3e6]/85',
          border: 'border-[#ffb074]',
          titleColor: 'text-[#8a420d]',
          mascotMood: 'urgent' as PetMascotMood,
          mascotCaption: `${pet?.name || '宝贝'} 正安静等待你的关注，建议 12–24 小时内预约线下兽医检查。`,
          Icon: AlertTriangle,
        }
      : {
          label: '一般关注',
          badgeBg: 'bg-[#2f9e7e] text-white',
          cardBg: 'bg-[#e6f7f1]/75',
          border: 'border-[#2f9e7e]/45',
          titleColor: 'text-[#1f5c4b]',
          mascotMood: 'watch' as PetMascotMood,
          mascotCaption: `${pet?.name || '宝贝'} 目前风险可控，继续保持温柔陪伴与饮食观察即可。`,
          Icon: CheckCircle2,
        };

  const StatusIcon = meta.Icon;

  return (
    <div className="space-y-5">
      {/* Part 1: Risk Level Banner */}
      <motion.div
        initial={prefersReducedMotion ? false : { opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.35 }}
        className={`rounded-3xl border p-6 space-y-3 ${meta.cardBg} ${meta.border}`}
      >
        <div className="flex items-center gap-3 flex-wrap">
          <span
            className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-2xl text-[15px] font-semibold whitespace-nowrap ${meta.badgeBg}`}
          >
            <StatusIcon className="w-4 h-4 shrink-0" />
            <span>风险等级：{meta.label}</span>
          </span>
          {pet && (
            <span className="text-[14px] text-[#4c5e56]">
              评估对象：{pet.name}
            </span>
          )}
        </div>

        <h2 className={`text-[24px] font-semibold leading-[1.35] break-words ${meta.titleColor}`}>
          {result.headline}
        </h2>

        <p className="text-[14px] text-[#4c5e56] leading-[1.6]">
          说明：以上分级由本地健康知识库规则直接计算得出，仅作为分诊参考，不代表医学确诊。
        </p>
      </motion.div>

      {/* Part 2: Risk-Responsive Pet Mascot */}
      <div className="rounded-3xl border border-[#e9e4d8] bg-[#fffbf2] p-5 flex flex-col sm:flex-row items-center gap-5">
        <div className="shrink-0">
          <PetMascot
            species={pet?.species || 'dog'}
            mood={meta.mascotMood}
            interactive={result.level !== 'emergency'}
            className="w-32 h-28 sm:w-36 sm:h-32"
          />
        </div>
        <div className="flex-1 min-w-0 text-center sm:text-left space-y-1.5">
          <div className="text-[14px] font-semibold text-[#1f5c4b]">
            {result.level === 'emergency'
              ? '严肃急诊提醒'
              : result.level === 'urgent'
              ? '贴心关注提醒'
              : '日常安抚陪伴'}
          </div>
          <p className="text-[16px] text-[#1f2e28] leading-[1.7] break-words">
            {meta.mascotCaption}
          </p>
        </div>
      </div>
    </div>
  );
}
