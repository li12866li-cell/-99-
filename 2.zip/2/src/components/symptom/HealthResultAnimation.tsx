import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { SymptomMatchResult } from '../../lib/symptomMatcher.ts';
import { Pet } from '../../types/pet.ts';

interface HealthResultAnimationProps {
  result: SymptomMatchResult;
  pet: Pet | null;
}

export function HealthResultAnimation({ result, pet }: HealthResultAnimationProps) {
  const [ringAnimated, setRingAnimated] = useState(false);

  useEffect(() => {
    const id = requestAnimationFrame(() => setRingAnimated(true));
    return () => cancelAnimationFrame(id);
  }, [result]);

  const tone =
    result.level === 'emergency'
      ? {
          bg: 'bg-[#fff0f4]',
          border: 'border-[#f48ca3]',
          text: 'text-[#9c2341]',
          badge: 'bg-[#d9385a] text-white',
          stroke: '#d9385a',
          track: '#fbd5df',
          ringRatio: Math.min(1, Math.max(0.78, result.score / 180)),
          shortLevel: '紧急就医',
        }
      : result.level === 'urgent'
      ? {
          bg: 'bg-[#fff3e6]',
          border: 'border-[#ffb074]',
          text: 'text-[#8a420d]',
          badge: 'bg-[#ea7d2b] text-white',
          stroke: '#ea7d2b',
          track: '#fde3c8',
          ringRatio: Math.min(0.75, Math.max(0.45, result.score / 150)),
          shortLevel: '尽快就医',
        }
      : {
          bg: 'bg-[#e6f7f1]',
          border: 'border-[#2f9e7e]/45',
          text: 'text-[#1f5c4b]',
          badge: 'bg-[#2f9e7e] text-white',
          stroke: '#2f9e7e',
          track: '#cdeee2',
          ringRatio: Math.min(0.42, Math.max(0.18, result.score / 120)),
          shortLevel: '一般关注',
        };

  const size = 104;
  const strokeWidth = 9;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const targetOffset = circumference * (1 - tone.ringRatio);
  const currentOffset = ringAnimated ? targetOffset : circumference;

  return (
    <section
      className={`result-slide-up rounded-3xl border p-5 sm:p-6 space-y-5 ${tone.bg} ${tone.border}`}
    >
      {/* Top Row: Circular SVG Risk Indicator + Headline */}
      <div
        className="result-fade-item flex flex-col sm:flex-row sm:items-center gap-5"
        style={{ animationDelay: '60ms' }}
      >
        {/* Circular SVG Risk Level Indicator (Strictly triage tier & rule score, NOT health %) */}
        <div className="relative w-[104px] h-[104px] shrink-0 mx-auto sm:mx-0 flex items-center justify-center">
          <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="#ffffff"
              fillOpacity="0.85"
              stroke={tone.track}
              strokeWidth={strokeWidth}
            />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={tone.stroke}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={currentOffset}
              style={{
                transition: 'stroke-dashoffset 0.85s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-2">
            <span className="text-[11px] font-bold leading-tight" style={{ color: tone.stroke }}>
              {tone.shortLevel}
            </span>
            <span className="text-xs font-mono font-bold tabular-nums text-[#1f2e28] mt-0.5">
              {result.score} 分
            </span>
          </div>
        </div>

        <div className="flex-1 space-y-2 min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className={`px-3 py-1 rounded-xl text-xs font-bold ${tone.badge}`}>
              {result.levelLabel}
            </span>
            <span className="text-xs font-mono tabular-nums text-[#4c5e56]">
              规则风险分值：{result.score} · 命中 {result.matchedSymptoms.length} 项症状
            </span>
            {pet && (
              <span className="text-xs text-[#72847c]">· 评估对象：{pet.name}</span>
            )}
          </div>

          <h2 className={`text-lg sm:text-xl font-bold leading-snug ${tone.text}`}>
            {result.headline}
          </h2>

          {result.hasHighDangerSignal && (
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#9c2341] bg-white/90 px-3 py-1.5 rounded-xl border border-[#f48ca3]">
              <ShieldAlert className="w-4 h-4 text-[#d9385a]" />
              <span>包含高危急症表现 · 请勿延误线下急诊</span>
            </div>
          )}
        </div>
      </div>

      {/* Matched Symptoms Summary */}
      <div
        className="result-fade-item bg-white/90 rounded-2xl border border-[#e9e4d8] p-4 space-y-2"
        style={{ animationDelay: '150ms' }}
      >
        <div className="text-xs font-bold text-[#1f2e28]">本次核对的已选症状</div>
        <div className="text-xs text-[#4c5e56] leading-relaxed">
          {result.matchedSymptoms.map((s) => s.name).join(' · ')}
        </div>
        {result.matchedCombos.length > 0 && (
          <div className="pt-1.5 border-t border-[#e9e4d8]/80 text-xs text-[#8a420d] font-medium">
            组合规则触发：{result.matchedCombos.map((c) => c.title).join('、')}
          </div>
        )}
      </div>

      {/* Reasoning & Advice Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div
          className="result-fade-item bg-white/95 rounded-2xl border border-[#e9e4d8] p-4 space-y-2.5"
          style={{ animationDelay: '230ms' }}
        >
          <h3 className="text-xs sm:text-sm font-bold text-[#1f2e28] flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-[#ea7d2b]" />
            <span>风险判断依据</span>
          </h3>
          <ul className="space-y-1.5 text-xs text-[#4c5e56] leading-relaxed">
            {result.reasoning.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        </div>

        <div
          className="result-fade-item bg-white/95 rounded-2xl border border-[#e9e4d8] p-4 space-y-2.5"
          style={{ animationDelay: '310ms' }}
        >
          <h3 className="text-xs sm:text-sm font-bold text-[#1f2e28] flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-[#2f9e7e]" />
            <span>建议处理措施</span>
          </h3>
          <ul className="space-y-1.5 text-xs text-[#4c5e56] leading-relaxed">
            {result.adviceList.map((a, i) => (
              <li key={i}>· {a}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Non-diagnostic Disclaimer & Source */}
      <div
        className="result-fade-item text-[11px] text-[#4c5e56] pt-2.5 border-t border-black/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
        style={{ animationDelay: '380ms' }}
      >
        <span>{result.disclaimer}</span>
        <span className="shrink-0 text-[#72847c]">数据来源：{result.knowledgeBaseSource}</span>
      </div>
    </section>
  );
}
