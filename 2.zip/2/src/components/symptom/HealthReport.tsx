import React from 'react';
import {
  AlertTriangle,
  BellRing,
  CheckCircle2,
  ClipboardList,
  MapPin,
  Phone,
  ShieldAlert,
} from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { Pet } from '../../types/pet.ts';
import { SymptomMatchResult } from '../../lib/symptomMatcher.ts';
import { NearbyHospitalContact } from '../../services/symptomService.ts';
import { RiskLevelCard } from './RiskLevelCard.tsx';

interface HealthReportProps {
  result: SymptomMatchResult;
  pet: Pet | null;
  hospitals: NearbyHospitalContact[];
}

export function HealthReport({ result, pet, hospitals }: HealthReportProps) {
  const prefersReducedMotion = useReducedMotion();

  const cardMotion = (delay: number) =>
    prefersReducedMotion
      ? {}
      : {
          initial: { opacity: 0, y: 18 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.38, delay, ease: [0.16, 1, 0.3, 1] as const },
        };

  return (
    <motion.article
      {...cardMotion(0)}
      className="max-w-4xl mx-auto wellness-card rounded-3xl bg-white p-6 sm:p-8 space-y-6 min-w-0"
    >
      {/* Part 1 & Part 2: Risk Level & Risk-Responsive Pet Mascot */}
      <RiskLevelCard result={result} pet={pet} />

      {/* Part 3: Selected Symptoms as Staggered Tags */}
      <motion.section
        {...cardMotion(0.12)}
        className="rounded-3xl border border-[#e9e4d8] bg-[#fffbf2]/75 p-6 space-y-3"
      >
        <h3 className="text-[19px] font-semibold text-[#1f2e28] flex items-center gap-2 leading-[1.4]">
          <ClipboardList className="w-5 h-5 text-[#2f9e7e] shrink-0" />
          <span>本次选择的症状与信息</span>
        </h3>

        <div className="flex flex-wrap gap-2.5">
          {result.matchedSymptoms.map((sym, idx) => (
            <motion.span
              key={sym.id}
              initial={prefersReducedMotion ? false : { opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.24, delay: 0.16 + idx * 0.04 }}
              className={`px-3.5 py-1.5 rounded-xl text-[14px] font-medium border ${
                sym.isBaselineNormal
                  ? 'bg-white border-[#e9e4d8] text-[#4c5e56]'
                  : sym.severity === 'emergency'
                  ? 'bg-[#fff0f4] border-[#f48ca3] text-[#9c2341]'
                  : sym.severity === 'urgent'
                  ? 'bg-[#fff3e6] border-[#ffb074] text-[#8a420d]'
                  : 'bg-[#e6f7f1] border-[#2f9e7e]/45 text-[#1f5c4b]'
              }`}
            >
              {sym.name}
            </motion.span>
          ))}
          {result.durationLabel && (
            <span className="px-3.5 py-1.5 rounded-xl text-[14px] font-medium bg-white border border-[#e9e4d8] text-[#1f5c4b]">
              持续时间：{result.durationLabel}
            </span>
          )}
        </div>

        {result.customNote && (
          <div className="rounded-2xl bg-white border border-[#e9e4d8] px-4 py-3 text-[14px] text-[#4c5e56] leading-[1.6] break-words">
            补充观察：{result.customNote}
          </div>
        )}
      </motion.section>

      {/* Part 4: Risk Judgment Reasoning */}
      <motion.section
        {...cardMotion(0.2)}
        className="rounded-3xl border border-[#e9e4d8] bg-white p-6 space-y-3"
      >
        <h3 className="text-[19px] font-semibold text-[#1f2e28] flex items-center gap-2 leading-[1.4]">
          <AlertTriangle className="w-5 h-5 text-[#ea7d2b] shrink-0" />
          <span>风险判断依据</span>
        </h3>
        <ul className="space-y-2.5 text-[16px] text-[#4c5e56] leading-[1.7] font-normal">
          {result.reasoning.map((reason, idx) => (
            <li key={idx} className="flex items-start gap-2.5 min-w-0">
              <span className="w-1.5 h-1.5 rounded-full bg-[#ea7d2b] mt-2.5 shrink-0" />
              <span className="break-words">{reason}</span>
            </li>
          ))}
        </ul>
      </motion.section>

      {/* Part 5: Suggested Care Measures (Staggered) */}
      <motion.section
        {...cardMotion(0.28)}
        className="rounded-3xl border border-[#e9e4d8] bg-[#fffbf2]/60 p-6 space-y-3"
      >
        <h3 className="text-[19px] font-semibold text-[#1f2e28] flex items-center gap-2 leading-[1.4]">
          <CheckCircle2 className="w-5 h-5 text-[#2f9e7e] shrink-0" />
          <span>建议处理措施</span>
        </h3>
        <ul className="space-y-2.5 text-[16px] text-[#1f2e28] leading-[1.7] font-normal">
          {result.adviceList.map((advice, idx) => (
            <motion.li
              key={idx}
              initial={prefersReducedMotion ? false : { opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.25, delay: 0.3 + idx * 0.05 }}
              className="flex items-start gap-2.5 min-w-0"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#2f9e7e] mt-2.5 shrink-0" />
              <span className="break-words">{advice}</span>
            </motion.li>
          ))}
        </ul>
      </motion.section>

      {/* Part 6: Veterinary Visit Reminder (+ Local Hospital Reference for Emergency) */}
      <motion.section
        {...cardMotion(0.36)}
        className={`rounded-3xl border p-6 space-y-4 ${
          result.level === 'emergency'
            ? 'border-[#d9385a]/65 bg-[#fff0f4]/70'
            : result.level === 'urgent'
            ? 'border-[#ffb074]/70 bg-[#fff3e6]/70'
            : 'border-[#2f9e7e]/35 bg-[#e6f7f1]/50'
        }`}
      >
        <h3 className="text-[19px] font-semibold text-[#1f2e28] flex items-center gap-2 leading-[1.4]">
          {result.level === 'emergency' ? (
            <ShieldAlert className="w-5 h-5 text-[#d9385a] shrink-0" />
          ) : (
            <BellRing className="w-5 h-5 text-[#2f9e7e] shrink-0" />
          )}
          <span>就医提醒</span>
        </h3>

        <p className="text-[16px] text-[#1f2e28] leading-[1.7] font-normal break-words">
          {result.vetReminder}
        </p>

        {result.level === 'emergency' && hospitals.length > 0 && (
          <div className="space-y-2.5 pt-2">
            <div className="text-[14px] font-semibold text-[#9c2341]">
              本地收录宠物医院参考联系方式：
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {hospitals.slice(0, 4).map((hosp) => (
                <div
                  key={hosp.id}
                  className="rounded-2xl bg-white border border-[#f48ca3]/60 p-4 flex flex-col justify-between gap-2.5"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="text-[15px] font-semibold text-[#1f2e28] truncate">
                      {hosp.name}
                    </div>
                    <div className="text-[13px] text-[#4c5e56] flex items-start gap-1.5">
                      <MapPin className="w-4 h-4 text-[#d9385a] shrink-0 mt-0.5" />
                      <span className="break-words">{hosp.address}</span>
                    </div>
                  </div>
                  <a
                    href={`tel:${hosp.phone.replace(/[^0-9+]/g, '')}`}
                    className="btn-press self-start px-3.5 py-2 rounded-xl bg-[#d9385a] hover:bg-[#b82c4a] text-white text-[14px] font-medium inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span className="tabular-nums">{hosp.phone}</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="pt-3 border-t border-black/10 text-[14px] text-[#4c5e56] leading-[1.6] space-y-1">
          <p className="break-words">{result.disclaimer}</p>
          <p className="text-[13px] text-[#72847c]">
            规则数据来源：{result.knowledgeBaseSource} · 更新日期：{result.updatedAt}
          </p>
        </div>
      </motion.section>
    </motion.article>
  );
}
