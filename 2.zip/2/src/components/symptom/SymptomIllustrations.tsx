import React from 'react';
import { Pet } from '../../types/pet.ts';

interface AnimatedCompanionSvgProps {
  species?: Pet['species'] | string;
  mode?: 'welcome' | 'doctor' | 'comfort-happy' | 'comfort-gentle';
  className?: string;
}

export function AnimatedCompanionSvg({
  species = 'dog',
  mode = 'welcome',
  className = 'w-28 h-24 sm:w-32 sm:h-28',
}: AnimatedCompanionSvgProps) {
  const isDoctor = mode === 'doctor';
  const isHappy = mode === 'comfort-happy';
  const isGentle = mode === 'comfort-gentle';
  const tailClass = isHappy ? 'pet-tail-wag-fast' : 'pet-tail-wag';
  const bodyClass = isHappy ? 'pet-breathe pet-happy-hop' : 'pet-breathe';

  const renderDoctorAccessory = () => {
    if (!isDoctor) return null;
    return (
      <g>
        {/* Cute Doctor Cap */}
        <path
          d="M66 36 C68 22, 112 22, 114 36 Z"
          fill="#ffffff"
          stroke="#2f9e7e"
          strokeWidth="2.2"
          strokeLinejoin="round"
        />
        <rect
          x="63"
          y="33"
          width="54"
          height="9"
          rx="4.5"
          fill="#e6f7f1"
          stroke="#2f9e7e"
          strokeWidth="2"
        />
        <path d="M90 25 V33 M86 29 H94" stroke="#2f9e7e" strokeWidth="2.2" strokeLinecap="round" />

        {/* Stethoscope around collar */}
        <path
          d="M66 96 C64 114, 78 122, 90 122 C102 122, 116 114, 114 96"
          fill="none"
          stroke="#1f5c4b"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path d="M90 122 L90 131" stroke="#1f5c4b" strokeWidth="3" strokeLinecap="round" />
        {/* Heartbeat Ripples on Stethoscope Chestpiece */}
        <circle
          cx="90"
          cy="134"
          r="9"
          fill="none"
          stroke="#2f9e7e"
          strokeWidth="1.8"
          className="stethoscope-ripple-1"
        />
        <circle
          cx="90"
          cy="134"
          r="9"
          fill="none"
          stroke="#f48ca3"
          strokeWidth="1.6"
          className="stethoscope-ripple-2"
        />
        <circle cx="90" cy="134" r="6.5" fill="#ffffff" stroke="#1f5c4b" strokeWidth="2.2" />
        <circle cx="90" cy="134" r="2.8" fill="#2f9e7e" />
      </g>
    );
  };

  if (species === 'cat') {
    return (
      <svg viewBox="0 0 180 160" className={`${className} select-none overflow-visible`} aria-hidden="true">
        <ellipse cx="90" cy="145" rx="42" ry="7.5" fill="#e9e4d8" opacity="0.7" />
        <g className={tailClass}>
          <path
            d="M124 126 C152 122, 160 92, 144 82 C136 77, 130 86, 136 94 C142 102, 134 114, 120 116"
            fill="none"
            stroke="#ffb074"
            strokeWidth="10.5"
            strokeLinecap="round"
          />
        </g>
        <g className={bodyClass}>
          <g className={isHappy ? 'pet-ear-perk' : ''}>
            <polygon points="52,58 46,24 76,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.4" strokeLinejoin="round" />
            <polygon points="56,52 52,32 70,45" fill="#f48ca3" opacity="0.75" />
            <polygon points="128,58 134,24 104,44" fill="#ffb074" stroke="#e48f50" strokeWidth="2.4" strokeLinejoin="round" />
            <polygon points="124,52 128,32 110,45" fill="#f48ca3" opacity="0.75" />
          </g>
          <ellipse cx="90" cy="113" rx="37" ry="29" fill="#fff6eb" stroke="#e48f50" strokeWidth="2.4" />
          <ellipse cx="90" cy="116" rx="21" ry="17" fill="#ffffff" />
          <path d="M62 91 Q90 102 118 91 Q114 99 90 104 Q66 99 62 91 Z" fill="#2f9e7e" />
          <circle cx="90" cy="102" r="4.8" fill="#ffb074" stroke="#fff" strokeWidth="1.4" />
          <ellipse cx="90" cy="69" rx="39" ry="31" fill="#ffe1c4" stroke="#e48f50" strokeWidth="2.4" />
          <path d="M84 42 L84 50 M90 40 L90 51 M96 42 L96 50" stroke="#e48f50" strokeWidth="2.4" strokeLinecap="round" />
          <g className="pet-blink">
            <ellipse cx="73" cy="68" rx="4.4" ry="5.3" fill="#1f2e28" />
            <circle cx="71.5" cy="66" r="1.6" fill="#ffffff" />
            <ellipse cx="107" cy="68" rx="4.4" ry="5.3" fill="#1f2e28" />
            <circle cx="105.5" cy="66" r="1.6" fill="#ffffff" />
          </g>
          <ellipse cx="62" cy="76" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.85' : '0.5'} />
          <ellipse cx="118" cy="76" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.85' : '0.5'} />
          <polygon points="87,74 93,74 90,78" fill="#f48ca3" />
          <path d="M83 81 Q86.5 85 90 80 Q93.5 85 97 81" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
          <path d="M45 71 L58 73 M44 78 L58 78 M122 73 L135 71 M122 78 L136 78" stroke="#c7a98d" strokeWidth="1.8" strokeLinecap="round" />
          <ellipse cx="72" cy="138" rx="8.5" ry="5.5" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
          <ellipse cx="108" cy="138" rx="8.5" ry="5.5" fill="#ffffff" stroke="#e48f50" strokeWidth="2" />
          {renderDoctorAccessory()}
        </g>
      </svg>
    );
  }

  if (species === 'bunny') {
    return (
      <svg viewBox="0 0 180 160" className={`${className} select-none overflow-visible`} aria-hidden="true">
        <ellipse cx="90" cy="145" rx="38" ry="7.5" fill="#e9e4d8" opacity="0.7" />
        <g className={tailClass}>
          <circle cx="128" cy="126" r="8.5" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2" />
        </g>
        <g className={bodyClass}>
          <g className={isHappy ? 'pet-ear-perk' : ''}>
            <ellipse cx="73" cy="31" rx="8.5" ry="22" transform="rotate(-10 73 31)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.4" />
            <ellipse cx="73" cy="33" rx="4.2" ry="13.5" transform="rotate(-10 73 33)" fill="#f48ca3" opacity="0.6" />
            <ellipse cx="107" cy="31" rx="8.5" ry="22" transform="rotate(10 107 31)" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.4" />
            <ellipse cx="107" cy="33" rx="4.2" ry="13.5" transform="rotate(10 107 33)" fill="#f48ca3" opacity="0.6" />
          </g>
          <ellipse cx="90" cy="115" rx="34" ry="28" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.4" />
          <path d="M64 94 Q90 104 116 94 Q112 101 90 106 Q68 101 64 94 Z" fill="#2f9e7e" />
          <ellipse cx="90" cy="73" rx="35" ry="29" fill="#ffffff" stroke="#e9b7c4" strokeWidth="2.4" />
          <g className="pet-blink">
            <ellipse cx="75" cy="71" rx="4.1" ry="5" fill="#1f2e28" />
            <circle cx="73.5" cy="69" r="1.5" fill="#ffffff" />
            <ellipse cx="105" cy="71" rx="4.1" ry="5" fill="#1f2e28" />
            <circle cx="103.5" cy="69" r="1.5" fill="#ffffff" />
          </g>
          <ellipse cx="64" cy="79" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.5'} />
          <ellipse cx="116" cy="79" rx="5.5" ry="3.2" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.5'} />
          <ellipse cx="90" cy="77" rx="3" ry="2.2" fill="#f48ca3" />
          <path d="M84 83 Q87 86 90 82 Q93 86 96 83" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
          <ellipse cx="73" cy="138" rx="8.5" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
          <ellipse cx="107" cy="138" rx="8.5" ry="5.5" fill="#fff0f4" stroke="#e9b7c4" strokeWidth="2" />
          {renderDoctorAccessory()}
        </g>
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 180 160" className={`${className} select-none overflow-visible`} aria-hidden="true">
      <ellipse cx="90" cy="145" rx="43" ry="7.5" fill="#e9e4d8" opacity="0.7" />
      <g className={tailClass}>
        <path
          d="M123 122 C145 112, 152 88, 139 82"
          fill="none"
          stroke="#f6c478"
          strokeWidth="11.5"
          strokeLinecap="round"
        />
      </g>
      <g className={bodyClass}>
        <g className={isHappy ? 'pet-ear-perk' : ''}>
          <ellipse cx="50" cy="68" rx="12.5" ry="23" transform="rotate(14 50 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.3" />
          <ellipse cx="130" cy="68" rx="12.5" ry="23" transform="rotate(-14 130 68)" fill="#e7a655" stroke="#c98636" strokeWidth="2.3" />
        </g>
        <ellipse cx="90" cy="113" rx="37" ry="28.5" fill="#ffe6bd" stroke="#c98636" strokeWidth="2.3" />
        <ellipse cx="90" cy="117" rx="21.5" ry="17.5" fill="#fffaf1" />
        <path d="M62 92 Q90 102 118 92 Q115 99 90 105 Q65 99 62 92 Z" fill="#2f9e7e" />
        <circle cx="90" cy="103" r="5" fill="#ffb074" stroke="#ffffff" strokeWidth="1.5" />
        <ellipse cx="90" cy="67" rx="38" ry="32" fill="#ffe6bd" stroke="#c98636" strokeWidth="2.3" />
        <ellipse cx="90" cy="78" rx="17.5" ry="12.5" fill="#fffaf1" />
        <g className="pet-blink">
          <circle cx="74" cy="63" r="4.6" fill="#1f2e28" />
          <circle cx="72.4" cy="61.2" r="1.6" fill="#ffffff" />
          <circle cx="106" cy="63" r="4.6" fill="#1f2e28" />
          <circle cx="104.4" cy="61.2" r="1.6" fill="#ffffff" />
        </g>
        <ellipse cx="62" cy="73" rx="5.8" ry="3.3" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.48'} />
        <ellipse cx="118" cy="73" rx="5.8" ry="3.3" fill="#f48ca3" opacity={isHappy || isGentle ? '0.88' : '0.48'} />
        <ellipse cx="90" cy="74" rx="5.3" ry="3.8" fill="#1f2e28" />
        <path d="M84 81 Q87 85 90 80 Q93 85 96 81" fill="none" stroke="#4c5e56" strokeWidth="2" strokeLinecap="round" />
        {(isHappy || isGentle) && <path d="M86 83 Q90 91 94 83 Z" fill="#f48ca3" />}
        <ellipse cx="71" cy="138" rx="9.5" ry="5.8" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
        <ellipse cx="109" cy="138" rx="9.5" ry="5.8" fill="#fffaf1" stroke="#c98636" strokeWidth="2" />
        {renderDoctorAccessory()}
      </g>
    </svg>
  );
}

export function PawPrintIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <ellipse cx="6.5" cy="9" rx="2" ry="2.6" transform="rotate(-14 6.5 9)" />
      <ellipse cx="10.2" cy="6.4" rx="1.9" ry="2.5" transform="rotate(-5 10.2 6.4)" />
      <ellipse cx="14.4" cy="6.4" rx="1.9" ry="2.5" transform="rotate(6 14.4 6.4)" />
      <ellipse cx="17.8" cy="9.2" rx="2" ry="2.6" transform="rotate(15 17.8 9.2)" />
      <path d="M7.5 15.2c0-2.4 2-4.2 4.5-4.2s4.5 1.8 4.5 4.2c0 1.8-1.4 3.2-3 3.2-.7 0-1-.3-1.5-.3s-.8.3-1.5.3c-1.6 0-3-1.4-3-3.2z" />
    </svg>
  );
}

export function SymptomIconIllustration({
  symptomId,
  severity,
  selected,
}: {
  symptomId: string;
  severity: 'emergency' | 'urgent' | 'watch';
  selected: boolean;
}) {
  const strokeColor = selected
    ? '#1f5c4b'
    : severity === 'emergency'
    ? '#d9385a'
    : severity === 'urgent'
    ? '#ea7d2b'
    : '#2f9e7e';
  const fillSoft = selected
    ? '#ffffff'
    : severity === 'emergency'
    ? '#fff0f4'
    : severity === 'urgent'
    ? '#fff3e6'
    : '#e6f7f1';

  const renderGlyph = () => {
    switch (symptomId) {
      case 'dyspnea':
        return (
          <>
            <path d="M12 6v6m0 0c-2.5 0-4.5 2-4.5 4.5S9.2 21 11 21c.8 0 1-.5 1-1.5v-7.5zm0 0c2.5 0 4.5 2 4.5 4.5S14.8 21 13 21c-.8 0-1-.5-1-1.5" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <path d="M4.5 9.5h3M16.5 9.5h3" stroke="#f48ca3" strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'seizure':
        return (
          <>
            <path d="M13 3L6 14h5l-1 7 8-11h-5l0-7z" fill="#ffb074" fillOpacity="0.35" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
          </>
        );
      case 'poison_suspected':
        return (
          <>
            <path d="M10 4h4v3l4 8.5a2.5 2.5 0 0 1-2.3 3.5H8.3A2.5 2.5 0 0 1 6 15.5L10 7V4z" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <path d="M9 4h6M10.5 13l3 3m0-3l-3 3" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'bloat_distension':
        return (
          <>
            <ellipse cx="12" cy="13.5" rx="6.5" ry="5.5" fill="#ffb074" fillOpacity="0.25" stroke={strokeColor} strokeWidth="2" />
            <path d="M12 5v2.5M7 7l1.5 1.5M17 7l-1.5 1.5" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'urinary_blockage':
        return (
          <>
            <path d="M12 4.5c2.6 3.6 5.2 6.8 5.2 9.8a5.2 5.2 0 1 1-10.4 0c0-3 2.6-6.2 5.2-9.8z" fill="#f48ca3" fillOpacity="0.25" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <path d="M10 15l4-4" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'severe_bleeding':
        return (
          <>
            <rect x="4.5" y="9" width="15" height="6" rx="3" transform="rotate(-35 12 12)" fill="#fff" stroke={strokeColor} strokeWidth="2" />
            <path d="M10.5 10.5l3 3M13.5 10.5l-3 3" stroke="#d9385a" strokeWidth="1.8" strokeLinecap="round" />
          </>
        );
      case 'repeated_vomiting':
        return (
          <>
            <circle cx="12" cy="8.5" r="3.5" fill="none" stroke={strokeColor} strokeWidth="2" />
            <path d="M8 14c1.5 1.8 2.2 3.8 2.2 5.5M12 14.5v5.5M16 14c-1.5 1.8-2.2 3.8-2.2 5.5" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'bloody_diarrhea':
      case 'mild_soft_stool':
        return (
          <>
            <path d="M7 9c0-2 2-3.5 5-3.5s5 1.5 5 3.5c0 1.4-1 2.2-2.2 2.6 1.6.5 2.7 1.6 2.7 3.1 0 2.2-2.3 3.8-5.5 3.8S6.5 16.9 6.5 14.7c0-1.5 1.1-2.6 2.7-3.1C8 11.2 7 10.4 7 9z" fill="#ffb074" fillOpacity="0.28" stroke={strokeColor} strokeWidth="2" />
            <path d="M9.5 14.5h5" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round" />
          </>
        );
      case 'high_fever_lethargy':
        return (
          <>
            <path d="M12 4a2.2 2.2 0 0 0-2.2 2.2v6.6a4 4 0 1 0 4.4 0V6.2A2.2 2.2 0 0 0 12 4z" fill="none" stroke={strokeColor} strokeWidth="2" />
            <circle cx="12" cy="16" r="1.8" fill={strokeColor} />
            <path d="M12 9.5v5" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'anorexia_24h':
      case 'appetite_slightly_down':
        return (
          <>
            <path d="M5 13h14l-1.5 5.5h-11L5 13z" fill="#ffb074" fillOpacity="0.25" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <path d="M7.5 13c1-2.2 2.7-3 4.5-3s3.5.8 4.5 3" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <path d="M9 6.5l1.5 1.5M15 6.5L13.5 8" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round" />
          </>
        );
      case 'eye_squinting':
        return (
          <>
            <path d="M3.5 12s3.5-5 8.5-5 8.5 5 8.5 5-3.5 5-8.5 5-8.5-5-8.5-5z" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <circle cx="12" cy="12" r="2.3" fill={strokeColor} />
          </>
        );
      case 'limping':
        return (
          <>
            <path d="M7 18c0-2.8 2.2-5 5-5s5 2.2 5 5c0 1.4-1.2 2.5-2.6 2.5-.8 0-1.6-.4-2.4-.4s-1.6.4-2.4.4C8.2 20.5 7 19.4 7 18z" fill="#ffb074" fillOpacity="0.28" stroke={strokeColor} strokeWidth="2" />
            <circle cx="7.5" cy="9.5" r="1.5" fill={strokeColor} />
            <circle cx="12" cy="7.5" r="1.5" fill={strokeColor} />
            <circle cx="16.5" cy="9.5" r="1.5" fill={strokeColor} />
          </>
        );
      case 'mild_sneeze':
        return (
          <>
            <path d="M4.5 10.5h8.5a2.2 2.2 0 1 0-2.2-2.2M4.5 14.5h11.5a2.2 2.2 0 1 1-2.2 2.2" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <circle cx="18.5" cy="10" r="1.3" fill="#2f9e7e" />
          </>
        );
      case 'cough':
        return (
          <>
            <circle cx="9.5" cy="12" r="4.5" fill="none" stroke={strokeColor} strokeWidth="2" />
            <path d="M15 9.5l3-1.5M15.5 12h3.5M15 14.5l3 1.5" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'spirit_normal':
        return (
          <>
            <circle cx="12" cy="12" r="7" fill="#e6f7f1" stroke={strokeColor} strokeWidth="2" />
            <path d="M9 11.5h.01M15 11.5h.01" stroke={strokeColor} strokeWidth="2.4" strokeLinecap="round" />
            <path d="M9 14.5c.8 1.2 2 1.8 3 1.8s2.2-.6 3-1.8" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
          </>
        );
      case 'lethargy_mild':
        return (
          <>
            <path d="M15.5 6.5a6.5 6.5 0 1 0 2 9.5 5.2 5.2 0 0 1-2-9.5z" fill="#ffb074" fillOpacity="0.28" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <path d="M15 6h3.5l-3.5 3.5h3.5" fill="none" stroke={strokeColor} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </>
        );
      case 'reduced_activity':
        return (
          <>
            <circle cx="12" cy="12" r="7" fill="none" stroke={strokeColor} strokeWidth="2" />
            <path d="M12 8.5v4l2.5 1.8" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </>
        );
      case 'appetite_normal':
        return (
          <>
            <path d="M5 13h14l-1.5 5.5h-11L5 13z" fill="#2f9e7e" fillOpacity="0.2" stroke={strokeColor} strokeWidth="2" strokeLinejoin="round" />
            <path d="M8.5 9.5c0-1 .7-1.8 1.5-2.2M12 9c0-1 .7-1.8 1.5-2.2M15.5 9.5c0-1 .7-1.8 1.5-2.2" fill="none" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round" />
          </>
        );
      case 'occasional_vomiting':
        return (
          <>
            <circle cx="12" cy="9" r="3.2" fill="none" stroke={strokeColor} strokeWidth="2" />
            <path d="M12 14v4.5M9.5 15.5l-1 3M14.5 15.5l1 3" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round" />
          </>
        );
      default:
        return (
          <>
            <path d="M6 16c1.5-2.5 3.5-3.5 6-3.5s4.5 1 6 3.5" fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" />
            <circle cx="9" cy="8.5" r="1.5" fill={strokeColor} />
            <circle cx="15" cy="8.5" r="1.5" fill={strokeColor} />
          </>
        );
    }
  };

  return (
    <div
      className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border border-black/5 transition-colors"
      style={{ backgroundColor: fillSoft }}
    >
      <svg viewBox="0 0 24 24" className="w-6 h-6" aria-hidden="true">
        {renderGlyph()}
      </svg>
    </div>
  );
}
