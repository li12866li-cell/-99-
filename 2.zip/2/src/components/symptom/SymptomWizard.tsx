import React from 'react';
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Check,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Pet } from '../../types/pet.ts';
import {
  DURATION_OPTIONS,
  DurationOptionId,
  getAllWizardSymptoms,
  SymptomRuleItem,
  WIZARD_STEPS,
} from '../../lib/symptomMatcher.ts';
import { NearbyHospitalContact } from '../../services/symptomService.ts';
import { PetMascot } from './PetMascot.tsx';
import { SymptomCard } from './SymptomCard.tsx';
import { EmergencyAlertAnimation } from './EmergencyAlertAnimation.tsx';

interface SymptomWizardProps {
  pet: Pet | null;
  currentStep: 1 | 2 | 3 | 4;
  selectedIds: string[];
  durationId: DurationOptionId | undefined;
  customNote: string;
  emergencySymptoms: SymptomRuleItem[];
  hospitals: NearbyHospitalContact[];
  onStepChange: (step: 1 | 2 | 3 | 4) => void;
  onToggleSymptom: (id: string) => void;
  onSelectDuration: (id: DurationOptionId) => void;
  onChangeCustomNote: (val: string) => void;
  onClearAll: () => void;
  onBackToWelcome: () => void;
  onSubmitCheck: () => void;
}

export function SymptomWizard({
  pet,
  currentStep,
  selectedIds,
  durationId,
  customNote,
  emergencySymptoms,
  hospitals,
  onStepChange,
  onToggleSymptom,
  onSelectDuration,
  onChangeCustomNote,
  onClearAll,
  onBackToWelcome,
  onSubmitCheck,
}: SymptomWizardProps) {
  const prefersReducedMotion = useReducedMotion();
  const catalog = React.useMemo(() => getAllWizardSymptoms(), []);

  const stepConfig = WIZARD_STEPS.find((s) => s.stepNumber === currentStep) || WIZARD_STEPS[0];
  const stepOptions = React.useMemo(() => {
    const map = new Map(catalog.map((item) => [item.id, item]));
    return stepConfig.optionIds
      .map((id) => map.get(id))
      .filter((item): item is SymptomRuleItem => Boolean(item));
  }, [catalog, stepConfig]);

  const selectedItems = React.useMemo(
    () => catalog.filter((s) => selectedIds.includes(s.id)),
    [catalog, selectedIds]
  );

  const progressPercent = (currentStep / 4) * 100;

  const companionTip =
    emergencySymptoms.length > 0
      ? '注意到高危急症表现！请优先查看上方紧急就医提醒，不要为了完成问卷而耽误送医。'
      : currentStep === 1
      ? `先看看 ${pet?.name || '宝贝'} 今天的精神状态和活动意愿吧～`
      : currentStep === 2
      ? '饮食和排泄能最直接反映肠胃状况，可以多选实际观察到的情况。'
      : currentStep === 3
      ? '如果有呼吸异常、抽搐或疑似误食，勾选后会第一时间弹出急救提示。'
      : '最后一步啦！确认一下持续时间，我马上帮您整理本地健康检查报告。';

  return (
    <div className="max-w-4xl mx-auto space-y-5 min-w-0">
      {/* Top Progress Header */}
      <section className="wellness-card rounded-3xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1 min-w-0">
            <div className="text-[14px] font-semibold text-[#2f9e7e]">
              分步健康问卷 · 第 {currentStep} / 4 步
            </div>
            <h2 className="text-[19px] font-semibold text-[#1f2e28] leading-[1.4]">
              {stepConfig.title}
            </h2>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="px-3 py-1.5 rounded-xl bg-[#e6f7f1] text-[#1f5c4b] text-[14px] font-medium tabular-nums whitespace-nowrap">
              已选 {selectedIds.length} 项
            </span>
          </div>
        </div>

        {/* Visual Progress Bar + Step Pills */}
        <div className="space-y-2.5">
          <div className="h-2.5 w-full rounded-full bg-[#e6f7f1] overflow-hidden">
            <div
              className="h-full rounded-full bg-[#2f9e7e]"
              style={{
                width: `${progressPercent}%`,
                transition: 'width 0.32s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {WIZARD_STEPS.map((step) => {
              const isCurrent = step.stepNumber === currentStep;
              const isPast = step.stepNumber < currentStep;
              return (
                <button
                  key={step.stepNumber}
                  type="button"
                  onClick={() => onStepChange(step.stepNumber)}
                  className={`px-3 py-2 rounded-xl text-[13px] text-left transition-colors cursor-pointer flex items-center gap-2 min-w-0 ${
                    isCurrent
                      ? 'bg-[#2f9e7e] text-white font-semibold'
                      : isPast
                      ? 'bg-[#e6f7f1] text-[#1f5c4b] font-medium hover:bg-[#d6f2e8]'
                      : 'bg-[#fffbf2] text-[#72847c] border border-[#e9e4d8] hover:bg-white'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold shrink-0 ${
                      isCurrent
                        ? 'bg-white text-[#2f9e7e]'
                        : isPast
                        ? 'bg-[#2f9e7e] text-white'
                        : 'bg-[#e9e4d8] text-[#4c5e56]'
                    }`}
                  >
                    {isPast ? <Check className="w-3 h-3" /> : step.stepNumber}
                  </span>
                  <span className="truncate">
                    {step.stepNumber === 1
                      ? '精神与活动'
                      : step.stepNumber === 2
                      ? '饮食与排泄'
                      : step.stepNumber === 3
                      ? '身体与呼吸'
                      : '持续时间'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Immediate Emergency Alert (shown right away during any step if emergency symptoms are picked) */}
      {emergencySymptoms.length > 0 && (
        <EmergencyAlertAnimation
          variant="precheck"
          preCheckEmergencySymptoms={emergencySymptoms}
          hospitals={hospitals}
          loadingHospitals={false}
        />
      )}

      {/* Persistent Pet Companion Banner */}
      <section className="wellness-card rounded-3xl p-4 sm:p-5 bg-gradient-to-r from-[#fffbf2] to-[#e6f7f1]/45 flex flex-col sm:flex-row items-center gap-4">
        <div className="shrink-0">
          <PetMascot
            species={pet?.species || 'dog'}
            mood={emergencySymptoms.length > 0 ? 'urgent' : 'companion'}
            interactive
            className="w-24 h-20 sm:w-28 sm:h-24"
          />
        </div>
        <div className="flex-1 min-w-0 text-center sm:text-left space-y-1">
          <div className="text-[14px] font-semibold text-[#2f9e7e]">
            {pet?.name ? `${pet.name} 的陪伴小助手` : '宠爱脉动陪伴小助手'}
          </div>
          <p className="text-[15px] text-[#1f2e28] leading-[1.6] break-words">
            {companionTip}
          </p>
        </div>
      </section>

      {/* Step Content Area (Fade-in + Slight Slide-up Transition) */}
      <AnimatePresence mode="wait">
        <motion.section
          key={currentStep}
          initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={prefersReducedMotion ? undefined : { opacity: 0, y: -8 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          className="wellness-card rounded-3xl p-5 sm:p-6 space-y-5"
        >
          <div className="space-y-1">
            <h3 className="text-[19px] font-semibold text-[#1f2e28] leading-[1.4]">
              {stepConfig.title}
            </h3>
            <p className="text-[14px] text-[#4c5e56] leading-[1.6]">{stepConfig.subtitle}</p>
          </div>

          {currentStep < 4 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {stepOptions.map((sym) => (
                <SymptomCard
                  key={sym.id}
                  symptom={sym}
                  selected={selectedIds.includes(sym.id)}
                  onToggle={onToggleSymptom}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-5">
              {/* Duration Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {DURATION_OPTIONS.map((opt) => {
                  const isSelected = durationId === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => onSelectDuration(opt.id)}
                      aria-pressed={isSelected}
                      className={`w-full min-w-0 p-4 rounded-2xl border-2 text-left flex items-start gap-3 cursor-pointer transition-all duration-200 hover:scale-[1.012] active:scale-[0.985] ${
                        isSelected
                          ? 'bg-[#e6f7f1]/80 border-[#2f9e7e] shadow-sm symptom-card-selected'
                          : 'bg-[#fffbf2]/80 border-[#e9e4d8] hover:border-[#2f9e7e]/55 hover:bg-white'
                      }`}
                    >
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isSelected
                            ? 'bg-[#2f9e7e] text-white'
                            : 'bg-white border border-[#e9e4d8] text-[#2f9e7e]'
                        }`}
                      >
                        <Clock className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[16px] font-semibold text-[#1f2e28]">
                            {opt.label}
                          </span>
                          {isSelected && (
                            <span className="px-2 py-0.5 rounded-full bg-[#2f9e7e] text-white text-[12px] font-medium whitespace-nowrap shrink-0">
                              已选
                            </span>
                          )}
                        </div>
                        <p className="text-[14px] text-[#4c5e56] leading-[1.6] break-words">
                          {opt.hint}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Optional Local Notes */}
              <div className="space-y-2">
                <label
                  htmlFor="symptom-custom-note"
                  className="block text-[16px] font-medium text-[#1f2e28]"
                >
                  其他补充观察（可选，仅本地保存）
                </label>
                <textarea
                  id="symptom-custom-note"
                  rows={3}
                  value={customNote}
                  onChange={(e) => onChangeCustomNote(e.target.value)}
                  placeholder="例如：今天更换了新猫粮/狗粮、外出散步后开始打喷嚏，或可能接触过的物品..."
                  className="w-full rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/75 focus:bg-white px-4 py-3 text-[16px] text-[#1f2e28] leading-[1.6] focus:outline-none focus:border-[#2f9e7e]"
                />
              </div>
            </div>
          )}

          {/* Selected Summary Bar */}
          <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
            <div className="text-[14px] text-[#4c5e56] leading-[1.6] min-w-0 break-words">
              {selectedItems.length > 0 ? (
                <span>
                  当前已选：<strong className="text-[#1f5c4b] font-semibold">{selectedItems.map((s) => s.name).join('、')}</strong>
                  {durationId
                    ? `（持续：${DURATION_OPTIONS.find((d) => d.id === durationId)?.label}）`
                    : ''}
                </span>
              ) : (
                <span>请在上方卡片中勾选至少一项宝贝目前的状态或症状</span>
              )}
            </div>

            {selectedIds.length > 0 && (
              <button
                type="button"
                onClick={onClearAll}
                className="text-[14px] text-[#72847c] hover:text-[#1f2e28] inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>清空重选</span>
              </button>
            )}
          </div>

          {/* Wizard Navigation Footer */}
          <div className="flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[#e9e4d8]">
            <div>
              {currentStep === 1 ? (
                <button
                  type="button"
                  onClick={onBackToWelcome}
                  className="btn-press w-full sm:w-auto min-h-[46px] px-5 py-2.5 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#fffbf2] text-[#4c5e56] text-[16px] font-medium inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>返回欢迎页</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => onStepChange((currentStep - 1) as 1 | 2 | 3 | 4)}
                  className="btn-press w-full sm:w-auto min-h-[46px] px-5 py-2.5 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#fffbf2] text-[#1f2e28] text-[16px] font-medium inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>上一步</span>
                </button>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {currentStep < 4 ? (
                <button
                  type="button"
                  onClick={() => onStepChange((currentStep + 1) as 1 | 2 | 3 | 4)}
                  className="btn-press min-h-[46px] px-6 py-2.5 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-[16px] font-semibold inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span>下一步</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onSubmitCheck}
                  disabled={selectedIds.length === 0}
                  className="btn-press min-h-[46px] px-6 py-2.5 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-45 text-white text-[16px] font-semibold inline-flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Activity className="w-5 h-5" />
                  <span>开始健康检查 ({selectedIds.length})</span>
                </button>
              )}
            </div>
          </div>
        </motion.section>
      </AnimatePresence>
    </div>
  );
}
