import React from 'react';
import { MapPin, Phone, ShieldAlert, ExternalLink } from 'lucide-react';
import { SymptomMatchResult, SymptomRuleItem } from '../../lib/symptomMatcher.ts';
import { NearbyHospitalContact } from '../../services/symptomService.ts';

interface EmergencyAlertAnimationProps {
  result?: SymptomMatchResult | null;
  preCheckEmergencySymptoms?: SymptomRuleItem[];
  hospitals: NearbyHospitalContact[];
  loadingHospitals: boolean;
  variant?: 'result' | 'precheck';
}

export function EmergencyAlertAnimation({
  result,
  preCheckEmergencySymptoms = [],
  hospitals,
  loadingHospitals,
  variant = 'result',
}: EmergencyAlertAnimationProps) {
  const verifiedPhoneHospitals = hospitals.filter(
    (h) => typeof h.phone === 'string' && h.phone.trim().length >= 5
  );

  if (variant === 'precheck') {
    if (preCheckEmergencySymptoms.length === 0) return null;
    return (
      <div
        role="alert"
        className="emergency-pulse-border rounded-3xl border-2 border-[#d9385a]/75 bg-[#fff0f4] p-5 sm:p-6 space-y-3.5"
      >
        <div className="flex items-start gap-3.5 min-w-0">
          <div className="w-11 h-11 rounded-2xl bg-[#d9385a] text-white flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="text-[19px] font-semibold text-[#9c2341] leading-[1.4] break-words">
              紧急就医提醒：检测到高危急症信号，请勿等待填完问卷！
            </div>
            <p className="text-[16px] text-[#7c1d35] leading-[1.7] font-normal break-words">
              您已选择「{preCheckEmergencySymptoms.map((s) => s.name).join('、')}」。若宝贝此刻状态危急，请立即联系附近 24 小时宠物医院前往急诊。
            </p>
          </div>
        </div>

        {verifiedPhoneHospitals.length > 0 && (
          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            {verifiedPhoneHospitals.slice(0, 2).map((hosp) => (
              <a
                key={hosp.id}
                href={`tel:${hosp.phone.replace(/[^0-9+]/g, '')}`}
                className="btn-press min-h-[42px] px-4 py-2 rounded-2xl bg-[#d9385a] hover:bg-[#b82c4a] text-white text-[14px] font-medium inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Phone className="w-3.5 h-3.5 shrink-0" />
                <span>
                  致电 {hosp.name} ({hosp.phone})
                </span>
              </a>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (!result || result.level !== 'emergency') return null;

  return (
    <section
      role="alert"
      className="emergency-pulse-border rounded-3xl border-2 border-[#d9385a]/80 bg-gradient-to-br from-[#fff0f4] via-white to-[#fff0f4] p-5 sm:p-6 space-y-4 result-slide-up"
    >
      <div className="flex items-start gap-3.5">
        <div className="w-12 h-12 rounded-2xl bg-[#d9385a] text-white flex items-center justify-center shrink-0">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <div className="space-y-1 flex-1 min-w-0">
          <div className="text-xs font-bold text-[#d9385a]">
            紧急就医警示 · 高危急症分诊结果
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-[#9c2341] leading-snug">
            请立即携带爱宠前往最近的 24 小时宠物医院急诊
          </h2>
          <p className="text-xs sm:text-sm text-[#6b1d31] leading-relaxed">
            呼吸困难、抽搐、疑似中毒或严重胃肠失水等症状病情进展迅速，请不要等待观察，立即联系医院做好接诊准备。
          </p>
        </div>
      </div>

      {/* Contact Nearby Pet Hospitals (Only shown when reliable contact info exists) */}
      {loadingHospitals ? (
        <div className="text-xs text-[#9c2341] py-2">正在查询附近合作宠物医院联系方式...</div>
      ) : verifiedPhoneHospitals.length > 0 ? (
        <div className="space-y-2.5 pt-1">
          <div className="text-xs font-bold text-[#9c2341]">
            可联系的宠物医院参考列表（来自本地医院目录）
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {verifiedPhoneHospitals.slice(0, 4).map((hosp) => (
              <div
                key={hosp.id}
                className="rounded-2xl bg-white border border-[#f48ca3]/65 p-3.5 flex flex-col justify-between gap-2.5"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-[#1f2e28] truncate">{hosp.name}</span>
                    {hosp.distanceText && hosp.distanceText !== '距离待定位' && (
                      <span className="text-[11px] font-mono tabular-nums text-[#d9385a] shrink-0">
                        {hosp.distanceText}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#4c5e56] flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#d9385a] shrink-0 mt-0.5" />
                    <span>{hosp.address}</span>
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <a
                    href={`tel:${hosp.phone.replace(/[^0-9+]/g, '')}`}
                    className="btn-press min-h-[40px] px-3.5 py-2 rounded-xl bg-[#d9385a] hover:bg-[#b82c4a] text-white text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span className="tabular-nums">{hosp.phone}</span>
                  </a>
                  {hosp.kakaoMapUrl && (
                    <a
                      href={hosp.kakaoMapUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-press min-h-[40px] px-3 py-2 rounded-xl border border-[#e9e4d8] bg-[#fffbf2] hover:bg-[#f7f1e5] text-[#1f2e28] text-xs font-semibold inline-flex items-center gap-1"
                    >
                      <span>查看位置</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}
