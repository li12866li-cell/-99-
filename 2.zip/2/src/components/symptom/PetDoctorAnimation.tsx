import React from 'react';
import { Check } from 'lucide-react';
import { Pet } from '../../types/pet.ts';
import { SymptomRuleItem } from '../../lib/symptomMatcher.ts';
import { PetMascot } from './PetMascot.tsx';
import { PawPrintIcon } from './SymptomIllustrations.tsx';

export const CHECK_EXECUTION_STAGES = [
  '正在整理宠物症状……',
  '正在匹配本地健康知识库……',
  '正在执行症状规则分析……',
  '正在整理健康检查报告……',
] as const;

interface PetDoctorAnimationProps {
  pet: Pet | null;
  stageIndex: number;
  progress: number;
  selectedSymptoms: SymptomRuleItem[];
}

export function PetDoctorAnimation({
  pet,
  stageIndex,
  progress,
  selectedSymptoms,
}: PetDoctorAnimationProps) {
  const safeStageIndex = Math.min(stageIndex, CHECK_EXECUTION_STAGES.length - 1);

  return (
    <section className="max-w-4xl mx-auto wellness-card rounded-3xl p-6 sm:p-10 bg-gradient-to-br from-[#fffbf2] via-white to-[#e6f7f1]/60 space-y-7 animate-card-enter">
      {/* Top Doctor Pet + Stethoscope Heartbeat Ripples */}
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="relative rounded-3xl bg-white border border-[#e9e4d8] px-8 py-5 shadow-xs flex flex-col items-center">
          <PetMascot
            species={pet?.species || 'dog'}
            mood="doctor"
            interactive={false}
            className="w-40 h-36 sm:w-44 sm:h-40"
          />

          {/* ECG Heartbeat Wave */}
          <svg viewBox="0 0 160 28" className="w-40 h-7 mt-1" aria-hidden="true">
            <path
              d="M0 14 H42 L52 14 L58 4 L66 24 L74 8 L80 18 L86 14 H160"
              fill="none"
              stroke="#e9e4d8"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M0 14 H42 L52 14 L58 4 L66 24 L74 8 L80 18 L86 14 H160"
              fill="none"
              stroke="#2f9e7e"
              strokeWidth="2.4"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="ecg-wave-line"
            />
          </svg>
        </div>

        <div className="space-y-1.5 max-w-xl">
          <div className="text-[14px] font-semibold text-[#2f9e7e]">
            本地 JavaScript 规则分析引擎运行中
          </div>
          <h2 className="text-[24px] font-semibold text-[#1f2e28] leading-[1.35]">
            {pet?.name ? `正在为 ${pet.name} 逐项核对症状规则` : '正在进行本地症状规则分析'}
          </h2>
          <p className="text-[14px] text-[#4c5e56] leading-[1.6] break-words">
            已选择项目：{selectedSymptoms.map((s) => s.name).join('、')}
          </p>
        </div>
      </div>

      {/* Center Dynamic Progress Bar & Stage List */}
      <div className="max-w-2xl mx-auto space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[15px] font-medium text-[#1f2e28] tabular-nums">
            <span>{CHECK_EXECUTION_STAGES[safeStageIndex]}</span>
            <span className="font-mono text-[#2f9e7e] font-semibold">{progress}%</span>
          </div>
          <div className="h-3.5 w-full rounded-full bg-[#e6f7f1] overflow-hidden border border-[#2f9e7e]/20">
            <div
              className="h-full rounded-full bg-gradient-to-r from-[#2f9e7e] to-[#ffb074]"
              style={{
                width: `${Math.max(10, progress)}%`,
                transition: 'width 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
            />
          </div>
        </div>

        <ol className="space-y-2.5">
          {CHECK_EXECUTION_STAGES.map((label, idx) => {
            const isDone = idx < stageIndex;
            const isActive = idx === stageIndex;
            return (
              <li
                key={label}
                className={`flex items-center gap-3 px-4 py-3 rounded-2xl border text-[15px] transition-all ${
                  isActive
                    ? 'bg-[#e6f7f1] border-[#2f9e7e]/50 text-[#1f5c4b] font-semibold'
                    : isDone
                    ? 'bg-white border-[#e9e4d8] text-[#4c5e56]'
                    : 'bg-[#fffbf2]/60 border-[#e9e4d8]/70 text-[#72847c]'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[12px] font-bold shrink-0 ${
                    isDone
                      ? 'bg-[#2f9e7e] text-white'
                      : isActive
                      ? 'bg-[#ffb074] text-white'
                      : 'bg-[#e9e4d8] text-[#72847c]'
                  }`}
                >
                  {isDone ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                </span>
                <span>{label}</span>
              </li>
            );
          })}
        </ol>
      </div>

      {/* Bottom Sequential Bouncing Paw Prints */}
      <div
        className="flex items-center justify-center gap-3.5 pt-2 text-[#2f9e7e]"
        aria-hidden="true"
      >
        <span className="paw-step-1 inline-flex">
          <PawPrintIcon className="w-5 h-5" />
        </span>
        <span className="paw-step-2 inline-flex text-[#ffb074]">
          <PawPrintIcon className="w-5 h-5" />
        </span>
        <span className="paw-step-3 inline-flex text-[#f48ca3]">
          <PawPrintIcon className="w-5 h-5" />
        </span>
      </div>
    </section>
  );
}
