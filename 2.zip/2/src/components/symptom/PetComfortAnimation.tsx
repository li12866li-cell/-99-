import React from 'react';
import {
  BookmarkCheck,
  BookmarkPlus,
  Clock,
  RotateCcw,
  ShieldAlert,
} from 'lucide-react';
import { Pet } from '../../types/pet.ts';
import { SymptomMatchResult } from '../../lib/symptomMatcher.ts';
import { PetMascot } from './PetMascot.tsx';

interface PetComfortAnimationProps {
  pet: Pet | null;
  result: SymptomMatchResult;
  isSaved: boolean;
  saving: boolean;
  historyCount: number;
  onSaveRecord: () => void;
  onViewHistory: () => void;
  onRestart: () => void;
}

export function PetComfortAnimation({
  pet,
  result,
  isSaved,
  saving,
  historyCount,
  onSaveRecord,
  onViewHistory,
  onRestart,
}: PetComfortAnimationProps) {
  const isEmergency = result.level === 'emergency';
  const isWatch = result.level === 'watch';
  const petName = pet?.name || '宝贝';

  return (
    <section
      className={`max-w-4xl mx-auto wellness-card rounded-3xl p-6 sm:p-8 space-y-5 result-fade-item ${
        isEmergency
          ? 'border-[#f48ca3] bg-[#fff0f4]/60'
          : 'bg-gradient-to-br from-white via-[#fffbf2] to-[#e6f7f1]/45'
      }`}
    >
      <div className="flex flex-col md:flex-row items-center gap-6">
        {/* Pet Mascot (NO happy/celebratory interaction on emergency) */}
        <div className="shrink-0">
          <PetMascot
            species={pet?.species || 'dog'}
            mood={
              isEmergency
                ? 'emergency'
                : isWatch
                ? 'comfort-happy'
                : 'comfort-gentle'
            }
            interactive={!isEmergency}
            className="w-32 h-28 sm:w-36 sm:h-32"
          />
        </div>

        <div className="flex-1 min-w-0 space-y-3 text-center md:text-left">
          <div className="inline-flex items-center gap-2 text-[14px] font-semibold text-[#2f9e7e]">
            {isEmergency && <ShieldAlert className="w-4 h-4 text-[#d9385a]" />}
            <span className={isEmergency ? 'text-[#d9385a]' : ''}>
              {isEmergency ? '紧急就医优先提示' : '检查流程结束'}
            </span>
          </div>

          <h3 className="text-[24px] font-semibold text-[#1f2e28] leading-[1.35]">
            本次健康检查已完成
          </h3>

          <p className="text-[16px] text-[#4c5e56] leading-[1.7] font-normal break-words">
            {isEmergency
              ? `当前为紧急风险，请优先安排 ${petName} 前往医院急诊，并可保存本次记录以便就诊时快速向兽医说明症状。`
              : isWatch
              ? `${petName} 的本次基础症状排查已经完成，记得继续细心陪伴与记录日常状态哦。`
              : `已为 ${petName} 整理好关注建议，建议保存本次检查方便预约就诊时与兽医沟通参考。`}
          </p>

          {/* Required 3 Action Buttons */}
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-2">
            <button
              type="button"
              onClick={onSaveRecord}
              disabled={isSaved || saving}
              className={`btn-press min-h-[46px] px-5 py-2.5 rounded-2xl text-[16px] font-semibold inline-flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 ${
                isSaved
                  ? 'bg-[#e6f7f1] text-[#1f5c4b] border border-[#2f9e7e]/40'
                  : 'bg-[#2f9e7e] hover:bg-[#258267] text-white'
              }`}
            >
              {isSaved ? (
                <BookmarkCheck className="w-4 h-4" />
              ) : (
                <BookmarkPlus className="w-4 h-4" />
              )}
              <span>{isSaved ? '已保存本次检查' : saving ? '保存中...' : '保存本次检查'}</span>
            </button>

            <button
              type="button"
              onClick={onViewHistory}
              className="btn-press min-h-[46px] px-5 py-2.5 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#fffbf2] text-[#1f2e28] text-[16px] font-medium inline-flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <Clock className="w-4 h-4 text-[#2f9e7e]" />
              <span>查看历史记录 ({historyCount})</span>
            </button>

            <button
              type="button"
              onClick={onRestart}
              className="btn-press min-h-[46px] px-5 py-2.5 rounded-2xl border border-[#e9e4d8] bg-[#fffbf2] hover:bg-[#f7f1e5] text-[#4c5e56] text-[16px] font-medium inline-flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-4 h-4" />
              <span>重新开始检查</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
