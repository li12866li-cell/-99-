import React from 'react';
import { SymptomRuleItem } from '../../lib/symptomMatcher.ts';
import { PawPrintIcon, SymptomIconIllustration } from './SymptomIllustrations.tsx';

interface SymptomCardAnimationProps {
  symptom: SymptomRuleItem;
  selected: boolean;
  onToggle: (id: string) => void;
}

export function SymptomCardAnimation({
  symptom,
  selected,
  onToggle,
}: SymptomCardAnimationProps) {
  const severityMeta =
    symptom.severity === 'emergency'
      ? { label: '急症信号', textClass: 'text-[#d9385a]' }
      : symptom.severity === 'urgent'
      ? { label: '尽快就医', textClass: 'text-[#ea7d2b]' }
      : { label: '居家观察', textClass: 'text-[#2f9e7e]' };

  return (
    <button
      type="button"
      onClick={() => onToggle(symptom.id)}
      aria-pressed={selected}
      className={`group relative w-full min-h-[72px] p-4 rounded-2xl border-2 text-left flex items-start gap-3.5 cursor-pointer touch-manipulation select-none transition-all duration-200 hover:scale-[1.016] active:scale-[0.975] ${
        selected
          ? 'bg-[#e6f7f1]/75 border-[#2f9e7e] text-[#1f2e28] shadow-sm symptom-card-selected'
          : 'bg-[#fffbf2]/75 border-[#e9e4d8] hover:border-[#2f9e7e]/50 hover:bg-white text-[#4c5e56]'
      }`}
    >
      {/* Dedicated Symptom SVG Illustration */}
      <SymptomIconIllustration
        symptomId={symptom.id}
        severity={symptom.severity}
        selected={selected}
      />

      {/* Content */}
      <div className="flex-1 min-w-0 pr-6 space-y-1">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <span className="text-xs sm:text-sm font-bold text-[#1f2e28] leading-snug">
            {symptom.name}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] font-medium">
          <span className={severityMeta.textClass}>{severityMeta.label}</span>
          <span aria-hidden="true" className="text-[#c5beb0]">
            ·
          </span>
          <span className="text-[#72847c]">{symptom.category}</span>
        </div>

        <p className="text-[11px] text-[#72847c] leading-relaxed">{symptom.hint}</p>
      </div>

      {/* Selected Paw Print Stamp / Unselected Indicator */}
      <div className="absolute top-3.5 right-3.5 flex items-center justify-center">
        {selected ? (
          <span
            className="paw-stamp-pop w-7 h-7 rounded-xl bg-[#2f9e7e] text-white flex items-center justify-center shadow-sm"
            aria-label="已选择"
          >
            <PawPrintIcon className="w-4 h-4" />
          </span>
        ) : (
          <span
            className="w-6 h-6 rounded-xl border border-[#d6d0c2] bg-white/90 group-hover:border-[#2f9e7e]/60 transition-colors"
            aria-hidden="true"
          />
        )}
      </div>
    </button>
  );
}
