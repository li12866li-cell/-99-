import React from 'react';
import { Pet } from '../../types/pet.ts';
import { AnimatedCompanionSvg } from './SymptomIllustrations.tsx';

interface PetWelcomeAnimationProps {
  pet: Pet | null;
  selectedCount: number;
  phase: 'select' | 'checking' | 'error' | 'result';
}

export function PetWelcomeAnimation({
  pet,
  selectedCount,
  phase,
}: PetWelcomeAnimationProps) {
  const petName = pet?.name ? `${pet.name} ` : '';
  const bubbleText =
    phase === 'checking'
      ? '别紧张，我正在仔细核对每一项表现...'
      : phase === 'error'
      ? '健康分析服务暂时没连上，请检查后再试一次。'
      : selectedCount > 0
      ? `今天宝贝感觉怎么样？让我帮你检查一下吧！（已选 ${selectedCount} 项表现）`
      : '今天宝贝感觉怎么样？让我帮你检查一下吧！';

  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-5 pt-1">
      {/* Cute Pet Sliding In From Left & Remaining Visible */}
      <div className="pet-slide-enter shrink-0 flex items-center justify-center rounded-3xl bg-white/85 border border-[#e9e4d8] px-3 py-2">
        <AnimatedCompanionSvg
          species={pet?.species || 'dog'}
          mode="welcome"
          className="w-24 h-20 sm:w-28 sm:h-24"
        />
      </div>

      {/* Dynamic Speech Bubble */}
      <div className="bubble-pop-in relative flex-1 w-full">
        <div className="rounded-2xl bg-white border border-[#2f9e7e]/25 px-4 py-3.5 shadow-sm">
          <div className="text-xs font-semibold text-[#2f9e7e] mb-1">
            {petName ? `${petName}的健康小助手` : '宠爱脉动健康小助手'}
          </div>
          <p className="text-sm sm:text-base font-semibold text-[#1f2e28] leading-relaxed">
            「{bubbleText}」
          </p>
        </div>
      </div>
    </div>
  );
}
