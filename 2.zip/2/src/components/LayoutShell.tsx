import React, { useState } from 'react';
import {
  Home,
  Stethoscope,
  ClipboardList,
  Database,
  Menu,
  X,
  PanelLeftClose,
  PanelLeft,
  Sparkles,
  FileHeart,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Pet } from '../types/pet.ts';

export type AppTabId =
  | 'home'
  | 'health-reminders'
  | 'symptom-check'
  | 'food-scan'
  | 'medical-records';

interface NavTabItem {
  id: AppTabId;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}

interface LayoutShellProps {
  activeTab: AppTabId;
  onSelectTab: (tab: AppTabId) => void;
  selectedPet: Pet | null;
  onReplayCover: () => void;
  pendingReminderCount: number;
  t: any;
  children: React.ReactNode;
}

function PetCareBrandMark({ className = 'w-8 h-8' }: { className?: string }) {
  return (
    <div
      className={`${className} rounded-2xl bg-[#2f9e7e] text-[#fffbf2] flex items-center justify-center shrink-0 border border-[#1f5c4b]/20`}
    >
      <svg viewBox="0 0 32 32" className="w-5 h-5" fill="none" aria-hidden="true">
        <path
          d="M16 7.5V24.5M7.5 16H24.5"
          stroke="currentColor"
          strokeWidth="2.6"
          strokeLinecap="round"
        />
        <circle cx="10.5" cy="10.5" r="2.1" fill="#ffb074" />
        <circle cx="21.5" cy="10.5" r="2.1" fill="#ffb074" />
        <circle cx="10.5" cy="21.5" r="2.1" fill="#f48ca3" />
        <circle cx="21.5" cy="21.5" r="2.1" fill="#f48ca3" />
      </svg>
    </div>
  );
}

export function LayoutShell({
  activeTab,
  onSelectTab,
  selectedPet,
  onReplayCover,
  pendingReminderCount,
  t,
  children,
}: LayoutShellProps) {
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const navItems: NavTabItem[] = [
    { id: 'home', icon: Home, label: t.home || '首页概览' },
    { id: 'health-reminders', icon: ClipboardList, label: '记录与提醒' },
    { id: 'symptom-check', icon: Stethoscope, label: '症状自查' },
    { id: 'food-scan', icon: Database, label: '食物安全库' },
    { id: 'medical-records', icon: FileHeart, label: '医疗检查记录' },
  ];

  const activeItem = navItems.find((item) => item.id === activeTab);

  return (
    <div className="min-h-screen bg-[#fffbf2] text-[#1f2e28] flex">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden md:flex flex-col border-r border-[#e9e4d8] bg-white sticky top-0 h-screen transition-all duration-200 ${
          isSidebarCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        <div className="h-14 px-4 border-b border-[#e9e4d8] flex items-center justify-between gap-2">
          {!isSidebarCollapsed && (
            <div className="flex items-center gap-2.5 min-w-0">
              <PetCareBrandMark className="w-7 h-7" />
              <span className="font-bold text-sm tracking-tight text-[#1f5c4b] whitespace-nowrap truncate">
                {t.appName || '宠爱脉动'}
              </span>
            </div>
          )}
          <button
            type="button"
            onClick={() => setIsSidebarCollapsed((prev) => !prev)}
            className="p-2 rounded-lg text-[#72847c] hover:text-[#1f2e28] hover:bg-[#fffbf2] transition-colors ml-auto"
            title={isSidebarCollapsed ? '展开侧边栏' : '收起侧边栏'}
          >
            {isSidebarCollapsed ? <PanelLeft className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold'
                    : 'text-[#4c5e56] hover:bg-[#fffbf2] hover:text-[#1f2e28]'
                }`}
                title={isSidebarCollapsed ? item.label : undefined}
              >
                <item.icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-[#2f9e7e]' : ''}`} />
                {!isSidebarCollapsed && <span className="truncate flex-1 text-left">{item.label}</span>}
                {!isSidebarCollapsed && item.id === 'health-reminders' && pendingReminderCount > 0 && (
                  <span className="text-[11px] font-mono tabular-nums text-[#2f9e7e] font-semibold">
                    {pendingReminderCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isMobileDrawerOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileDrawerOpen(false)}
              className="fixed inset-0 bg-black/40"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.2 }}
              className="relative w-72 max-w-[82vw] bg-white h-full z-10 flex flex-col border-r border-[#e9e4d8]"
            >
              <div className="h-14 px-4 border-b border-[#e9e4d8] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PetCareBrandMark className="w-7 h-7" />
                  <span className="font-bold text-sm text-[#1f5c4b]">{t.appName || '宠爱脉动'}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMobileDrawerOpen(false)}
                  className="p-2 rounded-lg text-[#72847c] hover:bg-[#fffbf2]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <nav className="flex-1 overflow-y-auto p-3 space-y-1">
                {navItems.map((item) => {
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onSelectTab(item.id);
                        setIsMobileDrawerOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-medium transition-colors ${
                        isActive
                          ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold'
                          : 'text-[#4c5e56] hover:bg-[#fffbf2]'
                      }`}
                    >
                      <item.icon className={`w-4 h-4 ${isActive ? 'text-[#2f9e7e]' : ''}`} />
                      <span className="flex-1 text-left">{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#e9e4d8] px-4 md:px-6 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setIsMobileDrawerOpen(true)}
              className="p-2 -ml-2 rounded-xl text-[#1f2e28] hover:bg-[#fffbf2] md:hidden flex items-center gap-1.5"
              aria-label="打开导航"
            >
              <Menu className="w-5 h-5 text-[#1f5c4b]" />
              <span className="font-bold text-sm text-[#1f5c4b] truncate">{t.appName || '宠爱脉动'}</span>
            </button>
            <h2 className="hidden md:block font-semibold text-base text-[#1f2e28] truncate">
              {activeItem?.label || t.appName}
            </h2>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {selectedPet && (
              <span className="hidden sm:inline-block text-xs text-[#4c5e56] whitespace-nowrap tabular-nums">
                {selectedPet.name} · {selectedPet.weight || 0} kg
              </span>
            )}
            <button
              type="button"
              onClick={onReplayCover}
              className="btn-press px-3 py-1.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="重播 3D 金毛开场交互封面"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#fff3e6]" />
              <span>3D 封面</span>
            </button>
          </div>
        </header>

        <main className="flex-1 max-w-6xl w-full min-w-0 mx-auto p-4 sm:p-6 md:p-8 pb-24 md:pb-10">
          <div key={activeTab} className="animate-page-enter min-w-0">
            {children}
          </div>
        </main>

        {/* Mobile Bottom Tab Bar (5 tabs) */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-[#e9e4d8] h-16 grid grid-cols-5 items-center px-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors ${
                  isActive ? 'text-[#2f9e7e] font-semibold' : 'text-[#72847c] hover:text-[#1f2e28]'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span className="text-[10px] font-medium truncate max-w-[60px]">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
