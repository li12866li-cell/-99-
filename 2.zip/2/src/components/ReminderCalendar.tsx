import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, CheckCircle2, Circle, Calendar as CalendarIcon } from 'lucide-react';
import { Reminder } from '../types/reminder.ts';

export function computeRemainingDays(dueDateStr: string): {
  days: number;
  label: string;
  tone: 'overdue' | 'soon' | 'normal';
} {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const due = new Date(`${dueDateStr}T00:00:00`);
  if (Number.isNaN(due.getTime())) {
    return { days: 0, label: '日期待定', tone: 'normal' };
  }
  const diffDays = Math.round((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays < 0) {
    return { days: diffDays, label: `已逾期 ${Math.abs(diffDays)} 天`, tone: 'overdue' };
  }
  if (diffDays === 0) {
    return { days: 0, label: '就是今天', tone: 'soon' };
  }
  if (diffDays <= 7) {
    return { days: diffDays, label: `剩余 ${diffDays} 天`, tone: 'soon' };
  }
  return { days: diffDays, label: `剩余 ${diffDays} 天`, tone: 'normal' };
}

interface ReminderCalendarProps {
  reminders: Reminder[];
  onToggleReminder: (id: string, completed: boolean) => Promise<void>;
}

const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六'];

export function ReminderCalendar({ reminders, onToggleReminder }: ReminderCalendarProps) {
  const now = new Date();
  const [viewYear, setViewYear] = useState(now.getFullYear());
  const [viewMonth, setViewMonth] = useState(now.getMonth());
  const [selectedDate, setSelectedDate] = useState<string>(now.toISOString().split('T')[0]);

  const reminderMap = useMemo(() => {
    const map = new Map<string, Reminder[]>();
    reminders.forEach((rem) => {
      const list = map.get(rem.dueDate) || [];
      list.push(rem);
      map.set(rem.dueDate, list);
    });
    return map;
  }, [reminders]);

  const calendarCells = useMemo(() => {
    const firstDay = new Date(viewYear, viewMonth, 1);
    const startWeekday = firstDay.getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

    const cells: Array<{ dateStr: string; day: number } | null> = [];
    for (let i = 0; i < startWeekday; i += 1) {
      cells.push(null);
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      const m = String(viewMonth + 1).padStart(2, '0');
      const d = String(day).padStart(2, '0');
      cells.push({ dateStr: `${viewYear}-${m}-${d}`, day });
    }
    return cells;
  }, [viewYear, viewMonth]);

  const selectedList = reminderMap.get(selectedDate) || [];
  const todayStr = now.toISOString().split('T')[0];

  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewYear((y) => y - 1);
      setViewMonth(11);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewYear((y) => y + 1);
      setViewMonth(0);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  return (
    <div className="space-y-4">
      {/* Month Navigator */}
      <div className="flex items-center justify-between px-1">
        <button
          type="button"
          onClick={handlePrevMonth}
          className="p-1.5 rounded-xl border border-[#e9e4d8] hover:bg-[#fffbf2] text-[#4c5e56]"
          aria-label="上个月"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <div className="text-sm font-bold text-[#1f2e28] tabular-nums">
          {viewYear} 年 {viewMonth + 1} 月
        </div>
        <button
          type="button"
          onClick={handleNextMonth}
          className="p-1.5 rounded-xl border border-[#e9e4d8] hover:bg-[#fffbf2] text-[#4c5e56]"
          aria-label="下个月"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Weekday Headers */}
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-[#72847c]">
        {WEEKDAYS.map((w) => (
          <div key={w} className="py-1">
            {w}
          </div>
        ))}
      </div>

      {/* Days Grid */}
      <div className="grid grid-cols-7 gap-1.5">
        {calendarCells.map((cell, idx) => {
          if (!cell) {
            return <div key={`empty_${idx}`} className="h-11" />;
          }
          const items = reminderMap.get(cell.dateStr) || [];
          const hasPending = items.some((i) => !i.completed);
          const hasCompleted = items.some((i) => i.completed);
          const isSelected = cell.dateStr === selectedDate;
          const isToday = cell.dateStr === todayStr;

          return (
            <button
              key={cell.dateStr}
              type="button"
              onClick={() => setSelectedDate(cell.dateStr)}
              className={`h-11 rounded-xl flex flex-col items-center justify-center relative transition-colors text-xs tabular-nums ${
                isSelected
                  ? 'bg-[#2f9e7e] text-white font-bold'
                  : isToday
                  ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold border border-[#2f9e7e]/40'
                  : 'hover:bg-[#fffbf2] text-[#1f2e28] border border-transparent'
              }`}
            >
              <span>{cell.day}</span>
              {items.length > 0 && (
                <span className="flex items-center gap-0.5 mt-0.5">
                  {hasPending && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isSelected ? 'bg-[#ffb074]' : 'bg-[#ffb074]'
                      }`}
                    />
                  )}
                  {hasCompleted && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isSelected ? 'bg-white' : 'bg-[#2f9e7e]'
                      }`}
                    />
                  )}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Selected Day Agenda */}
      <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-3.5 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-[#1f2e28] inline-flex items-center gap-1.5 tabular-nums">
            <CalendarIcon className="w-3.5 h-3.5 text-[#2f9e7e]" />
            {selectedDate} 护理安排
          </span>
          <span className="text-[#72847c] tabular-nums">{selectedList.length} 项</span>
        </div>

        {selectedList.length === 0 ? (
          <p className="text-xs text-[#72847c]">当日暂无排期，可点击「快速设置疫苗/驱虫日期」或「新建提醒」添加。</p>
        ) : (
          <ul className="space-y-2">
            {selectedList.map((rem) => {
              const remain = computeRemainingDays(rem.dueDate);
              return (
                <li
                  key={rem.id}
                  className="flex items-center gap-2.5 p-2.5 rounded-xl bg-white border border-[#e9e4d8]"
                >
                  <button
                    type="button"
                    onClick={() => onToggleReminder(rem.id, !rem.completed)}
                    className="text-[#72847c] hover:text-[#2f9e7e] shrink-0"
                  >
                    {rem.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-[#2f9e7e]" />
                    ) : (
                      <Circle className="w-4 h-4" />
                    )}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div
                      className={`text-xs font-semibold truncate ${
                        rem.completed ? 'line-through text-[#72847c]' : 'text-[#1f2e28]'
                      }`}
                    >
                      {rem.title}
                    </div>
                    <div className="text-[11px] text-[#72847c] tabular-nums">
                      {rem.completed ? '已完成' : remain.label}
                      {rem.dueTime ? ` · ${rem.dueTime}` : ''}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
