import foodDbRaw from './food_safety_db.json';
import { PetFoodPreferenceItem, PetFoodPreferences } from '../services/localStore.ts';

export type FoodSafetyLevel = 'safe' | 'caution' | 'forbidden';

export interface FoodSafetyEntry {
  id: string;
  name: string;
  aliases: string[];
  safetyLevel: FoodSafetyLevel;
  speciesNote: string;
  toxicComponents: string[];
  potentialRisks: string;
  precautions: string;
}

export interface SpeciesSuitability {
  status: 'suitable' | 'caution' | 'unsuitable';
  label: string;
  detail: string;
}

export interface FoodPersonalAlert {
  matchedLikes: PetFoodPreferenceItem[];
  matchedAllergies: PetFoodPreferenceItem[];
  matchedForbidden: PetFoodPreferenceItem[];
  matchedDislikes: PetFoodPreferenceItem[];
  hasDangerAlert: boolean;
  hasPreferenceAlert: boolean;
  hasLikeMatch: boolean;
}

export const FOOD_SAFETY_DB = foodDbRaw as {
  source: string;
  updatedAt: string;
  foods: FoodSafetyEntry[];
};

export function getLocalFoodImageUrl(foodId: string): string {
  return `/assets/foods/${foodId}.svg`;
}

export function getSpeciesSuitability(entry: FoodSafetyEntry): {
  dog: SpeciesSuitability;
  cat: SpeciesSuitability;
} {
  switch (entry.id) {
    case 'lily':
      return {
        dog: {
          status: 'unsuitable',
          label: '不建议 / 应远离',
          detail: '虽不如猫咪致命敏感，但误食仍可引起胃肠刺激，家庭应避免接触。',
        },
        cat: {
          status: 'unsuitable',
          label: '极度剧毒禁止',
          detail: '舔舐花瓣、花粉或花瓶水均可能在 24–72 小时内引发急性肾衰竭。',
        },
      };
    case 'macadamia':
      return {
        dog: {
          status: 'unsuitable',
          label: '禁止喂食',
          detail: '对狗狗具明确神经肌肉毒性，可致后肢无力、震颤、发热与呕吐。',
        },
        cat: {
          status: 'unsuitable',
          label: '禁止喂食',
          detail: '高油脂高风险坚果，不建议喂食猫咪。',
        },
      };
    case 'peanut_butter':
      return {
        dog: {
          status: 'caution',
          label: '可极少量（核对无木糖醇）',
          detail: '仅限纯花生无糖无盐无木糖醇配方，每次不超过半茶匙。',
        },
        cat: {
          status: 'unsuitable',
          label: '不建议喂食',
          detail: '猫咪为专性肉食动物，高脂坚果酱易致肠胃负担且存在代糖隐患。',
        },
      };
    case 'carrot':
      return {
        dog: {
          status: 'suitable',
          label: '相对安全（切小块/蒸熟）',
          detail: '可作为低热量磨牙或拌粮辅食，幼犬需防整根呛噎。',
        },
        cat: {
          status: 'caution',
          label: '需蒸熟切末极少量',
          detail: '猫咪消化植物纤维能力有限，建议蒸熟捣碎少量拌食。',
        },
      };
    case 'broccoli':
      return {
        dog: {
          status: 'suitable',
          label: '相对安全（极少量焯熟）',
          detail: '控制在每日总食量 10% 以内，避免花蕾引起胀气。',
        },
        cat: {
          status: 'caution',
          label: '可极少量（多数不喜食）',
          detail: '猫咪对十字花科蔬菜需求低，若喂食需彻底焯熟切碎。',
        },
      };
    case 'oatmeal':
      return {
        dog: {
          status: 'suitable',
          label: '相对安全（纯原味熟粥）',
          detail: '不含糖奶、葡萄干及代糖的纯燕麦熟粥可适量补充膳食纤维。',
        },
        cat: {
          status: 'caution',
          label: '不推荐多吃',
          detail: '猫咪为专性肉食动物，碳水消化能力有限，仅可极少量尝试。',
        },
      };
    case 'sweet_potato':
      return {
        dog: {
          status: 'suitable',
          label: '相对安全（蒸熟去皮）',
          detail: '熟透去皮红薯适口性好，但淀粉偏高需控制喂食分量。',
        },
        cat: {
          status: 'caution',
          label: '仅可极少量',
          detail: '高淀粉易产气，猫咪每次不超过一小指节熟泥。',
        },
      };
    case 'cat_grass':
      return {
        dog: {
          status: 'suitable',
          label: '相对安全（可啃食）',
          detail: '洁净水培嫩麦苗可提供少量植物纤维，过量可能轻微呕吐。',
        },
        cat: {
          status: 'suitable',
          label: '适合啃食（助吐毛球）',
          detail: '温和刺激肠胃帮助排出毛球，注意保持嫩叶洁净无农药。',
        },
      };
    default: {
      if (entry.safetyLevel === 'forbidden') {
        return {
          dog: {
            status: 'unsuitable',
            label: '禁止喂食',
            detail: entry.speciesNote || '存在明确中毒或机械损伤风险，禁止给狗狗食用。',
          },
          cat: {
            status: 'unsuitable',
            label: '禁止喂食',
            detail: entry.speciesNote || '存在明确中毒或机械损伤风险，禁止给猫咪食用。',
          },
        };
      }
      if (entry.safetyLevel === 'caution') {
        return {
          dog: {
            status: 'caution',
            label: '需谨慎少量',
            detail: entry.precautions,
          },
          cat: {
            status: 'caution',
            label: '需谨慎少量',
            detail: entry.precautions,
          },
        };
      }
      return {
        dog: {
          status: 'suitable',
          label: '相对安全',
          detail: '按规范处理去核/去刺/无调味后可适量作为健康加餐。',
        },
        cat: {
          status: 'suitable',
          label: '相对安全',
          detail: '无调味彻底处理后可适量作为加餐，仍应以全价主食为主。',
        },
      };
    }
  }
}

function normalizeText(str: string): string {
  return str.trim().toLowerCase().replace(/\s+/g, '');
}

function matchesFoodTerm(entry: FoodSafetyEntry, rawTerm: string): boolean {
  const term = normalizeText(rawTerm);
  if (!term) return false;

  const candidates = [
    entry.name,
    ...entry.aliases,
    ...entry.toxicComponents,
  ].map(normalizeText);

  for (const cand of candidates) {
    if (!cand) continue;
    if (cand === term) return true;
    if (term.length >= 2 && (cand.includes(term) || term.includes(cand))) {
      return true;
    }
    if (term.length === 1 && entry.aliases.some((a) => normalizeText(a) === term)) {
      return true;
    }
  }
  return false;
}

export function findMatchingFoodEntry(
  name: string,
  foodId?: string
): FoodSafetyEntry | null {
  if (foodId) {
    const byId = FOOD_SAFETY_DB.foods.find((f) => f.id === foodId);
    if (byId) return byId;
  }
  const term = normalizeText(name);
  if (!term) return null;
  for (const entry of FOOD_SAFETY_DB.foods) {
    if (normalizeText(entry.name) === term) return entry;
    if (entry.aliases.some((a) => normalizeText(a) === term)) return entry;
  }
  for (const entry of FOOD_SAFETY_DB.foods) {
    if (matchesFoodTerm(entry, name)) return entry;
  }
  return null;
}

export function checkFoodAgainstPetPreferences(
  entry: FoodSafetyEntry,
  prefs?: PetFoodPreferences | null
): FoodPersonalAlert {
  if (!prefs) {
    return {
      matchedLikes: [],
      matchedAllergies: [],
      matchedForbidden: [],
      matchedDislikes: [],
      hasDangerAlert: false,
      hasPreferenceAlert: false,
      hasLikeMatch: false,
    };
  }

  const matchedLikes = (prefs.likes || []).filter((item) =>
    matchesFoodTerm(entry, item.name)
  );
  const matchedAllergies = (prefs.allergies || []).filter((item) =>
    matchesFoodTerm(entry, item.name)
  );
  const matchedForbidden = (prefs.forbidden || []).filter((item) =>
    matchesFoodTerm(entry, item.name)
  );
  const matchedDislikes = (prefs.dislikes || []).filter((item) =>
    matchesFoodTerm(entry, item.name)
  );

  return {
    matchedLikes,
    matchedAllergies,
    matchedForbidden,
    matchedDislikes,
    hasDangerAlert: matchedAllergies.length > 0 || matchedForbidden.length > 0,
    hasPreferenceAlert: matchedDislikes.length > 0,
    hasLikeMatch: matchedLikes.length > 0,
  };
}
