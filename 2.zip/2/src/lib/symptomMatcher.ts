import symptomRulesRaw from '../data/symptom_rules.json';
import { Pet } from '../types/pet.ts';

export type TriageLevel = 'emergency' | 'urgent' | 'watch';

export interface SymptomRuleItem {
  id: string;
  name: string;
  category: string;
  severity: TriageLevel;
  weight: number;
  hint: string;
  isBaselineNormal?: boolean;
}

export interface CombinationRule {
  id: string;
  required: string[];
  level: TriageLevel;
  title: string;
  reason: string;
  advice: string;
}

export type DurationOptionId =
  | 'just_started'
  | 'few_hours'
  | 'over_24h'
  | 'multiple_days';

export interface DurationOption {
  id: DurationOptionId;
  label: string;
  hint: string;
  escalationBonus: number;
}

export interface WizardStepConfig {
  stepNumber: 1 | 2 | 3 | 4;
  title: string;
  subtitle: string;
  optionIds: string[];
}

export interface SymptomMatchResult {
  level: TriageLevel;
  levelLabel: string;
  headline: string;
  score: number;
  matchedSymptoms: SymptomRuleItem[];
  matchedCombos: CombinationRule[];
  reasoning: string[];
  adviceList: string[];
  vetReminder: string;
  durationId?: DurationOptionId;
  durationLabel?: string;
  customNote?: string;
  hasHighDangerSignal: boolean;
  disclaimer: string;
  knowledgeBaseSource: string;
  updatedAt: string;
}

const KNOWLEDGE_BASE = symptomRulesRaw as {
  version: string;
  source: string;
  updatedAt: string;
  symptoms: SymptomRuleItem[];
  combinationRules: CombinationRule[];
};

// Supplementary step options that complement symptom_rules.json without modifying existing rules
const WIZARD_EXTRA_SYMPTOMS: SymptomRuleItem[] = [
  {
    id: 'spirit_normal',
    name: '精神正常',
    category: '精神与活动',
    severity: 'watch',
    weight: 0,
    hint: '神情警觉、回应呼唤积极、互动意愿如常',
    isBaselineNormal: true,
  },
  {
    id: 'lethargy_mild',
    name: '精神不佳',
    category: '精神与活动',
    severity: 'watch',
    weight: 22,
    hint: '较平时嗜睡、安静趴卧时间变长，但仍能回应呼唤',
  },
  {
    id: 'reduced_activity',
    name: '活动减少',
    category: '精神与活动',
    severity: 'watch',
    weight: 20,
    hint: '不愿跑跳散步或减少玩耍追逐，行动偏慢',
  },
  {
    id: 'appetite_normal',
    name: '食欲正常',
    category: '饮食与排泄',
    severity: 'watch',
    weight: 0,
    hint: '按时进食饮水，采食速度与平时一致',
    isBaselineNormal: true,
  },
  {
    id: 'occasional_vomiting',
    name: '偶尔呕吐',
    category: '饮食与排泄',
    severity: 'watch',
    weight: 24,
    hint: '24 小时内偶发 1 次呕吐（如吐未消化食物或毛球），之后精神尚可',
  },
  {
    id: 'cough',
    name: '咳嗽',
    category: '身体与呼吸',
    severity: 'urgent',
    weight: 38,
    hint: '出现干咳、湿咳、鹅鸣样咳或运动后明显咳嗽',
  },
];

export const DURATION_OPTIONS: DurationOption[] = [
  {
    id: 'just_started',
    label: '刚刚出现',
    hint: '数分钟至 1 小时内刚刚观察到异常变化',
    escalationBonus: 0,
  },
  {
    id: 'few_hours',
    label: '持续数小时',
    hint: '症状已持续 2–12 小时左右，仍在观察发展',
    escalationBonus: 10,
  },
  {
    id: 'over_24h',
    label: '持续一天以上',
    hint: '异常表现已超过 24 小时仍未明显缓解',
    escalationBonus: 25,
  },
  {
    id: 'multiple_days',
    label: '持续多天',
    hint: '断续或连续持续 2 天以上，需重点关注病程进展',
    escalationBonus: 40,
  },
];

export const WIZARD_STEPS: WizardStepConfig[] = [
  {
    stepNumber: 1,
    title: '第一步：精神与活动状态',
    subtitle: '请选择宝贝当前的精神反应和日常活力表现（支持多选）',
    optionIds: ['spirit_normal', 'lethargy_mild', 'reduced_activity', 'high_fever_lethargy'],
  },
  {
    stepNumber: 2,
    title: '第二步：饮食与排泄情况',
    subtitle: '请选择进食饮水、呕吐、排便或腹部/排尿方面的异常情况',
    optionIds: [
      'appetite_normal',
      'appetite_slightly_down',
      'anorexia_24h',
      'occasional_vomiting',
      'repeated_vomiting',
      'bloody_diarrhea',
      'mild_soft_stool',
      'urinary_blockage',
      'bloat_distension',
    ],
  },
  {
    stepNumber: 3,
    title: '第三步：身体与呼吸表现',
    subtitle: '如勾选呼吸异常、抽搐或疑似误食危险物品，将立即弹出紧急就医提示',
    optionIds: [
      'cough',
      'mild_sneeze',
      'dyspnea',
      'limping',
      'seizure',
      'poison_suspected',
      'severe_bleeding',
      'eye_squinting',
      'skin_scratch',
    ],
  },
  {
    stepNumber: 4,
    title: '第四步：持续时间及其他信息',
    subtitle: '选择异常表现已持续的时间，并可补充饮食更换或接触史等观察',
    optionIds: [],
  },
];

export function getAllSymptoms(): SymptomRuleItem[] {
  return KNOWLEDGE_BASE.symptoms;
}

export function getAllWizardSymptoms(): SymptomRuleItem[] {
  const map = new Map<string, SymptomRuleItem>();
  KNOWLEDGE_BASE.symptoms.forEach((s) => map.set(s.id, s));
  WIZARD_EXTRA_SYMPTOMS.forEach((s) => {
    if (!map.has(s.id)) map.set(s.id, s);
  });
  return Array.from(map.values());
}

export function getSymptomById(id: string): SymptomRuleItem | undefined {
  return (
    KNOWLEDGE_BASE.symptoms.find((s) => s.id === id) ||
    WIZARD_EXTRA_SYMPTOMS.find((s) => s.id === id)
  );
}

export function getSymptomKnowledgeMeta() {
  return {
    version: KNOWLEDGE_BASE.version,
    source: KNOWLEDGE_BASE.source,
    updatedAt: KNOWLEDGE_BASE.updatedAt,
  };
}

export const DANGER_IDS = new Set([
  'dyspnea',
  'seizure',
  'poison_suspected',
  'bloat_distension',
  'urinary_blockage',
  'severe_bleeding',
]);

// Extra local combination rules for wizard symptom combinations (preserving all base rules)
const EXTRA_COMBINATION_RULES: CombinationRule[] = [
  {
    id: 'combo_cough_lethargy',
    required: ['cough', 'lethargy_mild'],
    level: 'urgent',
    title: '呼吸道异常伴精神下降',
    reason: '咳嗽同时伴随精神不佳，需排查犬窝咳、猫支气管炎或早期肺炎可能。',
    advice: '注意保持空气流通与温暖，避免剧烈运动，建议 24 小时内线下听诊排查。',
  },
  {
    id: 'combo_cough_high_fever',
    required: ['cough', 'high_fever_lethargy'],
    level: 'urgent',
    title: '咳嗽伴明显萎靡或发热倾向',
    reason: '持续咳嗽同时明显无力/萎靡，提示下呼吸道感染或心肺负担加重风险。',
    advice: '请尽早携宠至医院进行胸部听诊或 X 光排查，观察静息呼吸频率。',
  },
  {
    id: 'combo_vomit_anorexia',
    required: ['occasional_vomiting', 'anorexia_24h'],
    level: 'urgent',
    title: '呕吐伴持续拒食',
    reason: '出现呕吐后连续拒食超过 24 小时，提示胃肠道刺激或消化道梗阻初期可能。',
    advice: '不要强行灌食，建议尽快线下检查以防脱水（猫咪尤其需预防脂肪肝）。',
  },
];

export function matchSymptoms(selectedIds: string[]): SymptomMatchResult {
  return evaluateSymptomWizard({ selectedIds });
}

export interface EvaluateWizardInput {
  selectedIds: string[];
  durationId?: DurationOptionId;
  customNote?: string;
  pet?: Pet | null;
}

export function evaluateSymptomWizard({
  selectedIds,
  durationId,
  customNote,
  pet,
}: EvaluateWizardInput): SymptomMatchResult {
  const uniqueIds = Array.from(new Set(selectedIds));
  const selectedSet = new Set(uniqueIds);
  const catalog = getAllWizardSymptoms();
  const matchedSymptoms = catalog.filter((s) => selectedSet.has(s.id));

  // Separate abnormal findings vs baseline normal selections
  const abnormalSymptoms = matchedSymptoms.filter((s) => !s.isBaselineNormal);

  // Build effective matching set (map mild wizard synonyms cleanly to base combo checks when applicable)
  const effectiveSet = new Set(uniqueIds);

  const matchedBaseCombos = KNOWLEDGE_BASE.combinationRules.filter((combo) =>
    combo.required.every((reqId) => effectiveSet.has(reqId))
  );
  const matchedExtraCombos = EXTRA_COMBINATION_RULES.filter((combo) =>
    combo.required.every((reqId) => effectiveSet.has(reqId))
  );
  const matchedCombos = [...matchedBaseCombos, ...matchedExtraCombos];

  const durationOption = durationId
    ? DURATION_OPTIONS.find((d) => d.id === durationId)
    : undefined;
  const durationBonus =
    abnormalSymptoms.length > 0 && durationOption ? durationOption.escalationBonus : 0;

  const hasHighDangerSignal = abnormalSymptoms.some((s) => DANGER_IDS.has(s.id));
  const symptomWeightSum = abnormalSymptoms.reduce((sum, s) => sum + s.weight, 0);
  const totalScore = symptomWeightSum + durationBonus;

  let level: TriageLevel = 'watch';
  if (
    hasHighDangerSignal ||
    abnormalSymptoms.some((s) => s.severity === 'emergency') ||
    matchedCombos.some((c) => c.level === 'emergency') ||
    totalScore >= 130
  ) {
    level = 'emergency';
  } else if (
    abnormalSymptoms.some((s) => s.severity === 'urgent') ||
    matchedCombos.some((c) => c.level === 'urgent') ||
    totalScore >= 50 ||
    abnormalSymptoms.length >= 3 ||
    (abnormalSymptoms.length >= 1 &&
      (durationId === 'over_24h' || durationId === 'multiple_days'))
  ) {
    level = 'urgent';
  }

  const levelLabelMap: Record<TriageLevel, string> = {
    emergency: '紧急就医',
    urgent: '需要尽快就医',
    watch: '一般关注',
  };

  const headlineMap: Record<TriageLevel, string> = {
    emergency: '检测到高危急救信号，请立即带宝贝前往 24 小时宠物医院急诊！',
    urgent: '存在需重点关注的异常表现或持续时间较长，建议尽快预约线下兽医检查。',
    watch:
      abnormalSymptoms.length === 0
        ? '本次记录以正常日常状态为主，建议继续保持规律观察与护理。'
        : '目前主要为轻度常见表现，可先居家细致观察变化并记录。',
  };

  const vetReminderMap: Record<TriageLevel, string> = {
    emergency:
      '【立即就医提醒】请立刻联系附近的 24 小时动物医院并准备出发。出行途中保持呼吸通畅与环境平稳，避免自行喂药或强行灌水。',
    urgent:
      '【尽快预约提醒】建议在今天或 12–24 小时内预约线下宠物医院进行体格检查或基础化验；若期间出现精神骤降、反复呕吐或呼吸异常，请立即转为急诊。',
    watch:
      '【持续观察提醒】建议未来 24–48 小时内记录饮食、饮水与排便频率；若症状持续超过 24 小时未缓解或出现新发异常，请及时安排兽医评估。',
  };

  const reasoning: string[] = [];
  if (matchedCombos.length > 0) {
    matchedCombos.forEach((combo) => {
      reasoning.push(`【组合规则命中 · ${combo.title}】${combo.reason}`);
    });
  }

  abnormalSymptoms.forEach((sym) => {
    const tag =
      sym.severity === 'emergency'
        ? '高危急症规则'
        : sym.severity === 'urgent'
        ? '尽快就医规则'
        : '居家观察规则';
    reasoning.push(`【${tag}】触发项「${sym.name}」：${sym.hint}`);
  });

  if (
    abnormalSymptoms.length > 0 &&
    durationOption &&
    (durationId === 'over_24h' || durationId === 'multiple_days')
  ) {
    reasoning.push(
      `【持续时间规则】所选症状已「${durationOption.label}」，根据持续时长规则提升风险关注级别，建议线下明确诱因。`
    );
  } else if (durationOption && abnormalSymptoms.length > 0) {
    reasoning.push(`【病程记录】症状出现时长为「${durationOption.label}」。`);
  }

  if (abnormalSymptoms.length === 0) {
    reasoning.push(
      '【基础状态核对】您勾选的「精神正常 / 食欲正常」未触发任何异常预警规则，属于常规健康状态参考。'
    );
  }

  if (pet?.species === 'cat' && selectedSet.has('anorexia_24h')) {
    reasoning.push('【猫咪物种特别规则】猫咪连续拒食超过 24 小时易继发脂肪肝，需重点关注。');
  }

  const adviceList: string[] = [];
  if (level === 'emergency') {
    adviceList.push(
      '如出现呼吸异常、抽搐或疑似误食危险物品，请立即前往动物医院急诊，切勿自行喂食人用药物或强行催吐。'
    );
    if (selectedSet.has('poison_suspected')) {
      adviceList.push(
        '疑似误食危险物品时，请保留可疑包装袋或植物照片，并准确告知兽医误食时间与宝贝体重。'
      );
    }
    if (selectedSet.has('seizure')) {
      adviceList.push(
        '抽搐发作时请移开周围坚硬障碍物避免磕碰，切勿将手指伸入宠物口腔，尽量录制短暂视频供兽医参考。'
      );
    }
    if (selectedSet.has('dyspnea')) {
      adviceList.push(
        '呼吸异常期间请保持环境安静通风，减少紧抱压迫胸腔，尽快送院吸氧评估。'
      );
    }
  } else if (level === 'urgent') {
    adviceList.push('建议今日内或 24 小时内预约线下宠物医院进行体格检查与针对性排查。');
    adviceList.push('就诊前可拍照记录呕吐物或粪便性状，并梳理近期饮食及接触史便于沟通。');
    if (selectedSet.has('anorexia_24h')) {
      adviceList.push('持续不吃不喝易导致脱水或低血糖，尤其猫咪需尽早就医评估补液。');
    }
    if (selectedSet.has('cough')) {
      adviceList.push('咳嗽期间避免牵拉颈圈散步，保持室内湿度适宜并减少灰尘刺激。');
    }
  } else if (abnormalSymptoms.length === 0) {
    adviceList.push('继续维持规律喂食、足量洁净饮水与适度陪伴运动。');
    adviceList.push('可定期在「记录与提醒」中打卡体重，留意日常微小的食欲或排便变化。');
  } else {
    adviceList.push('保持环境安静温暖，提供充足洁净饮水，采取少量多餐方式观察采食反应。');
    adviceList.push('在「记录与提醒」中记下本次表现，若 24–48 小时内仍未好转或精神转差，请及时就医。');
  }

  matchedCombos.forEach((c) => {
    if (!adviceList.includes(c.advice)) {
      adviceList.push(c.advice);
    }
  });

  return {
    level,
    levelLabel: levelLabelMap[level],
    headline: headlineMap[level],
    score: totalScore,
    matchedSymptoms,
    matchedCombos,
    reasoning,
    adviceList,
    vetReminder: vetReminderMap[level],
    durationId,
    durationLabel: durationOption?.label,
    customNote: customNote?.trim() || undefined,
    hasHighDangerSignal,
    disclaimer:
      '医疗科普声明：本评估完全基于本地健康知识库规则进行分诊参考，不构成任何医学确诊；如宝贝精神快速恶化或您仍感到担忧，请随时联系执业兽医。',
    knowledgeBaseSource: KNOWLEDGE_BASE.source,
    updatedAt: KNOWLEDGE_BASE.updatedAt,
  };
}
