import { HealthRecord, Pet } from '../types/pet.ts';
import { MedicalRecord } from '../types/medicalRecord.ts';
import { Reminder } from '../types/reminder.ts';
import { SymptomCheckHistoryItem } from '../services/localStore.ts';

export interface WeeklyHealthSummary {
  petName: string;
  startDate: string;
  endDate: string;
  generatedAt: string;
  medicalInPeriod: MedicalRecord[];
  healthRecordsInPeriod: HealthRecord[];
  remindersInPeriod: Reminder[];
  symptomChecksInPeriod: SymptomCheckHistoryItem[];
  weightStats: {
    startWeight: number | null;
    endWeight: number | null;
    deltaKg: number | null;
    minWeight: number | null;
    maxWeight: number | null;
    count: number;
    trendText: string;
  };
  careStats: {
    completedReminders: number;
    pendingReminders: number;
    vaccineCount: number;
    dewormingCount: number;
  };
  narrativeSummary: string[];
  careRecommendations: string[];
}

function inRange(dateStr: string, startDate: string, endDate: string): boolean {
  if (!dateStr) return false;
  const d = dateStr.slice(0, 10);
  return d >= startDate && d <= endDate;
}

export function buildWeeklyHealthSummary(params: {
  pet: Pet;
  startDate: string;
  endDate: string;
  medicalRecords: MedicalRecord[];
  healthRecords: HealthRecord[];
  reminders: Reminder[];
  symptomHistory: SymptomCheckHistoryItem[];
}): WeeklyHealthSummary {
  const { pet, startDate, endDate, medicalRecords, healthRecords, reminders, symptomHistory } = params;

  const medicalInPeriod = medicalRecords.filter((m) => inRange(m.date, startDate, endDate));
  const healthRecordsInPeriod = healthRecords
    .filter((r) => inRange(r.date, startDate, endDate))
    .sort((a, b) => a.date.localeCompare(b.date));
  const remindersInPeriod = reminders.filter((rem) => inRange(rem.dueDate, startDate, endDate));
  const symptomChecksInPeriod = symptomHistory.filter((s) =>
    inRange(s.checkedAt, startDate, endDate)
  );

  const weightEntries = healthRecordsInPeriod
    .filter((r) => typeof r.weightKg === 'number' && r.weightKg > 0)
    .map((r) => ({ date: r.date, weight: r.weightKg as number }));

  const startWeight = weightEntries.length > 0 ? weightEntries[0].weight : null;
  const endWeight = weightEntries.length > 0 ? weightEntries[weightEntries.length - 1].weight : null;
  const deltaKg =
    startWeight !== null && endWeight !== null ? Number((endWeight - startWeight).toFixed(2)) : null;
  const minWeight =
    weightEntries.length > 0 ? Math.min(...weightEntries.map((w) => w.weight)) : null;
  const maxWeight =
    weightEntries.length > 0 ? Math.max(...weightEntries.map((w) => w.weight)) : null;

  let trendText = '本周期内暂无连续称重记录。';
  if (weightEntries.length === 1) {
    trendText = `周期内共有 1 次称重记录（${startWeight} kg），单次数据不用于直接判断患病与否。`;
  } else if (weightEntries.length >= 2 && deltaKg !== null) {
    if (Math.abs(deltaKg) < 0.05) {
      trendText = `周期内记录体重 ${weightEntries.length} 次，保持在 ${endWeight} kg 左右，体况平稳。`;
    } else if (deltaKg > 0) {
      trendText = `周期内由 ${startWeight} kg 变化至 ${endWeight} kg（+${deltaKg} kg），整体呈小幅上升趋势。`;
    } else {
      trendText = `周期内由 ${startWeight} kg 变化至 ${endWeight} kg（${deltaKg} kg），整体呈回落趋势。`;
    }
  }

  const completedReminders = remindersInPeriod.filter((r) => r.completed).length;
  const pendingReminders = remindersInPeriod.filter((r) => !r.completed).length;
  const vaccineCount =
    remindersInPeriod.filter((r) => r.category === 'vaccine').length +
    healthRecordsInPeriod.filter((r) => r.type === 'vaccine').length;
  const dewormingCount = remindersInPeriod.filter((r) => r.category === 'deworming').length;

  const narrativeSummary: string[] = [
    `统计区间 ${startDate} 至 ${endDate}，共归档 ${medicalInPeriod.length} 份医院检查记录、${healthRecordsInPeriod.length} 条日常健康记录。`,
    trendText,
    `护理计划方面，区间内共排期 ${remindersInPeriod.length} 项提醒，已完成 ${completedReminders} 项、待执行 ${pendingReminders} 项（含疫苗相关 ${vaccineCount} 项、驱虫 ${dewormingCount} 项）。`,
  ];

  if (symptomChecksInPeriod.length > 0) {
    const emergencyCount = symptomChecksInPeriod.filter((s) => s.level === 'emergency').length;
    narrativeSummary.push(
      `本周期内进行了 ${symptomChecksInPeriod.length} 次本地症状自查${
        emergencyCount > 0 ? `（其中包含 ${emergencyCount} 次高危提示记录）` : ''
      }，建议结合兽医面诊评估。`
    );
  }

  const careRecommendations: string[] = [];
  if (pendingReminders > 0) {
    careRecommendations.push(`还有 ${pendingReminders} 项待完成护理或疫苗/驱虫计划，请按时履约打卡。`);
  } else {
    careRecommendations.push('统计周期内护理计划均已完成或无遗漏待办，继续保持规律养护。');
  }
  if (weightEntries.length < 2) {
    careRecommendations.push('建议每周固定时间称重 1–2 次，累积长期体重曲线以便观察营养变化。');
  }
  if (medicalInPeriod.length > 0) {
    careRecommendations.push('线下复诊时可一并出示本周期医疗检查单及体重曲线，帮助兽医对照指标变化。');
  }
  careRecommendations.push('免责声明：本总结报告由本地健康数据自动聚合生成，仅作健康记录与就医沟通参考，不替代执业兽医诊断。');

  return {
    petName: pet.name,
    startDate,
    endDate,
    generatedAt: new Date().toLocaleString('zh-CN'),
    medicalInPeriod,
    healthRecordsInPeriod,
    remindersInPeriod,
    symptomChecksInPeriod,
    weightStats: {
      startWeight,
      endWeight,
      deltaKg,
      minWeight,
      maxWeight,
      count: weightEntries.length,
      trendText,
    },
    careStats: {
      completedReminders,
      pendingReminders,
      vaccineCount,
      dewormingCount,
    },
    narrativeSummary,
    careRecommendations,
  };
}

function escapeHtml(text: string): string {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function buildWeeklyReportHtml(
  pet: Pet,
  summary: WeeklyHealthSummary,
  ownerNotes?: string
): string {
  const speciesLabel =
    pet.species === 'dog' ? '犬' : pet.species === 'cat' ? '猫' : pet.species === 'bunny' ? '兔' : '其他';

  const medicalSection =
    summary.medicalInPeriod.length > 0
      ? summary.medicalInPeriod
          .map(
            (m) => `
          <div class="item-card">
            <div class="meta">${escapeHtml(m.date)} · ${escapeHtml(m.hospitalName || '未填医院')} · 附件 ${
              m.attachments.length
            } 份</div>
            <h4>${escapeHtml(m.title)}</h4>
            <p>${escapeHtml(m.results || '暂无结果文字说明').replace(/\n/g, '<br/>')}</p>
          </div>
        `
          )
          .join('')
      : '<p class="empty">该日期范围内暂无医院检查记录。</p>';

  const healthSection =
    summary.healthRecordsInPeriod.length > 0
      ? summary.healthRecordsInPeriod
          .map(
            (r) => `
          <tr>
            <td>${escapeHtml(r.date)}</td>
            <td>${escapeHtml(r.title)}</td>
            <td>${typeof r.weightKg === 'number' ? `${r.weightKg} kg` : '--'}</td>
            <td>${escapeHtml(r.content || '--')}</td>
          </tr>
        `
          )
          .join('')
      : '<tr><td colspan="4" class="empty">该日期范围内暂无日常健康记录。</td></tr>';

  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(pet.name)} - 健康总结周报 (${escapeHtml(summary.startDate)} ~ ${escapeHtml(
    summary.endDate
  )})</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif; color: #1f2e28; background: #fff; margin: 0; padding: 28px; line-height: 1.6; }
    .header { border-bottom: 2px solid #2f9e7e; padding-bottom: 14px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: flex-end; gap: 16px; }
    .header h1 { margin: 0; font-size: 21px; color: #1f5c4b; }
    .header .sub { font-size: 12px; color: #4c5e56; margin-top: 4px; }
    .pet-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; background: #fffbf2; border: 1px solid #e9e4d8; border-radius: 10px; padding: 12px 14px; margin-bottom: 16px; font-size: 12px; }
    .pet-grid .label { color: #72847c; font-size: 11px; display: block; }
    .pet-grid .val { font-weight: 700; }
    .summary-box { background: #e6f7f1; border: 1px solid #bde5d7; border-radius: 10px; padding: 14px; margin-bottom: 18px; }
    .summary-box h2 { margin: 0 0 8px 0; font-size: 14px; color: #1f5c4b; }
    .summary-box ul { margin: 0; padding-left: 18px; font-size: 12.5px; }
    .section-title { font-size: 14px; font-weight: 700; color: #1f5c4b; margin: 18px 0 8px 0; border-left: 3px solid #2f9e7e; padding-left: 8px; }
    .item-card { border: 1px solid #e9e4d8; border-radius: 8px; padding: 10px 12px; margin-bottom: 8px; }
    .item-card .meta { font-size: 11px; color: #72847c; }
    .item-card h4 { margin: 4px 0; font-size: 13.5px; color: #1f2e28; }
    .item-card p { margin: 0; font-size: 12.5px; color: #4c5e56; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th, td { border: 1px solid #e9e4d8; padding: 7px 9px; text-align: left; }
    th { background: #fffbf2; color: #1f5c4b; font-weight: 600; }
    .empty { color: #72847c; font-size: 12px; }
    .notes { background: #fff3e6; border: 1px solid #f7d9b6; border-radius: 8px; padding: 10px 12px; font-size: 12.5px; margin-bottom: 14px; }
    .footer { margin-top: 22px; padding-top: 10px; border-top: 1px solid #e9e4d8; font-size: 11px; color: #72847c; display: flex; justify-content: space-between; }
    @media print { body { padding: 12px; } }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h1>宠爱脉动 · 宠物健康总结周报</h1>
      <div class="sub">统计周期：${escapeHtml(summary.startDate)} 至 ${escapeHtml(summary.endDate)} · 生成时间：${escapeHtml(
    summary.generatedAt
  )}</div>
    </div>
    <div class="sub">宠物：${escapeHtml(pet.name)}</div>
  </div>

  <div class="pet-grid">
    <div><span class="label">宠物名称</span><span class="val">${escapeHtml(pet.name)}</span></div>
    <div><span class="label">物种 / 品种</span><span class="val">${speciesLabel} · ${escapeHtml(pet.breed || '未填写')}</span></div>
    <div><span class="label">当前体重</span><span class="val">${pet.weight ?? '--'} kg</span></div>
    <div><span class="label">周期称重 / 护理完成</span><span class="val">${summary.weightStats.count} 次 · ${summary.careStats.completedReminders} 项</span></div>
  </div>

  <div class="summary-box">
    <h2>周期综合健康摘要（本地聚合）</h2>
    <ul>
      ${summary.narrativeSummary.map((line) => `<li>${escapeHtml(line)}</li>`).join('')}
      ${summary.careRecommendations.map((line) => `<li>${escapeHtml(line)}</li>`).join('')}
    </ul>
  </div>

  ${
    ownerNotes?.trim()
      ? `<div class="notes"><strong>宠主补充备注：</strong><br/>${escapeHtml(ownerNotes.trim()).replace(
          /\n/g,
          '<br/>'
        )}</div>`
      : ''
  }

  <div class="section-title">医疗检查记录明细 (${summary.medicalInPeriod.length})</div>
  ${medicalSection}

  <div class="section-title">日常健康与体重记录 (${summary.healthRecordsInPeriod.length})</div>
  <table>
    <thead>
      <tr>
        <th style="width: 96px;">日期</th>
        <th style="width: 160px;">标题</th>
        <th style="width: 84px;">体重</th>
        <th>记录详情</th>
      </tr>
    </thead>
    <tbody>
      ${healthSection}
    </tbody>
  </table>

  <div class="footer">
    <span>宠爱脉动本地健康管理中心</span>
    <span>本报告仅供居家健康追踪及兽医问诊参考，不作为医疗诊断依据</span>
  </div>
</body>
</html>`;
}

export function printHtmlToPdf(htmlContent: string): void {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.setAttribute('aria-hidden', 'true');
  document.body.appendChild(iframe);

  const cleanup = () => {
    setTimeout(() => {
      if (iframe.parentNode) {
        iframe.parentNode.removeChild(iframe);
      }
    }, 1500);
  };

  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } finally {
      cleanup();
    }
  };
  iframe.srcdoc = htmlContent;
}
