import { Language } from './i18n.ts';
import { MedicalRecordCategory } from '../types/medicalRecord.ts';

export interface MedicalRecordsCopy {
  pageTitle: string;
  pageSubtitle: string;
  weeklyReportBtn: string;
  preVetExportBtn: string;
  choosePetHint: string;
  selectedLabel: string;
  clickToSwitch: string;
  recordsCountUnit: string;
  yearsOld: string;
  dogLabel: string;
  catLabel: string;
  otherPetLabel: string;
  morePetsLabel: string;
  noPetTitle: string;
  noPetDesc: string;

  // Form sections
  formTitle: string;
  formLimitNote: string;
  sectionATitle: string;
  sectionBTitle: string;
  sectionCTitle: string;
  titleLabel: string;
  titlePlaceholder: string;
  dateLabel: string;
  categoryLabel: string;
  hospitalLabel: string;
  hospitalPlaceholder: string;
  resultsLabel: string;
  resultsPlaceholder: string;

  // Upload
  dropZoneTitle: string;
  dropZoneDragActive: string;
  dropZoneDesc: string;
  browseFilesBtn: string;
  fileTypePdf: string;
  fileTypeImage: string;
  fileLimitErrorType: (name: string) => string;
  fileLimitErrorSize: (name: string) => string;
  fileLimitErrorCount: string;
  fileReadError: string;
  previewFileTooltip: string;
  removeFileTooltip: string;

  // Save & validation
  saveBtn: string;
  savingBtn: string;
  errSelectPet: string;
  errEnterTitle: string;

  // History list
  historyTitle: string;
  searchPlaceholder: string;
  filterAll: string;
  loadingHistory: string;
  emptyHistory: string;
  viewAction: string;
  editAction: string;
  deleteAction: string;
  confirmDeleteBtn: string;
  cancelDeleteBtn: string;
  attachmentsCount: (n: number) => string;

  // Modals
  detailModalTitle: string;
  detailCheckupDate: string;
  detailCategory: string;
  detailHospital: string;
  detailHospitalEmpty: string;
  detailResults: string;
  detailResultsEmpty: string;
  detailAttachments: string;
  detailNoAttachments: string;
  closeBtn: string;
  downloadBtn: string;

  editModalTitle: string;
  saveChangesBtn: string;
  cancelBtn: string;

  categories: Record<MedicalRecordCategory, string>;
}

const zh: MedicalRecordsCopy = {
  pageTitle: '医疗检查记录',
  pageSubtitle: '记录每一次检查，守护宠物健康。',
  weeklyReportBtn: '生成健康总结周报 (PDF)',
  preVetExportBtn: '就诊前导出报告',
  choosePetHint: '点击切换宠物档案，独立查看与保存各自的医疗记录',
  selectedLabel: '当前选中',
  clickToSwitch: '点击切换',
  recordsCountUnit: '份档案',
  yearsOld: '岁',
  dogLabel: '金毛犬',
  catLabel: '猫咪',
  otherPetLabel: '宠物',
  morePetsLabel: '其他宠物档案',
  noPetTitle: '暂无关联宠物档案',
  noPetDesc: '请先在「首页概览」添加一只宠物后，即可为其记录医疗检查并导出报告',

  formTitle: '新增医疗检查记录',
  formLimitNote: '支持 JPG / PNG / PDF · 单文件 ≤ 8MB · 最多 6 个',
  sectionATitle: 'A. 检查基本信息',
  sectionBTitle: 'B. 医疗信息',
  sectionCTitle: 'C. 检查报告上传',
  titleLabel: '检查标题 *',
  titlePlaceholder: '例如：年度生化 16 项血检 / 胸腔 X 光片',
  dateLabel: '检查日期',
  categoryLabel: '文档类别',
  hospitalLabel: '医院名称',
  hospitalPlaceholder: '填写就诊医院或诊所名称',
  resultsLabel: '检查结果、异常指标与医嘱',
  resultsPlaceholder: '记录关键指标（如 ALT、肌酐）、医生诊断结论或用药说明...',

  dropZoneTitle: '拖拽文件到此处，或点击选择检查报告',
  dropZoneDragActive: '松开鼠标即可添加检查报告文件',
  dropZoneDesc: '支持 JPG、PNG 图片与 PDF 文档（单文件 ≤ 8MB，最多 6 个附件）',
  browseFilesBtn: '选择文件',
  fileTypePdf: 'PDF 文档',
  fileTypeImage: '图片文件',
  fileLimitErrorType: (name) => `不支持的文件格式：${name}（仅支持 JPG、PNG 或 PDF）`,
  fileLimitErrorSize: (name) => `文件过大：${name} 超过 8MB 限制`,
  fileLimitErrorCount: '单条记录最多上传 6 个附件',
  fileReadError: '读取上传文档失败，请重试',
  previewFileTooltip: '预览文件',
  removeFileTooltip: '移除附件',

  saveBtn: '保存医疗记录',
  savingBtn: '保存中...',
  errSelectPet: '请先添加或选择一只宠物档案',
  errEnterTitle: '请填写检查标题',

  historyTitle: '历史医疗记录',
  searchPlaceholder: '搜索标题、医院或检查结果...',
  filterAll: '全部',
  loadingHistory: '正在加载医疗检查档案...',
  emptyHistory: '暂无符合条件的医疗检查记录。请在上方填写检查信息并保存。',
  viewAction: '查看',
  editAction: '修改',
  deleteAction: '删除',
  confirmDeleteBtn: '确认删除',
  cancelDeleteBtn: '取消',
  attachmentsCount: (n) => `${n} 个附件`,

  detailModalTitle: '医疗检查详情',
  detailCheckupDate: '检查日期',
  detailCategory: '文档类别',
  detailHospital: '就诊医院',
  detailHospitalEmpty: '未填写',
  detailResults: '检查结果、异常指标与医嘱',
  detailResultsEmpty: '未填写检查结果说明',
  detailAttachments: '上传的检查文件',
  detailNoAttachments: '本次记录未上传图片或 PDF 附件',
  closeBtn: '关闭',
  downloadBtn: '下载',

  editModalTitle: '修改医疗检查记录',
  saveChangesBtn: '保存修改',
  cancelBtn: '取消',

  categories: {
    lab: '血检化验',
    imaging: '影像检查 (X光/B超)',
    vaccine: '疫苗免疫',
    prescription: '处方病历',
    checkup: '常规体检',
    other: '其他医疗文档',
  },
};

const en: MedicalRecordsCopy = {
  pageTitle: 'Medical Checkup Records',
  pageSubtitle: 'Record every checkup to safeguard your pet’s health.',
  weeklyReportBtn: 'Weekly Health Report (PDF)',
  preVetExportBtn: 'Pre-Vet Export',
  choosePetHint: 'Select a pet to view and manage their independent medical archive',
  selectedLabel: 'Selected',
  clickToSwitch: 'Switch',
  recordsCountUnit: 'records',
  yearsOld: 'yrs',
  dogLabel: 'Golden Retriever',
  catLabel: 'Cat',
  otherPetLabel: 'Pet',
  morePetsLabel: 'Other Pets',
  noPetTitle: 'No Pet Profiles Found',
  noPetDesc: 'Add a pet on the Home overview first to record checkups and export reports.',

  formTitle: 'New Medical Checkup Record',
  formLimitNote: 'JPG / PNG / PDF · ≤ 8MB each · Up to 6 files',
  sectionATitle: 'A. Basic Checkup Info',
  sectionBTitle: 'B. Medical Info',
  sectionCTitle: 'C. Checkup Report Upload',
  titleLabel: 'Checkup Title *',
  titlePlaceholder: 'e.g., Annual Blood Chemistry Panel / Chest X-Ray',
  dateLabel: 'Checkup Date',
  categoryLabel: 'Document Category',
  hospitalLabel: 'Hospital / Clinic Name',
  hospitalPlaceholder: 'Enter veterinary hospital or clinic name',
  resultsLabel: 'Results, Abnormal Metrics & Vet Advice',
  resultsPlaceholder: 'Record key lab values, diagnosis notes, or prescription instructions...',

  dropZoneTitle: 'Drag & drop files here, or click to upload',
  dropZoneDragActive: 'Release to add checkup report files',
  dropZoneDesc: 'Supports JPG, PNG, and PDF (max 8MB per file, up to 6 files)',
  browseFilesBtn: 'Choose Files',
  fileTypePdf: 'PDF Document',
  fileTypeImage: 'Image',
  fileLimitErrorType: (name) => `Unsupported format: ${name} (JPG, PNG, or PDF only)`,
  fileLimitErrorSize: (name) => `File too large: ${name} exceeds the 8MB limit`,
  fileLimitErrorCount: 'Maximum 6 attachments per record',
  fileReadError: 'Failed to read the uploaded file, please try again',
  previewFileTooltip: 'Preview file',
  removeFileTooltip: 'Remove file',

  saveBtn: 'Save Medical Record',
  savingBtn: 'Saving...',
  errSelectPet: 'Please select or add a pet first',
  errEnterTitle: 'Please enter a checkup title',

  historyTitle: 'Medical Record History',
  searchPlaceholder: 'Search title, hospital, or results...',
  filterAll: 'All',
  loadingHistory: 'Loading medical records...',
  emptyHistory: 'No matching medical checkup records yet. Fill out the form above to add one.',
  viewAction: 'View',
  editAction: 'Edit',
  deleteAction: 'Delete',
  confirmDeleteBtn: 'Confirm',
  cancelDeleteBtn: 'Cancel',
  attachmentsCount: (n) => `${n} file${n === 1 ? '' : 's'}`,

  detailModalTitle: 'Checkup Record Details',
  detailCheckupDate: 'Checkup Date',
  detailCategory: 'Category',
  detailHospital: 'Hospital',
  detailHospitalEmpty: 'Not specified',
  detailResults: 'Results, Abnormal Metrics & Vet Advice',
  detailResultsEmpty: 'No written notes provided',
  detailAttachments: 'Uploaded Report Files',
  detailNoAttachments: 'No image or PDF attachments for this record',
  closeBtn: 'Close',
  downloadBtn: 'Download',

  editModalTitle: 'Edit Medical Record',
  saveChangesBtn: 'Save Changes',
  cancelBtn: 'Cancel',

  categories: {
    lab: 'Lab & Bloodwork',
    imaging: 'Imaging (X-Ray / Ultrasound)',
    vaccine: 'Vaccination',
    prescription: 'Prescription',
    checkup: 'Routine Checkup',
    other: 'Other Document',
  },
};

const ko: MedicalRecordsCopy = {
  pageTitle: '의료 검사 기록',
  pageSubtitle: '매 검사를 기록하여 반려동물의 건강을 지킵니다.',
  weeklyReportBtn: '주간 건강 리포트 (PDF)',
  preVetExportBtn: '진료 전 리포트 내보내기',
  choosePetHint: '반려동물을 선택하여 독립된 의료 기록을 확인하고 관리하세요',
  selectedLabel: '선택됨',
  clickToSwitch: '전환',
  recordsCountUnit: '건',
  yearsOld: '세',
  dogLabel: '골든 리트리버',
  catLabel: '고양이',
  otherPetLabel: '반려동물',
  morePetsLabel: '기타 반려동물',
  noPetTitle: '등록된 반려동물이 없습니다',
  noPetDesc: '먼저 홈 화면에서 반려동물을 추가한 후 의료 검사 기록을 관리해 주세요.',

  formTitle: '새 의료 검사 기록 추가',
  formLimitNote: 'JPG / PNG / PDF · 파일당 ≤ 8MB · 최대 6개',
  sectionATitle: 'A. 검사 기본 정보',
  sectionBTitle: 'B. 의료 정보',
  sectionCTitle: 'C. 검사 보고서 업로드',
  titleLabel: '검사 제목 *',
  titlePlaceholder: '예: 연간 혈액 생화학 검사 / 흉부 X-ray',
  dateLabel: '검사 날짜',
  categoryLabel: '문서 유형',
  hospitalLabel: '병원 이름',
  hospitalPlaceholder: '방문한 동물병원 또는 클리닉 이름 입력',
  resultsLabel: '검사 결과, 이상 수치 및 수의사 소견',
  resultsPlaceholder: '주요 수치(예: ALT, 크레아티닌), 진단 소견 또는 처방 내용을 기록하세요...',

  dropZoneTitle: '파일을 여기로 끌어다 놓거나 클릭하여 업로드하세요',
  dropZoneDragActive: '놓으면 검사 보고서 파일이 추가됩니다',
  dropZoneDesc: 'JPG, PNG 이미지 및 PDF 문서 지원 (파일당 최대 8MB, 최대 6개)',
  browseFilesBtn: '파일 선택',
  fileTypePdf: 'PDF 문서',
  fileTypeImage: '이미지 파일',
  fileLimitErrorType: (name) => `지원하지 않는 형식입니다: ${name} (JPG, PNG, PDF만 가능)`,
  fileLimitErrorSize: (name) => `파일 크기 초과: ${name} (8MB 제한)`,
  fileLimitErrorCount: '기록당 최대 6개의 파일만 첨부할 수 있습니다',
  fileReadError: '파일을 읽는 데 실패했습니다. 다시 시도해 주세요',
  previewFileTooltip: '파일 미리보기',
  removeFileTooltip: '첨부 삭제',

  saveBtn: '의료 기록 저장',
  savingBtn: '저장 중...',
  errSelectPet: '먼저 반려동물을 선택하거나 추가해 주세요',
  errEnterTitle: '검사 제목을 입력해 주세요',

  historyTitle: '이전 의료 기록',
  searchPlaceholder: '제목, 병원 또는 결과 검색...',
  filterAll: '전체',
  loadingHistory: '의료 검사 기록을 불러오는 중...',
  emptyHistory: '조건에 맞는 의료 검사 기록이 없습니다. 위 양식에서 새 기록을 저장해 보세요.',
  viewAction: '보기',
  editAction: '수정',
  deleteAction: '삭제',
  confirmDeleteBtn: '삭제 확인',
  cancelDeleteBtn: '취소',
  attachmentsCount: (n) => `첨부 ${n}개`,

  detailModalTitle: '의료 검사 상세 정보',
  detailCheckupDate: '검사 날짜',
  detailCategory: '문서 유형',
  detailHospital: '진료 병원',
  detailHospitalEmpty: '미입력',
  detailResults: '검사 결과, 이상 수치 및 수의사 소견',
  detailResultsEmpty: '작성된 결과 메모가 없습니다',
  detailAttachments: '업로드된 검사 파일',
  detailNoAttachments: '첨부된 이미지나 PDF 파일이 없습니다',
  closeBtn: '닫기',
  downloadBtn: '다운로드',

  editModalTitle: '의료 검사 기록 수정',
  saveChangesBtn: '변경 사항 저장',
  cancelBtn: '취소',

  categories: {
    lab: '혈액/임상 검사',
    imaging: '영상 검사 (X-ray/초음파)',
    vaccine: '예방 접종',
    prescription: '처방 및 진료기록',
    checkup: '정기 건강검진',
    other: '기타 의료 문서',
  },
};

export const medicalRecordsTranslations: Record<Language, MedicalRecordsCopy> = {
  zh,
  en,
  ko,
};
