export interface CompressImageOptions {
  maxDimension?: number;
  quality?: number;
  mimeType?: 'image/jpeg' | 'image/webp';
}

/**
 * Compresses and resizes an uploaded image File on the client side before sending
 * to the backend / Gemini Vision API. This reduces multi-MB camera photos down to
 * ~100-250 KB while keeping text and details crisp for OCR and visual analysis.
 */
export async function compressImage(
  file: File,
  options: CompressImageOptions = {}
): Promise<string> {
  const {
    maxDimension = 1200,
    quality = 0.82,
    mimeType = 'image/jpeg',
  } = options;

  const readAsDataURL = (blob: Blob): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Failed to read image file'));
      reader.readAsDataURL(blob);
    });

  // Skip re-encoding tiny images (< 120KB) unless they are non-standard formats
  if (file.size > 0 && file.size < 120 * 1024 && (file.type === 'image/jpeg' || file.type === 'image/webp')) {
    return readAsDataURL(file);
  }

  try {
    let width = 0;
    let height = 0;
    let drawSource: CanvasImageSource;
    let cleanup: (() => void) | undefined;

    if (typeof createImageBitmap === 'function') {
      const bitmap = await createImageBitmap(file);
      width = bitmap.width;
      height = bitmap.height;
      drawSource = bitmap;
      cleanup = () => bitmap.close();
    } else {
      const objectUrl = URL.createObjectURL(file);
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('Failed to decode image'));
        image.src = objectUrl;
      });
      width = img.naturalWidth || img.width;
      height = img.naturalHeight || img.height;
      drawSource = img;
      cleanup = () => URL.revokeObjectURL(objectUrl);
    }

    try {
      if (!width || !height) {
        return await readAsDataURL(file);
      }

      const scale = Math.min(1, maxDimension / Math.max(width, height));
      const targetWidth = Math.max(1, Math.round(width * scale));
      const targetHeight = Math.max(1, Math.round(height * scale));

      const canvas = document.createElement('canvas');
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        return await readAsDataURL(file);
      }

      // Fill white background in case source PNG/WEBP has transparency
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, targetWidth, targetHeight);
      ctx.drawImage(drawSource, 0, 0, targetWidth, targetHeight);

      const compressed = canvas.toDataURL(mimeType, quality);
      if (compressed && compressed.startsWith('data:image/')) {
        return compressed;
      }
      return await readAsDataURL(file);
    } finally {
      cleanup?.();
    }
  } catch (err) {
    console.warn('Image compression fallback to raw file:', err);
    return readAsDataURL(file);
  }
}

export function parseDataUrl(dataUrl: string): { mimeType: string; data: string } {
  const commaIdx = dataUrl.indexOf(',');
  if (commaIdx === -1) {
    return { mimeType: 'image/jpeg', data: dataUrl };
  }
  const header = dataUrl.slice(0, commaIdx);
  const data = dataUrl.slice(commaIdx + 1);
  const mimeMatch = header.match(/data:([^;]+)/);
  return {
    mimeType: mimeMatch?.[1] || 'image/jpeg',
    data,
  };
}
