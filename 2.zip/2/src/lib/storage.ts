export interface Pet {
  id: string;
  name: string;
  species: 'dog' | 'cat' | 'other';
  gender: 'male' | 'female';
  age?: number;
  weight?: number;
  isNeutered: boolean;
  breed?: string;
  avatar?: string;
  diet?: string;
  water?: string;
  vaccineStatus?: string;
  companionStartDate?: string;
}

export interface HealthRecord {
  id: string;
  petId: string;
  date: string;
  type: 'vaccine' | 'activity' | 'diet' | 'medical';
  title: string;
  content: string;
  attachments?: string[];
}

const DEFAULT_PETS: Pet[] = [
  {
    id: 'pet_bella',
    name: 'Bella',
    species: 'dog',
    gender: 'female',
    weight: 28,
    isNeutered: true,
    avatar: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=200&q=80',
    diet: JSON.stringify([{ name: '天然三文鱼无谷幼犬粮', amount: '220' }, { name: '冻干鸡肉粒', amount: '30' }]),
    water: '850ml',
    vaccineStatus: '2026-12-15',
    companionStartDate: '2024-03-10'
  }
];

const DEFAULT_RECORDS: HealthRecord[] = [
  {
    id: 'rec_1',
    petId: 'pet_bella',
    date: '2023-01-15',
    type: 'medical',
    title: '常规称重 (Weight)',
    content: '25'
  },
  {
    id: 'rec_2',
    petId: 'pet_bella',
    date: '2023-04-12',
    type: 'medical',
    title: '春季复查 (Weight)',
    content: '26.5'
  },
  {
    id: 'rec_3',
    petId: 'pet_bella',
    date: '2023-08-20',
    type: 'medical',
    title: '驱虫与称重 (Weight)',
    content: '28'
  },
  {
    id: 'rec_4',
    petId: 'pet_bella',
    date: '2023-12-08',
    type: 'medical',
    title: '年度体检称重 (Weight)',
    content: '28.3'
  }
];

export const storage = {
  getPets(): Pet[] {
    const raw = localStorage.getItem('pets');
    if (!raw) {
      localStorage.setItem('pets', JSON.stringify(DEFAULT_PETS));
      return DEFAULT_PETS;
    }
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((p: Pet) =>
          p.id === 'pet_bella' && !p.companionStartDate
            ? { ...p, companionStartDate: '2024-03-10' }
            : p
        );
      }
      localStorage.setItem('pets', JSON.stringify(DEFAULT_PETS));
      return DEFAULT_PETS;
    } catch {
      return DEFAULT_PETS;
    }
  },
  savePet(pet: Pet) {
    const pets = this.getPets();
    const index = pets.findIndex(p => p.id === pet.id);
    if (index > -1) pets[index] = pet;
    else pets.push(pet);
    localStorage.setItem('pets', JSON.stringify(pets));
  },
  getHealthRecords(petId: string): HealthRecord[] {
    const raw = localStorage.getItem('health_records');
    if (!raw) {
      if (petId === 'pet_bella') {
        localStorage.setItem('health_records', JSON.stringify(DEFAULT_RECORDS));
        return DEFAULT_RECORDS;
      }
      return [];
    }
    try {
      const all: HealthRecord[] = JSON.parse(raw);
      const filtered = all.filter((r: HealthRecord) => r.petId === petId);
      if (filtered.length === 0 && petId === 'pet_bella') {
        const combined = [...all, ...DEFAULT_RECORDS];
        localStorage.setItem('health_records', JSON.stringify(combined));
        return DEFAULT_RECORDS;
      }
      return filtered.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
    } catch {
      return petId === 'pet_bella' ? DEFAULT_RECORDS : [];
    }
  },
  saveHealthRecord(record: HealthRecord) {
    const raw = localStorage.getItem('health_records');
    const all: HealthRecord[] = raw ? JSON.parse(raw) : [];
    all.push(record);
    localStorage.setItem('health_records', JSON.stringify(all));
  }
};
