import * as THREE from 'three';
import petBreedsData from '../data/pet_breed.json';

/**
 * 开场交互状态机 PetState
 * - SCATTERED: 初始状态，所有特征点、信息组件、装饰粒子在球形空间内散开漂浮
 * - PET_SHAPE: 点击画布后平滑聚合，组成金毛寻回犬头部 3D 轮廓；完成后浮现进入主页面提示
 */
export enum PetState {
  SCATTERED = 'SCATTERED',
  PET_SHAPE = 'PET_SHAPE',
}

/**
 * 跳转信号载荷（供主应用 / Replit 前端捕捉并切换路由）
 */
export interface EnterAppSignal {
  signal: 'ENTER_PET_MAIN_APP';
  state: PetState;
  breedId: string;
  targetTab: 'home';
  timestamp: string;
}

/**
 * 内置金毛百科静态数据（同步自 pet_breed.json，支持导出为标准 JSON）
 */
export interface GoldenRetrieverEncyclopedia {
  id: string;
  species: 'dog';
  name: string;
  englishName: string;
  tagline: string;
  origin: string;
  lifespan: string;
  sizeLabel: string;
  coatLabel: string;
  temperament: string[];
  difficultyLabel: string;
  geneticDiseases: string[];
  careTips: string[];
}

const rawGolden = (petBreedsData as any[]).find((b) => b.id === 'golden-retriever');

export const GOLDEN_RETRIEVER_DATA: GoldenRetrieverEncyclopedia = {
  id: rawGolden?.id || 'golden-retriever',
  species: 'dog',
  name: rawGolden?.name || '金毛寻回犬',
  englishName: rawGolden?.englishName || 'Golden Retriever',
  tagline: '温顺家庭伴侣犬',
  origin: rawGolden?.origin || '英国苏格兰',
  lifespan: rawGolden?.lifespan || '10 - 13 年',
  sizeLabel: rawGolden?.sizeLabel || '大型 (25 - 34 kg)',
  coatLabel: rawGolden?.coatLabel || '长毛',
  temperament: rawGolden?.temperament || ['温顺友善', '聪明易训', '极度亲人'],
  difficultyLabel: rawGolden?.difficultyLabel || '较易饲养',
  geneticDiseases: rawGolden?.geneticDiseases || ['髋/肘关节发育不良', '白内障/眼疾', '皮肤湿疹与过敏'],
  careTips: rawGolden?.careTips || [
    '每日需保证 60 分钟以上户外遛弯与捡球互动，避免精力过剩啃咬家具。',
    '双层被毛掉毛较多，建议隔日梳理并在洗澡后彻底吹干底层毛发，预防皮肤湿疹。',
    '幼犬期避免频繁上下楼梯与剧烈跳跃，成年后注意控制食量防肥胖。',
  ],
};

/**
 * 双位置元素定义（Dual Position System）
 * 每个元素同时携带球形散开坐标 scatterPosition 与金毛轮廓聚合坐标 petPosition
 */
export interface DualPositionPointData {
  count: number;
  scatterPositions: Float32Array;
  petPositions: Float32Array;
  colors: Float32Array;
  sizes: Float32Array;
  phases: Float32Array;
  weights: Float32Array;
}

export interface InfoElementSpec {
  id: string;
  kind: 'card' | 'tag' | 'paw' | 'heart';
  title: string;
  subtitle?: string;
  /** 飘动权重：重型卡片 ~0.22，轻型标签 ~0.62，极轻爪印/爱心 ~1.35 */
  floatWeight: number;
  scatterPosition: THREE.Vector3;
  petPosition: THREE.Vector3;
  phase: number;
  scale: number;
}

/** 确定性伪随机生成器，保证每次开场散开美学分布稳定且可复现 */
function createSeededRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/** 在半径 [minR, maxR] 的球形空间内均匀采样 scatterPosition */
function sampleSpherePoint(rand: () => number, minR: number, maxR: number): [number, number, number] {
  const u = rand();
  const v = rand();
  const theta = u * 2 * Math.PI;
  const phi = Math.acos(2 * v - 1);
  const r = minR + Math.cbrt(rand()) * (maxR - minR);
  return [
    r * Math.sin(phi) * Math.cos(theta) * 1.18,
    r * Math.sin(phi) * Math.sin(theta) * 0.92,
    r * Math.cos(phi) * 0.85,
  ];
}

/**
 * 生成金毛头部 3D 轮廓特征点云的双位置数据
 * 包含：颅顶、双侧下垂长耳、脸颊绒毛、前凸吻部、鼻头、双眸、微笑嘴角、胸前蓬毛
 */
export function buildGoldenHeadPointCloud(totalCount: number = 1650): DualPositionPointData {
  const rand = createSeededRandom(20261120);

  const scatterPositions = new Float32Array(totalCount * 3);
  const petPositions = new Float32Array(totalCount * 3);
  const colors = new Float32Array(totalCount * 3);
  const sizes = new Float32Array(totalCount);
  const phases = new Float32Array(totalCount);
  const weights = new Float32Array(totalCount);

  // 暖奶金 + 浅棕 + 暖橙光晕调色板
  const creamGold = new THREE.Color('#FFF2C9');
  const warmGold = new THREE.Color('#F2C272');
  const honeyAmber = new THREE.Color('#E39A4B');
  const softBrown = new THREE.Color('#9A6638');
  const darkFeature = new THREE.Color('#4B2D19');
  const smileWarm = new THREE.Color('#D97757');
  const tmpColor = new THREE.Color();

  for (let i = 0; i < totalCount; i++) {
    const i3 = i * 3;
    const [sx, sy, sz] = sampleSpherePoint(rand, 2.2, 5.4);
    scatterPositions[i3] = sx;
    scatterPositions[i3 + 1] = sy;
    scatterPositions[i3 + 2] = sz;

    let px = 0;
    let py = 0;
    let pz = 0;
    let size = 0.08 + rand() * 0.06;
    let weight = 0.75 + rand() * 0.55;

    const p = i / totalCount;

    if (p < 0.36) {
      // 1. 圆润颅顶与面部轮廓主体 (Dome + Cheek silhouette)
      const angle = rand() * Math.PI * 2;
      const band = rand();
      const shellBias = band < 0.55 ? 0.88 + rand() * 0.14 : Math.sqrt(rand()) * 0.88;
      const rx = 1.05 * shellBias;
      const ry = 0.95 * shellBias;
      px = Math.cos(angle) * rx;
      py = Math.sin(angle) * ry + 0.14;
      // 下颊略宽，体现金毛温柔圆润脸颊
      if (py < 0.1) {
        px *= 1.08;
      }
      const distNorm = Math.min(1, Math.hypot(px / 1.12, (py - 0.12) / 1.0));
      pz = Math.sqrt(Math.max(0.02, 1 - distNorm * distNorm)) * 0.78 * (rand() > 0.22 ? 1 : -0.55);

      tmpColor.copy(creamGold).lerp(warmGold, 0.35 + distNorm * 0.55);
      if (band < 0.35) {
        tmpColor.lerp(honeyAmber, 0.35);
      }
    } else if (p < 0.60) {
      // 2. 两侧软萌下垂长耳 (Floppy Golden Retriever Ears)
      const side = i % 2 === 0 ? -1 : 1;
      const t = rand(); // 0=耳根(上) -> 1=耳尖(下)
      const spread = 0.94 + t * 0.44 + (rand() - 0.5) * 0.24 * (1 - t * 0.3);
      const earY = 0.68 - t * 1.48;
      const earWave = Math.sin(t * Math.PI) * 0.14;
      px = side * (spread + earWave);
      py = earY + (rand() - 0.5) * 0.12;
      pz = 0.16 - t * 0.28 + (rand() - 0.5) * 0.24;

      tmpColor.copy(honeyAmber).lerp(softBrown, 0.25 + t * 0.58);
      size *= 1.06;
    } else if (p < 0.76) {
      // 3. 立体前凸吻部与鼻梁 (3D Muzzle & Snout)
      const u = rand() * Math.PI * 2;
      const depth = rand();
      const rMuzzle = 0.44 - depth * 0.11;
      px = Math.cos(u) * rMuzzle * 1.08;
      py = -0.26 + Math.sin(u) * rMuzzle * 0.74;
      pz = 0.52 + depth * 0.62;

      tmpColor.copy(creamGold).lerp(warmGold, 0.28);
    } else if (p < 0.81) {
      // 4. 黑亮大鼻头 (Distinctive Golden Nose)
      const a = rand() * Math.PI * 2;
      const r = Math.sqrt(rand()) * 0.19;
      px = Math.cos(a) * r * 1.2;
      py = -0.07 + Math.sin(a) * r * 0.78;
      pz = 1.15 + Math.cos(r * 4) * 0.06;

      tmpColor.copy(darkFeature);
      size = 0.085 + rand() * 0.03;
      weight = 0.38;
    } else if (p < 0.86) {
      // 5. 温柔亮眸 (Left & Right Expressive Eyes)
      const side = i % 2 === 0 ? -1 : 1;
      const a = rand() * Math.PI * 2;
      const r = Math.sqrt(rand()) * 0.105;
      px = side * 0.44 + Math.cos(a) * r;
      py = 0.30 + Math.sin(a) * r * 0.88;
      pz = 0.88 + (1 - r * 5) * 0.04;

      // 眼瞳微带一点点高光
      tmpColor.copy(rand() < 0.18 ? creamGold : darkFeature);
      size = 0.08 + rand() * 0.025;
      weight = 0.35;
    } else if (p < 0.91) {
      // 6. 招牌金毛微笑唇线与微露浅暖舌头 (Warm Golden Smile)
      if (rand() < 0.72) {
        const s = (rand() - 0.5) * 2; // -1..1
        px = s * 0.36;
        // W 形温柔微笑弧线
        py = -0.34 - Math.cos(s * Math.PI * 1.1) * 0.06 - Math.abs(s) * 0.05;
        pz = 1.06 - Math.abs(s) * 0.12;
        tmpColor.copy(darkFeature);
      } else {
        // 温柔吐舌弧线
        const a = rand() * Math.PI;
        const r = Math.sqrt(rand()) * 0.15;
        px = Math.cos(a) * r * 0.85;
        py = -0.45 - Math.sin(a) * r * 1.15;
        pz = 1.02;
        tmpColor.copy(smileWarm);
      }
      size = 0.078 + rand() * 0.025;
      weight = 0.42;
    } else {
      // 7. 胸前蓬松围脖与外缘柔和金光晕 (Chest Ruff & Soft Aura)
      const s = (rand() - 0.5) * 2.2;
      const t = rand();
      px = s * (0.95 + t * 0.25);
      py = -0.92 - t * 0.42 + s * s * 0.12;
      pz = 0.25 - t * 0.32 + (rand() - 0.5) * 0.35;

      tmpColor.copy(creamGold).lerp(honeyAmber, 0.25 + t * 0.45);
      size = 0.095 + rand() * 0.06;
    }

    petPositions[i3] = px;
    petPositions[i3 + 1] = py;
    petPositions[i3 + 2] = pz;

    colors[i3] = tmpColor.r;
    colors[i3 + 1] = tmpColor.g;
    colors[i3 + 2] = tmpColor.b;

    sizes[i] = size;
    phases[i] = rand() * Math.PI * 2;
    weights[i] = weight;
  }

  return {
    count: totalCount,
    scatterPositions,
    petPositions,
    colors,
    sizes,
    phases,
    weights,
  };
}

/**
 * 构建实例化信息组件（重型卡片 / 轻型标签 / 极轻爪印与爱心粒子）
 * 各自具备明确的 scatterPosition、petPosition 与差异化 floatWeight
 */
export function buildInfoElements(): InfoElementSpec[] {
  const rand = createSeededRandom(88421);
  const elements: InfoElementSpec[] = [
    // 1. 重型元素：迷你品种简介卡片（飘动最慢 weight = 0.22）
    {
      id: 'card-golden-intro',
      kind: 'card',
      title: '金毛寻回犬 · Golden Retriever',
      subtitle: '温顺家庭伴侣犬 ｜ 英国苏格兰',
      floatWeight: 0.22,
      scatterPosition: new THREE.Vector3(-2.7, 1.55, 0.6),
      petPosition: new THREE.Vector3(2.48, 0.74, 0.18),
      phase: 0.4,
      scale: 1.0,
    },
    // 2. 轻型元素：3 个百科关键标签（飘动适中 weight = 0.58~0.68）
    {
      id: 'tag-weight',
      kind: 'tag',
      title: '体重：25 - 34 kg',
      subtitle: '大型长毛寻回犬',
      floatWeight: 0.58,
      scatterPosition: new THREE.Vector3(2.6, 1.65, -0.7),
      petPosition: new THREE.Vector3(-2.35, 0.78, 0.15),
      phase: 1.5,
      scale: 0.88,
    },
    {
      id: 'tag-lifespan',
      kind: 'tag',
      title: '寿命：10 - 13 年',
      subtitle: '温顺亲人 · 聪明易训',
      floatWeight: 0.62,
      scatterPosition: new THREE.Vector3(-2.9, -1.35, -0.5),
      petPosition: new THREE.Vector3(-2.32, -0.45, 0.25),
      phase: 2.8,
      scale: 0.88,
    },
    {
      id: 'tag-care',
      kind: 'tag',
      title: '饲养提示：每日 60 分钟户外互动',
      subtitle: '隔日梳毛 · 护关节防肥胖',
      floatWeight: 0.66,
      scatterPosition: new THREE.Vector3(2.85, -1.35, 0.75),
      petPosition: new THREE.Vector3(2.42, -0.52, 0.2),
      phase: 4.1,
      scale: 0.88,
    },
  ];

  // 3. 极轻元素：18 个爪印、爱心小粒子（飘动幅度最大 weight = 1.25~1.55）
  const decorCount = 18;
  for (let i = 0; i < decorCount; i++) {
    const kind = i % 2 === 0 ? 'paw' : 'heart';
    const [sx, sy, sz] = sampleSpherePoint(rand, 2.0, 4.8);
    const orbitAngle = (i / decorCount) * Math.PI * 2;
    const orbitR = 1.75 + (i % 3) * 0.36;
    const petX = Math.cos(orbitAngle) * orbitR * 1.15;
    const petY = Math.sin(orbitAngle) * orbitR * 0.88 + 0.05;
    const petZ = -0.35 + Math.sin(orbitAngle * 2) * 0.45;

    elements.push({
      id: `${kind}-${i}`,
      kind,
      title: kind === 'paw' ? '爪印' : '爱心',
      floatWeight: 1.25 + rand() * 0.35,
      scatterPosition: new THREE.Vector3(sx, sy, sz),
      petPosition: new THREE.Vector3(petX, petY, petZ),
      phase: rand() * Math.PI * 2,
      scale: 0.32 + rand() * 0.14,
    });
  }

  return elements;
}

/**
 * 触发标准 JSON 文件下载，供答辩或外部对接导出金毛静态百科数据
 */
export function exportGoldenRetrieverJson(): string {
  const payload = {
    coverTitle: 'Golden Retriever 金毛启动首页',
    exportedAt: new Date().toISOString(),
    breed: GOLDEN_RETRIEVER_DATA,
  };
  const jsonText = JSON.stringify(payload, null, 2);

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    const blob = new Blob([jsonText], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'golden_retriever_encyclopedia.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return jsonText;
}
