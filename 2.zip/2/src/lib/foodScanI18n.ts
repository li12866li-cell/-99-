import { Language } from './i18n.ts';
import { FoodSafetyLevel } from '../data/foodSafetyCatalog.ts';
import { InteractivePreferenceTab } from '../components/FoodPreferenceEntryCards.tsx';

export interface FoodScanCopy {
  libraryTitle: string;
  libraryTitleFallback: string;
  librarySubtitle: (speciesLabel: string) => string;
  dogSpecies: string;
  catSpecies: string;

  categories: Record<
    InteractivePreferenceTab,
    {
      title: string;
      placeholder: string;
    }
  >;
  countUnit: string;
  clickExpand: string;
  clickCollapse: string;
  addFoodBtn: string;
  collapseAria: string;
  quickAddLabel: string;
  emptyPrefList: string;
  customItemLabel: string;
  customBadgeLabel: string;
  categoryShortLabels: Record<InteractivePreferenceTab, string>;
  customCardSubtitle: (petName: string) => string;
  customCardFallbackNote: string;
  clickToEditOrView: string;
  viewDetailsLabel: string;

  // Modal Add/Edit
  addModalTitle: string;
  editModalTitle: string;
  foodNameLabel: string;
  foodNamePlaceholder: string;
  foodIconLabel: string;
  autoMatchedBadge: string;
  manualSelectedBadge: string;
  resetAutoIconBtn: string;
  foodNoteLabel: string;
  foodNotePlaceholder: string;
  saveBtn: string;
  saveChangesBtn: string;
  cancelBtn: string;
  errEmptyName: string;
  errDuplicateName: (name: string) => string;
  toastAdded: (petName: string, categoryTitle: string) => string;
  toastQuickAdded: (name: string, petName: string, categoryTitle: string) => string;
  toastUpdated: (name: string, petName: string) => string;
  toastDeleted: string;
  editTooltip: string;
  deleteTooltip: string;

  // Search & 27-food DB section
  searchPlaceholder: string;
  clearSearchAria: string;
  filterAll: string;
  levels: Record<FoodSafetyLevel, string>;
  commonQueriesLabel: string;
  emptySearchTitle: string;
  emptySearchDesc: (query: string) => string;
  showAllFoodsBtn: string;
  keyComponentsLabel: string;
  healthRisksLabel: string;
  clickForDetails: string;
  expandLabel: string;

  // Alerts & Detail Modal
  petAllergyAlert: (petName: string) => string;
  petDislikeAlert: (petName: string) => string;
  petLikeAlert: (petName: string) => string;
  safetyLevelPrefix: string;
  closeDetailAria: string;
  dogSuitabilityTitle: string;
  catSuitabilityTitle: string;
  feedingPrecautionsTitle: string;
  addToPetGalleryLabel: (petName: string) => string;
  quickLikeBtn: string;
  quickDislikeBtn: string;
  quickAllergyBtn: string;
  backToListBtn: string;
  customFoodDesc: (petName: string) => string;
  customFoodDisclaimer: string;
  removeBtn: string;
  closeBtn: string;
}

const zh: FoodScanCopy = {
  libraryTitle: '的饮食偏好图库',
  libraryTitleFallback: '宠物饮食偏好图库',
  librarySubtitle: (speciesLabel) => `${speciesLabel} · 点击卡片展开食物清单，或直接点击「＋ 添加食物」`,
  dogSpecies: '狗狗',
  catSpecies: '猫咪',

  categories: {
    likes: {
      title: '宠物喜欢的食物',
      placeholder: '输入喜欢的食物，如：苹果、鸡胸肉、南瓜...',
    },
    dislikes: {
      title: '宠物讨厌的食物',
      placeholder: '输入讨厌的食物，如：西兰花、胡萝卜...',
    },
    allergies: {
      title: '宠物过敏的食物',
      placeholder: '输入过敏的食物，如：虾仁、牛奶、鸡蛋...',
    },
  },
  countUnit: '种',
  clickExpand: '点击展开',
  clickCollapse: '点击收起',
  addFoodBtn: '＋ 添加食物',
  collapseAria: '收起',
  quickAddLabel: '快速添加：',
  emptyPrefList: '暂无记录的食物，点击右上角「＋ 添加食物」或上方推荐食材即可添加',
  customItemLabel: '自定义食物',
  customBadgeLabel: '自定义',
  categoryShortLabels: {
    likes: '喜欢',
    dislikes: '讨厌',
    allergies: '过敏',
  },
  customCardSubtitle: (petName) => `${petName} · 个人偏好添加`,
  customCardFallbackNote: '个人自定义添加的食物，不代表官方食物安全等级分类。',
  clickToEditOrView: '点击查看或编辑',
  viewDetailsLabel: '查看详情',

  addModalTitle: '添加食物偏好',
  editModalTitle: '修改食物信息',
  foodNameLabel: '食物名称 *',
  foodNamePlaceholder: '例如：苹果、香蕉、胡萝卜、鸡肉、鱼肉、鸡蛋、牛奶、南瓜...',
  foodIconLabel: '食物图标',
  autoMatchedBadge: '已自动匹配图标',
  manualSelectedBadge: '已手动选择图标',
  resetAutoIconBtn: '恢复自动匹配',
  foodNoteLabel: '喂食备注（可选）',
  foodNotePlaceholder: '例如：每次喂一小块、蒸熟切碎、忌食原因...',
  saveBtn: '保存',
  saveChangesBtn: '保存修改',
  cancelBtn: '取消',
  errEmptyName: '请输入食物名称',
  errDuplicateName: (name) => `「${name}」已在该分类列表中`,
  toastAdded: (petName, categoryTitle) => `已为 ${petName} 添加到「${categoryTitle}」`,
  toastQuickAdded: (name, petName, categoryTitle) =>
    `已将「${name}」加入 ${petName} 的${categoryTitle}`,
  toastUpdated: (name, petName) => `已更新 ${petName} 的「${name}」`,
  toastDeleted: '已移除该食物',
  editTooltip: '修改',
  deleteTooltip: '删除',

  searchPlaceholder: '输入食物或成分关键词搜索（如：巧克力、葡萄、洋葱、木糖醇、鸡胸肉...）',
  clearSearchAria: '清除搜索',
  filterAll: '全部',
  levels: {
    safe: '相对安全',
    caution: '需要谨慎',
    forbidden: '禁止喂食',
  },
  commonQueriesLabel: '常见查询：',
  emptySearchTitle: '暂无可靠资料',
  emptySearchDesc: (q) =>
    `本地食物安全数据库暂未收录与「${q}」匹配的条目。不确定安全性的食物请勿喂食，建议联系执业兽医确认。`,
  showAllFoodsBtn: '查看全部已收录食材',
  keyComponentsLabel: '危险 / 关键成分',
  healthRisksLabel: '潜在健康风险',
  clickForDetails: '点击查看完整详情',
  expandLabel: '展开',

  petAllergyAlert: (petName) => `${petName} 过敏/忌食`,
  petDislikeAlert: (petName) => `${petName} 讨厌`,
  petLikeAlert: (petName) => `${petName} 喜欢`,
  safetyLevelPrefix: '安全等级：',
  closeDetailAria: '关闭详情并返回列表',
  dogSuitabilityTitle: '对狗狗是否适合',
  catSuitabilityTitle: '对猫咪是否适合',
  feedingPrecautionsTitle: '喂食注意事项',
  addToPetGalleryLabel: (petName) => `添加到 ${petName} 的图库：`,
  quickLikeBtn: '+ 喜欢',
  quickDislikeBtn: '+ 讨厌',
  quickAllergyBtn: '+ 过敏',
  backToListBtn: '返回列表',
  customFoodDesc: (petName) => `属于 ${petName} 的自定义食物记录。`,
  customFoodDisclaimer: '个人偏好分类与公共食物安全数据库分开保存，不会改变全局食物安全等级。',
  removeBtn: '移除',
  closeBtn: '关闭',
};

const en: FoodScanCopy = {
  libraryTitle: "'s Diet Preference Gallery",
  libraryTitleFallback: 'Pet Diet Preference Gallery',
  librarySubtitle: (speciesLabel) =>
    `${speciesLabel} · Click a card to expand, or click "+ Add Food"`,
  dogSpecies: 'Dog',
  catSpecies: 'Cat',

  categories: {
    likes: {
      title: 'Favorite Foods',
      placeholder: 'Enter favorite food, e.g. Apple, Chicken, Pumpkin...',
    },
    dislikes: {
      title: 'Disliked Foods',
      placeholder: 'Enter disliked food, e.g. Broccoli, Carrot...',
    },
    allergies: {
      title: 'Allergic Foods',
      placeholder: 'Enter allergic food, e.g. Shrimp, Milk, Egg...',
    },
  },
  countUnit: 'items',
  clickExpand: 'Expand',
  clickCollapse: 'Collapse',
  addFoodBtn: '+ Add Food',
  collapseAria: 'Collapse',
  quickAddLabel: 'Quick add:',
  emptyPrefList: 'No foods yet. Click "+ Add Food" or choose from quick picks above.',
  customItemLabel: 'Custom Food',
  customBadgeLabel: 'Custom',
  categoryShortLabels: {
    likes: 'Likes',
    dislikes: 'Dislikes',
    allergies: 'Allergic',
  },
  customCardSubtitle: (petName) => `${petName}'s custom entry`,
  customCardFallbackNote:
    'User-added personal food entry. Not classified into official safety levels.',
  clickToEditOrView: 'Click to view or edit',
  viewDetailsLabel: 'View details',

  addModalTitle: 'Add Food Preference',
  editModalTitle: 'Edit Food Item',
  foodNameLabel: 'Food Name *',
  foodNamePlaceholder: 'e.g. Apple, Banana, Carrot, Chicken, Fish, Egg, Milk, Pumpkin...',
  foodIconLabel: 'Food Icon',
  autoMatchedBadge: 'Auto-matched icon',
  manualSelectedBadge: 'Custom selected icon',
  resetAutoIconBtn: 'Auto-match',
  foodNoteLabel: 'Note (Optional)',
  foodNotePlaceholder: 'e.g. Small steamed pieces only, allergy reaction...',
  saveBtn: 'Save',
  saveChangesBtn: 'Save Changes',
  cancelBtn: 'Cancel',
  errEmptyName: 'Please enter a food name',
  errDuplicateName: (name) => `"${name}" is already in this list`,
  toastAdded: (petName, categoryTitle) => `Added to ${petName}'s "${categoryTitle}"`,
  toastQuickAdded: (name, petName, categoryTitle) =>
    `Added "${name}" to ${petName}'s ${categoryTitle}`,
  toastUpdated: (name, petName) => `Updated "${name}" for ${petName}`,
  toastDeleted: 'Food item removed',
  editTooltip: 'Edit',
  deleteTooltip: 'Delete',

  searchPlaceholder: 'Search foods or ingredients (e.g. chocolate, grape, chicken, pumpkin...)',
  clearSearchAria: 'Clear search',
  filterAll: 'All',
  levels: {
    safe: 'Relatively Safe',
    caution: 'Use Caution',
    forbidden: 'Forbidden',
  },
  commonQueriesLabel: 'Popular:',
  emptySearchTitle: 'No Reliable Data Found',
  emptySearchDesc: (q) =>
    `No entry matching "${q}" was found in the local safety database. Never feed uncertain foods without consulting a vet.`,
  showAllFoodsBtn: 'Show All Database Foods',
  keyComponentsLabel: 'Key / Toxic Components',
  healthRisksLabel: 'Potential Health Risks',
  clickForDetails: 'Click for full details',
  expandLabel: 'View',

  petAllergyAlert: (petName) => `${petName} Allergic`,
  petDislikeAlert: (petName) => `${petName} Dislikes`,
  petLikeAlert: (petName) => `${petName} Likes`,
  safetyLevelPrefix: 'Safety Level: ',
  closeDetailAria: 'Close details',
  dogSuitabilityTitle: 'Suitability for Dogs',
  catSuitabilityTitle: 'Suitability for Cats',
  feedingPrecautionsTitle: 'Feeding Precautions',
  addToPetGalleryLabel: (petName) => `Add to ${petName}'s list:`,
  quickLikeBtn: '+ Favorite',
  quickDislikeBtn: '+ Dislike',
  quickAllergyBtn: '+ Allergy',
  backToListBtn: 'Back to List',
  customFoodDesc: (petName) => `Personal food preference entry for ${petName}.`,
  customFoodDisclaimer:
    'Personal preferences are saved separately from the public food safety database and do not alter global safety ratings.',
  removeBtn: 'Remove',
  closeBtn: 'Close',
};

const ko: FoodScanCopy = {
  libraryTitle: '의 식단 선호 목록',
  libraryTitleFallback: '반려동물 식단 선호 목록',
  librarySubtitle: (speciesLabel) =>
    `${speciesLabel} · 카드를 눌러 목록을 보거나 「＋ 음식 추가」를 클릭하세요`,
  dogSpecies: '강아지',
  catSpecies: '고양이',

  categories: {
    likes: {
      title: '좋아하는 음식',
      placeholder: '좋아하는 음식을 입력하세요 (예: 사과, 닭가슴살, 호박...)',
    },
    dislikes: {
      title: '싫어하는 음식',
      placeholder: '싫어하는 음식을 입력하세요 (예: 브로콜리, 당근...)',
    },
    allergies: {
      title: '알레르기 음식',
      placeholder: '알레르기 음식을 입력하세요 (예: 새우, 우유, 달걀...)',
    },
  },
  countUnit: '개',
  clickExpand: '펼치기',
  clickCollapse: '접기',
  addFoodBtn: '＋ 음식 추가',
  collapseAria: '접기',
  quickAddLabel: '빠른 추가:',
  emptyPrefList: '등록된 음식이 없습니다. 「＋ 음식 추가」를 눌러 추가해 보세요.',
  customItemLabel: '사용자 추가',
  customBadgeLabel: '사용자 추가',
  categoryShortLabels: {
    likes: '좋아함',
    dislikes: '싫어함',
    allergies: '알레르기',
  },
  customCardSubtitle: (petName) => `${petName} 맞춤 등록`,
  customCardFallbackNote:
    '사용자가 직접 추가한 음식으로 공식 안전 등급에 자동 분류되지 않습니다.',
  clickToEditOrView: '클릭하여 보기 또는 수정',
  viewDetailsLabel: '상세 보기',

  addModalTitle: '음식 선호 추가',
  editModalTitle: '음식 정보 수정',
  foodNameLabel: '음식 이름 *',
  foodNamePlaceholder: '예: 사과, 바나나, 당근, 닭고기, 생선, 달걀, 우유, 호박...',
  foodIconLabel: '음식 아이콘',
  autoMatchedBadge: '자동 매칭됨',
  manualSelectedBadge: '직접 선택됨',
  resetAutoIconBtn: '자동 매칭 복원',
  foodNoteLabel: '메모 (선택 사항)',
  foodNotePlaceholder: '예: 삶아서 잘게 썰어 급여, 알레르기 반응 주의...',
  saveBtn: '저장',
  saveChangesBtn: '수정 저장',
  cancelBtn: '취소',
  errEmptyName: '음식 이름을 입력해 주세요',
  errDuplicateName: (name) => `「${name}」은(는) 이미 목록에 있습니다`,
  toastAdded: (petName, categoryTitle) => `${petName}의 「${categoryTitle}」에 추가되었습니다`,
  toastQuickAdded: (name, petName, categoryTitle) =>
    `${petName}의 ${categoryTitle}에 「${name}」을(를) 추가했습니다`,
  toastUpdated: (name, petName) => `${petName}의 「${name}」 정보를 수정했습니다`,
  toastDeleted: '음식이 삭제되었습니다',
  editTooltip: '수정',
  deleteTooltip: '삭제',

  searchPlaceholder: '음식 또는 성분 검색 (예: 초콜릿, 포도, 양파, 자일리톨, 닭가슴살...)',
  clearSearchAria: '검색 지우기',
  filterAll: '전체',
  levels: {
    safe: '상대적 안전',
    caution: '주의 필요',
    forbidden: '급여 금지',
  },
  commonQueriesLabel: '자주 검색:',
  emptySearchTitle: '일치하는 자료가 없습니다',
  emptySearchDesc: (q) =>
    `로컬 안전 데이터베이스에 「${q}」 관련 항목이 없습니다. 안전이 확인되지 않은 음식은 수의사와 상담 후 급여하세요.`,
  showAllFoodsBtn: '전체 음식 목록 보기',
  keyComponentsLabel: '주요 / 주의 성분',
  healthRisksLabel: '잠재적 건강 위험',
  clickForDetails: '클릭하여 상세 보기',
  expandLabel: '자세히',

  petAllergyAlert: (petName) => `${petName} 알레르기`,
  petDislikeAlert: (petName) => `${petName} 싫어함`,
  petLikeAlert: (petName) => `${petName} 좋아함`,
  safetyLevelPrefix: '안전 등급: ',
  closeDetailAria: '상세 닫기',
  dogSuitabilityTitle: '강아지 급여 적합성',
  catSuitabilityTitle: '고양이 급여 적합성',
  feedingPrecautionsTitle: '급여 시 주의사항',
  addToPetGalleryLabel: (petName) => `${petName} 목록에 추가:`,
  quickLikeBtn: '+ 좋아함',
  quickDislikeBtn: '+ 싫어함',
  quickAllergyBtn: '+ 알레르기',
  backToListBtn: '목록으로',
  customFoodDesc: (petName) => `${petName}의 사용자 지정 음식 기록입니다.`,
  customFoodDisclaimer:
    '개인 선호 목록은 공용 식품 안전 데이터베이스와 별도로 저장되며 전역 안전 등급을 변경하지 않습니다.',
  removeBtn: '삭제',
  closeBtn: '닫기',
};

export const foodScanTranslations: Record<Language, FoodScanCopy> = {
  zh,
  en,
  ko,
};
