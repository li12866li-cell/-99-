export interface FoodEmojiOption {
  emoji: string;
  keywords: string[];
}

export const DEFAULT_FOOD_EMOJI = '🍽️';

const FOOD_EMOJI_RULES: FoodEmojiOption[] = [
  { emoji: '🍎', keywords: ['苹果', '青苹果', '红苹果', 'apple', '사과'] },
  { emoji: '🍌', keywords: ['香蕉', '芭蕉', 'banana', '바나나'] },
  { emoji: '🥕', keywords: ['胡萝卜', '红萝卜', '萝卜', 'carrot', '당근'] },
  {
    emoji: '🍗',
    keywords: [
      '鸡肉',
      '鸡胸肉',
      '鸡腿',
      '鸡翅',
      '鸡肝',
      '鸡心',
      '鸡胗',
      '鸭肉',
      '火鸡',
      '冻干鸡肉',
      'chicken',
      'turkey',
      'duck',
      'poultry',
      '닭고기',
      '닭가슴살',
      '오리',
    ],
  },
  {
    emoji: '🐟',
    keywords: [
      '鱼',
      '鱼肉',
      '三文鱼',
      '鲑鱼',
      '鳕鱼',
      '金枪鱼',
      '吞拿鱼',
      '沙丁鱼',
      '小鱼干',
      '多春鱼',
      'fish',
      'salmon',
      'tuna',
      'cod',
      '생선',
      '연어',
      '참치',
    ],
  },
  {
    emoji: '🥚',
    keywords: ['鸡蛋', '蛋黄', '蛋白', '鸭蛋', '鹌鹑蛋', '蛋', 'egg', 'yolk', '계란', '달걀'],
  },
  {
    emoji: '🥛',
    keywords: ['牛奶', '羊奶', '羊奶粉', '奶粉', '酸奶', '鲜奶', '乳制品', '奶', 'milk', 'yogurt', 'dairy', '우유', '요거트'],
  },
  { emoji: '🧀', keywords: ['奶酪', '芝士', '起司', 'cheese', '치즈'] },
  { emoji: '🎃', keywords: ['南瓜', '贝贝南瓜', 'pumpkin', 'squash', '호박'] },
  {
    emoji: '🍠',
    keywords: ['红薯', '地瓜', '番薯', '紫薯', '山药', '土豆', '马铃薯', 'sweet potato', 'yam', 'potato', '고구마', '감자'],
  },
  { emoji: '🥦', keywords: ['西兰花', '花椰菜', '菜花', 'broccoli', '브로콜리'] },
  { emoji: '🫐', keywords: ['蓝莓', '黑莓', 'blueberry', '블루베리'] },
  { emoji: '🍓', keywords: ['草莓', '覆盆子', '树莓', 'strawberry', 'berry', '딸기'] },
  { emoji: '🍉', keywords: ['西瓜', 'watermelon', '수박'] },
  { emoji: '🥭', keywords: ['芒果', 'mango', '망고'] },
  { emoji: '🍑', keywords: ['桃', '水蜜桃', '黄桃', 'peach', '복숭아'] },
  { emoji: '🍐', keywords: ['梨', '雪梨', 'pear', '배'] },
  { emoji: '🥒', keywords: ['黄瓜', '青瓜', '节瓜', 'cucumber', 'zucchini', '오이'] },
  { emoji: '🍅', keywords: ['番茄', '西红柿', '圣女果', 'tomato', '토마토'] },
  { emoji: '🥑', keywords: ['牛油果', '鳄梨', 'avocado', '아보카도'] },
  { emoji: '🦐', keywords: ['虾', '虾仁', '大虾', '磷虾', '螃蟹', '蟹', '海鲜', 'shrimp', 'prawn', 'crab', '새우', '게'] },
  {
    emoji: '🥩',
    keywords: [
      '牛肉',
      '牛排',
      '牛肝',
      '猪肉',
      '羊肉',
      '鹿肉',
      '兔肉',
      '肉干',
      '罐头',
      '肉',
      'beef',
      'steak',
      'pork',
      'lamb',
      'meat',
      '소고기',
      '돼지고기',
      '양고기',
      '고기',
    ],
  },
  { emoji: '🦴', keywords: ['骨头', '熟骨', '排骨', '牛骨', '猪骨', '鸡骨', '磨牙棒', 'bone', '뼈'] },
  {
    emoji: '🥣',
    keywords: [
      '燕麦',
      '麦片',
      '米饭',
      '白米',
      '糙米',
      '狗粮',
      '猫粮',
      '主食',
      '粥',
      'oat',
      'oatmeal',
      'rice',
      'kibble',
      '오트밀',
      '밥',
      '사료',
    ],
  },
  { emoji: '🥜', keywords: ['花生', '花生酱', '夏威夷果', '坚果', '核桃', '杏仁', 'peanut', 'macadamia', 'nut', '땅콩', '견과류'] },
  { emoji: '🍫', keywords: ['巧克力', '可可', '布朗尼', 'chocolate', 'cocoa', '초콜릿'] },
  { emoji: '🍇', keywords: ['葡萄', '提子', '葡萄干', '黑加仑', 'grape', 'raisin', '포도', '건포도'] },
  { emoji: '🧅', keywords: ['洋葱', '大葱', '香葱', '葱', 'onion', 'chive', '양파', '파'] },
  { emoji: '🧄', keywords: ['大蒜', '蒜', '蒜泥', 'garlic', '마늘'] },
  { emoji: '☕', keywords: ['咖啡', '茶', '奶茶', '可乐', '咖啡因', '酒', '啤酒', 'coffee', 'tea', 'alcohol', 'caffeine', '커피', '술'] },
  { emoji: '🥬', keywords: ['猫草', '麦苗', '青菜', '生菜', '白菜', '菠菜', '卷心菜', '蔬菜', 'cat grass', 'lettuce', 'spinach', 'vegetable', '캣그라스', '채소', '야채'] },
  { emoji: '🌸', keywords: ['百合', '百合花', '鲜花', '植物', 'lily', 'flower', '백합'] },
  { emoji: '🍞', keywords: ['面包', '吐司', '饼干', '曲奇', '蛋糕', '馒头', 'bread', 'cookie', 'cake', '빵', '쿠키'] },
  { emoji: '🍬', keywords: ['木糖醇', '口香糖', '糖果', '甜点', 'xylitol', 'candy', 'sugar', '자일리톨', '사탕'] },
  { emoji: '💧', keywords: ['水', '饮水', '骨汤', '肉汤', 'water', 'broth', 'soup', '물'] },
];

export const FOOD_EMOJI_PALETTE: string[] = [
  '🍽️',
  '🍎',
  '🍌',
  '🥕',
  '🍗',
  '🐟',
  '🥚',
  '🥛',
  '🎃',
  '🍠',
  '🥦',
  '🫐',
  '🍓',
  '🍉',
  '🥭',
  '🍑',
  '🥒',
  '🍅',
  '🥩',
  '🦴',
  '🦐',
  '🧀',
  '🥣',
  '🥬',
  '🥜',
  '🍞',
  '🍫',
  '🍇',
];

/**
 * Automatically matches a food name (Chinese / English / Korean) to an Emoji icon.
 * Falls back to '🍽️' when no match is found.
 */
export function matchFoodEmoji(foodName: string): string {
  const normalized = foodName.trim().toLowerCase();
  if (!normalized) return DEFAULT_FOOD_EMOJI;

  for (const rule of FOOD_EMOJI_RULES) {
    if (rule.keywords.some((kw) => normalized.includes(kw.toLowerCase()))) {
      return rule.emoji;
    }
  }
  return DEFAULT_FOOD_EMOJI;
}
