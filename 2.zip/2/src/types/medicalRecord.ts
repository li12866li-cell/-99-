export type MedicalRecordCategory =
  | 'lab'
  | 'imaging'
  | 'vaccine'
  | 'prescription'
  | 'checkup'
  | 'other';

export interface MedicalAttachment {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  dataUrl: string;
}

export interface MedicalRecord {
  id: string;
  userId?: string;
  petId: string;
  title: string;
  date: string;
  hospitalName: string;
  category: MedicalRecordCategory;
  results: string;
  attachments: MedicalAttachment[];
  createdAt: string;
}

export interface MedicalRecordInput {
  petId: string;
  title: string;
  date: string;
  hospitalName: string;
  category: MedicalRecordCategory;
  results: string;
  attachments: MedicalAttachment[];
}

export type ReportExportFormat = 'pdf-print' | 'word-doc' | 'html' | 'markdown' | 'json';
export type ReportScopeMode = 'full' | 'summary';
