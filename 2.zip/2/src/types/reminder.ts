export type ReminderCategory = 'vaccine' | 'deworming' | 'medication' | 'checkup' | 'grooming';
export type ReminderRepeat = 'once' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface Reminder {
  id: string;
  petId: string;
  title: string;
  category: ReminderCategory;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm
  repeat: ReminderRepeat;
  notes?: string;
  completed: boolean;
  createdAt: string;
  isDemo?: boolean;
}

export interface ReminderInput {
  petId: string;
  title: string;
  category: ReminderCategory;
  dueDate: string;
  dueTime?: string;
  repeat: ReminderRepeat;
  notes?: string;
}
