export type PetSpecies = 'dog' | 'cat' | 'bunny' | 'other';
export type PetGender = 'male' | 'female';

export interface PetDietItem {
  name: string;
  amount: string;
}

export interface Pet {
  id: string;
  name: string;
  species: PetSpecies;
  breed?: string;
  gender: PetGender;
  age?: number;
  weight?: number;
  isNeutered: boolean;
  avatar?: string;
  diet?: string;
  water?: string;
  vaccineStatus?: string;
  companionStartDate?: string;
  isDemo?: boolean;
  updatedAt?: string;
}

export interface PetFormInput {
  name: string;
  species: PetSpecies;
  breed?: string;
  gender: PetGender;
  age?: number;
  weight?: number;
  isNeutered: boolean;
  avatar?: string;
  diet?: string;
  companionStartDate?: string;
  water?: string;
  vaccineStatus?: string;
}

export type HealthRecordType = 'vaccine' | 'activity' | 'diet' | 'medical';

export interface HealthRecord {
  id: string;
  petId: string;
  date: string;
  type: HealthRecordType;
  title: string;
  content: string;
  weightKg?: number;
  isDemo?: boolean;
}

export interface HealthRecordInput {
  petId: string;
  date: string;
  type: HealthRecordType;
  title: string;
  content: string;
  weightKg?: number;
}
