import { HealthRecord, HealthRecordInput } from '../types/pet.ts';
import { localStore } from './localStore.ts';

export const recordService = {
  async listRecords(petId?: string): Promise<HealthRecord[]> {
    return localStore.listRecords(petId);
  },

  async createRecord(payload: HealthRecordInput): Promise<HealthRecord> {
    return localStore.createRecord(payload);
  },

  async updateRecord(
    id: string,
    patch: Partial<Omit<HealthRecord, 'id' | 'petId'>>
  ): Promise<HealthRecord> {
    return localStore.updateRecord(id, patch);
  },

  async upsertWeightRecord(
    payload: HealthRecordInput,
    mode: 'overwrite' | 'create' = 'overwrite'
  ): Promise<{ record: HealthRecord; updatedExisting: boolean }> {
    return localStore.upsertWeightRecord(payload, mode);
  },

  async importPetWeightRecords(
    petId: string,
    items: Array<{ date: string; weightKg: number; title?: string; content?: string }>
  ): Promise<{ importedCount: number; updatedCount: number; records: HealthRecord[] }> {
    return localStore.importPetWeightRecords(petId, items);
  },

  async deleteRecord(id: string): Promise<void> {
    localStore.deleteRecord(id);
  },
};
