import { MedicalRecord, MedicalRecordInput } from '../types/medicalRecord.ts';
import { localStore } from './localStore.ts';

export const medicalRecordService = {
  async listMedicalRecords(petId?: string): Promise<MedicalRecord[]> {
    return localStore.listMedicalRecords(petId);
  },

  async createMedicalRecord(payload: MedicalRecordInput): Promise<MedicalRecord> {
    return localStore.createMedicalRecord(payload);
  },

  async updateMedicalRecord(
    id: string,
    patch: Partial<Omit<MedicalRecord, 'id' | 'petId' | 'createdAt'>>
  ): Promise<MedicalRecord> {
    return localStore.updateMedicalRecord(id, patch);
  },

  async deleteMedicalRecord(id: string): Promise<void> {
    localStore.deleteMedicalRecord(id);
  },
};
