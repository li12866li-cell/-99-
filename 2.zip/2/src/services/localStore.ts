import { HealthRecord, HealthRecordInput, Pet, PetFormInput } from '../types/pet.ts';
import { Reminder, ReminderInput } from '../types/reminder.ts';
import { MedicalRecord, MedicalRecordInput } from '../types/medicalRecord.ts';

export interface VirtualPetInteractionLog {
  id: string;
  action: 'pet' | 'feed' | 'checkin' | 'task';
  label: string;
  points: number;
  timestamp: string;
}

export interface VirtualPetState {
  petId: string;
  intimacy: number;
  streakDays: number;
  lastCheckInDate: string | null;
  feedCountToday: number;
  feedDate: string | null;
  interactions: VirtualPetInteractionLog[];
}

export interface SymptomCheckHistoryItem {
  id: string;
  petId: string;
  petName: string;
  symptomIds: string[];
  symptomNames: string[];
  level: 'emergency' | 'urgent' | 'watch';
  headline: string;
  durationLabel?: string;
  reasoning?: string[];
  adviceList?: string[];
  customNote?: string;
  checkedAt: string;
}

export type FoodPreferenceCategory = 'likes' | 'allergies' | 'dislikes' | 'forbidden';

export interface PetFoodPreferenceItem {
  id: string;
  name: string;
  category: FoodPreferenceCategory;
  foodId?: string;
  icon?: string;
  note?: string;
  updatedAt: string;
}

export interface PetFoodPreferences {
  petId: string;
  likes: PetFoodPreferenceItem[];
  allergies: PetFoodPreferenceItem[];
  dislikes: PetFoodPreferenceItem[];
  forbidden: PetFoodPreferenceItem[];
}

export interface VaccineRecord {
  id: string;
  petId: string;
  vaccineName: string;
  vaccinatedDate: string;
  doseCount: string;
  hospital: string;
  notes: string;
  updatedAt: string;
  isDemo?: boolean;
}

export interface VaccineRecordInput {
  petId: string;
  vaccineName: string;
  vaccinatedDate: string;
  doseCount: string;
  hospital?: string;
  notes?: string;
}

const KEYS = {
  INITIALIZED: 'petpulse_initialized_v2',
  PETS: 'petpulse_pets_v2',
  SELECTED_PET: 'petpulse_selected_pet_v2',
  RECORDS: 'petpulse_records_v2',
  REMINDERS: 'petpulse_reminders_v2',
  MEDICAL_RECORDS: 'petpulse_medical_records_v2',
  VIRTUAL_PET: 'petpulse_virtual_pet_v2',
  SYMPTOM_HISTORY: 'petpulse_symptom_history_v2',
  FOOD_PREFERENCES: 'petpulse_food_preferences_v1',
  VACCINE_RECORDS: 'petpulse_vaccine_records_v1',
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage quota errors gracefully
  }
}

function getTodayStr(): string {
  return new Date().toISOString().split('T')[0];
}

function addDaysStr(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function ensureInitialized(): void {
  if (localStorage.getItem(KEYS.INITIALIZED)) return;

  const existingPets = readJson<Pet[]>(KEYS.PETS, []);
  if (existingPets.length === 0) {
    seedInitialDemoData();
  }
  localStorage.setItem(KEYS.INITIALIZED, '1');
}

function seedInitialDemoData(): Pet[] {
  const bellaId = 'pet_demo_bella';
  const mochiId = 'pet_demo_mochi';

  const demoPets: Pet[] = [
    {
      id: bellaId,
      name: 'Bella',
      species: 'dog',
      breed: '金毛寻回犬',
      gender: 'female',
      age: 3,
      weight: 27.8,
      isNeutered: true,
      avatar: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
      diet: JSON.stringify([
        { name: '天然三文鱼无谷成犬粮', amount: '220' },
        { name: '冻干鸡肉粒', amount: '30' },
      ]),
      water: '850ml',
      vaccineStatus: addDaysStr(18),
      companionStartDate: '2024-03-10',
      isDemo: true,
      updatedAt: new Date().toISOString(),
    },
    {
      id: mochiId,
      name: 'Mochi',
      species: 'cat',
      breed: '英国短毛猫',
      gender: 'male',
      age: 2,
      weight: 4.6,
      isNeutered: true,
      avatar: '/src/assets/images/british_shorthair_cat_1794751020533.jpg',
      diet: JSON.stringify([
        { name: '全价室内成猫粮', amount: '55' },
        { name: '鸡肉主食罐头', amount: '85' },
      ]),
      water: '240ml',
      vaccineStatus: addDaysStr(26),
      companionStartDate: '2025-01-15',
      isDemo: true,
      updatedAt: new Date().toISOString(),
    },
  ];

  const demoRecords: HealthRecord[] = [
    {
      id: 'rec_demo_1',
      petId: bellaId,
      date: addDaysStr(-21),
      type: 'vaccine',
      title: '年度联苗免疫检查',
      content: '抗体检测达标，注射部位无异常肿块。',
      weightKg: 27.1,
      isDemo: true,
    },
    {
      id: 'rec_demo_2',
      petId: bellaId,
      date: addDaysStr(-10),
      type: 'activity',
      title: '公园慢走及例行称重',
      content: '早晚各散步 25 分钟，精神饱满，食欲正常。',
      weightKg: 27.5,
      isDemo: true,
    },
    {
      id: 'rec_demo_3',
      petId: bellaId,
      date: addDaysStr(-2),
      type: 'medical',
      title: '常规体况评估与称重',
      content: '27.8 kg，体况评分 BCS 5/9，皮毛光泽良好。',
      weightKg: 27.8,
      isDemo: true,
    },
    {
      id: 'rec_demo_4',
      petId: mochiId,
      date: addDaysStr(-14),
      type: 'medical',
      title: '秋季体内外驱虫后复称',
      content: '体重稳定在 4.5 kg，排便正常。',
      weightKg: 4.5,
      isDemo: true,
    },
    {
      id: 'rec_demo_5',
      petId: mochiId,
      date: addDaysStr(-3),
      type: 'activity',
      title: '居家互动称重记录',
      content: '4.6 kg，建议每天逗猫棒互动两次。',
      weightKg: 4.6,
      isDemo: true,
    },
  ];

  const demoReminders: Reminder[] = [
    {
      id: 'rem_demo_1',
      petId: bellaId,
      title: '体外驱虫滴剂护理',
      category: 'deworming',
      dueDate: addDaysStr(4),
      dueTime: '20:00',
      repeat: 'monthly',
      notes: '滴在肩胛骨后方皮肤处，用药后 48 小时内避免洗澡。',
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: true,
    },
    {
      id: 'rem_demo_2',
      petId: bellaId,
      title: '年度狂犬疫苗加强针',
      category: 'vaccine',
      dueDate: addDaysStr(18),
      dueTime: '10:30',
      repeat: 'yearly',
      notes: '携带免疫本，接种后留院观察 20 分钟。',
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: true,
    },
    {
      id: 'rem_demo_3',
      petId: mochiId,
      title: '猫三联疫苗年度补强',
      category: 'vaccine',
      dueDate: addDaysStr(26),
      dueTime: '14:00',
      repeat: 'yearly',
      notes: '确保接种前精神食欲良好、无发热软便。',
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: true,
    },
    {
      id: 'rem_demo_4',
      petId: mochiId,
      title: '体内广谱驱虫片',
      category: 'deworming',
      dueDate: addDaysStr(6),
      dueTime: '19:30',
      repeat: 'monthly',
      notes: '随晚餐拌食或喂食后观察 1 小时。',
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: true,
    },
  ];

  const demoMedical: MedicalRecord[] = [
    {
      id: 'med_demo_1',
      petId: bellaId,
      title: '秋季常规血常规 + 生化基础检查',
      date: addDaysStr(-5),
      hospitalName: '安心宠伴动物医院',
      category: 'lab',
      results: '红细胞、白细胞及肝肾基础指标（ALT 38 U/L、肌酐 1.1 mg/dL）均在参考区间内，建议保持每日足量饮水。',
      attachments: [],
      createdAt: new Date().toISOString(),
    },
  ];

  const demoVaccines: VaccineRecord[] = [
    {
      id: 'vac_demo_1',
      petId: bellaId,
      vaccineName: '犬六联疫苗（DHPPi-L）',
      vaccinatedDate: addDaysStr(-180),
      doseCount: '年度加强第 1 针',
      hospital: '安心宠伴动物医院',
      notes: '接种后留院观察 20 分钟无不良反应，精神食欲正常。',
      updatedAt: new Date().toISOString(),
      isDemo: true,
    },
    {
      id: 'vac_demo_2',
      petId: bellaId,
      vaccineName: '狂犬病灭活疫苗',
      vaccinatedDate: addDaysStr(-120),
      doseCount: '第 2 次加强',
      hospital: '安心宠伴动物医院',
      notes: '注射于左后肢外侧皮下，已登记免疫手册。',
      updatedAt: new Date().toISOString(),
      isDemo: true,
    },
    {
      id: 'vac_demo_3',
      petId: mochiId,
      vaccineName: '猫三联疫苗（妙三多）',
      vaccinatedDate: addDaysStr(-95),
      doseCount: '第 3 针基础免疫',
      hospital: '暖爪猫专科诊所',
      notes: '接种部位无硬结，回家后饮水排便均正常。',
      updatedAt: new Date().toISOString(),
      isDemo: true,
    },
  ];

  writeJson(KEYS.PETS, demoPets);
  writeJson(KEYS.RECORDS, demoRecords);
  writeJson(KEYS.REMINDERS, demoReminders);
  writeJson(KEYS.MEDICAL_RECORDS, demoMedical);
  writeJson(KEYS.VACCINE_RECORDS, demoVaccines);
  localStorage.setItem(KEYS.SELECTED_PET, bellaId);
  localStorage.setItem(KEYS.INITIALIZED, '1');
  return demoPets;
}

export const localStore = {
  // ---- Pets ----
  listPets(): Pet[] {
    ensureInitialized();
    return readJson<Pet[]>(KEYS.PETS, []);
  },

  seedDemoPets(): Pet[] {
    const existing = readJson<Pet[]>(KEYS.PETS, []);
    if (existing.length > 0) return existing;
    return seedInitialDemoData();
  },

  getSelectedPetId(): string {
    ensureInitialized();
    return localStorage.getItem(KEYS.SELECTED_PET) || '';
  },

  setSelectedPetId(id: string): void {
    if (id) localStorage.setItem(KEYS.SELECTED_PET, id);
    else localStorage.removeItem(KEYS.SELECTED_PET);
  },

  createPet(input: PetFormInput): Pet {
    ensureInitialized();
    const pets = readJson<Pet[]>(KEYS.PETS, []);
    const avatarBySpecies: Record<string, string> = {
      dog: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
      cat: '/src/assets/images/british_shorthair_cat_1794751020533.jpg',
      bunny: '/src/assets/images/bunny_model_natural_1794231711465.jpg',
      other: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
    };
    const pet: Pet = {
      ...input,
      id: `pet_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      avatar: input.avatar || avatarBySpecies[input.species] || avatarBySpecies.dog,
      diet: input.diet || '[]',
      water: input.water || '0ml',
      companionStartDate: input.companionStartDate || getTodayStr(),
      isDemo: false,
      updatedAt: new Date().toISOString(),
    };
    const next = [...pets, pet];
    writeJson(KEYS.PETS, next);
    localStorage.setItem(KEYS.SELECTED_PET, pet.id);
    return pet;
  },

  updatePet(id: string, patch: Partial<Pet>): Pet {
    ensureInitialized();
    const pets = readJson<Pet[]>(KEYS.PETS, []);
    const idx = pets.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error('未找到对应宠物档案');
    const updated: Pet = {
      ...pets[idx],
      ...patch,
      id,
      updatedAt: new Date().toISOString(),
    };
    pets[idx] = updated;
    writeJson(KEYS.PETS, pets);
    return updated;
  },

  deletePet(id: string): void {
    ensureInitialized();
    const pets = readJson<Pet[]>(KEYS.PETS, []).filter((p) => p.id !== id);
    writeJson(KEYS.PETS, pets);
    writeJson(
      KEYS.RECORDS,
      readJson<HealthRecord[]>(KEYS.RECORDS, []).filter((r) => r.petId !== id)
    );
    writeJson(
      KEYS.REMINDERS,
      readJson<Reminder[]>(KEYS.REMINDERS, []).filter((rem) => rem.petId !== id)
    );
    writeJson(
      KEYS.MEDICAL_RECORDS,
      readJson<MedicalRecord[]>(KEYS.MEDICAL_RECORDS, []).filter((m) => m.petId !== id)
    );
    const allPrefs = readJson<Record<string, PetFoodPreferences>>(KEYS.FOOD_PREFERENCES, {});
    if (allPrefs[id]) {
      delete allPrefs[id];
      writeJson(KEYS.FOOD_PREFERENCES, allPrefs);
    }
    writeJson(
      KEYS.VACCINE_RECORDS,
      readJson<VaccineRecord[]>(KEYS.VACCINE_RECORDS, []).filter((v) => v.petId !== id)
    );
    const allVirtual = readJson<Record<string, VirtualPetState>>(KEYS.VIRTUAL_PET, {});
    if (allVirtual[id]) {
      delete allVirtual[id];
      writeJson(KEYS.VIRTUAL_PET, allVirtual);
    }
  },

  // ---- Health Records ----
  listRecords(petId?: string): HealthRecord[] {
    ensureInitialized();
    const list = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    const filtered = petId ? list.filter((r) => r.petId === petId) : list;
    return [...filtered].sort((a, b) => b.date.localeCompare(a.date));
  },

  _syncLatestPetWeight(petId: string, allRecords: HealthRecord[]): void {
    const petWeights = allRecords
      .filter((r) => r.petId === petId && typeof r.weightKg === 'number' && r.weightKg > 0)
      .sort((a, b) => a.date.localeCompare(b.date));
    if (petWeights.length === 0) return;
    const latestWeight = petWeights[petWeights.length - 1].weightKg;
    if (typeof latestWeight !== 'number' || latestWeight <= 0) return;

    const pets = readJson<Pet[]>(KEYS.PETS, []);
    const idx = pets.findIndex((p) => p.id === petId);
    if (idx !== -1) {
      pets[idx] = {
        ...pets[idx],
        weight: latestWeight,
        updatedAt: new Date().toISOString(),
      };
      writeJson(KEYS.PETS, pets);
    }
  },

  createRecord(input: HealthRecordInput): HealthRecord {
    ensureInitialized();
    const list = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    const created: HealthRecord = {
      ...input,
      id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      isDemo: false,
    };
    list.push(created);
    writeJson(KEYS.RECORDS, list);

    if (typeof created.weightKg === 'number' && created.weightKg > 0) {
      this._syncLatestPetWeight(created.petId, list);
    }
    return created;
  },

  updateRecord(
    id: string,
    patch: Partial<Omit<HealthRecord, 'id' | 'petId'>>
  ): HealthRecord {
    ensureInitialized();
    const list = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) throw new Error('未找到对应健康记录');

    const updated: HealthRecord = {
      ...list[idx],
      ...patch,
      id,
      petId: list[idx].petId,
      isDemo: false,
    };
    list[idx] = updated;
    writeJson(KEYS.RECORDS, list);
    this._syncLatestPetWeight(updated.petId, list);
    return updated;
  },

  upsertWeightRecord(
    input: HealthRecordInput,
    mode: 'overwrite' | 'create' = 'overwrite'
  ): { record: HealthRecord; updatedExisting: boolean } {
    ensureInitialized();
    const list = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    if (mode === 'overwrite') {
      const existingIdx = list.findIndex(
        (r) =>
          r.petId === input.petId &&
          r.date === input.date &&
          typeof r.weightKg === 'number' &&
          r.weightKg > 0
      );
      if (existingIdx !== -1) {
        const updated: HealthRecord = {
          ...list[existingIdx],
          title: input.title || list[existingIdx].title,
          content: input.content !== undefined ? input.content : list[existingIdx].content,
          weightKg: input.weightKg,
          type: input.type || list[existingIdx].type,
          isDemo: false,
        };
        list[existingIdx] = updated;
        writeJson(KEYS.RECORDS, list);
        this._syncLatestPetWeight(updated.petId, list);
        return { record: updated, updatedExisting: true };
      }
    }

    const created = this.createRecord(input);
    return { record: created, updatedExisting: false };
  },

  importPetWeightRecords(
    petId: string,
    items: Array<{ date: string; weightKg: number; title?: string; content?: string }>
  ): { importedCount: number; updatedCount: number; records: HealthRecord[] } {
    ensureInitialized();
    const list = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    let importedCount = 0;
    let updatedCount = 0;

    for (const item of items) {
      const dateStr = String(item.date || '').trim();
      const weightVal = Number(item.weightKg);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) continue;
      if (!Number.isFinite(weightVal) || weightVal <= 0 || weightVal > 200) continue;

      const roundedWeight = Number(weightVal.toFixed(2));
      const existingIdx = list.findIndex(
        (r) =>
          r.petId === petId &&
          r.date === dateStr &&
          typeof r.weightKg === 'number' &&
          r.weightKg > 0
      );

      if (existingIdx !== -1) {
        list[existingIdx] = {
          ...list[existingIdx],
          weightKg: roundedWeight,
          title: item.title?.trim() || list[existingIdx].title || '体重导入记录',
          content:
            item.content !== undefined
              ? item.content.trim()
              : list[existingIdx].content || `称重 ${roundedWeight} kg`,
          isDemo: false,
        };
        updatedCount += 1;
      } else {
        list.push({
          id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          petId,
          date: dateStr,
          type: 'activity',
          title: item.title?.trim() || '体重导入记录',
          content: item.content?.trim() || `称重 ${roundedWeight} kg`,
          weightKg: roundedWeight,
          isDemo: false,
        });
        importedCount += 1;
      }
    }

    writeJson(KEYS.RECORDS, list);
    this._syncLatestPetWeight(petId, list);
    return {
      importedCount,
      updatedCount,
      records: this.listRecords(petId),
    };
  },

  deleteRecord(id: string): void {
    ensureInitialized();
    const current = readJson<HealthRecord[]>(KEYS.RECORDS, []);
    const target = current.find((r) => r.id === id);
    const next = current.filter((r) => r.id !== id);
    writeJson(KEYS.RECORDS, next);
    if (target) {
      this._syncLatestPetWeight(target.petId, next);
    }
  },

  // ---- Reminders ----
  listReminders(petId?: string): Reminder[] {
    ensureInitialized();
    const list = readJson<Reminder[]>(KEYS.REMINDERS, []);
    const filtered = petId ? list.filter((r) => r.petId === petId) : list;
    return [...filtered].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  },

  createReminder(input: ReminderInput): Reminder {
    ensureInitialized();
    const list = readJson<Reminder[]>(KEYS.REMINDERS, []);
    const created: Reminder = {
      ...input,
      id: `rem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: false,
    };
    list.push(created);
    writeJson(KEYS.REMINDERS, list);
    return created;
  },

  toggleReminder(id: string, completed: boolean): Reminder {
    ensureInitialized();
    const list = readJson<Reminder[]>(KEYS.REMINDERS, []);
    const idx = list.findIndex((r) => r.id === id);
    if (idx === -1) throw new Error('未找到对应提醒');
    list[idx] = { ...list[idx], completed };
    writeJson(KEYS.REMINDERS, list);
    return list[idx];
  },

  deleteReminder(id: string): void {
    ensureInitialized();
    const next = readJson<Reminder[]>(KEYS.REMINDERS, []).filter((r) => r.id !== id);
    writeJson(KEYS.REMINDERS, next);
  },

  // ---- Medical Records ----
  listMedicalRecords(petId?: string): MedicalRecord[] {
    ensureInitialized();
    const list = readJson<MedicalRecord[]>(KEYS.MEDICAL_RECORDS, []);
    const filtered = petId ? list.filter((m) => m.petId === petId) : list;
    return [...filtered].sort((a, b) => {
      const cmp = b.date.localeCompare(a.date);
      return cmp !== 0 ? cmp : b.createdAt.localeCompare(a.createdAt);
    });
  },

  createMedicalRecord(input: MedicalRecordInput): MedicalRecord {
    ensureInitialized();
    const list = readJson<MedicalRecord[]>(KEYS.MEDICAL_RECORDS, []);
    const created: MedicalRecord = {
      ...input,
      id: `med_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    list.push(created);
    writeJson(KEYS.MEDICAL_RECORDS, list);
    return created;
  },

  updateMedicalRecord(
    id: string,
    patch: Partial<Omit<MedicalRecord, 'id' | 'petId' | 'createdAt'>>
  ): MedicalRecord {
    ensureInitialized();
    const list = readJson<MedicalRecord[]>(KEYS.MEDICAL_RECORDS, []);
    const idx = list.findIndex((m) => m.id === id);
    if (idx === -1) throw new Error('未找到对应医疗记录');
    const updated: MedicalRecord = {
      ...list[idx],
      ...patch,
      id,
      petId: list[idx].petId,
      createdAt: list[idx].createdAt,
    };
    list[idx] = updated;
    writeJson(KEYS.MEDICAL_RECORDS, list);
    return updated;
  },

  deleteMedicalRecord(id: string): void {
    ensureInitialized();
    const next = readJson<MedicalRecord[]>(KEYS.MEDICAL_RECORDS, []).filter((m) => m.id !== id);
    writeJson(KEYS.MEDICAL_RECORDS, next);
  },

  // ---- Virtual Pet Interaction & Intimacy ----
  getVirtualPetState(petId: string): VirtualPetState {
    ensureInitialized();
    const all = readJson<Record<string, VirtualPetState>>(KEYS.VIRTUAL_PET, {});
    const today = getTodayStr();
    const existing = all[petId];
    if (existing) {
      if (existing.feedDate !== today) {
        return { ...existing, feedCountToday: 0, feedDate: today };
      }
      return existing;
    }
    const starterByPetId: Record<string, { intimacy: number; streakDays: number }> = {
      pet_demo_bella: { intimacy: 72, streakDays: 3 },
      pet_demo_mochi: { intimacy: 20, streakDays: 1 },
    };
    const starter = starterByPetId[petId] || { intimacy: 10, streakDays: 0 };
    const fresh: VirtualPetState = {
      petId,
      intimacy: starter.intimacy,
      streakDays: starter.streakDays,
      lastCheckInDate: null,
      feedCountToday: 0,
      feedDate: today,
      interactions: [],
    };
    all[petId] = fresh;
    writeJson(KEYS.VIRTUAL_PET, all);
    return fresh;
  },

  recordVirtualPetAction(
    petId: string,
    action: VirtualPetInteractionLog['action'],
    label: string,
    points: number
  ): { state: VirtualPetState; alreadyCheckedIn?: boolean } {
    ensureInitialized();
    const all = readJson<Record<string, VirtualPetState>>(KEYS.VIRTUAL_PET, {});
    const current = this.getVirtualPetState(petId);
    const today = getTodayStr();

    if (action === 'checkin' && current.lastCheckInDate === today) {
      return { state: current, alreadyCheckedIn: true };
    }

    const log: VirtualPetInteractionLog = {
      id: `vp_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      action,
      label,
      points,
      timestamp: new Date().toISOString(),
    };

    let nextStreak = current.streakDays;
    let nextCheckIn = current.lastCheckInDate;
    if (action === 'checkin') {
      const yesterday = addDaysStr(-1);
      nextStreak = current.lastCheckInDate === yesterday ? current.streakDays + 1 : 1;
      nextCheckIn = today;
    }

    const nextFeedCount =
      action === 'feed'
        ? (current.feedDate === today ? current.feedCountToday : 0) + 1
        : current.feedDate === today
        ? current.feedCountToday
        : 0;

    const updated: VirtualPetState = {
      petId,
      intimacy: current.intimacy + points,
      streakDays: nextStreak,
      lastCheckInDate: nextCheckIn,
      feedCountToday: nextFeedCount,
      feedDate: today,
      interactions: [log, ...current.interactions].slice(0, 20),
    };

    all[petId] = updated;
    writeJson(KEYS.VIRTUAL_PET, all);
    return { state: updated };
  },

  // ---- Symptom Self-Check History ----
  listSymptomHistory(petId?: string): SymptomCheckHistoryItem[] {
    ensureInitialized();
    const list = readJson<SymptomCheckHistoryItem[]>(KEYS.SYMPTOM_HISTORY, []);
    const filtered = petId ? list.filter((i) => i.petId === petId) : list;
    return filtered;
  },

  addSymptomHistory(item: Omit<SymptomCheckHistoryItem, 'id' | 'checkedAt'>): SymptomCheckHistoryItem {
    ensureInitialized();
    const list = readJson<SymptomCheckHistoryItem[]>(KEYS.SYMPTOM_HISTORY, []);
    const created: SymptomCheckHistoryItem = {
      ...item,
      id: `sym_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      checkedAt: new Date().toISOString(),
    };
    writeJson(KEYS.SYMPTOM_HISTORY, [created, ...list].slice(0, 30));
    return created;
  },

  clearSymptomHistory(petId?: string): void {
    ensureInitialized();
    const list = readJson<SymptomCheckHistoryItem[]>(KEYS.SYMPTOM_HISTORY, []);
    const next = petId ? list.filter((i) => i.petId !== petId) : [];
    writeJson(KEYS.SYMPTOM_HISTORY, next);
  },

  // ---- Per-Pet Food Preferences (Likes / Dislikes / Allergies / Forbidden) ----
  getPetFoodPreferences(petId: string): PetFoodPreferences {
    ensureInitialized();
    const raw = localStorage.getItem(KEYS.FOOD_PREFERENCES);
    let all = readJson<Record<string, PetFoodPreferences>>(KEYS.FOOD_PREFERENCES, {});
    if (raw === null) {
      const pets = readJson<Pet[]>(KEYS.PETS, []);
      const now = new Date().toISOString();
      const seeded: Record<string, PetFoodPreferences> = {};
      if (pets.some((p) => p.id === 'pet_demo_bella')) {
        seeded['pet_demo_bella'] = {
          petId: 'pet_demo_bella',
          likes: [
            { id: 'fp_seed_b1', name: '鸡胸肉', foodId: 'chicken_breast', category: 'likes', updatedAt: now },
            { id: 'fp_seed_b2', name: '三文鱼', foodId: 'salmon', category: 'likes', updatedAt: now },
            { id: 'fp_seed_b3', name: '南瓜', foodId: 'pumpkin', category: 'likes', updatedAt: now },
          ],
          dislikes: [
            { id: 'fp_seed_b4', name: '西兰花', foodId: 'broccoli', category: 'dislikes', updatedAt: now },
          ],
          allergies: [
            { id: 'fp_seed_b5', name: '虾仁', foodId: 'shrimp_crab', category: 'allergies', updatedAt: now },
          ],
          forbidden: [],
        };
      }
      if (pets.some((p) => p.id === 'pet_demo_mochi')) {
        seeded['pet_demo_mochi'] = {
          petId: 'pet_demo_mochi',
          likes: [
            { id: 'fp_seed_m1', name: '三文鱼', foodId: 'salmon', category: 'likes', updatedAt: now },
            { id: 'fp_seed_m2', name: '猫草', foodId: 'cat_grass', category: 'likes', updatedAt: now },
          ],
          dislikes: [
            { id: 'fp_seed_m3', name: '胡萝卜', foodId: 'carrot', category: 'dislikes', updatedAt: now },
          ],
          allergies: [
            { id: 'fp_seed_m4', name: '纯牛奶', foodId: 'dairy_milk', category: 'allergies', updatedAt: now },
          ],
          forbidden: [],
        };
      }
      if (Object.keys(seeded).length > 0) {
        writeJson(KEYS.FOOD_PREFERENCES, seeded);
        all = seeded;
      }
    }
    const existing = all[petId];
    if (existing) {
      return {
        petId,
        likes: Array.isArray(existing.likes) ? existing.likes : [],
        allergies: Array.isArray(existing.allergies) ? existing.allergies : [],
        dislikes: Array.isArray(existing.dislikes) ? existing.dislikes : [],
        forbidden: Array.isArray(existing.forbidden) ? existing.forbidden : [],
      };
    }
    return {
      petId,
      likes: [],
      allergies: [],
      dislikes: [],
      forbidden: [],
    };
  },

  addPetFoodPreference(
    petId: string,
    category: FoodPreferenceCategory,
    name: string,
    note?: string,
    foodId?: string,
    icon?: string
  ): PetFoodPreferences {
    ensureInitialized();
    const cleanName = name.trim();
    if (!cleanName) throw new Error('请输入食物名称');

    const all = readJson<Record<string, PetFoodPreferences>>(KEYS.FOOD_PREFERENCES, {});
    const current = this.getPetFoodPreferences(petId);
    const list = current[category] || [];
    const duplicate = list.some(
      (item) => item.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (duplicate) {
      throw new Error(`「${cleanName}」已在该分类列表中`);
    }

    const newItem: PetFoodPreferenceItem = {
      id: `fp_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: cleanName,
      category,
      foodId: foodId || undefined,
      icon: icon || undefined,
      note: note?.trim() || undefined,
      updatedAt: new Date().toISOString(),
    };

    const next: PetFoodPreferences = {
      ...current,
      [category]: [newItem, ...list],
    };
    all[petId] = next;
    writeJson(KEYS.FOOD_PREFERENCES, all);
    return next;
  },

  updatePetFoodPreference(
    petId: string,
    category: FoodPreferenceCategory,
    itemId: string,
    patch: { name: string; note?: string; icon?: string; foodId?: string }
  ): PetFoodPreferences {
    ensureInitialized();
    const cleanName = patch.name.trim();
    if (!cleanName) throw new Error('食物名称不能为空');

    const all = readJson<Record<string, PetFoodPreferences>>(KEYS.FOOD_PREFERENCES, {});
    const current = this.getPetFoodPreferences(petId);
    const list = current[category];
    const duplicate = list.some(
      (item) =>
        item.id !== itemId && item.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (duplicate) {
      throw new Error(`「${cleanName}」已存在于该分类中`);
    }

    const nextList = list.map((item) =>
      item.id === itemId
        ? {
            ...item,
            name: cleanName,
            icon: patch.icon !== undefined ? patch.icon : item.icon,
            foodId: patch.foodId !== undefined ? patch.foodId : item.foodId,
            note: patch.note !== undefined ? patch.note.trim() || undefined : item.note,
            updatedAt: new Date().toISOString(),
          }
        : item
    );

    const next: PetFoodPreferences = {
      ...current,
      [category]: nextList,
    };
    all[petId] = next;
    writeJson(KEYS.FOOD_PREFERENCES, all);
    return next;
  },

  deletePetFoodPreference(
    petId: string,
    category: FoodPreferenceCategory,
    itemId: string
  ): PetFoodPreferences {
    ensureInitialized();
    const all = readJson<Record<string, PetFoodPreferences>>(KEYS.FOOD_PREFERENCES, {});
    const current = this.getPetFoodPreferences(petId);
    const next: PetFoodPreferences = {
      ...current,
      [category]: current[category].filter((item) => item.id !== itemId),
    };
    all[petId] = next;
    writeJson(KEYS.FOOD_PREFERENCES, all);
    return next;
  },

  // ---- Per-Pet Vaccine Inoculation Records (No expiry calculation / No reminders) ----
  listVaccineRecords(petId?: string): VaccineRecord[] {
    ensureInitialized();
    const raw = localStorage.getItem(KEYS.VACCINE_RECORDS);
    let list = readJson<VaccineRecord[]>(KEYS.VACCINE_RECORDS, []);
    if (raw === null) {
      // One-time seed for existing initialized browsers that don't yet have KEYS.VACCINE_RECORDS
      const pets = readJson<Pet[]>(KEYS.PETS, []);
      const demoBella = pets.find((p) => p.id === 'pet_demo_bella');
      const demoMochi = pets.find((p) => p.id === 'pet_demo_mochi');
      const initialList: VaccineRecord[] = [];
      if (demoBella) {
        initialList.push({
          id: 'vac_demo_1',
          petId: demoBella.id,
          vaccineName: '犬六联疫苗（DHPPi-L）',
          vaccinatedDate: addDaysStr(-180),
          doseCount: '年度加强第 1 针',
          hospital: '安心宠伴动物医院',
          notes: '接种后留院观察 20 分钟无不良反应，精神食欲正常。',
          updatedAt: new Date().toISOString(),
          isDemo: true,
        });
      }
      if (demoMochi) {
        initialList.push({
          id: 'vac_demo_3',
          petId: demoMochi.id,
          vaccineName: '猫三联疫苗（妙三多）',
          vaccinatedDate: addDaysStr(-95),
          doseCount: '第 3 针基础免疫',
          hospital: '暖爪猫专科诊所',
          notes: '接种部位无硬结，回家后饮水排便均正常。',
          updatedAt: new Date().toISOString(),
          isDemo: true,
        });
      }
      if (initialList.length > 0) {
        writeJson(KEYS.VACCINE_RECORDS, initialList);
        list = initialList;
      }
    }
    const filtered = petId ? list.filter((v) => v.petId === petId) : list;
    return [...filtered].sort((a, b) => b.vaccinatedDate.localeCompare(a.vaccinatedDate));
  },

  createVaccineRecord(input: VaccineRecordInput): VaccineRecord {
    ensureInitialized();
    const name = input.vaccineName.trim();
    if (!name) throw new Error('请输入疫苗名称');
    if (!input.vaccinatedDate) throw new Error('请选择接种日期');
    const dose = input.doseCount.trim() || '第 1 针';

    const list = this.listVaccineRecords();
    const created: VaccineRecord = {
      id: `vac_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      petId: input.petId,
      vaccineName: name,
      vaccinatedDate: input.vaccinatedDate,
      doseCount: dose,
      hospital: input.hospital?.trim() || '',
      notes: input.notes?.trim() || '',
      updatedAt: new Date().toISOString(),
      isDemo: false,
    };
    writeJson(KEYS.VACCINE_RECORDS, [created, ...list]);
    return created;
  },

  updateVaccineRecord(
    id: string,
    patch: Partial<Omit<VaccineRecord, 'id' | 'petId'>>
  ): VaccineRecord {
    ensureInitialized();
    const list = this.listVaccineRecords();
    const idx = list.findIndex((v) => v.id === id);
    if (idx === -1) throw new Error('未找到对应疫苗接种记录');

    const nextName =
      patch.vaccineName !== undefined ? patch.vaccineName.trim() : list[idx].vaccineName;
    if (!nextName) throw new Error('疫苗名称不能为空');

    const updated: VaccineRecord = {
      ...list[idx],
      ...patch,
      vaccineName: nextName,
      doseCount:
        patch.doseCount !== undefined
          ? patch.doseCount.trim() || '第 1 针'
          : list[idx].doseCount,
      hospital:
        patch.hospital !== undefined ? patch.hospital.trim() : list[idx].hospital,
      notes: patch.notes !== undefined ? patch.notes.trim() : list[idx].notes,
      id,
      petId: list[idx].petId,
      updatedAt: new Date().toISOString(),
      isDemo: false,
    };
    list[idx] = updated;
    writeJson(KEYS.VACCINE_RECORDS, list);
    return updated;
  },

  deleteVaccineRecord(id: string): void {
    ensureInitialized();
    const next = this.listVaccineRecords().filter((v) => v.id !== id);
    writeJson(KEYS.VACCINE_RECORDS, next);
  },
};
