import axios, { AxiosError } from 'axios';

/**
 * 统一 Axios 客户端：
 * - 在 AI Studio 预览环境中默认请求同源 `/api`（由 Node/Express 提供接口）
 * - 连接独立 Python FastAPI 后端时，在环境变量配置 `VITE_PYTHON_API_URL`（如 `http://localhost:8000`）
 */
const PYTHON_BACKEND_URL = (import.meta.env.VITE_PYTHON_API_URL || '').trim().replace(/\/+$/, '');

export const API_BASE_URL = PYTHON_BACKEND_URL ? `${PYTHON_BACKEND_URL}/api` : '/api';
export const IS_PYTHON_BACKEND_TARGET = Boolean(PYTHON_BACKEND_URL);

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export function extractApiErrorMessage(err: unknown, fallback = '请求失败，请稍后重试'): string {
  if (axios.isAxiosError(err)) {
    const axiosErr = err as AxiosError<{ error?: string; detail?: string | Array<{ msg?: string }> }>;
    const detail = axiosErr.response?.data?.detail;
    const serverMsg =
      axiosErr.response?.data?.error ||
      (typeof detail === 'string'
        ? detail
        : Array.isArray(detail) && detail[0]?.msg
        ? detail[0].msg
        : undefined);
    if (serverMsg) return serverMsg;
    if (axiosErr.code === 'ECONNABORTED') return '请求超时，请检查网络连接';
    if (!axiosErr.response) return '无法连接后端服务，请确认服务已启动';
    return `接口返回错误 (${axiosErr.response.status})`;
  }
  if (err instanceof Error && err.message) return err.message;
  return fallback;
}
