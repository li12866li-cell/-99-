import { Reminder, ReminderInput } from '../types/reminder.ts';
import { localStore } from './localStore.ts';

export const reminderService = {
  async listReminders(petId?: string): Promise<Reminder[]> {
    return localStore.listReminders(petId);
  },

  async createReminder(payload: ReminderInput): Promise<Reminder> {
    return localStore.createReminder(payload);
  },

  async toggleReminder(id: string, completed: boolean): Promise<Reminder> {
    return localStore.toggleReminder(id, completed);
  },

  async deleteReminder(id: string): Promise<void> {
    localStore.deleteReminder(id);
  },
};
