import { localStore, SymptomCheckHistoryItem } from './localStore.ts';
import {
  DurationOptionId,
  evaluateSymptomWizard,
  SymptomMatchResult,
} from '../lib/symptomMatcher.ts';
import { Pet } from '../types/pet.ts';
import petHospitalsRaw from '../data/pet_hospital.json';

export interface NearbyHospitalContact {
  id: string;
  name: string;
  cityLabel: string;
  district: string;
  address: string;
  phone: string;
  distanceText?: string;
  kakaoMapUrl?: string;
}

export interface SaveSymptomHistoryPayload {
  petId: string;
  petName: string;
  symptomIds: string[];
  symptomNames: string[];
  level: 'emergency' | 'urgent' | 'watch';
  score: number;
  headline: string;
  durationLabel?: string;
  reasoning: string[];
  adviceList: string[];
  customNote?: string;
}

export interface LocalCheckInput {
  symptomIds: string[];
  durationId?: DurationOptionId;
  customNote?: string;
  pet: Pet | null;
  onStageChange?: (stageIndex: number, progress: number) => void;
}

function nextFrameYield(): Promise<void> {
  return new Promise((resolve) => {
    if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
      window.requestAnimationFrame(() => resolve());
    } else {
      setTimeout(resolve, 16);
    }
  });
}

export const symptomService = {
  /**
   * 100% local rule-engine execution with zero network calls.
   * Each stage callback tracks actual local computation steps rather than fake AI delays.
   */
  async checkSymptoms({
    symptomIds,
    durationId,
    customNote,
    pet,
    onStageChange,
  }: LocalCheckInput): Promise<SymptomMatchResult> {
    // Stage 0: Organizing selected symptoms & duration
    onStageChange?.(0, 22);
    const normalizedIds = Array.from(new Set(symptomIds));
    await nextFrameYield();

    // Stage 1: Loading & matching local health knowledge base
    onStageChange?.(1, 52);
    await nextFrameYield();

    // Stage 2: Executing local rule & combination & duration engine
    onStageChange?.(2, 82);
    const matched = evaluateSymptomWizard({
      selectedIds: normalizedIds,
      durationId,
      customNote,
      pet,
    });
    await nextFrameYield();

    // Stage 3: Finalizing structured local health report
    onStageChange?.(3, 100);
    await nextFrameYield();

    return matched;
  },

  async listHistory(petId?: string): Promise<SymptomCheckHistoryItem[]> {
    return localStore.listSymptomHistory(petId);
  },

  async saveHistory(payload: SaveSymptomHistoryPayload): Promise<SymptomCheckHistoryItem> {
    return localStore.addSymptomHistory({
      petId: payload.petId || 'general',
      petName: payload.petName || '未指定宠物',
      symptomIds: payload.symptomIds,
      symptomNames: payload.symptomNames,
      level: payload.level,
      headline: payload.headline,
      durationLabel: payload.durationLabel,
      reasoning: payload.reasoning,
      adviceList: payload.adviceList,
      customNote: payload.customNote,
    });
  },

  async clearHistory(petId?: string): Promise<void> {
    localStore.clearSymptomHistory(petId);
  },

  async fetchNearbyEmergencyHospitals(): Promise<NearbyHospitalContact[]> {
    const rawList = Array.isArray(petHospitalsRaw) ? (petHospitalsRaw as any[]) : [];
    return rawList
      .filter((h) => Boolean(h?.name) && typeof h?.phone === 'string' && h.phone.trim().length >= 5)
      .map((h) => ({
        id: String(h.id || h.name),
        name: String(h.name),
        cityLabel: String(h.cityLabel || ''),
        district: String(h.district || ''),
        address: String(h.address || ''),
        phone: String(h.phone),
      }));
  },
};
