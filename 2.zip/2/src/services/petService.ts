import { Pet, PetFormInput } from '../types/pet.ts';
import { localStore } from './localStore.ts';

export const petService = {
  async listPets(): Promise<Pet[]> {
    return localStore.listPets();
  },

  async seedDemoPets(): Promise<Pet[]> {
    return localStore.seedDemoPets();
  },

  async createPet(payload: PetFormInput): Promise<Pet> {
    return localStore.createPet(payload);
  },

  async updatePet(id: string, patch: Partial<Pet>): Promise<Pet> {
    return localStore.updatePet(id, patch);
  },

  async deletePet(id: string): Promise<void> {
    localStore.deletePet(id);
  },
};
