import React, { useCallback, useState } from 'react';
import { translations } from './lib/i18n.ts';
import { GoldenRetrieverCover } from './components/GoldenRetrieverCover.tsx';
import { EnterAppSignal } from './lib/goldenRetrieverCover.ts';
import { AppTabId, LayoutShell } from './components/LayoutShell.tsx';
import { ToastBanner, ToastState } from './components/ToastBanner.tsx';
import { usePets } from './hooks/usePets.ts';
import { useHealthRecords } from './hooks/useHealthRecords.ts';
import { useReminders } from './hooks/useReminders.ts';
import { useVaccineRecords } from './hooks/useVaccineRecords.ts';
import { useVirtualPet } from './hooks/useVirtualPet.ts';
import { HomePage } from './pages/HomePage.tsx';
import { HealthRecordsPage } from './pages/HealthRecordsPage.tsx';
import { SymptomCheckerPage } from './pages/SymptomCheckerPage.tsx';
import { FoodScanPage } from './pages/FoodScanPage.tsx';
import { MedicalRecordsPage } from './pages/MedicalRecordsPage.tsx';

const WORKSPACE_USER_ID = 'default_pet_owner';

export default function App() {
  const [showCover, setShowCover] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<AppTabId>('home');
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  const t = translations.zh;

  const {
    pets,
    selectedPet,
    loading: loadingPets,
    refreshPets,
    seedDemoPets,
    selectPet,
    addPet,
    updatePet,
    deletePet,
  } = usePets(WORKSPACE_USER_ID, showToast);

  const {
    records,
    weightChartData,
    loading: loadingRecords,
    addRecord,
    updateRecord,
    upsertWeightRecord,
    importWeightRecords,
    deleteRecord,
  } = useHealthRecords(WORKSPACE_USER_ID, selectedPet?.id, showToast, refreshPets);

  const {
    reminders,
    pendingCount,
    toggleReminder,
  } = useReminders(WORKSPACE_USER_ID, selectedPet?.id, showToast);

  const {
    vaccineRecords,
    loading: loadingVaccines,
    addVaccineRecord,
    updateVaccineRecord,
    deleteVaccineRecord,
  } = useVaccineRecords(selectedPet?.id, showToast);

  const { virtualPetState, interactWithPet } = useVirtualPet(selectedPet?.id, showToast);

  const handleEnterAppFromCover = useCallback(
    (_signal: EnterAppSignal) => {
      setShowCover(false);
      setActiveTab('home');
      showToast('已从金毛 3D 开场封面进入首页概览');
    },
    [showToast]
  );

  if (showCover) {
    return (
      <>
        <ToastBanner toast={toast} />
        <GoldenRetrieverCover
          onEnterApp={handleEnterAppFromCover}
          onSkipToHome={() => {
            setShowCover(false);
            setActiveTab('home');
          }}
          onExportJson={() => showToast('已导出金毛静态 JSON 数据')}
        />
      </>
    );
  }

  return (
    <>
      <ToastBanner toast={toast} />
      <LayoutShell
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        selectedPet={selectedPet}
        onReplayCover={() => setShowCover(true)}
        pendingReminderCount={pendingCount}
        t={t}
      >
        {activeTab === 'home' && (
          <HomePage
            pets={pets}
            selectedPet={selectedPet}
            loadingPets={loadingPets}
            onSelectPet={selectPet}
            onAddPet={addPet}
            onUpdatePet={updatePet}
            onDeletePet={deletePet}
            weightChartData={weightChartData}
            reminders={reminders}
            onToggleReminder={toggleReminder}
            onSeedDemoPets={seedDemoPets}
            onNavigateTab={setActiveTab}
            virtualPetState={virtualPetState}
            onVirtualPetInteract={interactWithPet}
            t={t}
          />
        )}

        {activeTab === 'health-reminders' && (
          <HealthRecordsPage
            pets={pets}
            selectedPet={selectedPet}
            onSelectPet={selectPet}
            records={records}
            weightChartData={weightChartData}
            loadingRecords={loadingRecords}
            onAddRecord={addRecord}
            onUpdateRecord={updateRecord}
            onUpsertWeightRecord={upsertWeightRecord}
            onImportWeightRecords={importWeightRecords}
            onDeleteRecord={deleteRecord}
            vaccineRecords={vaccineRecords}
            loadingVaccines={loadingVaccines}
            onAddVaccineRecord={addVaccineRecord}
            onUpdateVaccineRecord={updateVaccineRecord}
            onDeleteVaccineRecord={deleteVaccineRecord}
            showToast={showToast}
          />
        )}

        {activeTab === 'symptom-check' && (
          <SymptomCheckerPage
            selectedPet={selectedPet}
            showToast={showToast}
            onNavigateHome={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'food-scan' && (
          <FoodScanPage
            t={t}
            pets={pets}
            selectedPet={selectedPet}
            onSelectPet={selectPet}
            showToast={showToast}
          />
        )}

        {activeTab === 'medical-records' && (
          <MedicalRecordsPage
            pets={pets}
            selectedPet={selectedPet}
            onSelectPet={selectPet}
            healthRecords={records}
            reminders={reminders}
            showToast={showToast}
          />
        )}
      </LayoutShell>
    </>
  );
}
