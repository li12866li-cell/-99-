import { useCallback, useEffect, useMemo, useState } from 'react';
import { localStore, VirtualPetInteractionLog, VirtualPetState } from '../services/localStore.ts';

export function useVirtualPet(
  petId?: string,
  showToast?: (msg: string, type?: 'success' | 'error') => void
) {
  const [state, setState] = useState<VirtualPetState | null>(() =>
    petId ? localStore.getVirtualPetState(petId) : null
  );

  const refresh = useCallback(() => {
    if (!petId) {
      setState(null);
      return;
    }
    setState(localStore.getVirtualPetState(petId));
  }, [petId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Synchronously resolve state for the active petId so switching pets never flashes previous pet data
  const activeState = useMemo(() => {
    if (!petId) return null;
    if (state && state.petId === petId) return state;
    return localStore.getVirtualPetState(petId);
  }, [petId, state]);

  const interact = useCallback(
    (
      action: VirtualPetInteractionLog['action'],
      label: string,
      points: number,
      silent = false
    ) => {
      if (!petId) return null;
      const result = localStore.recordVirtualPetAction(petId, action, label, points);
      setState(result.state);
      if (result.alreadyCheckedIn) {
        if (!silent) showToast?.('今天已经完成每日打卡啦，明天继续保持！', 'success');
      } else if (!silent) {
        showToast?.(`${label} · 亲密度 +${points}`, 'success');
      }
      return result;
    },
    [petId, showToast]
  );

  return {
    virtualPetState: activeState,
    refreshVirtualPet: refresh,
    interactWithPet: interact,
  };
}
