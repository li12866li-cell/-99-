import { useCallback, useEffect, useState } from 'react';
import { localStore, VaccineRecord, VaccineRecordInput } from '../services/localStore.ts';

export function useVaccineRecords(
  petId?: string,
  onToast?: (msg: string, type?: 'success' | 'error') => void
) {
  const [vaccineRecords, setVaccineRecords] = useState<VaccineRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchVaccineRecords = useCallback(() => {
    if (!petId) {
      setVaccineRecords([]);
      return;
    }
    setLoading(true);
    try {
      setVaccineRecords(localStore.listVaccineRecords(petId));
    } finally {
      setLoading(false);
    }
  }, [petId]);

  useEffect(() => {
    fetchVaccineRecords();
  }, [fetchVaccineRecords]);

  const addVaccineRecord = useCallback(
    async (input: VaccineRecordInput) => {
      const created = localStore.createVaccineRecord(input);
      setVaccineRecords(localStore.listVaccineRecords(input.petId));
      onToast?.(`已保存疫苗接种记录「${created.vaccineName}」`, 'success');
      return created;
    },
    [onToast]
  );

  const updateVaccineRecord = useCallback(
    async (id: string, patch: Partial<Omit<VaccineRecord, 'id' | 'petId'>>) => {
      const updated = localStore.updateVaccineRecord(id, patch);
      if (petId) {
        setVaccineRecords(localStore.listVaccineRecords(petId));
      } else {
        setVaccineRecords((prev) => prev.map((v) => (v.id === id ? updated : v)));
      }
      onToast?.(`已更新「${updated.vaccineName}」接种记录`, 'success');
      return updated;
    },
    [petId, onToast]
  );

  const deleteVaccineRecord = useCallback(
    async (id: string) => {
      localStore.deleteVaccineRecord(id);
      setVaccineRecords((prev) => prev.filter((v) => v.id !== id));
      onToast?.('已删除该条疫苗接种记录', 'success');
    },
    [onToast]
  );

  return {
    vaccineRecords,
    loading,
    refreshVaccineRecords: fetchVaccineRecords,
    addVaccineRecord,
    updateVaccineRecord,
    deleteVaccineRecord,
  };
}
