import { useState, useEffect, useCallback, useMemo } from 'react';
import { Reminder, ReminderInput } from '../types/reminder.ts';
import { reminderService } from '../services/reminderService.ts';

export function useReminders(
  userId?: string,
  petId?: string,
  showToast?: (msg: string, type?: 'success' | 'error') => void
) {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchReminders = useCallback(async () => {
    if (!userId || !petId) {
      setReminders([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const list = await reminderService.listReminders(petId);
      setReminders(list);
    } catch (err: any) {
      const msg = err?.message || '获取护理提醒失败';
      setError(msg);
      showToast?.(msg, 'error');
    } finally {
      setLoading(false);
    }
  }, [userId, petId, showToast]);

  useEffect(() => {
    fetchReminders();
  }, [fetchReminders]);

  const addReminder = useCallback(
    async (input: ReminderInput) => {
      try {
        const created = await reminderService.createReminder(input);
        setReminders((prev) => [...prev, created].sort((a, b) => a.dueDate.localeCompare(b.dueDate)));
        showToast?.('已创建提醒计划', 'success');
        return created;
      } catch (err: any) {
        showToast?.(err?.message || '创建提醒失败', 'error');
        throw err;
      }
    },
    [showToast]
  );

  const toggleReminder = useCallback(
    async (id: string, completed: boolean) => {
      try {
        const updated = await reminderService.toggleReminder(id, completed);
        setReminders((prev) => prev.map((r) => (r.id === id ? updated : r)));
        showToast?.(completed ? '已标记完成' : '已恢复待办', 'success');
      } catch (err: any) {
        showToast?.(err?.message || '更新状态失败', 'error');
      }
    },
    [showToast]
  );

  const deleteReminder = useCallback(
    async (id: string) => {
      try {
        await reminderService.deleteReminder(id);
        setReminders((prev) => prev.filter((r) => r.id !== id));
        showToast?.('已删除提醒', 'success');
      } catch (err: any) {
        showToast?.(err?.message || '删除提醒失败', 'error');
      }
    },
    [showToast]
  );

  const pendingCount = useMemo(
    () => reminders.filter((r) => !r.completed).length,
    [reminders]
  );

  return {
    reminders,
    pendingCount,
    loading,
    error,
    refreshReminders: fetchReminders,
    addReminder,
    toggleReminder,
    deleteReminder,
  };
}
