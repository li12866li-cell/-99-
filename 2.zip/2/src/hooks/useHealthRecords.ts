import { useState, useEffect, useCallback, useMemo } from 'react';
import { HealthRecord, HealthRecordInput } from '../types/pet.ts';
import { recordService } from '../services/recordService.ts';

export function useHealthRecords(
  userId?: string,
  petId?: string,
  showToast?: (msg: string, type?: 'success' | 'error') => void,
  onWeightSynced?: () => void
) {
  const [records, setRecords] = useState<HealthRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRecords = useCallback(async () => {
    if (!userId || !petId) {
      setRecords([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const list = await recordService.listRecords(petId);
      setRecords(list);
    } catch (err: any) {
      const msg = err?.message || '获取健康记录失败';
      setError(msg);
      showToast?.(msg, 'error');
    } finally {
      setLoading(false);
    }
  }, [userId, petId, showToast]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  const addRecord = useCallback(
    async (input: HealthRecordInput) => {
      try {
        const created = await recordService.createRecord(input);
        setRecords((prev) =>
          [created, ...prev].sort((a, b) => b.date.localeCompare(a.date))
        );
        if (typeof input.weightKg === 'number' && input.weightKg > 0) {
          onWeightSynced?.();
        }
        showToast?.('已保存健康记录', 'success');
        return created;
      } catch (err: any) {
        showToast?.(err?.message || '保存健康记录失败', 'error');
        throw err;
      }
    },
    [showToast, onWeightSynced]
  );

  const updateRecord = useCallback(
    async (id: string, patch: Partial<Omit<HealthRecord, 'id' | 'petId'>>) => {
      try {
        const updated = await recordService.updateRecord(id, patch);
        setRecords((prev) =>
          prev
            .map((r) => (r.id === id ? updated : r))
            .sort((a, b) => b.date.localeCompare(a.date))
        );
        onWeightSynced?.();
        showToast?.('已更新记录', 'success');
        return updated;
      } catch (err: any) {
        showToast?.(err?.message || '更新记录失败', 'error');
        throw err;
      }
    },
    [showToast, onWeightSynced]
  );

  const upsertWeightRecord = useCallback(
    async (input: HealthRecordInput, mode: 'overwrite' | 'create' = 'overwrite') => {
      try {
        const res = await recordService.upsertWeightRecord(input, mode);
        if (res.updatedExisting) {
          setRecords((prev) =>
            prev
              .map((r) => (r.id === res.record.id ? res.record : r))
              .sort((a, b) => b.date.localeCompare(a.date))
          );
          showToast?.(`已覆盖更新 ${input.date} 的体重记录`, 'success');
        } else {
          setRecords((prev) =>
            [res.record, ...prev].sort((a, b) => b.date.localeCompare(a.date))
          );
          showToast?.('已记录当日体重', 'success');
        }
        onWeightSynced?.();
        return res;
      } catch (err: any) {
        showToast?.(err?.message || '保存体重记录失败', 'error');
        throw err;
      }
    },
    [showToast, onWeightSynced]
  );

  const importWeightRecords = useCallback(
    async (
      targetPetId: string,
      items: Array<{ date: string; weightKg: number; title?: string; content?: string }>
    ) => {
      try {
        const result = await recordService.importPetWeightRecords(targetPetId, items);
        if (targetPetId === petId) {
          setRecords(result.records);
        }
        onWeightSynced?.();
        showToast?.(
          `导入完成：新增 ${result.importedCount} 条，更新 ${result.updatedCount} 条`,
          'success'
        );
        return result;
      } catch (err: any) {
        showToast?.(err?.message || '导入体重记录失败', 'error');
        throw err;
      }
    },
    [petId, showToast, onWeightSynced]
  );

  const deleteRecord = useCallback(
    async (id: string) => {
      try {
        await recordService.deleteRecord(id);
        setRecords((prev) => prev.filter((r) => r.id !== id));
        onWeightSynced?.();
        showToast?.('已删除健康记录', 'success');
      } catch (err: any) {
        showToast?.(err?.message || '删除健康记录失败', 'error');
        throw err;
      }
    },
    [showToast, onWeightSynced]
  );

  const weightChartData = useMemo(() => {
    const byDate = new Map<
      string,
      {
        recordId: string;
        date: string;
        fullDate: string;
        weight: number;
        title: string;
        content: string;
      }
    >();

    // Iterate chronological or reverse; records are newest-first, so first occurrence per date is latest
    for (const r of records) {
      if (typeof r.weightKg !== 'number' || r.weightKg <= 0) continue;
      if (!byDate.has(r.date)) {
        byDate.set(r.date, {
          recordId: r.id,
          date: r.date.slice(5),
          fullDate: r.date,
          weight: Number(r.weightKg.toFixed(2)),
          title: r.title,
          content: r.content,
        });
      }
    }

    return Array.from(byDate.values()).sort((a, b) => a.fullDate.localeCompare(b.fullDate));
  }, [records]);

  return {
    records,
    weightChartData,
    loading,
    error,
    refreshRecords: fetchRecords,
    addRecord,
    updateRecord,
    upsertWeightRecord,
    importWeightRecords,
    deleteRecord,
  };
}
