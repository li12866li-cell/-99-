import { useCallback, useEffect, useState } from 'react';
import { MedicalRecord, MedicalRecordInput } from '../types/medicalRecord.ts';
import { medicalRecordService } from '../services/medicalRecordService.ts';

export function useMedicalRecords(
  userId?: string,
  petId?: string,
  showToast?: (msg: string, type?: 'success' | 'error') => void
) {
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchMedicalRecords = useCallback(async () => {
    if (!userId || !petId) {
      setMedicalRecords([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const list = await medicalRecordService.listMedicalRecords(petId);
      setMedicalRecords(list);
    } catch (err: any) {
      const msg = err?.message || '加载医疗记录失败';
      setError(msg);
      showToast?.(msg, 'error');
    } finally {
      setLoading(false);
    }
  }, [userId, petId, showToast]);

  useEffect(() => {
    fetchMedicalRecords();
  }, [fetchMedicalRecords]);

  const addMedicalRecord = useCallback(
    async (input: MedicalRecordInput) => {
      try {
        const created = await medicalRecordService.createMedicalRecord(input);
        setMedicalRecords((prev) =>
          [created, ...prev].sort((a, b) => b.date.localeCompare(a.date))
        );
        showToast?.('已保存医疗记录与附件', 'success');
        return created;
      } catch (err: any) {
        const msg = err?.message || '保存医疗记录失败';
        showToast?.(msg, 'error');
        throw err;
      }
    },
    [showToast]
  );

  const updateMedicalRecord = useCallback(
    async (
      id: string,
      patch: Partial<Omit<MedicalRecord, 'id' | 'petId' | 'createdAt'>>
    ) => {
      try {
        const updated = await medicalRecordService.updateMedicalRecord(id, patch);
        setMedicalRecords((prev) =>
          prev
            .map((r) => (r.id === id ? updated : r))
            .sort((a, b) => b.date.localeCompare(a.date))
        );
        showToast?.('已更新医疗检查记录', 'success');
        return updated;
      } catch (err: any) {
        const msg = err?.message || '更新医疗记录失败';
        showToast?.(msg, 'error');
        throw err;
      }
    },
    [showToast]
  );

  const deleteMedicalRecord = useCallback(
    async (id: string) => {
      try {
        await medicalRecordService.deleteMedicalRecord(id);
        setMedicalRecords((prev) => prev.filter((r) => r.id !== id));
        showToast?.('已删除医疗记录', 'success');
      } catch (err: any) {
        showToast?.(err?.message || '删除医疗记录失败', 'error');
      }
    },
    [showToast]
  );

  return {
    medicalRecords,
    loading,
    error,
    refreshMedicalRecords: fetchMedicalRecords,
    addMedicalRecord,
    updateMedicalRecord,
    deleteMedicalRecord,
  };
}
