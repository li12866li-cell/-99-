import { useState, useEffect, useCallback } from 'react';
import { Pet, PetFormInput } from '../types/pet.ts';
import { petService } from '../services/petService.ts';

function getSelectedPetStorageKey(userId?: string): string {
  return userId ? `petcare_selected_pet_id_${userId}` : 'petcare_selected_pet_id';
}

export function usePets(
  userId?: string,
  showToast?: (msg: string, type?: 'success' | 'error') => void
) {
  const [pets, setPets] = useState<Pet[]>([]);
  const [selectedPetId, setSelectedPetId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPets = useCallback(async () => {
    if (!userId) {
      setPets([]);
      setSelectedPetId('');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const list = await petService.listPets();
      setPets(list);
      const storageKey = getSelectedPetStorageKey(userId);
      const savedId = localStorage.getItem(storageKey) || '';
      if (list.length > 0) {
        const exists = list.some((p) => p.id === savedId);
        const nextId = exists ? savedId : list[0].id;
        setSelectedPetId(nextId);
        localStorage.setItem(storageKey, nextId);
      } else {
        setSelectedPetId('');
        localStorage.removeItem(storageKey);
      }
    } catch (err: any) {
      const msg = err?.message || '加载宠物档案失败';
      setError(msg);
      showToast?.(msg, 'error');
    } finally {
      setLoading(false);
    }
  }, [userId, showToast]);

  useEffect(() => {
    fetchPets();
  }, [fetchPets]);

  const selectedPet = pets.find((p) => p.id === selectedPetId) || pets[0] || null;

  const selectPet = useCallback(
    (pet: Pet | string) => {
      const id = typeof pet === 'string' ? pet : pet.id;
      setSelectedPetId(id);
      if (userId) {
        localStorage.setItem(getSelectedPetStorageKey(userId), id);
      }
    },
    [userId]
  );

  const seedDemoPets = useCallback(async () => {
    if (!userId) return [];
    try {
      await petService.seedDemoPets();
      await fetchPets();
      showToast?.('已为当前账号载入示例宠物档案', 'success');
    } catch (err: any) {
      showToast?.(err?.message || '载入示例档案失败', 'error');
    }
  }, [userId, fetchPets, showToast]);

  const addPet = useCallback(
    async (input: PetFormInput) => {
      try {
        const created = await petService.createPet(input);
        setPets((prev) => [...prev, created]);
        setSelectedPetId(created.id);
        if (userId) {
          localStorage.setItem(getSelectedPetStorageKey(userId), created.id);
        }
        showToast?.(`已新增宠物档案：${created.name}`, 'success');
        return created;
      } catch (err: any) {
        showToast?.(err?.message || '新增宠物失败', 'error');
        throw err;
      }
    },
    [userId, showToast]
  );

  const updatePet = useCallback(
    async (id: string, patch: Partial<Pet>) => {
      try {
        const updated = await petService.updatePet(id, patch);
        setPets((prev) => prev.map((p) => (p.id === id ? updated : p)));
        showToast?.(`已更新 ${updated.name} 的档案`, 'success');
        return updated;
      } catch (err: any) {
        showToast?.(err?.message || '更新宠物失败', 'error');
        throw err;
      }
    },
    [showToast]
  );

  const deletePet = useCallback(
    async (id: string) => {
      try {
        await petService.deletePet(id);
        setPets((prev) => {
          const remaining = prev.filter((p) => p.id !== id);
          if (selectedPetId === id) {
            const nextId = remaining[0]?.id || '';
            setSelectedPetId(nextId);
            if (userId) {
              if (nextId) localStorage.setItem(getSelectedPetStorageKey(userId), nextId);
              else localStorage.removeItem(getSelectedPetStorageKey(userId));
            }
          }
          return remaining;
        });
        showToast?.('已删除宠物档案', 'success');
      } catch (err: any) {
        showToast?.(err?.message || '删除宠物失败', 'error');
        throw err;
      }
    },
    [selectedPetId, userId, showToast]
  );

  return {
    pets,
    selectedPet,
    loading,
    error,
    refreshPets: fetchPets,
    seedDemoPets,
    selectPet,
    addPet,
    updatePet,
    deletePet,
  };
}
