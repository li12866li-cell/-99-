import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Clock, Trash2, X, ChevronDown, ChevronUp } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Pet } from '../types/pet.ts';
import {
  DANGER_IDS,
  DurationOptionId,
  getAllWizardSymptoms,
  SymptomMatchResult,
} from '../lib/symptomMatcher.ts';
import { SymptomCheckHistoryItem } from '../services/localStore.ts';
import { NearbyHospitalContact, symptomService } from '../services/symptomService.ts';
import { PetWelcome } from '../components/symptom/PetWelcome.tsx';
import { SymptomWizard } from '../components/symptom/SymptomWizard.tsx';
import { PetDoctorAnimation } from '../components/symptom/PetDoctorAnimation.tsx';
import { HealthReport } from '../components/symptom/HealthReport.tsx';
import { PetComfortAnimation } from '../components/symptom/PetComfortAnimation.tsx';

interface SymptomCheckerPageProps {
  selectedPet: Pet | null;
  showToast: (msg: string, type?: 'success' | 'error') => void;
  onNavigateHome?: () => void;
}

type CheckStage = 'welcome' | 'wizard' | 'checking' | 'report';

export function SymptomCheckerPage({
  selectedPet,
  showToast,
}: SymptomCheckerPageProps) {
  const prefersReducedMotion = useReducedMotion();
  const catalog = useMemo(() => getAllWizardSymptoms(), []);

  // Always start on Stage 1 (welcome) when entering the Symptom Checker
  const [stage, setStage] = useState<CheckStage>('welcome');
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [durationId, setDurationId] = useState<DurationOptionId | undefined>('just_started');
  const [customNote, setCustomNote] = useState<string>('');

  // Stage 3 real execution tracking
  const [checkStageIndex, setCheckStageIndex] = useState<number>(0);
  const [checkProgress, setCheckProgress] = useState<number>(0);

  // Stage 4 & 5 result + history state
  const [result, setResult] = useState<SymptomMatchResult | null>(null);
  const [history, setHistory] = useState<SymptomCheckHistoryItem[]>([]);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [savingHistory, setSavingHistory] = useState<boolean>(false);
  const [showHistoryPanel, setShowHistoryPanel] = useState<boolean>(false);
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);
  const [hospitals, setHospitals] = useState<NearbyHospitalContact[]>([]);

  const historySectionRef = useRef<HTMLElement | null>(null);
  const runCounterRef = useRef<number>(0);

  // Load persisted local history & local hospitals without any external network call
  useEffect(() => {
    let mounted = true;
    symptomService.listHistory(selectedPet?.id).then((items) => {
      if (mounted) setHistory(items);
    });
    symptomService.fetchNearbyEmergencyHospitals().then((list) => {
      if (mounted) setHospitals(list);
    });
    return () => {
      mounted = false;
    };
  }, [selectedPet?.id]);

  const selectedSymptoms = useMemo(
    () => catalog.filter((s) => selectedIds.includes(s.id)),
    [catalog, selectedIds]
  );

  const emergencySymptoms = useMemo(
    () => selectedSymptoms.filter((s) => DANGER_IDS.has(s.id) || s.severity === 'emergency'),
    [selectedSymptoms]
  );

  const handleToggleSymptom = (id: string) => {
    setSelectedIds((prev) => {
      const exists = prev.includes(id);
      if (exists) {
        return prev.filter((item) => item !== id);
      }
      // Smart mutual-exclusion for baseline "normal" choices within the same group
      if (id === 'spirit_normal') {
        return [
          ...prev.filter(
            (item) =>
              item !== 'lethargy_mild' &&
              item !== 'reduced_activity' &&
              item !== 'high_fever_lethargy'
          ),
          id,
        ];
      }
      if (
        id === 'lethargy_mild' ||
        id === 'reduced_activity' ||
        id === 'high_fever_lethargy'
      ) {
        return [...prev.filter((item) => item !== 'spirit_normal'), id];
      }
      if (id === 'appetite_normal') {
        return [
          ...prev.filter(
            (item) => item !== 'appetite_slightly_down' && item !== 'anorexia_24h'
          ),
          id,
        ];
      }
      if (id === 'appetite_slightly_down' || id === 'anorexia_24h') {
        return [...prev.filter((item) => item !== 'appetite_normal'), id];
      }
      return [...prev, id];
    });
  };

  const handleStartChecking = async () => {
    if (selectedIds.length === 0) {
      showToast('请至少选择一项观察到的状态或症状', 'error');
      return;
    }

    const currentRun = ++runCounterRef.current;
    setStage('checking');
    setResult(null);
    setIsSaved(false);
    setCheckStageIndex(0);
    setCheckProgress(15);

    const matched = await symptomService.checkSymptoms({
      symptomIds: selectedIds,
      durationId,
      customNote,
      pet: selectedPet,
      onStageChange: (idx, pct) => {
        if (runCounterRef.current === currentRun) {
          setCheckStageIndex(idx);
          setCheckProgress(pct);
        }
      },
    });

    if (runCounterRef.current !== currentRun) return;
    setResult(matched);
    setStage('report');
    showToast(`已完成本地健康检查：${matched.levelLabel}`);
  };

  const handleSaveRecord = async () => {
    if (!result || isSaved || savingHistory) return;
    setSavingHistory(true);
    try {
      const saved = await symptomService.saveHistory({
        petId: selectedPet?.id || 'general',
        petName: selectedPet?.name || '未指定宠物',
        symptomIds: selectedIds,
        symptomNames: result.matchedSymptoms.map((s) => s.name),
        level: result.level,
        score: result.score,
        headline: result.headline,
        durationLabel: result.durationLabel,
        reasoning: result.reasoning,
        adviceList: result.adviceList,
        customNote: result.customNote,
      });
      setHistory((prev) => [saved, ...prev]);
      setIsSaved(true);
      showToast('已保存本次检查记录到本地档案');
    } finally {
      setSavingHistory(false);
    }
  };

  const handleOpenHistory = () => {
    setShowHistoryPanel(true);
    setTimeout(() => {
      historySectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  };

  const handleRestartToWelcome = () => {
    runCounterRef.current += 1;
    setSelectedIds([]);
    setDurationId('just_started');
    setCustomNote('');
    setWizardStep(1);
    setResult(null);
    setIsSaved(false);
    setCheckStageIndex(0);
    setCheckProgress(0);
    setStage('welcome');
  };

  const handleClearHistory = async () => {
    await symptomService.clearHistory(selectedPet?.id);
    setHistory([]);
    setExpandedHistoryId(null);
    showToast('已清空本地检查历史记录');
  };

  return (
    <div className="w-full min-w-0 space-y-6">
      {/* Main 5-Stage Interactive Flow */}
      <AnimatePresence mode="wait">
        {stage === 'welcome' && (
          <motion.div
            key="stage-welcome"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="max-w-4xl mx-auto"
          >
            <PetWelcome
              pet={selectedPet}
              historyCount={history.length}
              onStartCheck={() => {
                setWizardStep(1);
                setStage('wizard');
              }}
              onOpenHistory={handleOpenHistory}
            />
          </motion.div>
        )}

        {stage === 'wizard' && (
          <motion.div
            key="stage-wizard"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
          >
            <SymptomWizard
              pet={selectedPet}
              currentStep={wizardStep}
              selectedIds={selectedIds}
              durationId={durationId}
              customNote={customNote}
              emergencySymptoms={emergencySymptoms}
              hospitals={hospitals}
              onStepChange={setWizardStep}
              onToggleSymptom={handleToggleSymptom}
              onSelectDuration={setDurationId}
              onChangeCustomNote={setCustomNote}
              onClearAll={() => setSelectedIds([])}
              onBackToWelcome={() => setStage('welcome')}
              onSubmitCheck={handleStartChecking}
            />
          </motion.div>
        )}

        {stage === 'checking' && (
          <motion.div
            key="stage-checking"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <PetDoctorAnimation
              pet={selectedPet}
              stageIndex={checkStageIndex}
              progress={checkProgress}
              selectedSymptoms={selectedSymptoms}
            />
          </motion.div>
        )}

        {stage === 'report' && result && (
          <motion.div
            key="stage-report"
            initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0 }}
            transition={{ duration: 0.28 }}
            className="space-y-6"
          >
            {/* Stage 4: Single-column Dynamic Health Report */}
            <HealthReport result={result} pet={selectedPet} hospitals={hospitals} />

            {/* Stage 5: Check Completed & 3 Action Buttons */}
            <PetComfortAnimation
              pet={selectedPet}
              result={result}
              isSaved={isSaved}
              saving={savingHistory}
              historyCount={history.length}
              onSaveRecord={handleSaveRecord}
              onViewHistory={handleOpenHistory}
              onRestart={handleRestartToWelcome}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persisted Local Check History Panel */}
      {(showHistoryPanel || (stage !== 'welcome' && history.length > 0)) && (
        <section
          ref={historySectionRef}
          className="max-w-4xl mx-auto wellness-card rounded-3xl p-6 space-y-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-[19px] font-semibold text-[#1f2e28]">
              <Clock className="w-5 h-5 text-[#2f9e7e] shrink-0" />
              <span>症状自查历史记录 ({history.length})</span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {history.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearHistory}
                  className="px-3 py-1.5 rounded-xl text-[14px] text-[#72847c] hover:text-rose-600 hover:bg-rose-50 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>清空历史</span>
                </button>
              )}
              {showHistoryPanel && (
                <button
                  type="button"
                  onClick={() => setShowHistoryPanel(false)}
                  className="p-1.5 rounded-xl text-[#72847c] hover:bg-[#fffbf2] cursor-pointer"
                  aria-label="收起历史记录"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {history.length === 0 ? (
            <p className="text-[14px] text-[#72847c] leading-[1.6]">
              暂无历史检查记录。完成自查后点击「保存本次检查」，即可永久保存在本地浏览器中，刷新页面也不会丢失。
            </p>
          ) : (
            <ul className="space-y-3">
              {history.slice(0, 15).map((item) => {
                const isExpanded = expandedHistoryId === item.id;
                const levelText =
                  item.level === 'emergency'
                    ? '紧急就医'
                    : item.level === 'urgent'
                    ? '需要尽快就医'
                    : '一般关注';
                const levelColor =
                  item.level === 'emergency'
                    ? 'text-[#d9385a] bg-[#fff0f4] border-[#f48ca3]'
                    : item.level === 'urgent'
                    ? 'text-[#ea7d2b] bg-[#fff3e6] border-[#ffb074]'
                    : 'text-[#1f5c4b] bg-[#e6f7f1] border-[#2f9e7e]/40';

                return (
                  <li
                    key={item.id}
                    className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-4 space-y-2"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 flex-wrap min-w-0">
                        <span
                          className={`px-2.5 py-0.5 rounded-lg border text-[13px] font-semibold whitespace-nowrap shrink-0 ${levelColor}`}
                        >
                          {levelText}
                        </span>
                        <span className="text-[15px] font-semibold text-[#1f2e28]">
                          {item.petName}
                        </span>
                        {item.durationLabel && (
                          <span className="text-[13px] text-[#72847c]">
                            · 持续：{item.durationLabel}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[13px] text-[#72847c] tabular-nums">
                          {new Date(item.checkedAt).toLocaleString('zh-CN')}
                        </span>
                        {(item.reasoning?.length || item.adviceList?.length || item.customNote) && (
                          <button
                            type="button"
                            onClick={() =>
                              setExpandedHistoryId(isExpanded ? null : item.id)
                            }
                            className="px-2.5 py-1 rounded-lg bg-white border border-[#e9e4d8] text-[13px] text-[#1f5c4b] font-medium inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                          >
                            <span>{isExpanded ? '收起' : '详情'}</span>
                            {isExpanded ? (
                              <ChevronUp className="w-3.5 h-3.5" />
                            ) : (
                              <ChevronDown className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="text-[14px] text-[#4c5e56] leading-[1.6] break-words">
                      已选项目：{item.symptomNames.join('、')}
                    </div>

                    <div className="text-[14px] text-[#1f2e28] leading-[1.6] break-words">
                      {item.headline}
                    </div>

                    {isExpanded && (
                      <div className="pt-2 border-t border-[#e9e4d8] space-y-2 text-[14px] text-[#4c5e56] leading-[1.6]">
                        {item.customNote && (
                          <div className="break-words">补充观察：{item.customNote}</div>
                        )}
                        {item.reasoning && item.reasoning.length > 0 && (
                          <div>
                            <div className="font-semibold text-[#1f2e28] mb-1">判断依据：</div>
                            <ul className="space-y-1">
                              {item.reasoning.map((r, idx) => (
                                <li key={idx} className="break-words">
                                  · {r}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        {item.adviceList && item.adviceList.length > 0 && (
                          <div>
                            <div className="font-semibold text-[#1f2e28] mb-1">处理建议：</div>
                            <ul className="space-y-1">
                              {item.adviceList.map((a, idx) => (
                                <li key={idx} className="break-words">
                                  · {a}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      )}
    </div>
  );
}
