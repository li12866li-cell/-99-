import React, { useMemo, useState } from 'react';
import { Plus, Pencil, Trash2, Heart, PawPrint, CalendarDays } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Pet, PetFormInput } from '../types/pet.ts';
import { Reminder } from '../types/reminder.ts';
import { WeightPoint } from '../components/WeightChart.tsx';
import { PetFormModal } from '../components/PetFormModal.tsx';
import { StatEditModal, StatEditTarget } from '../components/StatEditModal.tsx';
import { CuteVirtualPet } from '../components/CuteVirtualPet.tsx';
import { AnimatedNumber } from '../components/HealthProgressRing.tsx';
import { PawLoader } from '../components/PawLoader.tsx';
import { AppTabId } from '../components/LayoutShell.tsx';
import { VirtualPetInteractionLog, VirtualPetState } from '../services/localStore.ts';

interface HomePageProps {
  pets: Pet[];
  selectedPet: Pet | null;
  loadingPets: boolean;
  onSelectPet: (pet: Pet) => void;
  onAddPet: (input: PetFormInput) => Promise<Pet>;
  onUpdatePet: (id: string, patch: Partial<Pet>) => Promise<Pet>;
  onDeletePet: (id: string) => Promise<void>;
  weightChartData?: WeightPoint[];
  reminders?: Reminder[];
  onToggleReminder?: (id: string, completed: boolean) => Promise<void>;
  onSeedDemoPets?: () => Promise<any>;
  onNavigateTab?: (tab: AppTabId) => void;
  virtualPetState: VirtualPetState | null;
  onVirtualPetInteract: (
    action: VirtualPetInteractionLog['action'],
    label: string,
    points: number
  ) => { state: VirtualPetState; alreadyCheckedIn?: boolean } | null;
  t?: any;
}

function computeCompanionDays(startDateStr?: string): number {
  if (!startDateStr) return 1;
  const start = new Date(`${startDateStr}T00:00:00`);
  if (Number.isNaN(start.getTime())) return 1;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const diff = Math.floor((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(1, diff + 1);
}

export function HomePage({
  pets,
  selectedPet,
  loadingPets,
  onSelectPet,
  onAddPet,
  onUpdatePet,
  onDeletePet,
  onSeedDemoPets,
  virtualPetState,
  onVirtualPetInteract,
}: HomePageProps) {
  const prefersReducedMotion = Boolean(useReducedMotion());
  const [petModalOpen, setPetModalOpen] = useState(false);
  const [editingPet, setEditingPet] = useState<Pet | null>(null);
  const [statModalTarget, setStatModalTarget] = useState<StatEditTarget | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const companionDays = useMemo(
    () => computeCompanionDays(selectedPet?.companionStartDate),
    [selectedPet?.companionStartDate]
  );

  const handleSavePetForm = async (data: PetFormInput, editingId?: string) => {
    if (editingId) {
      await onUpdatePet(editingId, data);
    } else {
      await onAddPet(data);
    }
  };

  const handleSaveStat = async (value: string) => {
    if (!selectedPet || !statModalTarget) return;
    if (statModalTarget.id === 'companion') {
      await onUpdatePet(selectedPet.id, { companionStartDate: value });
    }
  };

  return (
    <div className="space-y-6">
      {/* Pet Switcher Bar */}
      <section className="wellness-card rounded-3xl p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <PawPrint className="w-4 h-4 text-[#2f9e7e]" />
            <h1 className="font-bold text-base sm:text-lg text-[#1f2e28]">我的宠物</h1>
            <span className="text-xs text-[#72847c] tabular-nums">({pets.length})</span>
          </div>
          <button
            type="button"
            onClick={() => {
              setEditingPet(null);
              setPetModalOpen(true);
            }}
            className="btn-press px-3.5 py-2 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>添加宠物</span>
          </button>
        </div>

        {loadingPets ? (
          <PawLoader label="正在读取本地宠物档案..." />
        ) : pets.length === 0 ? (
          <div className="py-8 px-4 text-center rounded-2xl border border-dashed border-[#e9e4d8] bg-[#fffbf2] space-y-3">
            <p className="text-sm text-[#4c5e56]">
              当前暂无宠物档案，请添加宠物或载入示例档案。
            </p>
            <div className="flex items-center justify-center gap-2.5 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setEditingPet(null);
                  setPetModalOpen(true);
                }}
                className="btn-press px-4 py-2 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                + 添加第一只宠物
              </button>
              {onSeedDemoPets && (
                <button
                  type="button"
                  onClick={() => onSeedDemoPets()}
                  className="btn-press px-4 py-2 rounded-2xl border border-[#e9e4d8] bg-white hover:bg-[#f7f1e5] text-[#4c5e56] text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                >
                  载入示例宠物 (Bella &amp; Mochi)
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap gap-3">
            {pets.map((pet) => {
              const isSelected = selectedPet?.id === pet.id;
              return (
                <div
                  key={pet.id}
                  className={`flex items-center gap-3 px-3.5 py-2.5 rounded-2xl border transition-all ${
                    isSelected
                      ? 'bg-[#e6f7f1] border-[#2f9e7e] text-[#1f2e28] shadow-2xs'
                      : 'bg-[#fffbf2] border-[#e9e4d8] hover:border-[#2f9e7e]/45 text-[#4c5e56]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmDeleteId(null);
                      onSelectPet(pet);
                    }}
                    className="flex items-center gap-2.5 text-left cursor-pointer"
                  >
                    <div className="w-9 h-9 rounded-full bg-white border border-[#e9e4d8] overflow-hidden flex items-center justify-center text-xs font-bold text-[#2f9e7e] shrink-0">
                      {pet.avatar ? (
                        <img src={pet.avatar} alt={pet.name} className="w-full h-full object-cover" />
                      ) : (
                        pet.name.slice(0, 1)
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-semibold leading-tight flex items-center gap-1.5">
                        <span>{pet.name}</span>
                      </div>
                      <div className="text-[11px] text-[#72847c] tabular-nums">
                        {pet.breed ||
                          (pet.species === 'cat'
                            ? '猫咪'
                            : pet.species === 'dog'
                            ? '狗狗'
                            : pet.species === 'bunny'
                            ? '兔兔'
                            : '宠物')}{' '}
                        · {pet.age ?? '--'} 岁 · {pet.weight ?? '--'} kg
                      </div>
                    </div>
                  </button>

                  {isSelected && (
                    <div className="flex items-center gap-1 pl-2 border-l border-[#2f9e7e]/20">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingPet(pet);
                          setPetModalOpen(true);
                        }}
                        className="p-1.5 rounded-lg text-[#4c5e56] hover:text-[#2f9e7e] hover:bg-white transition-colors"
                        title="编辑档案"
                        aria-label={`编辑 ${pet.name}`}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      {confirmDeleteId === pet.id ? (
                        <button
                          type="button"
                          onClick={async () => {
                            await onDeletePet(pet.id);
                            setConfirmDeleteId(null);
                          }}
                          className="px-2 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-semibold whitespace-nowrap shrink-0"
                        >
                          确认删除
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(pet.id)}
                          className="p-1.5 rounded-lg text-[#72847c] hover:text-rose-600 hover:bg-white transition-colors"
                          title="删除档案"
                          aria-label={`删除 ${pet.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Core Module 1: Dynamic Pet Vitality Nest (元气小窝) with Smooth Fade Transition */}
      {selectedPet && (
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedPet.id}
            initial={prefersReducedMotion ? false : { opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -8 }}
            transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          >
            <CuteVirtualPet
              pet={selectedPet}
              state={virtualPetState}
              onInteract={onVirtualPetInteract}
            />
          </motion.div>
        </AnimatePresence>
      )}

      {/* Core Module 2: Standalone Companion Days Card (陪伴天数) with Smooth Fade Transition */}
      {selectedPet && (
        <AnimatePresence mode="wait">
          <motion.section
            key={`companion-${selectedPet.id}`}
            initial={prefersReducedMotion ? false : { opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -8 }}
            transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
            className="wellness-card rounded-3xl p-5 sm:p-6 bg-gradient-to-r from-[#fffbf2] via-white to-[#e6f7f1]/45 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-[#fff0f4] border border-[#f48ca3]/40 flex items-center justify-center shrink-0">
                <Heart className="w-6 h-6 text-[#f48ca3] fill-[#f48ca3]" />
              </div>
              <div className="space-y-1 min-w-0">
                <div className="text-xs font-semibold text-[#1f5c4b]">
                  {selectedPet.name} 的陪伴天数
                </div>
                <div className="flex items-baseline gap-2">
                  <AnimatedNumber
                    value={companionDays}
                    className="text-3xl sm:text-4xl font-bold text-[#1f2e28] tabular-nums"
                  />
                  <span className="text-sm font-semibold text-[#4c5e56]">天</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#72847c] tabular-nums">
                  <CalendarDays className="w-3.5 h-3.5 text-[#2f9e7e] shrink-0" />
                  <span>
                    陪伴起始日：{selectedPet.companionStartDate || '未设置'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                setStatModalTarget({
                  id: 'companion',
                  label: `${selectedPet.name} 的陪伴起始日`,
                  initial:
                    selectedPet.companionStartDate ||
                    new Date().toISOString().split('T')[0],
                })
              }
              className="btn-press px-4 py-2.5 rounded-2xl bg-[#fffbf2] hover:bg-[#e6f7f1] border border-[#e9e4d8] hover:border-[#2f9e7e]/45 text-xs sm:text-sm font-semibold text-[#1f5c4b] inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Pencil className="w-3.5 h-3.5 text-[#2f9e7e]" />
              <span>修改陪伴起始日</span>
            </button>
          </motion.section>
        </AnimatePresence>
      )}

      {/* Modals */}
      <PetFormModal
        isOpen={petModalOpen}
        editingPet={editingPet}
        onClose={() => setPetModalOpen(false)}
        onSubmit={handleSavePetForm}
      />

      <StatEditModal
        stat={statModalTarget}
        onClose={() => setStatModalTarget(null)}
        onSave={handleSaveStat}
      />
    </div>
  );
}
