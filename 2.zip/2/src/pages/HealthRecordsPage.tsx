import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ClipboardList,
  Plus,
  Trash2,
  Calendar,
  Scale,
  X,
  Search,
  Syringe,
  TrendingUp,
  Pencil,
  Download,
  Upload,
  Check,
  AlertCircle,
  Building2,
  FileText,
  Hash,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { HealthRecord, HealthRecordInput, HealthRecordType, Pet } from '../types/pet.ts';
import { VaccineRecord, VaccineRecordInput } from '../services/localStore.ts';
import { WeightChart, WeightPoint } from '../components/WeightChart.tsx';
import { PawLoader } from '../components/PawLoader.tsx';

type WeightTimeRange = '7d' | '30d' | 'all';

interface HealthRecordsPageProps {
  pets?: Pet[];
  selectedPet: Pet | null;
  onSelectPet?: (id: string) => void;
  records: HealthRecord[];
  weightChartData: WeightPoint[];
  loadingRecords: boolean;
  onAddRecord: (input: HealthRecordInput) => Promise<HealthRecord>;
  onUpdateRecord?: (
    id: string,
    patch: Partial<Omit<HealthRecord, 'id' | 'petId'>>
  ) => Promise<HealthRecord>;
  onUpsertWeightRecord?: (
    input: HealthRecordInput,
    mode?: 'overwrite' | 'create'
  ) => Promise<{ record: HealthRecord; updatedExisting: boolean }>;
  onImportWeightRecords?: (
    petId: string,
    items: Array<{ date: string; weightKg: number; title?: string; content?: string }>
  ) => Promise<{ importedCount: number; updatedCount: number; records: HealthRecord[] }>;
  onDeleteRecord: (id: string) => Promise<void>;
  vaccineRecords: VaccineRecord[];
  loadingVaccines: boolean;
  onAddVaccineRecord: (input: VaccineRecordInput) => Promise<VaccineRecord>;
  onUpdateVaccineRecord: (
    id: string,
    patch: Partial<Omit<VaccineRecord, 'id' | 'petId'>>
  ) => Promise<VaccineRecord>;
  onDeleteVaccineRecord: (id: string) => Promise<void>;
  showToast?: (msg: string, type?: 'success' | 'error') => void;
}

const RECORD_TYPE_LABELS: Record<HealthRecordType, string> = {
  vaccine: '免疫记录',
  activity: '体重与运动',
  diet: '饮食调整',
  medical: '就诊检查',
};

const DOSE_QUICK_OPTIONS = ['第 1 针', '第 2 针', '第 3 针', '年度加强'];

function getVaccinePresets(species?: Pet['species']): string[] {
  if (species === 'cat') {
    return ['猫三联疫苗', '狂犬病疫苗', '猫白血病疫苗'];
  }
  if (species === 'dog') {
    return ['犬六联疫苗', '犬四联疫苗', '狂犬病疫苗', '钩端螺旋体疫苗'];
  }
  return ['基础免疫疫苗', '狂犬病疫苗', '年度加强疫苗'];
}

function validateWeightInput(raw: string): { valid: boolean; value?: number; error?: string } {
  const trimmed = raw.trim();
  if (!trimmed) {
    return { valid: false, error: '请输入有效的体重数值（kg）' };
  }
  const num = Number(trimmed);
  if (!Number.isFinite(num) || Number.isNaN(num)) {
    return { valid: false, error: '体重格式不正确，请输入数字' };
  }
  if (num <= 0) {
    return { valid: false, error: '体重必须大于 0 kg' };
  }
  if (num > 200) {
    return { valid: false, error: '体重数值超出合理范围（最大支持 200 kg）' };
  }
  return { valid: true, value: Number(num.toFixed(2)) };
}

function getCutoffDateStr(daysBack: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysBack);
  return d.toISOString().split('T')[0];
}

export function HealthRecordsPage({
  pets,
  selectedPet,
  onSelectPet,
  records,
  weightChartData,
  loadingRecords,
  onAddRecord,
  onUpdateRecord,
  onUpsertWeightRecord,
  onImportWeightRecords,
  onDeleteRecord,
  vaccineRecords,
  loadingVaccines,
  onAddVaccineRecord,
  onUpdateVaccineRecord,
  onDeleteVaccineRecord,
  showToast,
}: HealthRecordsPageProps) {
  const todayStr = new Date().toISOString().split('T')[0];
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Filter & view state
  const [weightRange, setWeightRange] = useState<WeightTimeRange>('all');
  const [recordFilter, setRecordFilter] = useState<'all' | HealthRecordType>('all');
  const [recordQuery, setRecordQuery] = useState('');
  const [vaccineQuery, setVaccineQuery] = useState('');

  // Modal for general health record
  const [showRecordModal, setShowRecordModal] = useState(false);

  // Free weight logger state (date defaults to today, freely editable)
  const [quickWeightDate, setQuickWeightDate] = useState(todayStr);
  const [quickWeightKg, setQuickWeightKg] = useState('');
  const [quickWeightNote, setQuickWeightNote] = useState('');
  const [quickWeightError, setQuickWeightError] = useState<string | null>(null);
  const [overwriteSameDay, setOverwriteSameDay] = useState(true);
  const [savingWeight, setSavingWeight] = useState(false);

  // Inline weight record edit state
  const [editingWeightId, setEditingWeightId] = useState<string | null>(null);
  const [editWeightDate, setEditWeightDate] = useState('');
  const [editWeightKg, setEditWeightKg] = useState('');
  const [editWeightNote, setEditWeightNote] = useState('');
  const [editWeightError, setEditWeightError] = useState<string | null>(null);
  const [savingEditWeight, setSavingEditWeight] = useState(false);

  // Vaccine inoculation add form state
  const [showAddVaccineForm, setShowAddVaccineForm] = useState(false);
  const [vaccineForm, setVaccineForm] = useState({
    vaccineName: '',
    vaccinatedDate: todayStr,
    doseCount: '第 1 针',
    hospital: '',
    notes: '',
  });
  const [vaccineFormError, setVaccineFormError] = useState<string | null>(null);
  const [savingVaccine, setSavingVaccine] = useState(false);

  // Inline vaccine record edit state
  const [editingVaccineId, setEditingVaccineId] = useState<string | null>(null);
  const [editVaccineForm, setEditVaccineForm] = useState({
    vaccineName: '',
    vaccinatedDate: '',
    doseCount: '',
    hospital: '',
    notes: '',
  });
  const [editVaccineError, setEditVaccineError] = useState<string | null>(null);
  const [savingEditVaccine, setSavingEditVaccine] = useState(false);

  // Health record modal state
  const [recordForm, setRecordForm] = useState<{
    date: string;
    type: HealthRecordType;
    title: string;
    content: string;
    weightKg: string;
  }>({
    date: todayStr,
    type: 'medical',
    title: '',
    content: '',
    weightKg: '',
  });
  const [recordWeightError, setRecordWeightError] = useState<string | null>(null);
  const [submittingRecord, setSubmittingRecord] = useState(false);

  // Reset transient editing states whenever active pet switches
  useEffect(() => {
    setEditingWeightId(null);
    setEditWeightError(null);
    setQuickWeightError(null);
    setEditingVaccineId(null);
    setEditVaccineError(null);
    setVaccineFormError(null);
  }, [selectedPet?.id]);

  // All weight records sorted newest first
  const allWeightRecords = useMemo(() => {
    return records
      .filter((r) => typeof r.weightKg === 'number' && r.weightKg > 0)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [records]);

  // Filtered weight chart points by selected time range (7d / 30d / all)
  const rangedWeightChartData = useMemo(() => {
    if (weightRange === 'all') return weightChartData;
    const cutoff = getCutoffDateStr(weightRange === '7d' ? 7 : 30);
    return weightChartData.filter((pt) => pt.fullDate >= cutoff);
  }, [weightChartData, weightRange]);

  const rangedWeightRecords = useMemo(() => {
    if (weightRange === 'all') return allWeightRecords;
    const cutoff = getCutoffDateStr(weightRange === '7d' ? 7 : 30);
    return allWeightRecords.filter((r) => r.date >= cutoff);
  }, [allWeightRecords, weightRange]);

  // Auto-computed statistics from actual saved records: 最新体重、最高体重、最低体重、累计变化
  const weightSummary = useMemo(() => {
    if (rangedWeightChartData.length === 0) {
      return {
        latest: null as number | null,
        max: null as number | null,
        min: null as number | null,
        delta: null as number | null,
      };
    }
    const weights = rangedWeightChartData.map((w) => w.weight);
    const first = weights[0];
    const latest = weights[weights.length - 1];
    const delta = weights.length >= 2 ? Number((latest - first).toFixed(2)) : 0;

    return {
      latest,
      max: Math.max(...weights),
      min: Math.min(...weights),
      delta,
    };
  }, [rangedWeightChartData]);

  // Detect same-day weight entry
  const sameDayExistingRecord = useMemo(() => {
    if (!quickWeightDate) return null;
    return allWeightRecords.find((r) => r.date === quickWeightDate) || null;
  }, [allWeightRecords, quickWeightDate]);

  // Filtered vaccine records
  const filteredVaccineRecords = useMemo(() => {
    const q = vaccineQuery.trim().toLowerCase();
    if (!q) return vaccineRecords;
    return vaccineRecords.filter(
      (v) =>
        v.vaccineName.toLowerCase().includes(q) ||
        v.doseCount.toLowerCase().includes(q) ||
        v.hospital.toLowerCase().includes(q) ||
        v.notes.toLowerCase().includes(q) ||
        v.vaccinatedDate.includes(q)
    );
  }, [vaccineRecords, vaccineQuery]);

  // Filtered general health records
  const filteredRecords = useMemo(() => {
    const q = recordQuery.trim().toLowerCase();
    return records.filter((r) => {
      if (recordFilter !== 'all' && r.type !== recordFilter) return false;
      if (!q) return true;
      return (
        r.title.toLowerCase().includes(q) ||
        r.content.toLowerCase().includes(q) ||
        r.date.includes(q)
      );
    });
  }, [records, recordFilter, recordQuery]);

  const handleQuickWeightSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPet || savingWeight) return;

    if (!quickWeightDate) {
      setQuickWeightError('请选择称重日期');
      return;
    }

    const validation = validateWeightInput(quickWeightKg);
    if (!validation.valid || validation.value === undefined) {
      setQuickWeightError(validation.error || '请输入有效体重');
      return;
    }

    setQuickWeightError(null);
    setSavingWeight(true);
    try {
      const payload: HealthRecordInput = {
        petId: selectedPet.id,
        date: quickWeightDate,
        type: 'activity',
        title: '体重记录',
        content: quickWeightNote.trim() || `称重 ${validation.value} kg`,
        weightKg: validation.value,
      };

      if (onUpsertWeightRecord) {
        await onUpsertWeightRecord(
          payload,
          sameDayExistingRecord && overwriteSameDay ? 'overwrite' : 'create'
        );
      } else {
        await onAddRecord(payload);
      }
      setQuickWeightKg('');
      setQuickWeightNote('');
    } finally {
      setSavingWeight(false);
    }
  };

  const startEditWeight = (rec: HealthRecord) => {
    setEditingWeightId(rec.id);
    setEditWeightDate(rec.date);
    setEditWeightKg(String(rec.weightKg ?? ''));
    setEditWeightNote(rec.content || '');
    setEditWeightError(null);
  };

  const handleSaveEditWeight = async (recId: string) => {
    if (!onUpdateRecord || savingEditWeight) return;
    if (!editWeightDate) {
      setEditWeightError('请选择日期');
      return;
    }
    const validation = validateWeightInput(editWeightKg);
    if (!validation.valid || validation.value === undefined) {
      setEditWeightError(validation.error || '体重数值无效');
      return;
    }

    setEditWeightError(null);
    setSavingEditWeight(true);
    try {
      await onUpdateRecord(recId, {
        date: editWeightDate,
        weightKg: validation.value,
        title: '体重记录',
        content: editWeightNote.trim() || `称重 ${validation.value} kg`,
      });
      setEditingWeightId(null);
    } finally {
      setSavingEditWeight(false);
    }
  };

  const handleExportWeightJson = () => {
    if (!selectedPet) return;
    const exportPayload = {
      app: 'Pet Pulse 宠爱脉动',
      exportedAt: new Date().toISOString(),
      petId: selectedPet.id,
      petName: selectedPet.name,
      species: selectedPet.species,
      weightRecords: allWeightRecords.map((r) => ({
        date: r.date,
        weightKg: r.weightKg,
        title: r.title,
        content: r.content,
      })),
    };
    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedPet.name}_体重记录_${todayStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast?.(`已导出 ${selectedPet.name} 的 ${allWeightRecords.length} 条体重记录`, 'success');
  };

  const handleImportJsonChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !selectedPet || !onImportWeightRecords) return;

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const rawArray = Array.isArray(parsed)
        ? parsed
        : Array.isArray(parsed?.weightRecords)
        ? parsed.weightRecords
        : Array.isArray(parsed?.records)
        ? parsed.records
        : null;

      if (!rawArray) {
        showToast?.('JSON 文件格式不支持，需包含 weightRecords 数组', 'error');
        return;
      }

      const validItems: Array<{
        date: string;
        weightKg: number;
        title?: string;
        content?: string;
      }> = [];

      for (const item of rawArray) {
        const date = String(item?.date || '').trim();
        const weightVal = Number(item?.weightKg ?? item?.weight);
        if (
          /^\d{4}-\d{2}-\d{2}$/.test(date) &&
          Number.isFinite(weightVal) &&
          weightVal > 0 &&
          weightVal <= 200
        ) {
          validItems.push({
            date,
            weightKg: Number(weightVal.toFixed(2)),
            title: typeof item?.title === 'string' ? item.title : undefined,
            content:
              typeof item?.content === 'string'
                ? item.content
                : typeof item?.note === 'string'
                ? item.note
                : undefined,
          });
        }
      }

      if (validItems.length === 0) {
        showToast?.('未检测到有效的日期与体重记录（需为 YYYY-MM-DD 与正数 kg）', 'error');
        return;
      }

      await onImportWeightRecords(selectedPet.id, validItems);
    } catch {
      showToast?.('JSON 解析失败，请检查文件是否为有效的 JSON 文本', 'error');
    }
  };

  const handleAddVaccineSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPet || savingVaccine) return;

    const cleanName = vaccineForm.vaccineName.trim();
    if (!cleanName) {
      setVaccineFormError('请填写疫苗名称');
      return;
    }
    if (!vaccineForm.vaccinatedDate) {
      setVaccineFormError('请选择接种日期');
      return;
    }

    setVaccineFormError(null);
    setSavingVaccine(true);
    try {
      await onAddVaccineRecord({
        petId: selectedPet.id,
        vaccineName: cleanName,
        vaccinatedDate: vaccineForm.vaccinatedDate,
        doseCount: vaccineForm.doseCount.trim() || '第 1 针',
        hospital: vaccineForm.hospital.trim(),
        notes: vaccineForm.notes.trim(),
      });
      setVaccineForm({
        vaccineName: '',
        vaccinatedDate: todayStr,
        doseCount: '第 1 针',
        hospital: '',
        notes: '',
      });
      setShowAddVaccineForm(false);
    } catch (err) {
      setVaccineFormError(err instanceof Error ? err.message : '保存接种记录失败');
    } finally {
      setSavingVaccine(false);
    }
  };

  const startEditVaccine = (rec: VaccineRecord) => {
    setEditingVaccineId(rec.id);
    setEditVaccineForm({
      vaccineName: rec.vaccineName,
      vaccinatedDate: rec.vaccinatedDate,
      doseCount: rec.doseCount,
      hospital: rec.hospital,
      notes: rec.notes,
    });
    setEditVaccineError(null);
  };

  const handleSaveEditVaccine = async (recId: string) => {
    if (savingEditVaccine) return;
    const cleanName = editVaccineForm.vaccineName.trim();
    if (!cleanName) {
      setEditVaccineError('疫苗名称不能为空');
      return;
    }
    if (!editVaccineForm.vaccinatedDate) {
      setEditVaccineError('请选择接种日期');
      return;
    }

    setEditVaccineError(null);
    setSavingEditVaccine(true);
    try {
      await onUpdateVaccineRecord(recId, {
        vaccineName: cleanName,
        vaccinatedDate: editVaccineForm.vaccinatedDate,
        doseCount: editVaccineForm.doseCount.trim() || '第 1 针',
        hospital: editVaccineForm.hospital.trim(),
        notes: editVaccineForm.notes.trim(),
      });
      setEditingVaccineId(null);
    } catch (err) {
      setEditVaccineError(err instanceof Error ? err.message : '更新接种记录失败');
    } finally {
      setSavingEditVaccine(false);
    }
  };

  const handleRecordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPet || !recordForm.title.trim() || submittingRecord) return;

    let parsedWeight: number | undefined = undefined;
    if (recordForm.weightKg.trim() !== '') {
      const check = validateWeightInput(recordForm.weightKg);
      if (!check.valid) {
        setRecordWeightError(check.error || '体重数值无效');
        return;
      }
      parsedWeight = check.value;
    }

    setRecordWeightError(null);
    setSubmittingRecord(true);
    try {
      await onAddRecord({
        petId: selectedPet.id,
        date: recordForm.date || todayStr,
        type: recordForm.type,
        title: recordForm.title.trim(),
        content: recordForm.content.trim(),
        weightKg: parsedWeight,
      });
      setRecordForm({
        date: todayStr,
        type: 'medical',
        title: '',
        content: '',
        weightKg: '',
      });
      setShowRecordModal(false);
    } finally {
      setSubmittingRecord(false);
    }
  };

  if (!selectedPet) {
    return (
      <div className="wellness-card rounded-3xl p-10 text-center space-y-2">
        <ClipboardList className="w-8 h-8 text-[#72847c] mx-auto" />
        <p className="text-sm text-[#4c5e56]">请先在「首页概览」选择或添加一只宠物</p>
      </div>
    );
  }

  const vaccinePresets = getVaccinePresets(selectedPet.species);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <section className="wellness-card rounded-3xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-lg sm:text-xl font-bold text-[#1f2e28]">
            {selectedPet.name} 的体重管理与疫苗接种档案
          </h1>
          <p className="text-xs sm:text-sm text-[#4c5e56]">
            按实际称重自由记录体重变化，自主管理已完成疫苗接种档案；各宠物数据独立保存在本地
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap shrink-0">
          {pets && pets.length > 1 && onSelectPet && (
            <div className="inline-flex items-center gap-1 rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-1">
              {pets.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onSelectPet(p.id)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    p.id === selectedPet.id
                      ? 'bg-[#2f9e7e] text-white'
                      : 'text-[#4c5e56] hover:text-[#1f2e28]'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setRecordWeightError(null);
              setShowRecordModal(true);
            }}
            className="btn-press px-3.5 py-2 rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span>新增健康记录</span>
          </button>
        </div>
      </section>

      {/* Module 1: 体重管理（自由记录模式） */}
      <section className="wellness-card rounded-3xl p-5 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#2f9e7e] shrink-0" />
              <h2 className="font-bold text-base text-[#1f2e28]">体重管理 (kg)</h2>
            </div>
            <p className="text-[11px] text-[#72847c]">
              随时根据实际称重情况记录，支持补记任意日期，不设每日记录要求
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Time Range Filter */}
            <div className="inline-flex rounded-xl bg-[#fffbf2] border border-[#e9e4d8] p-0.5">
              {(
                [
                  { id: '7d', label: '近7天' },
                  { id: '30d', label: '近30天' },
                  { id: 'all', label: '全部记录' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setWeightRange(tab.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    weightRange === tab.id
                      ? 'bg-[#2f9e7e] text-white'
                      : 'text-[#4c5e56] hover:text-[#1f2e28]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Local JSON Export & Import */}
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleImportJsonChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={handleExportWeightJson}
              className="btn-press px-3 py-1.5 rounded-xl bg-[#fffbf2] hover:bg-[#e6f7f1] border border-[#e9e4d8] text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>导出 JSON</span>
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="btn-press px-3 py-1.5 rounded-xl bg-[#fffbf2] hover:bg-[#e6f7f1] border border-[#e9e4d8] text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Upload className="w-3.5 h-3.5 shrink-0" />
              <span>导入 JSON</span>
            </button>
          </div>
        </div>

        {/* 4 Requested Real-Data Summary Cards: 最新体重、最高体重、最低体重、累计变化 */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="rounded-2xl bg-[#e6f7f1]/65 border border-[#2f9e7e]/30 px-4 py-3">
            <div className="text-[11px] font-medium text-[#4c5e56]">最新体重</div>
            <div className="text-lg font-bold text-[#1f5c4b] tabular-nums mt-0.5">
              {weightSummary.latest !== null ? `${weightSummary.latest} kg` : '--'}
            </div>
          </div>
          <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] px-4 py-3">
            <div className="text-[11px] font-medium text-[#4c5e56]">最高体重</div>
            <div className="text-lg font-bold text-[#1f2e28] tabular-nums mt-0.5">
              {weightSummary.max !== null ? `${weightSummary.max} kg` : '--'}
            </div>
          </div>
          <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] px-4 py-3">
            <div className="text-[11px] font-medium text-[#4c5e56]">最低体重</div>
            <div className="text-lg font-bold text-[#1f2e28] tabular-nums mt-0.5">
              {weightSummary.min !== null ? `${weightSummary.min} kg` : '--'}
            </div>
          </div>
          <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] px-4 py-3">
            <div className="text-[11px] font-medium text-[#4c5e56]">累计变化</div>
            <div
              className={`text-lg font-bold tabular-nums mt-0.5 ${
                weightSummary.delta === null
                  ? 'text-[#1f2e28]'
                  : weightSummary.delta > 0
                  ? 'text-[#2f9e7e]'
                  : weightSummary.delta < 0
                  ? 'text-[#ea7d2b]'
                  : 'text-[#1f2e28]'
              }`}
            >
              {weightSummary.delta !== null
                ? `${weightSummary.delta > 0 ? '+' : ''}${weightSummary.delta} kg`
                : '--'}
            </div>
          </div>
        </div>

        {/* Manual Weight Entry Form (Date defaults to today, freely editable) */}
        <form
          onSubmit={handleQuickWeightSubmit}
          noValidate
          className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-3.5 space-y-2.5"
        >
          <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-end">
            <div className="md:col-span-3 min-w-0 space-y-1">
              <label className="text-[11px] font-semibold text-[#4c5e56]">称重日期</label>
              <input
                type="date"
                required
                value={quickWeightDate}
                onChange={(e) => {
                  setQuickWeightDate(e.target.value);
                  if (quickWeightError) setQuickWeightError(null);
                }}
                className="w-full min-w-0 rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs tabular-nums focus:outline-none focus:border-[#2f9e7e]"
              />
            </div>

            <div className="md:col-span-2 min-w-0 space-y-1">
              <label className="text-[11px] font-semibold text-[#4c5e56]">体重 (kg) *</label>
              <input
                type="number"
                step="0.05"
                min="0.05"
                max="200"
                value={quickWeightKg}
                onChange={(e) => {
                  setQuickWeightKg(e.target.value);
                  if (quickWeightError) setQuickWeightError(null);
                }}
                placeholder={`如 ${selectedPet.weight || 5.0}`}
                className={`w-full min-w-0 rounded-xl border bg-white px-3 py-2 text-xs tabular-nums focus:outline-none ${
                  quickWeightError
                    ? 'border-rose-400 focus:border-rose-500'
                    : 'border-[#e9e4d8] focus:border-[#2f9e7e]'
                }`}
              />
            </div>

            <div className="md:col-span-5 min-w-0 space-y-1">
              <label className="text-[11px] font-semibold text-[#4c5e56]">
                备注（可选）
              </label>
              <input
                type="text"
                value={quickWeightNote}
                onChange={(e) => setQuickWeightNote(e.target.value)}
                placeholder="例如：早餐前称重 / 体检时顺便称重"
                className="w-full min-w-0 rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
              />
            </div>

            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={savingWeight}
                className="btn-press w-full py-2 px-3 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-45 text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {savingWeight
                    ? '保存中...'
                    : sameDayExistingRecord && overwriteSameDay
                    ? '更新该日'
                    : '添加记录'}
                </span>
              </button>
            </div>
          </div>

          {quickWeightError && (
            <div className="flex items-center gap-1.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-1.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{quickWeightError}</span>
            </div>
          )}

          {sameDayExistingRecord && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-xl bg-[#e6f7f1]/70 border border-[#2f9e7e]/35 px-3 py-2 text-xs text-[#1f5c4b]">
              <span>
                该日期（<strong>{quickWeightDate}</strong>）已有记录（
                <strong className="tabular-nums">{sameDayExistingRecord.weightKg} kg</strong>
                ），可选择覆盖更新或保留多条。
              </span>
              <label className="inline-flex items-center gap-1.5 font-semibold cursor-pointer whitespace-nowrap shrink-0">
                <input
                  type="checkbox"
                  checked={overwriteSameDay}
                  onChange={(e) => setOverwriteSameDay(e.target.checked)}
                  className="accent-[#2f9e7e]"
                />
                <span>覆盖更新同日记录</span>
              </label>
            </div>
          )}
        </form>

        {/* Line Chart */}
        <WeightChart data={rangedWeightChartData} />

        {/* Historical Weight Records List (Modify & Delete) */}
        <div className="space-y-2.5 pt-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <h3 className="text-xs font-bold text-[#1f5c4b]">
              历史体重记录（{rangedWeightRecords.length} 条）
            </h3>
            <span className="text-[11px] text-[#72847c]">
              修改或删除历史记录后，统计数值与折线图会自动同步更新
            </span>
          </div>

          {rangedWeightRecords.length === 0 ? (
            <div className="rounded-2xl bg-[#fffbf2] border border-dashed border-[#e9e4d8] px-4 py-5 text-center text-xs text-[#72847c]">
              当前时间范围内暂无体重记录，可在上方随时手动添加
            </div>
          ) : (
            <ul className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <AnimatePresence initial={false}>
                {rangedWeightRecords.map((rec) => {
                  const isEditing = editingWeightId === rec.id;
                  return (
                    <motion.li
                      key={rec.id}
                      layout
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.18 }}
                      className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/45 px-3.5 py-2.5"
                    >
                      {isEditing ? (
                        <div className="space-y-2">
                          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                            <input
                              type="date"
                              value={editWeightDate}
                              onChange={(e) => setEditWeightDate(e.target.value)}
                              className="sm:col-span-3 rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                            />
                            <input
                              type="number"
                              step="0.05"
                              min="0.05"
                              max="200"
                              value={editWeightKg}
                              onChange={(e) => {
                                setEditWeightKg(e.target.value);
                                if (editWeightError) setEditWeightError(null);
                              }}
                              placeholder="体重 kg"
                              className="sm:col-span-2 rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                            />
                            <input
                              type="text"
                              value={editWeightNote}
                              onChange={(e) => setEditWeightNote(e.target.value)}
                              placeholder="备注（可选）"
                              className="sm:col-span-5 rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
                            />
                            <div className="sm:col-span-2 flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingWeightId(null);
                                  setEditWeightError(null);
                                }}
                                className="px-2.5 py-1.5 rounded-xl bg-white border border-[#e9e4d8] text-xs font-medium text-[#4c5e56] whitespace-nowrap shrink-0"
                              >
                                取消
                              </button>
                              <button
                                type="button"
                                disabled={savingEditWeight}
                                onClick={() => handleSaveEditWeight(rec.id)}
                                className="px-2.5 py-1.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>保存</span>
                              </button>
                            </div>
                          </div>
                          {editWeightError && (
                            <div className="text-[11px] font-medium text-rose-700">
                              {editWeightError}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-3 flex-wrap min-w-0 text-xs">
                            <span className="font-mono tabular-nums font-bold text-[#1f5c4b]">
                              {rec.date}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-lg bg-[#e6f7f1] text-[#1f5c4b] font-bold tabular-nums">
                              {rec.weightKg} kg
                            </span>
                            <span className="text-[#4c5e56] truncate">
                              {rec.content || rec.title}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {onUpdateRecord && (
                              <button
                                type="button"
                                onClick={() => startEditWeight(rec)}
                                className="px-2.5 py-1 rounded-xl bg-white hover:bg-[#e6f7f1] border border-[#e9e4d8] text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                              >
                                <Pencil className="w-3 h-3" />
                                <span>修改</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => onDeleteRecord(rec.id)}
                              className="px-2.5 py-1 rounded-xl bg-white hover:bg-rose-50 border border-[#e9e4d8] text-xs font-semibold text-rose-600 inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>删除</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </motion.li>
                  );
                })}
              </AnimatePresence>
            </ul>
          )}
        </div>
      </section>

      {/* Two-Column Split: 疫苗接种记录 (Pure Archive) & 其他健康档案 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Module 2: 疫苗接种记录（纯接种档案管理，无提醒/无到期计算/无倒计时） */}
        <section className="lg:col-span-6 wellness-card rounded-3xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="space-y-0.5">
              <h2 className="font-bold text-base text-[#1f2e28] flex items-center gap-2">
                <Syringe className="w-4 h-4 text-[#2f9e7e] shrink-0" />
                <span>疫苗接种记录 ({vaccineRecords.length})</span>
              </h2>
              <p className="text-[11px] text-[#72847c]">
                仅保存 {selectedPet.name} 已完成的疫苗接种历史，独立记录疫苗、针次与医院信息
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setVaccineFormError(null);
                setShowAddVaccineForm((prev) => !prev);
              }}
              className="btn-press px-3 py-1.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              {showAddVaccineForm ? (
                <>
                  <X className="w-3.5 h-3.5 shrink-0" />
                  <span>收起表单</span>
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5 shrink-0" />
                  <span>添加接种记录</span>
                </>
              )}
            </button>
          </div>

          {/* Manual Add Vaccination Form */}
          <AnimatePresence initial={false}>
            {showAddVaccineForm && (
              <motion.form
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleAddVaccineSubmit}
                noValidate
                className="overflow-hidden"
              >
                <div className="rounded-2xl bg-[#fffbf2] border border-[#e9e4d8] p-4 space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-[#4c5e56]">
                      疫苗名称 *
                    </label>
                    <input
                      type="text"
                      value={vaccineForm.vaccineName}
                      onChange={(e) => {
                        setVaccineForm({ ...vaccineForm, vaccineName: e.target.value });
                        if (vaccineFormError) setVaccineFormError(null);
                      }}
                      placeholder="例如：狂犬病疫苗 / 犬六联疫苗 / 猫三联疫苗"
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
                    />
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {vaccinePresets.map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => {
                            setVaccineForm({ ...vaccineForm, vaccineName: preset });
                            if (vaccineFormError) setVaccineFormError(null);
                          }}
                          className="px-2 py-0.5 rounded-lg bg-white hover:bg-[#e6f7f1] border border-[#e9e4d8] text-[11px] text-[#4c5e56] hover:text-[#1f5c4b] transition-colors"
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-[#4c5e56]">
                        接种日期 *
                      </label>
                      <input
                        type="date"
                        required
                        value={vaccineForm.vaccinatedDate}
                        onChange={(e) => {
                          setVaccineForm({ ...vaccineForm, vaccinatedDate: e.target.value });
                          if (vaccineFormError) setVaccineFormError(null);
                        }}
                        className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-[#4c5e56]">
                        接种次数 *
                      </label>
                      <input
                        type="text"
                        value={vaccineForm.doseCount}
                        onChange={(e) =>
                          setVaccineForm({ ...vaccineForm, doseCount: e.target.value })
                        }
                        placeholder="如 第 1 针 / 年度加强"
                        className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {DOSE_QUICK_OPTIONS.map((dose) => (
                      <button
                        key={dose}
                        type="button"
                        onClick={() => setVaccineForm({ ...vaccineForm, doseCount: dose })}
                        className={`px-2 py-0.5 rounded-lg border text-[11px] transition-colors ${
                          vaccineForm.doseCount === dose
                            ? 'bg-[#e6f7f1] border-[#2f9e7e]/40 text-[#1f5c4b] font-semibold'
                            : 'bg-white border-[#e9e4d8] text-[#4c5e56]'
                        }`}
                      >
                        {dose}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-[#4c5e56]">
                      接种医院（可选）
                    </label>
                    <input
                      type="text"
                      value={vaccineForm.hospital}
                      onChange={(e) =>
                        setVaccineForm({ ...vaccineForm, hospital: e.target.value })
                      }
                      placeholder="例如：安心宠伴动物医院"
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-[#4c5e56]">
                      备注（可选）
                    </label>
                    <textarea
                      rows={2}
                      value={vaccineForm.notes}
                      onChange={(e) =>
                        setVaccineForm({ ...vaccineForm, notes: e.target.value })
                      }
                      placeholder="可填写疫苗批号、接种后观察情况等"
                      className="w-full rounded-xl border border-[#e9e4d8] bg-white px-3 py-2 text-xs focus:outline-none focus:border-[#2f9e7e]"
                    />
                  </div>

                  {vaccineFormError && (
                    <div className="flex items-center gap-1.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-xl px-3 py-1.5">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{vaccineFormError}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddVaccineForm(false);
                        setVaccineFormError(null);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-white border border-[#e9e4d8] text-xs font-medium text-[#4c5e56] whitespace-nowrap shrink-0"
                    >
                      取消
                    </button>
                    <button
                      type="submit"
                      disabled={savingVaccine}
                      className="btn-press px-3.5 py-1.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{savingVaccine ? '保存中...' : '保存接种记录'}</span>
                    </button>
                  </div>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Search box for vaccination records */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#72847c] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={vaccineQuery}
              onChange={(e) => setVaccineQuery(e.target.value)}
              placeholder="搜索疫苗名称、接种次数、医院或日期..."
              className="w-full rounded-xl border border-[#e9e4d8] bg-[#fffbf2]/70 focus:bg-white pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
            />
          </div>

          {/* Vaccination History List */}
          {loadingVaccines ? (
            <PawLoader label="正在加载疫苗接种记录..." />
          ) : filteredVaccineRecords.length === 0 ? (
            <div className="py-10 text-center rounded-2xl bg-[#fffbf2] border border-dashed border-[#e9e4d8] text-xs text-[#72847c] px-4">
              {vaccineRecords.length === 0
                ? `${selectedPet.name} 暂无疫苗接种记录，点击「添加接种记录」即可录入已完成的疫苗档案`
                : '未找到匹配的疫苗接种记录'}
            </div>
          ) : (
            <ul className="space-y-2.5">
              <AnimatePresence initial={false}>
                {filteredVaccineRecords.map((vac) => {
                  const isEditing = editingVaccineId === vac.id;
                  return (
                    <motion.li
                      key={vac.id}
                      layout
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.18 }}
                      className="p-3.5 rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/45 hover:bg-[#fffbf2]/80 transition-colors"
                    >
                      {isEditing ? (
                        <div className="space-y-2.5">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div className="space-y-1 sm:col-span-2">
                              <label className="text-[11px] font-semibold text-[#4c5e56]">
                                疫苗名称 *
                              </label>
                              <input
                                type="text"
                                value={editVaccineForm.vaccineName}
                                onChange={(e) => {
                                  setEditVaccineForm({
                                    ...editVaccineForm,
                                    vaccineName: e.target.value,
                                  });
                                  if (editVaccineError) setEditVaccineError(null);
                                }}
                                className="w-full rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[11px] font-semibold text-[#4c5e56]">
                                接种日期 *
                              </label>
                              <input
                                type="date"
                                value={editVaccineForm.vaccinatedDate}
                                onChange={(e) =>
                                  setEditVaccineForm({
                                    ...editVaccineForm,
                                    vaccinatedDate: e.target.value,
                                  })
                                }
                                className="w-full rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs tabular-nums focus:outline-none focus:border-[#2f9e7e]"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[11px] font-semibold text-[#4c5e56]">
                                接种次数
                              </label>
                              <input
                                type="text"
                                value={editVaccineForm.doseCount}
                                onChange={(e) =>
                                  setEditVaccineForm({
                                    ...editVaccineForm,
                                    doseCount: e.target.value,
                                  })
                                }
                                className="w-full rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
                              />
                            </div>
                            <div className="space-y-1 sm:col-span-2">
                              <label className="text-[11px] font-semibold text-[#4c5e56]">
                                接种医院
                              </label>
                              <input
                                type="text"
                                value={editVaccineForm.hospital}
                                onChange={(e) =>
                                  setEditVaccineForm({
                                    ...editVaccineForm,
                                    hospital: e.target.value,
                                  })
                                }
                                placeholder="可选"
                                className="w-full rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
                              />
                            </div>
                            <div className="space-y-1 sm:col-span-2">
                              <label className="text-[11px] font-semibold text-[#4c5e56]">
                                备注
                              </label>
                              <textarea
                                rows={2}
                                value={editVaccineForm.notes}
                                onChange={(e) =>
                                  setEditVaccineForm({
                                    ...editVaccineForm,
                                    notes: e.target.value,
                                  })
                                }
                                placeholder="可选"
                                className="w-full rounded-xl border border-[#e9e4d8] bg-white px-2.5 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
                              />
                            </div>
                          </div>

                          {editVaccineError && (
                            <div className="text-[11px] font-medium text-rose-700">
                              {editVaccineError}
                            </div>
                          )}

                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingVaccineId(null);
                                setEditVaccineError(null);
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-white border border-[#e9e4d8] text-xs font-medium text-[#4c5e56] whitespace-nowrap shrink-0"
                            >
                              取消
                            </button>
                            <button
                              type="button"
                              disabled={savingEditVaccine}
                              onClick={() => handleSaveEditVaccine(vac.id)}
                              className="px-2.5 py-1.5 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>保存修改</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-3">
                            <div className="space-y-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className="text-sm font-bold text-[#1f2e28]">
                                  {vac.vaccineName}
                                </h3>
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#e6f7f1] text-[#1f5c4b] text-[11px] font-semibold">
                                  <Hash className="w-3 h-3" />
                                  {vac.doseCount}
                                </span>
                                {vac.isDemo && (
                                  <span className="text-[11px] text-[#9a4d12]">示例档案</span>
                                )}
                              </div>

                              <div className="flex items-center gap-3 flex-wrap text-xs text-[#4c5e56]">
                                <span className="inline-flex items-center gap-1 font-mono tabular-nums text-[#1f5c4b] font-semibold">
                                  <Calendar className="w-3.5 h-3.5 text-[#2f9e7e]" />
                                  接种日期：{vac.vaccinatedDate}
                                </span>
                                {vac.hospital && (
                                  <span className="inline-flex items-center gap-1">
                                    <Building2 className="w-3.5 h-3.5 text-[#72847c]" />
                                    {vac.hospital}
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => startEditVaccine(vac)}
                                className="px-2.5 py-1 rounded-xl bg-white hover:bg-[#e6f7f1] border border-[#e9e4d8] text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                              >
                                <Pencil className="w-3 h-3" />
                                <span>修改</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => onDeleteVaccineRecord(vac.id)}
                                className="px-2.5 py-1 rounded-xl bg-white hover:bg-rose-50 border border-[#e9e4d8] text-xs font-semibold text-rose-600 inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>删除</span>
                              </button>
                            </div>
                          </div>

                          {vac.notes && (
                            <div className="flex items-start gap-1.5 text-xs text-[#4c5e56] bg-white/80 rounded-xl px-2.5 py-1.5 border border-[#e9e4d8]/70">
                              <FileText className="w-3.5 h-3.5 text-[#72847c] shrink-0 mt-0.5" />
                              <p className="leading-relaxed">{vac.notes}</p>
                            </div>
                          )}
                        </div>
                      )}
                    </motion.li>
                  );
                })}
              </AnimatePresence>
            </ul>
          )}
        </section>

        {/* Right: 日常健康与体检档案 */}
        <section className="lg:col-span-6 wellness-card rounded-3xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h2 className="font-bold text-base text-[#1f2e28] flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-[#2f9e7e]" />
              <span>日常健康与体检档案 ({filteredRecords.length})</span>
            </h2>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 sm:items-center justify-between">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-[#72847c] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={recordQuery}
                onChange={(e) => setRecordQuery(e.target.value)}
                placeholder="查询历史记录（标题、内容或日期）..."
                className="w-full rounded-xl border border-[#e9e4d8] bg-[#fffbf2]/70 focus:bg-white pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-[#2f9e7e]"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto">
              {(
                [
                  { id: 'all', label: '全部' },
                  { id: 'medical', label: '体检/就诊' },
                  { id: 'activity', label: '体重/运动' },
                  { id: 'diet', label: '饮食' },
                  { id: 'vaccine', label: '免疫笔记' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setRecordFilter(tab.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                    recordFilter === tab.id
                      ? 'bg-[#e6f7f1] text-[#1f5c4b] font-semibold'
                      : 'text-[#72847c] hover:bg-[#fffbf2]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {loadingRecords ? (
            <PawLoader label="正在加载历史档案..." />
          ) : filteredRecords.length === 0 ? (
            <div className="py-10 text-center rounded-2xl bg-[#fffbf2] border border-dashed border-[#e9e4d8] text-xs text-[#72847c]">
              暂无匹配的健康档案，点击右上角「新增健康记录」即可保存
            </div>
          ) : (
            <ul className="space-y-2.5">
              {filteredRecords.map((rec) => (
                <li
                  key={rec.id}
                  className="p-3.5 rounded-2xl border border-[#e9e4d8] hover:bg-[#fffbf2]/70 transition-colors flex items-start justify-between gap-3"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap text-xs text-[#72847c]">
                      <span className="font-mono tabular-nums font-semibold text-[#1f5c4b]">
                        {rec.date}
                      </span>
                      <span>·</span>
                      <span className="font-medium text-[#2f9e7e]">
                        {RECORD_TYPE_LABELS[rec.type]}
                      </span>
                      {typeof rec.weightKg === 'number' && rec.weightKg > 0 && (
                        <>
                          <span>·</span>
                          <span className="font-semibold text-[#1f2e28] tabular-nums">
                            称重 {rec.weightKg} kg
                          </span>
                        </>
                      )}
                    </div>
                    <h3 className="text-sm font-semibold text-[#1f2e28]">{rec.title}</h3>
                    {rec.content && (
                      <p className="text-xs text-[#4c5e56] leading-relaxed">{rec.content}</p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteRecord(rec.id)}
                    className="p-1.5 rounded-lg text-[#72847c] hover:text-rose-600 hover:bg-rose-50 shrink-0"
                    title="删除记录"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Add General Health Record Modal */}
      <AnimatePresence>
        {showRecordModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRecordModal(false)}
              className="absolute inset-0 bg-black/45 backdrop-blur-xs"
            />
            <motion.form
              onSubmit={handleRecordSubmit}
              initial={{ opacity: 0, scale: 0.96, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 12 }}
              className="relative z-10 w-full max-w-md bg-white rounded-3xl border border-[#e9e4d8] shadow-xl overflow-hidden"
            >
              <div className="px-5 py-4 border-b border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between">
                <h3 className="font-bold text-base text-[#1f2e28]">
                  新增健康记录 · {selectedPet.name}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowRecordModal(false)}
                  className="p-1.5 rounded-lg text-[#72847c] hover:bg-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#4c5e56]">记录日期</label>
                    <input
                      type="date"
                      required
                      value={recordForm.date}
                      onChange={(e) => setRecordForm({ ...recordForm, date: e.target.value })}
                      className="w-full bg-[#fffbf2] border border-[#e9e4d8] rounded-xl px-3 py-2 text-sm"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#4c5e56]">记录类型</label>
                    <select
                      value={recordForm.type}
                      onChange={(e) =>
                        setRecordForm({
                          ...recordForm,
                          type: e.target.value as HealthRecordType,
                        })
                      }
                      className="w-full bg-[#fffbf2] border border-[#e9e4d8] rounded-xl px-3 py-2 text-sm"
                    >
                      <option value="medical">就诊体检</option>
                      <option value="activity">体重与运动</option>
                      <option value="diet">饮食调整</option>
                      <option value="vaccine">免疫笔记</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#4c5e56]">记录标题 *</label>
                  <input
                    required
                    type="text"
                    value={recordForm.title}
                    onChange={(e) => setRecordForm({ ...recordForm, title: e.target.value })}
                    placeholder="例如：例行称重 / 年度体检 / 饮食调整"
                    className="w-full bg-[#fffbf2] border border-[#e9e4d8] rounded-xl px-3.5 py-2.5 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#4c5e56]">
                    测量体重 (kg，可选，填写将自动更新趋势图与档案)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    min="0.05"
                    max="200"
                    value={recordForm.weightKg}
                    onChange={(e) => {
                      setRecordForm({ ...recordForm, weightKg: e.target.value });
                      if (recordWeightError) setRecordWeightError(null);
                    }}
                    placeholder="例如：18.6"
                    className="w-full bg-[#fffbf2] border border-[#e9e4d8] rounded-xl px-3.5 py-2.5 text-sm tabular-nums"
                  />
                  {recordWeightError && (
                    <p className="text-xs text-rose-600">{recordWeightError}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-[#4c5e56]">详细描述（可选）</label>
                  <textarea
                    rows={3}
                    value={recordForm.content}
                    onChange={(e) => setRecordForm({ ...recordForm, content: e.target.value })}
                    placeholder="记录体检结果、饮食变化或日常观察"
                    className="w-full bg-[#fffbf2] border border-[#e9e4d8] rounded-xl px-3.5 py-2 text-sm"
                  />
                </div>
              </div>
              <div className="px-5 py-3.5 border-t border-[#e9e4d8] flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowRecordModal(false)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-[#4c5e56] bg-[#fffbf2] border border-[#e9e4d8] whitespace-nowrap shrink-0"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={!recordForm.title.trim() || submittingRecord}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white bg-[#2f9e7e] hover:bg-[#258267] disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  {submittingRecord ? '保存中...' : '保存记录'}
                </button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
