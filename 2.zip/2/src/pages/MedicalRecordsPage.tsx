import React, { useState } from 'react';
import { CalendarRange, FileDown, FileHeart } from 'lucide-react';
import { motion, useReducedMotion } from 'framer-motion';
import { HealthRecord, Pet } from '../types/pet.ts';
import { Reminder } from '../types/reminder.ts';
import { Language } from '../lib/i18n.ts';
import { medicalRecordsTranslations } from '../lib/medicalRecordsI18n.ts';
import { MedicalRecordsPanel } from '../components/MedicalRecordsPanel.tsx';

interface MedicalRecordsPageProps {
  pets: Pet[];
  selectedPet: Pet | null;
  onSelectPet: (pet: Pet | string) => void;
  healthRecords: HealthRecord[];
  reminders: Reminder[];
  showToast: (msg: string, type?: 'success' | 'error') => void;
  lang?: Language;
}

export function MedicalRecordsPage({
  pets,
  selectedPet,
  onSelectPet,
  healthRecords,
  reminders,
  showToast,
  lang = 'zh',
}: MedicalRecordsPageProps) {
  const prefersReducedMotion = useReducedMotion();
  const copy = medicalRecordsTranslations[lang] || medicalRecordsTranslations.zh;

  const [weeklyModalOpen, setWeeklyModalOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Section 1: Page Header */}
      <section className="wellness-card rounded-3xl p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-[#e6f7f1] text-[#1f5c4b] flex items-center justify-center shrink-0">
            <FileHeart className="w-5 h-5 text-[#2f9e7e]" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-[#1f2e28] tracking-tight">
              {copy.pageTitle}
            </h1>
            <p className="text-xs sm:text-sm text-[#72847c] mt-0.5">{copy.pageSubtitle}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <motion.button
            type="button"
            onClick={() => setWeeklyModalOpen(true)}
            whileHover={prefersReducedMotion ? undefined : { y: -1, scale: 1.01 }}
            whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
            transition={{ duration: 0.16 }}
            className="px-4 py-2.5 min-h-[42px] rounded-2xl bg-[#fff3e6] hover:bg-[#ffe8cf] border border-[#ffb074]/65 text-[#9a4d12] text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
          >
            <CalendarRange className="w-4 h-4 shrink-0" />
            <span>{copy.weeklyReportBtn}</span>
          </motion.button>

          <motion.button
            type="button"
            onClick={() => setExportModalOpen(true)}
            whileHover={prefersReducedMotion ? undefined : { y: -1, scale: 1.01 }}
            whileTap={prefersReducedMotion ? undefined : { scale: 0.98 }}
            transition={{ duration: 0.16 }}
            className="px-4 py-2.5 min-h-[42px] rounded-2xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
          >
            <FileDown className="w-4 h-4 shrink-0" />
            <span>{copy.preVetExportBtn}</span>
          </motion.button>
        </div>
      </section>

      <MedicalRecordsPanel
        pets={pets}
        selectedPet={selectedPet}
        onSelectPet={onSelectPet}
        healthRecords={healthRecords}
        reminders={reminders}
        showToast={showToast}
        lang={lang}
        weeklyModalOpen={weeklyModalOpen}
        onWeeklyModalOpenChange={setWeeklyModalOpen}
        exportModalOpen={exportModalOpen}
        onExportModalOpenChange={setExportModalOpen}
      />
    </div>
  );
}
