import React, { useEffect, useMemo, useState } from 'react';
import {
  Search,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Ban,
  X,
  Info,
  Heart,
  HeartOff,
  Trash2,
  Pencil,
  Dog,
  Cat,
  ChevronRight,
  Tag,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import foodScanPlaceholderImg from '../assets/images/pet_food_scan_1794129006097.jpg';
import {
  checkFoodAgainstPetPreferences,
  findMatchingFoodEntry,
  FOOD_SAFETY_DB,
  FoodSafetyEntry,
  FoodSafetyLevel,
  getLocalFoodImageUrl,
  getSpeciesSuitability,
  SpeciesSuitability,
} from '../data/foodSafetyCatalog.ts';
import {
  FoodPreferenceCategory,
  localStore,
  PetFoodPreferenceItem,
  PetFoodPreferences,
} from '../services/localStore.ts';
import { Pet } from '../types/pet.ts';
import { Language } from '../lib/i18n.ts';
import { foodScanTranslations } from '../lib/foodScanI18n.ts';
import { matchFoodEmoji } from '../lib/foodEmojiMatcher.ts';
import {
  FoodPreferenceEntryCards,
  InteractivePreferenceTab,
} from '../components/FoodPreferenceEntryCards.tsx';
import { FoodPreferenceModal } from '../components/food/FoodPreferenceModal.tsx';

const LEVEL_STYLES: Record<
  FoodSafetyLevel,
  {
    cardBorder: string;
    headerBg: string;
    textColor: string;
    badgeBg: string;
    icon: React.ComponentType<{ className?: string }>;
  }
> = {
  safe: {
    cardBorder: 'border-[#2f9e7e]/35',
    headerBg: 'bg-[#e6f7f1]/75',
    textColor: 'text-[#1f5c4b]',
    badgeBg: 'bg-[#e6f7f1] border-[#2f9e7e]/45 text-[#1f5c4b]',
    icon: CheckCircle2,
  },
  caution: {
    cardBorder: 'border-[#ffb074]/55',
    headerBg: 'bg-[#fff3e6]/85',
    textColor: 'text-[#9a4d12]',
    badgeBg: 'bg-[#fff3e6] border-[#ffb074]/60 text-[#9a4d12]',
    icon: AlertTriangle,
  },
  forbidden: {
    cardBorder: 'border-[#f48ca3]/65',
    headerBg: 'bg-[#fff0f4]/85',
    textColor: 'text-[#9c2341]',
    badgeBg: 'bg-[#fff0f4] border-[#f48ca3]/70 text-[#9c2341]',
    icon: Ban,
  },
};

const INTERACTIVE_TAB_STYLES: Record<
  InteractivePreferenceTab,
  {
    panelBg: string;
    panelBorder: string;
    accentText: string;
    btnBg: string;
    tileBorder: string;
  }
> = {
  likes: {
    panelBg: 'bg-[#e6f7f1]/35',
    panelBorder: 'border-[#2f9e7e]/35',
    accentText: 'text-[#1f5c4b]',
    btnBg: 'bg-[#2f9e7e] hover:bg-[#258267]',
    tileBorder: 'border-[#2f9e7e]/30 hover:border-[#2f9e7e]/70',
  },
  dislikes: {
    panelBg: 'bg-[#fff3e6]/45',
    panelBorder: 'border-[#ffb074]/55',
    accentText: 'text-[#9a4d12]',
    btnBg: 'bg-[#ea7d2b] hover:bg-[#cf6a1e]',
    tileBorder: 'border-[#ffb074]/45 hover:border-[#ea7d2b]',
  },
  allergies: {
    panelBg: 'bg-[#fff0f4]/45',
    panelBorder: 'border-[#f48ca3]/60',
    accentText: 'text-[#9c2341]',
    btnBg: 'bg-[#d9385a] hover:bg-[#bd2a49]',
    tileBorder: 'border-[#f48ca3]/50 hover:border-[#d9385a]',
  },
};

function SuitabilityBadge({ suitability }: { suitability: SpeciesSuitability }) {
  if (suitability.status === 'suitable') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e6f7f1] text-[#1f5c4b] border border-[#2f9e7e]/35 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3 h-3" />
        <span>{suitability.label}</span>
      </span>
    );
  }
  if (suitability.status === 'caution') {
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#fff3e6] text-[#9a4d12] border border-[#ffb074]/55 whitespace-nowrap shrink-0">
        <AlertTriangle className="w-3 h-3" />
        <span>{suitability.label}</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#fff0f4] text-[#9c2341] border border-[#f48ca3]/60 whitespace-nowrap shrink-0">
      <Ban className="w-3 h-3" />
      <span>{suitability.label}</span>
    </span>
  );
}

const PREF_BADGE_STYLES: Record<
  InteractivePreferenceTab,
  {
    badgeClass: string;
    icon: React.ComponentType<{ className?: string }>;
  }
> = {
  likes: {
    badgeClass: 'bg-[#e6f7f1] text-[#1f5c4b] border-[#2f9e7e]/35',
    icon: Heart,
  },
  dislikes: {
    badgeClass: 'bg-[#fff3e6] text-[#9a4d12] border-[#ffb074]/55',
    icon: HeartOff,
  },
  allergies: {
    badgeClass: 'bg-[#fff0f4] text-[#9c2341] border-[#f48ca3]/60',
    icon: ShieldAlert,
  },
};

function isCustomPreferenceFood(item: PetFoodPreferenceItem): boolean {
  if (item.id.startsWith('fp_seed_')) return false;
  return !item.foodId || Boolean(item.icon);
}

interface AggregatedCustomFood {
  key: string;
  name: string;
  icon: string;
  categories: InteractivePreferenceTab[];
  itemsByCategory: Partial<Record<InteractivePreferenceTab, PetFoodPreferenceItem>>;
  primaryCategory: InteractivePreferenceTab;
  primaryItem: PetFoodPreferenceItem;
  notes: string[];
  updatedAt: string;
}

interface FoodScanPageProps {
  t?: any;
  lang?: string;
  pets?: Pet[];
  selectedPet?: Pet | null;
  onSelectPet?: (petId: string) => void;
  showToast?: (msg: string, type?: 'success' | 'error') => void;
}

export function FoodScanPage({
  lang = 'zh',
  pets: propPets,
  selectedPet: propSelectedPet,
  onSelectPet,
  showToast,
}: FoodScanPageProps) {
  const prefersReducedMotion = useReducedMotion();
  const safeLang: Language = lang === 'en' || lang === 'ko' ? lang : 'zh';
  const copy = foodScanTranslations[safeLang];

  // Local fallback pet list in case FoodScanPage is mounted standalone
  const fallbackPets = useMemo(() => localStore.listPets(), []);
  const pets = propPets && propPets.length > 0 ? propPets : fallbackPets;
  const [localPetId, setLocalPetId] = useState<string>(
    () => propSelectedPet?.id || localStore.getSelectedPetId() || pets[0]?.id || ''
  );

  useEffect(() => {
    if (propSelectedPet?.id) {
      setLocalPetId(propSelectedPet.id);
    }
  }, [propSelectedPet?.id]);

  const activePet = useMemo(() => {
    if (propSelectedPet) return propSelectedPet;
    return pets.find((p) => p.id === localPetId) || pets[0] || null;
  }, [propSelectedPet, pets, localPetId]);

  const handleSwitchPet = (petId: string) => {
    setLocalPetId(petId);
    onSelectPet?.(petId);
  };

  // Search & filter state (preserved across detail open/close)
  const [query, setQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<'all' | FoodSafetyLevel>('all');
  const [selectedFood, setSelectedFood] = useState<FoodSafetyEntry | null>(null);
  const [selectedCustomItem, setSelectedCustomItem] = useState<{
    item: PetFoodPreferenceItem;
    category: InteractivePreferenceTab;
  } | null>(null);

  // Per-pet personalized diet preferences
  const [prefs, setPrefs] = useState<PetFoodPreferences>(() =>
    activePet
      ? localStore.getPetFoodPreferences(activePet.id)
      : { petId: '', likes: [], allergies: [], dislikes: [], forbidden: [] }
  );

  // Which of the 3 side-by-side animated entry cards is expanded
  const [expandedPrefTab, setExpandedPrefTab] = useState<InteractivePreferenceTab | null>(
    null
  );

  // Add / Edit Food Modal State
  const [foodModalState, setFoodModalState] = useState<{
    mode: 'add' | 'edit';
    category: InteractivePreferenceTab;
    item?: PetFoodPreferenceItem | null;
  } | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);

  // Reload independent preferences from localStorage whenever activePet changes
  useEffect(() => {
    if (!activePet) {
      setPrefs({ petId: '', likes: [], allergies: [], dislikes: [], forbidden: [] });
      return;
    }
    setPrefs(localStore.getPetFoodPreferences(activePet.id));
    setFoodModalState(null);
    setSelectedCustomItem(null);
    setModalError(null);
  }, [activePet?.id]);

  // Esc key closes detail view
  useEffect(() => {
    if (!selectedFood && !selectedCustomItem && !foodModalState) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setFoodModalState(null);
        setSelectedFood(null);
        setSelectedCustomItem(null);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [selectedFood, selectedCustomItem, foodModalState]);

  // Single source of truth: derive deduplicated custom foods directly from active pet's prefs
  const customFoodsInAll = useMemo<AggregatedCustomFood[]>(() => {
    const map = new Map<string, AggregatedCustomFood>();
    const categoriesOrder: InteractivePreferenceTab[] = ['likes', 'dislikes', 'allergies'];

    for (const category of categoriesOrder) {
      const list = prefs[category] || [];
      for (const item of list) {
        if (!isCustomPreferenceFood(item)) continue;
        const key = item.name.trim().toLowerCase();
        if (!key) continue;

        const existing = map.get(key);
        const resolvedIcon = item.icon || matchFoodEmoji(item.name);
        if (!existing) {
          map.set(key, {
            key,
            name: item.name,
            icon: resolvedIcon,
            categories: [category],
            itemsByCategory: { [category]: item },
            primaryCategory: category,
            primaryItem: item,
            notes: item.note ? [item.note] : [],
            updatedAt: item.updatedAt,
          });
        } else {
          if (!existing.categories.includes(category)) {
            existing.categories.push(category);
          }
          existing.itemsByCategory[category] = item;
          if (item.note && !existing.notes.includes(item.note)) {
            existing.notes.push(item.note);
          }
          if (item.updatedAt > existing.updatedAt) {
            existing.updatedAt = item.updatedAt;
            existing.primaryCategory = category;
            existing.primaryItem = item;
            if (item.icon) {
              existing.icon = item.icon;
            }
          }
        }
      }
    }

    return Array.from(map.values()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }, [prefs]);

  const counts = useMemo(() => {
    const safe = FOOD_SAFETY_DB.foods.filter((f) => f.safetyLevel === 'safe').length;
    const caution = FOOD_SAFETY_DB.foods.filter((f) => f.safetyLevel === 'caution').length;
    const forbidden = FOOD_SAFETY_DB.foods.filter((f) => f.safetyLevel === 'forbidden').length;
    return {
      all: FOOD_SAFETY_DB.foods.length + customFoodsInAll.length,
      safe,
      caution,
      forbidden,
    };
  }, [customFoodsInAll.length]);

  const filteredCustomFoods = useMemo(() => {
    if (levelFilter !== 'all') return [];
    const q = query.trim().toLowerCase();
    if (!q) return customFoodsInAll;
    return customFoodsInAll.filter(
      (entry) =>
        entry.name.toLowerCase().includes(q) ||
        entry.notes.some((n) => n.toLowerCase().includes(q)) ||
        copy.customBadgeLabel.toLowerCase().includes(q) ||
        entry.categories.some((c) => copy.categoryShortLabels[c].toLowerCase().includes(q))
    );
  }, [customFoodsInAll, levelFilter, query, copy.customBadgeLabel, copy.categoryShortLabels]);

  const filteredFoods = useMemo(() => {
    const q = query.trim().toLowerCase();
    return FOOD_SAFETY_DB.foods.filter((item) => {
      if (levelFilter !== 'all' && item.safetyLevel !== levelFilter) return false;
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.aliases.some((a) => a.toLowerCase().includes(q)) ||
        item.toxicComponents.some((c) => c.toLowerCase().includes(q)) ||
        item.potentialRisks.toLowerCase().includes(q) ||
        item.speciesNote.toLowerCase().includes(q)
      );
    });
  }, [query, levelFilter]);

  // Quick visual picks from local DB assets inside the expanded category drawer
  const quickPickFoods = useMemo(() => {
    if (!expandedPrefTab) return [];
    const existingNames = new Set(
      (prefs[expandedPrefTab] || []).map((i) => i.name.trim().toLowerCase())
    );
    const candidates = FOOD_SAFETY_DB.foods.filter((f) => {
      const shortName = f.name.split(/[（(]/)[0].split('/')[0].trim().toLowerCase();
      if (existingNames.has(shortName) || existingNames.has(f.name.toLowerCase())) {
        return false;
      }
      if (expandedPrefTab === 'likes') return f.safetyLevel === 'safe';
      if (expandedPrefTab === 'dislikes') return f.safetyLevel !== 'forbidden';
      return true;
    });
    return candidates.slice(0, 8);
  }, [expandedPrefTab, prefs]);

  const handleToggleEntryCard = (tab: InteractivePreferenceTab) => {
    setExpandedPrefTab((prev) => (prev === tab ? null : tab));
  };

  const handleOpenAddModal = (category: InteractivePreferenceTab) => {
    setModalError(null);
    setFoodModalState({ mode: 'add', category, item: null });
  };

  const handleOpenEditModal = (
    category: InteractivePreferenceTab,
    item: PetFoodPreferenceItem
  ) => {
    setModalError(null);
    setFoodModalState({ mode: 'edit', category, item });
  };

  const handleModalSubmit = (payload: { name: string; icon: string; note?: string }) => {
    if (!activePet || !foodModalState) return;
    const cleanName = payload.name.trim();
    if (!cleanName) {
      setModalError(copy.errEmptyName);
      return;
    }

    const { mode, category, item } = foodModalState;
    const currentList = prefs[category] || [];
    const duplicate = currentList.some(
      (existing) =>
        (mode === 'add' || existing.id !== item?.id) &&
        existing.name.trim().toLowerCase() === cleanName.toLowerCase()
    );
    if (duplicate) {
      setModalError(copy.errDuplicateName(cleanName));
      return;
    }

    try {
      if (mode === 'add') {
        const updated = localStore.addPetFoodPreference(
          activePet.id,
          category,
          cleanName,
          payload.note,
          undefined,
          payload.icon
        );
        setPrefs(updated);
        setExpandedPrefTab(category);
        setFoodModalState(null);
        setModalError(null);
        showToast?.(
          copy.toastAdded(activePet.name, copy.categories[category].title),
          'success'
        );
      } else if (item) {
        const keepDbLink = !isCustomPreferenceFood(item) && item.foodId ? item.foodId : '';
        const updated = localStore.updatePetFoodPreference(
          activePet.id,
          category,
          item.id,
          {
            name: cleanName,
            icon: payload.icon,
            note: payload.note ?? '',
            foodId: keepDbLink,
          }
        );
        setPrefs(updated);
        if (selectedCustomItem?.item.id === item.id) {
          const refreshed = updated[category].find((x) => x.id === item.id);
          if (refreshed) {
            setSelectedCustomItem({ item: refreshed, category });
          } else {
            setSelectedCustomItem(null);
          }
        }
        setFoodModalState(null);
        setModalError(null);
        showToast?.(copy.toastUpdated(cleanName, activePet.name), 'success');
      }
    } catch (err: any) {
      setModalError(err?.message || copy.errEmptyName);
    }
  };

  const handleQuickAddDbFood = (
    category: InteractivePreferenceTab,
    food: FoodSafetyEntry
  ) => {
    if (!activePet) return;
    const shortName = food.name.split(/[（(]/)[0].split('/')[0].trim();
    try {
      const updated = localStore.addPetFoodPreference(
        activePet.id,
        category,
        shortName,
        undefined,
        food.id
      );
      setPrefs(updated);
      showToast?.(
        copy.toastQuickAdded(shortName, activePet.name, copy.categories[category].title),
        'success'
      );
    } catch {
      showToast?.(copy.errDuplicateName(shortName), 'error');
    }
  };

  const handleDeletePref = (category: FoodPreferenceCategory, itemId: string) => {
    if (!activePet) return;
    const updated = localStore.deletePetFoodPreference(activePet.id, category, itemId);
    setPrefs(updated);
    if (selectedCustomItem?.item.id === itemId) {
      setSelectedCustomItem(null);
    }
    showToast?.(copy.toastDeleted, 'success');
  };

  const handleOpenPreferenceFoodTile = (
    item: PetFoodPreferenceItem,
    category: InteractivePreferenceTab
  ) => {
    if (isCustomPreferenceFood(item)) {
      setSelectedCustomItem({ item, category });
      return;
    }
    const matched = findMatchingFoodEntry(item.name, item.foodId);
    if (matched) {
      setSelectedFood(matched);
    } else {
      setSelectedCustomItem({ item, category });
    }
  };

  const quickKeywords = [
    '巧克力',
    '葡萄',
    '木糖醇',
    '鸡胸肉',
    '南瓜',
    '牛奶',
    '百合花',
    '三文鱼',
  ];

  const selectedFoodAlert = useMemo(
    () => (selectedFood ? checkFoodAgainstPetPreferences(selectedFood, prefs) : null),
    [selectedFood, prefs]
  );

  const selectedFoodSuitability = useMemo(
    () => (selectedFood ? getSpeciesSuitability(selectedFood) : null),
    [selectedFood]
  );

  const activeItems = expandedPrefTab ? prefs[expandedPrefTab] || [] : [];
  const activeTabStyle = expandedPrefTab ? INTERACTIVE_TAB_STYLES[expandedPrefTab] : null;
  const activeTabCopy = expandedPrefTab ? copy.categories[expandedPrefTab] : null;

  return (
    <div className="space-y-6">
      {/* Three Side-by-Side Animated Pet Preference Entry Cards + Smooth Expandable List */}
      <section className="wellness-card rounded-3xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-base font-bold text-[#1f2e28]">
              {activePet ? `${activePet.name}${copy.libraryTitle}` : copy.libraryTitleFallback}
            </h2>
            {activePet && (
              <span className="text-xs text-[#72847c]">
                {copy.librarySubtitle(
                  activePet.species === 'cat' ? copy.catSpecies : copy.dogSpecies
                )}
              </span>
            )}
          </div>

          {pets.length > 1 && (
            <div className="flex items-center gap-1 bg-[#fffbf2] border border-[#e9e4d8] rounded-xl p-1 shrink-0">
              {pets.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSwitchPet(p.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    activePet?.id === p.id
                      ? 'bg-[#2f9e7e] text-white'
                      : 'text-[#4c5e56] hover:bg-white'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 3 Side-by-Side Animated Entry Cards with "+ 添加食物" buttons */}
        <FoodPreferenceEntryCards
          prefs={prefs}
          activeTab={expandedPrefTab}
          onSelectTab={handleToggleEntryCard}
          onAddFood={handleOpenAddModal}
          copy={copy}
        />

        {/* Smooth Expandable Food List Panel */}
        <AnimatePresence initial={false}>
          {expandedPrefTab && activeTabStyle && activeTabCopy && activePet && (
            <motion.div
              key={expandedPrefTab}
              initial={
                prefersReducedMotion
                  ? false
                  : { opacity: 0, height: 0, y: -6 }
              }
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={
                prefersReducedMotion
                  ? undefined
                  : { opacity: 0, height: 0, y: -6 }
              }
              transition={{ duration: 0.26, ease: [0.16, 1, 0.3, 1] }}
              className="overflow-hidden"
            >
              <div
                className={`rounded-3xl border p-4 sm:p-5 space-y-4 ${activeTabStyle.panelBorder} ${activeTabStyle.panelBg}`}
              >
                {/* Drawer Header & "+ Add Food" Modal Trigger */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-bold ${activeTabStyle.accentText}`}>
                      {activePet.name} · {activeTabCopy.title}
                    </span>
                    <span className="text-xs text-[#72847c] tabular-nums">
                      ({activeItems.length})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenAddModal(expandedPrefTab)}
                      className={`btn-press px-4 py-2 rounded-xl text-white text-xs font-semibold inline-flex items-center gap-1 whitespace-nowrap shrink-0 ${activeTabStyle.btnBg}`}
                    >
                      <span>{copy.addFoodBtn}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setExpandedPrefTab(null)}
                      className="p-2 rounded-xl bg-white border border-[#e9e4d8] text-[#72847c] hover:text-[#1f2e28] shrink-0"
                      aria-label={copy.collapseAria}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Visual Quick-Pick Food Thumbnails (1-click add from local SVG assets) */}
                {quickPickFoods.length > 0 && (
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    <span className="text-[11px] font-medium text-[#72847c] whitespace-nowrap shrink-0">
                      {copy.quickAddLabel}
                    </span>
                    {quickPickFoods.map((food) => {
                      const shortName = food.name.split(/[（(]/)[0].split('/')[0].trim();
                      return (
                        <button
                          key={food.id}
                          type="button"
                          onClick={() => handleQuickAddDbFood(expandedPrefTab, food)}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white hover:bg-[#fffbf2] border border-[#e9e4d8] text-xs font-medium text-[#1f2e28] whitespace-nowrap shrink-0 transition-transform hover:-translate-y-0.5"
                        >
                          <img
                            src={getLocalFoodImageUrl(food.id)}
                            alt={shortName}
                            className="w-5 h-5 object-contain shrink-0"
                          />
                          <span>+ {shortName}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Preference Food Cards Grid */}
                {activeItems.length === 0 ? (
                  <div className="rounded-2xl bg-white/80 border border-dashed border-[#e9e4d8] py-8 px-4 text-center text-xs text-[#72847c]">
                    {copy.emptyPrefList}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                    <AnimatePresence initial={false}>
                      {activeItems.map((item) => {
                        const isCustomItem = isCustomPreferenceFood(item);
                        const matched = !isCustomItem
                          ? findMatchingFoodEntry(item.name, item.foodId)
                          : null;
                        const levelStyle = matched
                          ? LEVEL_STYLES[matched.safetyLevel]
                          : null;
                        const levelLabel = matched
                          ? copy.levels[matched.safetyLevel]
                          : null;
                        // Respect explicit user-chosen/matched Emoji first, then local SVG if DB-linked, else Emoji fallback
                        const displayEmoji =
                          item.icon || (!matched ? matchFoodEmoji(item.name) : null);

                        return (
                          <motion.div
                            key={item.id}
                            layout={!prefersReducedMotion}
                            initial={
                              prefersReducedMotion ? false : { opacity: 0, scale: 0.92 }
                            }
                            animate={{ opacity: 1, scale: 1 }}
                            exit={
                              prefersReducedMotion
                                ? undefined
                                : { opacity: 0, scale: 0.88 }
                            }
                            transition={{ duration: 0.2 }}
                            whileHover={
                              prefersReducedMotion ? undefined : { y: -4, scale: 1.02 }
                            }
                            onClick={() =>
                              handleOpenPreferenceFoodTile(item, expandedPrefTab)
                            }
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                handleOpenPreferenceFoodTile(item, expandedPrefTab);
                              }
                            }}
                            className={`group relative rounded-2xl bg-white border p-3 cursor-pointer flex flex-col items-center text-center gap-2 shadow-2xs transition-shadow hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2f9e7e] ${activeTabStyle.tileBorder}`}
                          >
                            {/* Edit & Delete Action Buttons */}
                            <div className="absolute top-1.5 right-1.5 flex items-center gap-1 z-10">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenEditModal(expandedPrefTab, item);
                                }}
                                aria-label={`${copy.editTooltip} ${item.name}`}
                                title={copy.editTooltip}
                                className="w-7 h-7 rounded-full bg-[#fffbf2]/95 hover:bg-[#e6f7f1] border border-[#e9e4d8] text-[#4c5e56] hover:text-[#1f5c4b] flex items-center justify-center transition-colors"
                              >
                                <Pencil className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeletePref(expandedPrefTab, item.id);
                                }}
                                aria-label={`${copy.deleteTooltip} ${item.name}`}
                                title={copy.deleteTooltip}
                                className="w-7 h-7 rounded-full bg-[#fffbf2]/95 hover:bg-rose-50 border border-[#e9e4d8] text-[#72847c] hover:text-rose-600 flex items-center justify-center transition-colors"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>

                            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-[#fffbf2] border border-[#e9e4d8]/80 p-2 flex items-center justify-center overflow-hidden mt-2">
                              {displayEmoji ? (
                                <span
                                  className="text-3xl sm:text-4xl leading-none select-none transition-transform duration-300 group-hover:scale-110"
                                  aria-hidden="true"
                                >
                                  {displayEmoji}
                                </span>
                              ) : matched ? (
                                <img
                                  src={getLocalFoodImageUrl(matched.id)}
                                  alt={item.name}
                                  loading="lazy"
                                  onError={(e) => {
                                    e.currentTarget.src = foodScanPlaceholderImg;
                                  }}
                                  className="w-full h-full object-contain rounded-xl transition-transform duration-300 group-hover:scale-105"
                                />
                              ) : null}
                            </div>

                            <div className="w-full min-w-0">
                              <div className="text-xs sm:text-sm font-bold text-[#1f2e28] truncate">
                                {item.name}
                              </div>
                              <div
                                className={`text-[11px] font-medium truncate mt-0.5 ${
                                  levelStyle ? levelStyle.textColor : 'text-[#72847c]'
                                }`}
                              >
                                {levelLabel || copy.customItemLabel}
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Search & Classification Filter (Preserved) */}
      <section className="wellness-card rounded-3xl p-5 space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[#72847c] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={copy.searchPlaceholder}
              className="w-full rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/70 focus:bg-white pl-10 pr-9 py-2.5 text-sm focus:outline-none focus:border-[#2f9e7e]"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#72847c] hover:text-[#1f2e28]"
                aria-label={copy.clearSearchAria}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
            {(
              [
                { id: 'all', label: `${copy.filterAll} (${counts.all})` },
                { id: 'safe', label: `${copy.levels.safe} (${counts.safe})` },
                { id: 'caution', label: `${copy.levels.caution} (${counts.caution})` },
                { id: 'forbidden', label: `${copy.levels.forbidden} (${counts.forbidden})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setLevelFilter(tab.id)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  levelFilter === tab.id
                    ? tab.id === 'forbidden'
                      ? 'bg-[#fff0f4] text-[#9c2341] border border-[#f48ca3]/60'
                      : tab.id === 'caution'
                      ? 'bg-[#fff3e6] text-[#9a4d12] border border-[#ffb074]/60'
                      : 'bg-[#e6f7f1] text-[#1f5c4b] border border-[#2f9e7e]/45'
                    : 'bg-[#fffbf2] text-[#4c5e56] border border-[#e9e4d8] hover:bg-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Search Hints */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="text-[#72847c]">{copy.commonQueriesLabel}</span>
          {quickKeywords.map((kw) => (
            <button
              key={kw}
              type="button"
              onClick={() => setQuery(kw)}
              className="px-2.5 py-1 rounded-lg bg-[#fffbf2] hover:bg-[#e6f7f1] border border-[#e9e4d8] text-[#4c5e56] hover:text-[#1f5c4b] transition-colors whitespace-nowrap shrink-0"
            >
              {kw}
            </button>
          ))}
        </div>
      </section>

      {/* 27-Food Safety Database + Custom Pet Foods Grid OR Empty Match Notice */}
      {filteredFoods.length === 0 && filteredCustomFoods.length === 0 ? (
        <section className="rounded-3xl border border-[#ffb074]/60 bg-[#fff3e6]/70 p-8 text-center space-y-3">
          <ShieldAlert className="w-9 h-9 text-[#ea7d2b] mx-auto" />
          <h2 className="text-base font-bold text-[#7c3b0b]">{copy.emptySearchTitle}</h2>
          <p className="text-xs sm:text-sm text-[#7c3b0b] max-w-lg mx-auto leading-relaxed">
            {copy.emptySearchDesc(query.trim() || copy.filterAll)}
          </p>
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                setLevelFilter('all');
              }}
              className="px-4 py-2 rounded-xl bg-white border border-[#ffb074] text-xs font-semibold text-[#9a4d12] whitespace-nowrap shrink-0"
            >
              {copy.showAllFoodsBtn}
            </button>
          )}
        </section>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {/* Synced Custom Pet Foods (Visible ONLY under "All" filter, never auto-classified into safety levels) */}
          {filteredCustomFoods.map((customEntry, idx) => (
            <motion.article
              key={`custom-${activePet?.id || 'pet'}-${customEntry.key}`}
              layout={!prefersReducedMotion}
              initial={prefersReducedMotion ? false : { opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.24,
                delay: Math.min(idx * 0.02, 0.2),
                ease: [0.16, 1, 0.3, 1],
              }}
              whileHover={
                prefersReducedMotion
                  ? undefined
                  : { y: -5, scale: 1.016, transition: { duration: 0.22 } }
              }
              whileTap={prefersReducedMotion ? undefined : { scale: 0.99 }}
              onClick={() =>
                setSelectedCustomItem({
                  item: customEntry.primaryItem,
                  category: customEntry.primaryCategory,
                })
              }
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setSelectedCustomItem({
                    item: customEntry.primaryItem,
                    category: customEntry.primaryCategory,
                  });
                }
              }}
              className="group food-card-interactive wellness-card rounded-3xl overflow-hidden border border-[#e9e4d8] hover:border-[#2f9e7e]/45 cursor-pointer flex flex-col justify-between focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2f9e7e]"
            >
              <div>
                <div className="px-4 py-3 bg-[#fffbf2]/90 border-b border-[#e9e4d8]/70 flex items-center justify-between gap-2.5">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-12 h-12 rounded-2xl bg-white/95 border border-[#e9e4d8] flex items-center justify-center text-2xl shrink-0 shadow-2xs select-none transition-transform duration-300 group-hover:scale-105 group-hover:-translate-y-0.5"
                      aria-hidden="true"
                    >
                      {customEntry.icon}
                    </div>
                    <div className="min-w-0">
                      <h2 className="text-sm sm:text-[15px] font-bold text-[#1f2e28] truncate">
                        {customEntry.name}
                      </h2>
                      <div className="text-[11px] text-[#72847c] truncate">
                        {activePet ? copy.customCardSubtitle(activePet.name) : copy.customItemLabel}
                      </div>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#f4f1e8] border border-[#d8d1c1] text-[#4c5e56] shrink-0 whitespace-nowrap">
                    <Tag className="w-3 h-3" />
                    <span>{copy.customBadgeLabel}</span>
                  </span>
                </div>

                <div className="p-4 space-y-2.5 text-xs leading-relaxed">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {customEntry.categories.map((cat) => {
                      const badge = PREF_BADGE_STYLES[cat];
                      const BadgeIcon = badge.icon;
                      return (
                        <span
                          key={cat}
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-semibold whitespace-nowrap ${badge.badgeClass}`}
                        >
                          <BadgeIcon className="w-3 h-3 shrink-0" />
                          <span>{copy.categoryShortLabels[cat]}</span>
                        </span>
                      );
                    })}
                  </div>

                  <p className="text-[#4c5e56] line-clamp-2">
                    {customEntry.notes.length > 0
                      ? customEntry.notes.join('；')
                      : copy.customCardFallbackNote}
                  </p>
                </div>
              </div>

              <div className="px-4 py-2.5 border-t border-[#e9e4d8]/80 text-[11px] text-[#72847c] flex items-center justify-between gap-2 bg-[#fffbf2]/45">
                <span className="inline-flex items-center gap-1 truncate">
                  <Info className="w-3 h-3 shrink-0" />
                  <span>{copy.clickToEditOrView}</span>
                </span>
                <span className="inline-flex items-center gap-0.5 font-semibold text-[#2f9e7e] shrink-0 group-hover:translate-x-0.5 transition-transform">
                  <span>{copy.expandLabel}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </motion.article>
          ))}

          {filteredFoods.map((item, idx) => {
            const style = LEVEL_STYLES[item.safetyLevel];
            const Icon = style.icon;
            const alert = checkFoodAgainstPetPreferences(item, prefs);

            return (
              <motion.article
                key={item.id}
                layout={!prefersReducedMotion}
                initial={prefersReducedMotion ? false : { opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.24,
                  delay: Math.min(idx * 0.02, 0.24),
                  ease: [0.16, 1, 0.3, 1],
                }}
                whileHover={
                  prefersReducedMotion
                    ? undefined
                    : { y: -5, scale: 1.016, transition: { duration: 0.22 } }
                }
                whileTap={prefersReducedMotion ? undefined : { scale: 0.99 }}
                onClick={() => setSelectedFood(item)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setSelectedFood(item);
                  }
                }}
                className={`group food-card-interactive wellness-card rounded-3xl overflow-hidden border cursor-pointer flex flex-col justify-between focus:outline-none focus-visible:ring-2 focus-visible:ring-[#2f9e7e] ${
                  alert.hasDangerAlert
                    ? 'border-rose-400 ring-1 ring-rose-200'
                    : style.cardBorder
                }`}
              >
                <div>
                  <div
                    className={`px-4 py-3 ${style.headerBg} flex items-center justify-between gap-2.5`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-12 rounded-2xl bg-white/95 border border-[#e9e4d8] p-1 shrink-0 overflow-hidden shadow-2xs transition-transform duration-300 group-hover:scale-105 group-hover:-translate-y-0.5">
                        <img
                          src={getLocalFoodImageUrl(item.id)}
                          alt={item.name}
                          loading="lazy"
                          onError={(e) => {
                            e.currentTarget.src = foodScanPlaceholderImg;
                          }}
                          className="w-full h-full object-contain rounded-xl"
                        />
                      </div>
                      <div className="min-w-0">
                        <h2 className="text-sm sm:text-[15px] font-bold text-[#1f2e28] truncate">
                          {item.name}
                        </h2>
                        <div className="text-[11px] text-[#4c5e56] truncate">
                          {item.speciesNote}
                        </div>
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-bold shrink-0 whitespace-nowrap ${style.textColor}`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{copy.levels[item.safetyLevel]}</span>
                    </span>
                  </div>

                  <div className="p-4 space-y-2.5 text-xs leading-relaxed">
                    {(alert.hasDangerAlert ||
                      alert.hasPreferenceAlert ||
                      alert.hasLikeMatch) &&
                      activePet && (
                        <div className="flex flex-wrap gap-2 text-[11px] font-semibold">
                          {(alert.matchedAllergies.length > 0 ||
                            alert.matchedForbidden.length > 0) && (
                            <span className="inline-flex items-center gap-1 text-rose-700">
                              <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                              <span>{copy.petAllergyAlert(activePet.name)}</span>
                            </span>
                          )}
                          {alert.matchedDislikes.length > 0 && (
                            <span className="inline-flex items-center gap-1 text-[#9a4d12]">
                              <HeartOff className="w-3.5 h-3.5 shrink-0" />
                              <span>{copy.petDislikeAlert(activePet.name)}</span>
                            </span>
                          )}
                          {alert.matchedLikes.length > 0 && (
                            <span className="inline-flex items-center gap-1 text-[#2f9e7e]">
                              <Heart className="w-3.5 h-3.5 shrink-0 fill-[#f48ca3] text-[#f48ca3]" />
                              <span>{copy.petLikeAlert(activePet.name)}</span>
                            </span>
                          )}
                        </div>
                      )}

                    <div>
                      <div className="font-semibold text-[#1f2e28] mb-0.5">
                        {copy.keyComponentsLabel}
                      </div>
                      <div className="text-[#4c5e56] line-clamp-2">
                        {item.toxicComponents.join('；')}
                      </div>
                    </div>

                    <div>
                      <div className="font-semibold text-[#1f2e28] mb-0.5">
                        {copy.healthRisksLabel}
                      </div>
                      <p className="text-[#4c5e56] line-clamp-2">{item.potentialRisks}</p>
                    </div>
                  </div>
                </div>

                <div className="px-4 py-2.5 border-t border-[#e9e4d8]/80 text-[11px] text-[#72847c] flex items-center justify-between gap-2 bg-[#fffbf2]/45">
                  <span className="inline-flex items-center gap-1 truncate">
                    <Info className="w-3 h-3 shrink-0" />
                    <span>{copy.clickForDetails}</span>
                  </span>
                  <span className="inline-flex items-center gap-0.5 font-semibold text-[#2f9e7e] shrink-0 group-hover:translate-x-0.5 transition-transform">
                    <span>{copy.expandLabel}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </motion.article>
            );
          })}
        </div>
      )}

      {/* Add / Edit Pet Food Preference Modal */}
      {activePet && foodModalState && (
        <FoodPreferenceModal
          isOpen={Boolean(foodModalState)}
          mode={foodModalState.mode}
          category={foodModalState.category}
          petName={activePet.name}
          initialItem={foodModalState.item}
          onClose={() => {
            setFoodModalState(null);
            setModalError(null);
          }}
          onSubmit={handleModalSubmit}
          errorMessage={modalError}
          onClearError={() => setModalError(null)}
          copy={copy}
        />
      )}

      {/* Smooth Animated Food Detail Modal (DB Foods - Global Safety Level Never Modified) */}
      <AnimatePresence>
        {selectedFood && selectedFoodSuitability && selectedFoodAlert && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5">
            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={prefersReducedMotion ? undefined : { opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setSelectedFood(null)}
              className="absolute inset-0 bg-[#1f2e28]/45 backdrop-blur-xs"
            />

            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="food-detail-title"
              initial={
                prefersReducedMotion ? false : { opacity: 0, scale: 0.94, y: 18 }
              }
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={
                prefersReducedMotion ? undefined : { opacity: 0, scale: 0.95, y: 14 }
              }
              transition={{ type: 'spring', stiffness: 360, damping: 28 }}
              className="relative z-10 w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl overflow-hidden flex flex-col"
            >
              {(() => {
                const style = LEVEL_STYLES[selectedFood.safetyLevel];
                const LevelIcon = style.icon;
                return (
                  <div
                    className={`px-5 py-4 border-b border-[#e9e4d8] ${style.headerBg} flex items-center justify-between gap-3`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-14 h-14 rounded-2xl bg-white border border-[#e9e4d8] p-1.5 shrink-0 shadow-xs">
                        <img
                          src={getLocalFoodImageUrl(selectedFood.id)}
                          alt={selectedFood.name}
                          onError={(e) => {
                            e.currentTarget.src = foodScanPlaceholderImg;
                          }}
                          className="w-full h-full object-contain rounded-xl"
                        />
                      </div>
                      <div className="min-w-0">
                        <h2
                          id="food-detail-title"
                          className="text-base sm:text-lg font-bold text-[#1f2e28] truncate"
                        >
                          {selectedFood.name}
                        </h2>
                        <div className="flex items-center gap-2 flex-wrap mt-1 text-xs">
                          <span
                            className={`inline-flex items-center gap-1 font-bold ${style.textColor}`}
                          >
                            <LevelIcon className="w-3.5 h-3.5" />
                            <span>
                              {copy.safetyLevelPrefix}
                              {copy.levels[selectedFood.safetyLevel]}
                            </span>
                          </span>
                          {selectedFood.aliases.length > 0 && (
                            <>
                              <span className="text-[#72847c]" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-[11px] text-[#4c5e56] truncate">
                                {selectedFood.aliases.slice(0, 4).join(' / ')}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setSelectedFood(null)}
                      className="p-2 rounded-xl bg-white/80 hover:bg-white border border-[#e9e4d8] text-[#4c5e56] hover:text-[#1f2e28] shrink-0"
                      aria-label={copy.closeDetailAria}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                );
              })()}

              <div className="p-5 space-y-4 overflow-y-auto">
                {/* Personalized Alerts */}
                {activePet && selectedFoodAlert.hasDangerAlert && (
                  <div className="rounded-2xl border-2 border-rose-400 bg-rose-50 p-3.5 space-y-1">
                    <div className="flex items-center gap-2 text-rose-800 font-bold text-sm">
                      <ShieldAlert className="w-4 h-4 shrink-0 text-rose-600" />
                      <span>
                        {copy.petAllergyAlert(activePet.name)} ·{' '}
                        {selectedFoodAlert.matchedAllergies
                          .concat(selectedFoodAlert.matchedForbidden)
                          .map((i) => i.name)
                          .join('、')}
                      </span>
                    </div>
                  </div>
                )}

                {activePet && selectedFoodAlert.hasPreferenceAlert && (
                  <div className="rounded-2xl border border-[#ffb074] bg-[#fff3e6] p-3.5">
                    <div className="flex items-center gap-2 text-[#9a4d12] font-bold text-xs sm:text-sm">
                      <HeartOff className="w-4 h-4 shrink-0 text-[#ea7d2b]" />
                      <span>
                        {copy.petDislikeAlert(activePet.name)} ·{' '}
                        {selectedFoodAlert.matchedDislikes.map((i) => i.name).join('、')}
                      </span>
                    </div>
                  </div>
                )}

                {activePet && selectedFoodAlert.hasLikeMatch && (
                  <div className="rounded-2xl border border-[#2f9e7e]/35 bg-[#e6f7f1]/70 p-3.5">
                    <div className="flex items-center gap-2 text-[#1f5c4b] font-bold text-xs sm:text-sm">
                      <Heart className="w-4 h-4 shrink-0 fill-[#f48ca3] text-[#f48ca3]" />
                      <span>
                        {copy.petLikeAlert(activePet.name)} ·{' '}
                        {selectedFoodAlert.matchedLikes.map((i) => i.name).join('、')}
                      </span>
                    </div>
                  </div>
                )}

                {/* Dog & Cat Suitability */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/75 p-3.5 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1f2e28]">
                        <Dog className="w-4 h-4 text-[#2f9e7e]" />
                        <span>{copy.dogSuitabilityTitle}</span>
                      </span>
                      <SuitabilityBadge suitability={selectedFoodSuitability.dog} />
                    </div>
                    <p className="text-xs text-[#4c5e56] leading-relaxed">
                      {selectedFoodSuitability.dog.detail}
                    </p>
                  </div>

                  <div className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2]/75 p-3.5 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#1f2e28]">
                        <Cat className="w-4 h-4 text-[#ea7d2b]" />
                        <span>{copy.catSuitabilityTitle}</span>
                      </span>
                      <SuitabilityBadge suitability={selectedFoodSuitability.cat} />
                    </div>
                    <p className="text-xs text-[#4c5e56] leading-relaxed">
                      {selectedFoodSuitability.cat.detail}
                    </p>
                  </div>
                </div>

                {/* Key Components */}
                <div className="rounded-2xl border border-[#e9e4d8] bg-white p-4 space-y-1.5">
                  <div className="text-xs font-bold text-[#1f2e28]">
                    {copy.keyComponentsLabel}
                  </div>
                  <div className="text-xs text-[#4c5e56]">
                    {selectedFood.toxicComponents.join(' · ')}
                  </div>
                </div>

                {/* Health Risks */}
                <div className="rounded-2xl border border-[#e9e4d8] bg-white p-4 space-y-1.5">
                  <div className="text-xs font-bold text-[#1f2e28]">
                    {copy.healthRisksLabel}
                  </div>
                  <p className="text-xs sm:text-sm text-[#4c5e56] leading-relaxed">
                    {selectedFood.potentialRisks}
                  </p>
                </div>

                {/* Feeding Precautions */}
                <div className="rounded-2xl border border-[#2f9e7e]/35 bg-[#e6f7f1]/55 p-4 space-y-1.5">
                  <div className="text-xs font-bold text-[#1f5c4b]">
                    {copy.feedingPrecautionsTitle}
                  </div>
                  <p className="text-xs sm:text-sm text-[#1f2e28] leading-relaxed">
                    {selectedFood.precautions}
                  </p>
                </div>

                {/* Quick Add to 3 Pet Preference Categories */}
                {activePet && (
                  <div className="rounded-2xl border border-[#e9e4d8] bg-[#fffbf2] p-3.5 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-[#4c5e56]">
                      {copy.addToPetGalleryLabel(activePet.name)}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => handleQuickAddDbFood('likes', selectedFood)}
                        className="btn-press px-3 py-1.5 rounded-xl bg-white hover:bg-[#e6f7f1] border border-[#2f9e7e]/45 text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <Heart className="w-3.5 h-3.5 text-[#f48ca3]" />
                        <span>{copy.quickLikeBtn}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickAddDbFood('dislikes', selectedFood)}
                        className="btn-press px-3 py-1.5 rounded-xl bg-white hover:bg-[#fff3e6] border border-[#ffb074]/70 text-xs font-semibold text-[#9a4d12] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <HeartOff className="w-3.5 h-3.5" />
                        <span>{copy.quickDislikeBtn}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickAddDbFood('allergies', selectedFood)}
                        className="btn-press px-3 py-1.5 rounded-xl bg-white hover:bg-[#fff0f4] border border-[#f48ca3]/60 text-xs font-semibold text-[#9c2341] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>{copy.quickAllergyBtn}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-5 py-3 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-3">
                <span className="text-[11px] text-[#72847c] truncate">
                  {FOOD_SAFETY_DB.source} · {FOOD_SAFETY_DB.updatedAt}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedFood(null)}
                  className="btn-press px-4 py-2 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold whitespace-nowrap shrink-0"
                >
                  {copy.backToListBtn}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Lightweight Detail Modal for Custom User-Added Foods Not in the 27-Food DB */}
      <AnimatePresence>
        {selectedCustomItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={prefersReducedMotion ? undefined : { opacity: 0 }}
              transition={{ duration: 0.18 }}
              onClick={() => setSelectedCustomItem(null)}
              className="absolute inset-0 bg-[#1f2e28]/45 backdrop-blur-xs"
            />

            <motion.div
              role="dialog"
              aria-modal="true"
              initial={
                prefersReducedMotion ? false : { opacity: 0, scale: 0.94, y: 14 }
              }
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={
                prefersReducedMotion ? undefined : { opacity: 0, scale: 0.95, y: 10 }
              }
              transition={{ duration: 0.2 }}
              className="relative z-10 w-full max-w-md bg-white rounded-3xl border border-[#e9e4d8] shadow-2xl overflow-hidden"
            >
              <div className="px-5 py-4 border-b border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-white border border-[#e9e4d8] flex items-center justify-center text-2xl shrink-0 select-none">
                    {selectedCustomItem.item.icon ||
                      matchFoodEmoji(selectedCustomItem.item.name)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-base font-bold text-[#1f2e28] truncate">
                        {selectedCustomItem.item.name}
                      </h2>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#f4f1e8] border border-[#d8d1c1] text-[#4c5e56]">
                        {copy.customBadgeLabel}
                      </span>
                    </div>
                    <div className="text-xs text-[#72847c] mt-0.5">
                      {activePet?.name} ·{' '}
                      {copy.categories[selectedCustomItem.category].title}
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedCustomItem(null)}
                  className="p-2 rounded-xl bg-white border border-[#e9e4d8] text-[#4c5e56]"
                  aria-label={copy.closeBtn}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-5 space-y-3 text-xs text-[#4c5e56]">
                {(() => {
                  const agg = customFoodsInAll.find(
                    (c) => c.key === selectedCustomItem.item.name.trim().toLowerCase()
                  );
                  if (!agg || agg.categories.length === 0) return null;
                  return (
                    <div className="flex flex-wrap items-center gap-1.5">
                      {agg.categories.map((cat) => {
                        const badge = PREF_BADGE_STYLES[cat];
                        const BadgeIcon = badge.icon;
                        const isActiveCat = cat === selectedCustomItem.category;
                        const catItem = agg.itemsByCategory[cat];
                        return (
                          <button
                            key={cat}
                            type="button"
                            onClick={() => {
                              if (catItem) {
                                setSelectedCustomItem({ item: catItem, category: cat });
                              }
                            }}
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-semibold transition-all ${
                              badge.badgeClass
                            } ${isActiveCat ? 'ring-2 ring-offset-1 ring-[#2f9e7e]/45' : 'opacity-80 hover:opacity-100'}`}
                          >
                            <BadgeIcon className="w-3 h-3 shrink-0" />
                            <span>{copy.categoryShortLabels[cat]}</span>
                          </button>
                        );
                      })}
                    </div>
                  );
                })()}
                <div>{copy.customFoodDesc(activePet?.name || '')}</div>
                {selectedCustomItem.item.note && (
                  <div className="rounded-xl bg-[#fffbf2] border border-[#e9e4d8] px-3 py-2 text-[#1f2e28]">
                    {selectedCustomItem.item.note}
                  </div>
                )}
                <div className="text-[11px] text-[#72847c]">
                  {copy.customFoodDisclaimer}
                </div>
              </div>

              <div className="px-5 py-3 border-t border-[#e9e4d8] bg-[#fffbf2] flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const { category, item } = selectedCustomItem;
                      handleOpenEditModal(category, item);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white hover:bg-[#e6f7f1] border border-[#2f9e7e]/45 text-xs font-semibold text-[#1f5c4b] inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    <span>{copy.editTooltip}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleDeletePref(
                        selectedCustomItem.category,
                        selectedCustomItem.item.id
                      );
                    }}
                    className="px-3.5 py-2 rounded-xl bg-white hover:bg-rose-50 border border-[#e9e4d8] text-xs font-semibold text-rose-600 inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{copy.removeBtn}</span>
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedCustomItem(null)}
                  className="px-4 py-2 rounded-xl bg-[#2f9e7e] hover:bg-[#258267] text-white text-xs font-semibold whitespace-nowrap shrink-0"
                >
                  {copy.closeBtn}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
