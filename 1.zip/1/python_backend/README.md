# PetCare AI — 独立 Python FastAPI 后端

本目录为课程汇报与独立部署预留的 **Python FastAPI** 后端项目，提供与前端 Axios 服务层（`src/services/*.ts`）完全兼容的 `/api/*` REST 与 SSE 接口。

> **运行环境说明**：当前 Google AI Studio 在线预览容器通过 `"dev": "tsx server.ts"` 运行 Node.js + Express + Vite（监听 `3000` 端口）。若在本地电脑、服务器或课程答辩现场运行独立 Python 后端，只需启动本服务并配置前端环境变量 `VITE_PYTHON_API_URL=http://localhost:8000`，前端 Axios 客户端即会自动切换对接 FastAPI。

## 目录结构

- `main.py`：FastAPI 应用入口、CORS 中间件、SQLite 建表初始化与路由挂载
- `database.py`：SQLAlchemy 2.0 SQLite 引擎（`PRAGMA foreign_keys=ON`）与会话依赖
- `security.py`：Argon2id 密码哈希（`pwdlib`）、PyJWT 令牌签发与 `get_current_user` 鉴权依赖
- `models/db_models.py`：SQLAlchemy ORM 表模型（`users`、`password_reset_tokens`、`revoked_tokens`、`pets`、`health_records`、`reminders`、`chat_messages`）
- `models/schemas.py`：Pydantic v2 请求与响应数据模型（含邮箱格式与密码强度校验）
- `services/deepseek_service.py`：服务端调用 DeepSeek Chat Completions API（不暴露密钥）
- `services/distance_service.py`：Haversine 地球球面距离计算 + Kakao Local 地理编码
- `services/email_service.py`：SMTP 邮件重置发信模块（未配置 SMTP 时如实提示，不伪造发信成功）
- `routers/`：`auth.py`、`pets.py`、`records.py`、`reminders.py`、`vet.py`、`hospitals.py`

## 本地启动方式

```bash
cd python_backend
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# 在 .env 中填入 JWT_SECRET_KEY、DEEPSEEK_API_KEY 与（可选）SMTP_* / KAKAO_MAP_API_KEY

uvicorn main:app --reload --port 8000
```

启动后可访问：
- Swagger 交互式接口文档：`http://localhost:8000/docs`
- 健康检查：`GET http://localhost:8000/api/health`
