import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import Pet, Reminder, User, utc_now_iso
from models.schemas import ReminderCreate, ReminderPatch
from security import get_current_user

router = APIRouter(prefix="/reminders", tags=["Reminders"])


def serialize_reminder(rem: Reminder) -> dict:
    return {
        "id": rem.id,
        "userId": rem.user_id,
        "petId": rem.pet_id,
        "title": rem.title,
        "category": rem.category,
        "dueDate": rem.due_date,
        "dueTime": rem.due_time,
        "repeat": rem.repeat,
        "notes": rem.notes,
        "completed": bool(rem.completed),
        "createdAt": rem.created_at,
        "isDemo": bool(rem.is_demo),
    }


@router.get("")
def list_reminders(
    petId: Optional[str] = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(Reminder).filter(Reminder.user_id == current_user.id)
    if petId:
        pet = db.query(Pet).filter(Pet.id == petId).first()
        if not pet:
            return {"reminders": []}
        if pet.user_id != current_user.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权查看其他用户的宠物提醒")
        query = query.filter(Reminder.pet_id == petId)

    rows = query.order_by(Reminder.due_date.asc()).all()
    return {"reminders": [serialize_reminder(r) for r in rows]}


@router.post("", status_code=201)
def create_reminder(
    payload: ReminderCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = db.query(Pet).filter(Pet.id == payload.petId).first()
    if not pet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="关联的宠物档案不存在")
    if pet.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权为其他用户的宠物创建提醒")

    rem = Reminder(
        id=f"rem_{uuid.uuid4().hex[:14]}",
        user_id=current_user.id,
        pet_id=pet.id,
        title=payload.title.strip(),
        category=payload.category,
        due_date=payload.dueDate,
        due_time=payload.dueTime,
        repeat=payload.repeat,
        notes=payload.notes.strip() if payload.notes else None,
        completed=False,
        created_at=utc_now_iso(),
        is_demo=False,
    )
    db.add(rem)
    db.commit()
    db.refresh(rem)
    return {"reminder": serialize_reminder(rem)}


@router.patch("/{reminder_id}")
def patch_reminder(
    reminder_id: str,
    payload: ReminderPatch,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rem = db.query(Reminder).filter(Reminder.id == reminder_id).first()
    if not rem:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="未找到该护理提醒")
    if rem.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权修改其他用户的护理提醒")

    patch = payload.model_dump(exclude_unset=True)
    field_map = {
        "title": "title",
        "category": "category",
        "dueDate": "due_date",
        "dueTime": "due_time",
        "repeat": "repeat",
        "notes": "notes",
        "completed": "completed",
    }
    for src, dst in field_map.items():
        if src in patch and patch[src] is not None:
            setattr(rem, dst, patch[src])
    db.add(rem)
    db.commit()
    db.refresh(rem)
    return {"reminder": serialize_reminder(rem)}


@router.delete("/{reminder_id}")
def delete_reminder(
    reminder_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rem = db.query(Reminder).filter(Reminder.id == reminder_id).first()
    if not rem:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="未找到该护理提醒")
    if rem.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权删除其他用户的护理提醒")
    db.delete(rem)
    db.commit()
    return {"deleted": True, "id": reminder_id}
