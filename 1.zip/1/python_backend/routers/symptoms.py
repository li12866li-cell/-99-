import json
import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import SymptomCheckRecord, utc_now_iso
from models.schemas import SymptomCheckRequest, SymptomHistoryCreate
from services.symptom_service import load_symptom_rules, match_symptoms

router = APIRouter(prefix="/symptoms", tags=["Symptoms"])


def _serialize_history(row: SymptomCheckRecord) -> dict:
    try:
        symptom_ids = json.loads(row.symptom_ids_json or "[]")
    except Exception:
        symptom_ids = []
    try:
        symptom_names = json.loads(row.symptom_names_json or "[]")
    except Exception:
        symptom_names = []
    try:
        reasoning = json.loads(row.reasoning_json or "[]")
    except Exception:
        reasoning = []
    try:
        advice_list = json.loads(row.advice_json or "[]")
    except Exception:
        advice_list = []

    return {
        "id": row.id,
        "petId": row.pet_id,
        "petName": row.pet_name,
        "symptomIds": symptom_ids,
        "symptomNames": symptom_names,
        "level": row.level,
        "score": int(row.score or 0),
        "headline": row.headline,
        "reasoning": reasoning,
        "adviceList": advice_list,
        "checkedAt": row.checked_at,
    }


@router.get("/rules")
def get_symptom_rules():
    try:
        return load_symptom_rules()
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/check")
def check_symptoms(payload: SymptomCheckRequest):
    cleaned_ids = [s.strip() for s in payload.symptomIds if isinstance(s, str) and s.strip()]
    if not cleaned_ids:
        raise HTTPException(status_code=400, detail="请至少选择一项观察到的症状")
    result = match_symptoms(cleaned_ids)
    if not result["matchedSymptoms"]:
        raise HTTPException(status_code=400, detail="未匹配到有效症状编号，请重新选择")
    return result


@router.get("/history")
def list_symptom_history(
    petId: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    query = db.query(SymptomCheckRecord)
    if petId:
        query = query.filter(SymptomCheckRecord.pet_id == petId)
    rows = query.order_by(SymptomCheckRecord.checked_at.desc()).limit(30).all()
    return {"history": [_serialize_history(r) for r in rows]}


@router.post("/history", status_code=201)
def create_symptom_history(
    payload: SymptomHistoryCreate,
    db: Session = Depends(get_db),
):
    row = SymptomCheckRecord(
        id=f"sym_{uuid.uuid4().hex[:12]}",
        pet_id=payload.petId or "general",
        pet_name=payload.petName or "未指定宠物",
        symptom_ids_json=json.dumps(payload.symptomIds, ensure_ascii=False),
        symptom_names_json=json.dumps(payload.symptomNames, ensure_ascii=False),
        level=payload.level,
        score=float(payload.score or 0),
        headline=payload.headline,
        reasoning_json=json.dumps(payload.reasoning, ensure_ascii=False),
        advice_json=json.dumps(payload.adviceList, ensure_ascii=False),
        checked_at=utc_now_iso(),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"item": _serialize_history(row)}


@router.delete("/history")
def clear_symptom_history(
    petId: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    query = db.query(SymptomCheckRecord)
    if petId:
        query = query.filter(SymptomCheckRecord.pet_id == petId)
    query.delete()
    db.commit()
    return {"cleared": True, "petId": petId}
