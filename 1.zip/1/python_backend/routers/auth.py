import hashlib
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.security import HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import PasswordResetToken, RevokedToken, User, utc_now_iso
from models.schemas import (
    ChangePasswordRequest,
    ForgotPasswordRequest,
    LoginRequest,
    RegisterRequest,
    ResetPasswordRequest,
    UserProfileUpdate,
)
from security import (
    bearer_scheme,
    create_access_token,
    decode_access_token,
    get_current_user,
    hash_password,
    verify_password,
)
from services.email_service import is_smtp_configured, send_password_reset_email

router = APIRouter(prefix="/auth", tags=["Authentication"])


def serialize_user(user: User) -> dict:
    return {
        "id": user.id,
        "fullName": user.full_name,
        "email": user.email,
        "avatarUrl": user.avatar_url,
        "isActive": bool(user.is_active),
        "emailVerified": bool(user.email_verified),
        "createdAt": user.created_at,
        "updatedAt": user.updated_at,
    }


def _hash_reset_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if not payload.agreedToTerms:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="请阅读并同意服务条款和隐私政策",
        )
    if payload.confirmPassword is not None and payload.password != payload.confirmPassword:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="两次输入的密码不一致",
        )

    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="该电子邮箱已被注册，请直接登录或更换邮箱",
        )

    now = utc_now_iso()
    user = User(
        id=f"usr_{uuid.uuid4().hex[:16]}",
        full_name=payload.fullName,
        email=payload.email,
        password_hash=hash_password(payload.password),
        avatar_url=None,
        is_active=True,
        email_verified=False,
        created_at=now,
        updated_at=now,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token_info = create_access_token(user_id=user.id, email=user.email)
    return {
        "accessToken": token_info["access_token"],
        "tokenType": token_info["token_type"],
        "expiresAt": token_info["expires_at"],
        "user": serialize_user(user),
    }


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="邮箱或密码不正确，请核对后重试",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="该账号已被停用，请联系管理员",
        )

    ttl = timedelta(days=14) if payload.rememberMe else timedelta(hours=12)
    token_info = create_access_token(
        user_id=user.id,
        email=user.email,
        expires_delta=ttl,
    )
    return {
        "accessToken": token_info["access_token"],
        "tokenType": token_info["token_type"],
        "expiresAt": token_info["expires_at"],
        "user": serialize_user(user),
    }


@router.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    return {"user": serialize_user(current_user)}


@router.put("/profile")
def update_profile(
    payload: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    email_reverification_required = False

    if payload.fullName is not None:
        cleaned_name = payload.fullName.strip()
        if not cleaned_name:
            raise HTTPException(status_code=400, detail="姓名不能为空")
        current_user.full_name = cleaned_name

    if payload.avatarUrl is not None:
        current_user.avatar_url = payload.avatarUrl.strip() or None

    if payload.email is not None and payload.email != current_user.email:
        conflict = (
            db.query(User)
            .filter(User.email == payload.email, User.id != current_user.id)
            .first()
        )
        if conflict:
            raise HTTPException(status_code=409, detail="该邮箱已被其他账号占用")
        current_user.email = payload.email
        current_user.email_verified = False
        email_reverification_required = True

    current_user.updated_at = utc_now_iso()
    db.add(current_user)
    db.commit()
    db.refresh(current_user)

    return {
        "user": serialize_user(current_user),
        "emailReverificationRequired": email_reverification_required,
        "message": (
            "资料已保存。由于您修改了邮箱地址，需要重新完成邮箱验证。"
            if email_reverification_required
            else "个人资料已更新"
        ),
    }


@router.post("/change-password")
def change_password(
    payload: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(payload.currentPassword, current_user.password_hash):
        raise HTTPException(status_code=400, detail="当前密码不正确")
    if payload.currentPassword == payload.newPassword:
        raise HTTPException(status_code=400, detail="新密码不能与当前密码相同")

    current_user.password_hash = hash_password(payload.newPassword)
    current_user.updated_at = utc_now_iso()
    db.add(current_user)
    db.commit()
    return {"updated": True, "message": "密码已修改成功"}


@router.post("/forgot-password")
def forgot_password(payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    smtp_ready = is_smtp_configured()

    if not user:
        if not smtp_ready:
            return {
                "requested": True,
                "smtpConfigured": False,
                "emailSent": False,
                "devNotice": (
                    "当前开发环境未配置 SMTP 邮件服务（需设置 SMTP_HOST、SMTP_USER、SMTP_PASSWORD），"
                    "且未找到该邮箱对应的注册账户，因此未生成重置链接。"
                ),
            }
        return {
            "requested": True,
            "smtpConfigured": True,
            "emailSent": False,
            "message": "如果该邮箱已注册，我们已向其发送密码重置指引。",
        }

    raw_token = secrets.token_urlsafe(32)
    expires_at = (datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat()
    reset_entry = PasswordResetToken(
        id=f"rst_{uuid.uuid4().hex[:16]}",
        user_id=user.id,
        token_hash=_hash_reset_token(raw_token),
        expires_at=expires_at,
        used_at=None,
        created_at=utc_now_iso(),
    )
    db.add(reset_entry)
    db.commit()

    base_url = os.getenv("APP_BASE_URL", "http://localhost:3000").rstrip("/")
    reset_url = f"{base_url}/reset-password?token={raw_token}"
    delivery = send_password_reset_email(user.email, reset_url)

    return {
        "requested": True,
        "smtpConfigured": delivery["smtpConfigured"],
        "emailSent": delivery["emailSent"],
        "devNotice": delivery["devNotice"],
        "devResetToken": raw_token if not delivery["smtpConfigured"] else None,
        "devResetUrl": delivery["devResetUrl"],
        "message": (
            "密码重置邮件已发送，请在 30 分钟内查收。"
            if delivery["emailSent"]
            else "开发环境提示：未配置邮件服务，未实际发送邮件。"
        ),
    }


@router.get("/reset-password/verify")
def verify_reset_token(token: str = Query(..., min_length=10), db: Session = Depends(get_db)):
    token_hash = _hash_reset_token(token.strip())
    entry = db.query(PasswordResetToken).filter(PasswordResetToken.token_hash == token_hash).first()
    if not entry or entry.used_at is not None:
        raise HTTPException(status_code=400, detail="重置令牌无效或已被使用")
    if datetime.fromisoformat(entry.expires_at) < datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="重置令牌已过期，请重新申请")
    return {"valid": True}


@router.post("/reset-password")
def reset_password(payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    token_hash = _hash_reset_token(payload.token.strip())
    entry = db.query(PasswordResetToken).filter(PasswordResetToken.token_hash == token_hash).first()
    if not entry or entry.used_at is not None:
        raise HTTPException(status_code=400, detail="重置令牌无效或已被使用")
    if datetime.fromisoformat(entry.expires_at) < datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="重置令牌已过期，请重新申请")

    user = db.query(User).filter(User.id == entry.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="关联用户不存在")

    now = utc_now_iso()
    user.password_hash = hash_password(payload.newPassword)
    user.updated_at = now
    entry.used_at = now
    db.add(user)
    db.add(entry)
    db.commit()

    return {"reset": True, "message": "密码重置成功，请使用新密码登录"}


@router.post("/logout")
def logout(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if credentials and credentials.credentials:
        payload = decode_access_token(credentials.credentials)
        jti = str(payload["jti"])
        exp_ts = payload.get("exp")
        expires_at = (
            datetime.fromtimestamp(int(exp_ts), tz=timezone.utc).isoformat()
            if exp_ts
            else utc_now_iso()
        )
        exists = db.query(RevokedToken).filter(RevokedToken.jti == jti).first()
        if not exists:
            db.add(
                RevokedToken(
                    jti=jti,
                    user_id=current_user.id,
                    expires_at=expires_at,
                    revoked_at=utc_now_iso(),
                )
            )
            db.commit()
    return {"loggedOut": True}
