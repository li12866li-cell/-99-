import json
import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from database import SessionLocal, get_db
from models.db_models import ChatMessage, Pet, User, utc_now_iso
from models.schemas import VetChatRequest
from security import get_current_user
from services.deepseek_service import (
    chat_completion,
    extract_user_text,
    get_vet_status,
    stream_chat_completion,
)

router = APIRouter(prefix="/vet", tags=["AI Vet"])


def _resolve_pet_key(db: Session, user_id: str, payload_pet_id: Optional[str]) -> str:
    if not payload_pet_id or payload_pet_id == "general":
        return "general"
    pet = db.query(Pet).filter(Pet.id == payload_pet_id).first()
    if not pet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="关联宠物不存在")
    if pet.user_id != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权使用其他用户的宠物档案进行问诊")
    return pet.id


def _serialize_chat(row: ChatMessage) -> dict:
    sources = []
    if row.sources_json:
        try:
            sources = json.loads(row.sources_json)
        except Exception:
            sources = []
    return {
        "id": row.id,
        "role": row.role,
        "text": row.text,
        "image": row.image,
        "engine": row.engine,
        "sources": sources,
        "timestamp": row.created_at,
    }


@router.get("/status")
def vet_status():
    return get_vet_status()


@router.get("/history")
def get_chat_history(
    petId: Optional[str] = Query(default="general"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet_key = _resolve_pet_key(db, current_user.id, petId)
    rows = (
        db.query(ChatMessage)
        .filter(ChatMessage.user_id == current_user.id, ChatMessage.pet_id == pet_key)
        .order_by(ChatMessage.created_at.asc())
        .limit(60)
        .all()
    )
    return {"messages": [_serialize_chat(r) for r in rows]}


@router.delete("/history")
def clear_chat_history(
    petId: Optional[str] = Query(default="general"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet_key = _resolve_pet_key(db, current_user.id, petId)
    db.query(ChatMessage).filter(
        ChatMessage.user_id == current_user.id, ChatMessage.pet_id == pet_key
    ).delete()
    db.commit()
    return {"cleared": True, "petId": pet_key}


@router.post("/chat")
async def vet_chat(
    payload: VetChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        pet_id = payload.petId or (payload.petContext.id if payload.petContext else None)
        pet_key = _resolve_pet_key(db, current_user.id, pet_id)
        history = [h.model_dump() for h in (payload.history or [])]
        pet_ctx = payload.petContext.model_dump() if payload.petContext else None
        result = await chat_completion(
            history=history,
            message=payload.message,
            language=payload.language,
            pet_context=pet_ctx,
        )

        user_msg = ChatMessage(
            id=f"msg_{uuid.uuid4().hex[:14]}",
            user_id=current_user.id,
            pet_id=pet_key,
            role="user",
            text=extract_user_text(payload.message),
            created_at=utc_now_iso(),
        )
        ai_msg = ChatMessage(
            id=f"msg_{uuid.uuid4().hex[:14]}",
            user_id=current_user.id,
            pet_id=pet_key,
            role="model",
            text=result["response"],
            engine=result.get("engine"),
            sources_json=json.dumps(result.get("sources") or [], ensure_ascii=False),
            created_at=utc_now_iso(),
        )
        db.add(user_msg)
        db.add(ai_msg)
        db.commit()
        return result
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/chat/stream")
async def vet_chat_stream(
    payload: VetChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet_id = payload.petId or (payload.petContext.id if payload.petContext else None)
    pet_key = _resolve_pet_key(db, current_user.id, pet_id)
    history = [h.model_dump() for h in (payload.history or [])]
    pet_ctx = payload.petContext.model_dump() if payload.petContext else None
    user_text = extract_user_text(payload.message)
    user_id = current_user.id

    async def persist_and_stream():
        full_reply = ""
        detected_engine = None
        async for sse_line in stream_chat_completion(
            history=history,
            message=payload.message,
            language=payload.language,
            pet_context=pet_ctx,
        ):
            if sse_line.startswith("data: "):
                raw_json = sse_line[6:].strip()
                if raw_json and raw_json != "[DONE]":
                    try:
                        parsed = json.loads(raw_json)
                        if parsed.get("meta") and parsed["meta"].get("engine"):
                            detected_engine = parsed["meta"]["engine"]
                        if parsed.get("chunk"):
                            full_reply += parsed["chunk"]
                    except json.JSONDecodeError:
                        pass
            yield sse_line

        if full_reply.strip():
            with SessionLocal() as write_db:
                write_db.add(
                    ChatMessage(
                        id=f"msg_{uuid.uuid4().hex[:14]}",
                        user_id=user_id,
                        pet_id=pet_key,
                        role="user",
                        text=user_text,
                        created_at=utc_now_iso(),
                    )
                )
                write_db.add(
                    ChatMessage(
                        id=f"msg_{uuid.uuid4().hex[:14]}",
                        user_id=user_id,
                        pet_id=pet_key,
                        role="model",
                        text=full_reply,
                        engine=detected_engine,
                        created_at=utc_now_iso(),
                    )
                )
                write_db.commit()

    return StreamingResponse(
        persist_and_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
