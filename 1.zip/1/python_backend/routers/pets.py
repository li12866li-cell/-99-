import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import Pet, User, utc_now_iso
from models.schemas import PetCreate, PetUpdate
from security import get_current_user

router = APIRouter(prefix="/pets", tags=["Pets"])

AVATAR_BY_SPECIES = {
    "dog": "/src/assets/images/golden_retriever_dog_1794751022608.jpg",
    "cat": "/src/assets/images/british_shorthair_cat_1794751020533.jpg",
    "bunny": "/src/assets/images/bunny_model_natural_1794231711465.jpg",
    "other": "/src/assets/images/golden_retriever_dog_1794751022608.jpg",
}


def serialize_pet(pet: Pet) -> dict:
    return {
        "id": pet.id,
        "userId": pet.user_id,
        "name": pet.name,
        "species": pet.species,
        "breed": pet.breed or "",
        "gender": pet.gender,
        "age": pet.age,
        "weight": pet.weight,
        "isNeutered": bool(pet.is_neutered),
        "avatar": pet.avatar,
        "diet": pet.diet or "[]",
        "water": pet.water or "0ml",
        "vaccineStatus": pet.vaccine_status or "",
        "companionStartDate": pet.companion_start_date,
        "isDemo": bool(pet.is_demo),
        "updatedAt": pet.updated_at,
    }


def _get_owned_pet(db: Session, pet_id: str, user_id: str) -> Pet:
    pet = db.query(Pet).filter(Pet.id == pet_id).first()
    if not pet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="未找到该宠物档案")
    if pet.user_id != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权访问其他用户的宠物档案")
    return pet


@router.get("")
def list_pets(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rows = db.query(Pet).filter(Pet.user_id == current_user.id).all()
    return {"pets": [serialize_pet(p) for p in rows]}


@router.post("", status_code=201)
def create_pet(
    payload: PetCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = Pet(
        id=f"pet_{uuid.uuid4().hex[:14]}",
        user_id=current_user.id,
        name=payload.name.strip(),
        species=payload.species,
        breed=payload.breed or "",
        gender=payload.gender,
        age=payload.age,
        weight=payload.weight if payload.weight is not None else 0.0,
        is_neutered=payload.isNeutered,
        avatar=payload.avatar or AVATAR_BY_SPECIES.get(payload.species, AVATAR_BY_SPECIES["dog"]),
        diet=payload.diet or "[]",
        water=payload.water or "0ml",
        vaccine_status=payload.vaccineStatus or "",
        companion_start_date=payload.companionStartDate or datetime.now().strftime("%Y-%m-%d"),
        is_demo=False,
        updated_at=utc_now_iso(),
    )
    db.add(pet)
    db.commit()
    db.refresh(pet)
    return {"pet": serialize_pet(pet)}


@router.put("/{pet_id}")
def update_pet(
    pet_id: str,
    payload: PetUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = _get_owned_pet(db, pet_id, current_user.id)
    patch = payload.model_dump(exclude_unset=True)
    field_map = {
        "name": "name",
        "species": "species",
        "breed": "breed",
        "gender": "gender",
        "age": "age",
        "weight": "weight",
        "isNeutered": "is_neutered",
        "avatar": "avatar",
        "diet": "diet",
        "water": "water",
        "vaccineStatus": "vaccine_status",
        "companionStartDate": "companion_start_date",
    }
    for src, dst in field_map.items():
        if src in patch and patch[src] is not None:
            setattr(pet, dst, patch[src])
    pet.updated_at = utc_now_iso()
    db.add(pet)
    db.commit()
    db.refresh(pet)
    return {"pet": serialize_pet(pet)}


@router.delete("/{pet_id}")
def delete_pet(
    pet_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = _get_owned_pet(db, pet_id, current_user.id)
    db.delete(pet)
    db.commit()
    return {"deleted": True, "id": pet_id}
