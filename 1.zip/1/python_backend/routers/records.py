import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import HealthRecord, Pet, User, utc_now_iso
from models.schemas import HealthRecordCreate
from security import get_current_user

router = APIRouter(prefix="/records", tags=["HealthRecords"])


def serialize_record(rec: HealthRecord) -> dict:
    return {
        "id": rec.id,
        "userId": rec.user_id,
        "petId": rec.pet_id,
        "date": rec.date,
        "type": rec.type,
        "title": rec.title,
        "content": rec.content,
        "weightKg": rec.weight_kg,
        "isDemo": bool(rec.is_demo),
    }


@router.get("")
def list_records(
    petId: Optional[str] = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(HealthRecord).filter(HealthRecord.user_id == current_user.id)
    if petId:
        pet = db.query(Pet).filter(Pet.id == petId).first()
        if not pet:
            return {"records": []}
        if pet.user_id != current_user.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权查看其他用户的宠物记录")
        query = query.filter(HealthRecord.pet_id == petId)

    rows = query.order_by(HealthRecord.date.desc()).all()
    return {"records": [serialize_record(r) for r in rows]}


@router.post("", status_code=201)
def create_record(
    payload: HealthRecordCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = db.query(Pet).filter(Pet.id == payload.petId).first()
    if not pet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="关联的宠物档案不存在")
    if pet.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权为其他用户的宠物添加健康记录")

    rec = HealthRecord(
        id=f"rec_{uuid.uuid4().hex[:14]}",
        user_id=current_user.id,
        pet_id=pet.id,
        date=payload.date,
        type=payload.type,
        title=payload.title.strip(),
        content=payload.content.strip(),
        weight_kg=payload.weightKg,
        is_demo=False,
    )
    db.add(rec)
    if payload.weightKg is not None and payload.weightKg > 0:
        pet.weight = payload.weightKg
        pet.updated_at = utc_now_iso()
        db.add(pet)
    db.commit()
    db.refresh(rec)
    return {"record": serialize_record(rec)}


@router.delete("/{record_id}")
def delete_record(
    record_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rec = db.query(HealthRecord).filter(HealthRecord.id == record_id).first()
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="未找到该健康记录")
    if rec.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="无权删除其他用户的健康记录")
    db.delete(rec)
    db.commit()
    return {"deleted": True, "id": record_id}
