import json
import uuid
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import MedicalRecord, Pet, User, utc_now_iso
from models.schemas import MedicalRecordCreate
from security import get_current_user

router = APIRouter(prefix="/medical-records", tags=["MedicalRecords"])


def serialize_medical_record(rec: MedicalRecord) -> dict:
    try:
        attachments = json.loads(rec.attachments_json or "[]")
    except Exception:
        attachments = []
    return {
        "id": rec.id,
        "userId": rec.user_id,
        "petId": rec.pet_id,
        "title": rec.title,
        "date": rec.date,
        "hospitalName": rec.hospital_name or "",
        "category": rec.category or "lab",
        "results": rec.results or "",
        "attachments": attachments,
        "createdAt": rec.created_at,
    }


@router.get("")
def list_medical_records(
    petId: Optional[str] = Query(default=None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(MedicalRecord).filter(MedicalRecord.user_id == current_user.id)
    if petId:
        pet = db.query(Pet).filter(Pet.id == petId).first()
        if not pet:
            return {"records": []}
        if pet.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="无权查看其他用户的医疗记录",
            )
        query = query.filter(MedicalRecord.pet_id == petId)

    rows = query.order_by(MedicalRecord.date.desc(), MedicalRecord.created_at.desc()).all()
    return {"records": [serialize_medical_record(r) for r in rows]}


@router.post("", status_code=201)
def create_medical_record(
    payload: MedicalRecordCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    pet = db.query(Pet).filter(Pet.id == payload.petId).first()
    if not pet:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="关联的宠物档案不存在")
    if pet.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="无权为其他用户的宠物添加医疗记录",
        )

    attachments_payload = [a.model_dump() for a in payload.attachments]
    rec = MedicalRecord(
        id=f"med_{uuid.uuid4().hex[:14]}",
        user_id=current_user.id,
        pet_id=pet.id,
        title=payload.title.strip(),
        date=payload.date,
        hospital_name=payload.hospitalName.strip(),
        category=payload.category,
        results=payload.results.strip(),
        attachments_json=json.dumps(attachments_payload, ensure_ascii=False),
        created_at=utc_now_iso(),
    )
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return {"record": serialize_medical_record(rec)}


@router.delete("/{record_id}")
def delete_medical_record(
    record_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rec = db.query(MedicalRecord).filter(MedicalRecord.id == record_id).first()
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="未找到该医疗记录")
    if rec.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="无权删除其他用户的医疗记录",
        )
    db.delete(rec)
    db.commit()
    return {"deleted": True, "id": record_id}
