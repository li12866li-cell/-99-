from typing import Optional
from fastapi import APIRouter, Query
from services.distance_service import get_nearby_hospitals

router = APIRouter(prefix="/hospitals", tags=["Hospitals"])


@router.get("/nearby")
async def nearby_hospitals(
    lat: Optional[float] = Query(default=None),
    lng: Optional[float] = Query(default=None),
    city: str = Query(default="all"),
):
    return await get_nearby_hospitals(lat=lat, lng=lng, city=city)
