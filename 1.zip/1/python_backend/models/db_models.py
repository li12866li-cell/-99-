from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, Float, ForeignKey, Index, String, Text
from sqlalchemy.orm import relationship
from database import Base


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class User(Base):
    __tablename__ = "users"

    id = Column(String(64), primary_key=True)
    full_name = Column(String(100), nullable=False)
    email = Column(String(255), nullable=False, unique=True, index=True)
    password_hash = Column(String(255), nullable=False)
    avatar_url = Column(Text, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    email_verified = Column(Boolean, nullable=False, default=False)
    created_at = Column(String(64), nullable=False, default=utc_now_iso)
    updated_at = Column(String(64), nullable=False, default=utc_now_iso, onupdate=utc_now_iso)

    pets = relationship("Pet", back_populates="owner", cascade="all, delete-orphan")
    health_records = relationship("HealthRecord", back_populates="owner", cascade="all, delete-orphan")
    medical_records = relationship("MedicalRecord", back_populates="owner", cascade="all, delete-orphan")
    reminders = relationship("Reminder", back_populates="owner", cascade="all, delete-orphan")
    chat_messages = relationship("ChatMessage", back_populates="owner", cascade="all, delete-orphan")
    reset_tokens = relationship("PasswordResetToken", back_populates="user", cascade="all, delete-orphan")


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = Column(String(128), nullable=False, unique=True, index=True)
    expires_at = Column(String(64), nullable=False)
    used_at = Column(String(64), nullable=True)
    created_at = Column(String(64), nullable=False, default=utc_now_iso)

    user = relationship("User", back_populates="reset_tokens")


class RevokedToken(Base):
    __tablename__ = "revoked_tokens"

    jti = Column(String(128), primary_key=True)
    user_id = Column(String(64), nullable=False, index=True)
    expires_at = Column(String(64), nullable=False)
    revoked_at = Column(String(64), nullable=False, default=utc_now_iso)


class Pet(Base):
    __tablename__ = "pets"

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(80), nullable=False)
    species = Column(String(24), nullable=False, default="dog")
    breed = Column(String(120), nullable=True, default="")
    gender = Column(String(16), nullable=False, default="male")
    age = Column(Float, nullable=True)
    weight = Column(Float, nullable=True, default=0.0)
    is_neutered = Column(Boolean, nullable=False, default=False)
    avatar = Column(Text, nullable=True)
    diet = Column(Text, nullable=True, default="[]")
    water = Column(String(64), nullable=True, default="0ml")
    vaccine_status = Column(String(64), nullable=True, default="")
    companion_start_date = Column(String(32), nullable=True)
    is_demo = Column(Boolean, nullable=False, default=False)
    updated_at = Column(String(64), nullable=False, default=utc_now_iso, onupdate=utc_now_iso)

    owner = relationship("User", back_populates="pets")
    records = relationship("HealthRecord", back_populates="pet", cascade="all, delete-orphan")
    medical_records = relationship("MedicalRecord", back_populates="pet", cascade="all, delete-orphan")
    reminders = relationship("Reminder", back_populates="pet", cascade="all, delete-orphan")


class HealthRecord(Base):
    __tablename__ = "health_records"
    __table_args__ = (Index("ix_health_records_user_pet", "user_id", "pet_id"),)

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    pet_id = Column(String(64), ForeignKey("pets.id", ondelete="CASCADE"), nullable=False, index=True)
    date = Column(String(32), nullable=False)
    type = Column(String(32), nullable=False, default="activity")
    title = Column(String(160), nullable=False)
    content = Column(Text, nullable=False, default="")
    weight_kg = Column(Float, nullable=True)
    is_demo = Column(Boolean, nullable=False, default=False)

    owner = relationship("User", back_populates="health_records")
    pet = relationship("Pet", back_populates="records")


class MedicalRecord(Base):
    __tablename__ = "medical_records"
    __table_args__ = (Index("ix_medical_records_user_pet", "user_id", "pet_id"),)

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    pet_id = Column(String(64), ForeignKey("pets.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(160), nullable=False)
    date = Column(String(32), nullable=False)
    hospital_name = Column(String(160), nullable=False, default="")
    category = Column(String(40), nullable=False, default="lab")
    results = Column(Text, nullable=False, default="")
    attachments_json = Column(Text, nullable=False, default="[]")
    created_at = Column(String(64), nullable=False, default=utc_now_iso)

    owner = relationship("User", back_populates="medical_records")
    pet = relationship("Pet", back_populates="medical_records")


class Reminder(Base):
    __tablename__ = "reminders"
    __table_args__ = (Index("ix_reminders_user_pet", "user_id", "pet_id"),)

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    pet_id = Column(String(64), ForeignKey("pets.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(160), nullable=False)
    category = Column(String(32), nullable=False, default="checkup")
    due_date = Column(String(32), nullable=False)
    due_time = Column(String(16), nullable=True)
    repeat = Column(String(32), nullable=False, default="once")
    notes = Column(Text, nullable=True)
    completed = Column(Boolean, nullable=False, default=False)
    created_at = Column(String(64), nullable=False, default=utc_now_iso)
    is_demo = Column(Boolean, nullable=False, default=False)

    owner = relationship("User", back_populates="reminders")
    pet = relationship("Pet", back_populates="reminders")


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    __table_args__ = (Index("ix_chat_messages_user_pet", "user_id", "pet_id"),)

    id = Column(String(64), primary_key=True)
    user_id = Column(String(64), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    pet_id = Column(String(64), nullable=False, default="general", index=True)
    role = Column(String(16), nullable=False)  # 'user' | 'model'
    text = Column(Text, nullable=False, default="")
    image = Column(Text, nullable=True)
    engine = Column(String(32), nullable=True)
    sources_json = Column(Text, nullable=True)
    created_at = Column(String(64), nullable=False, default=utc_now_iso)

    owner = relationship("User", back_populates="chat_messages")


class SymptomCheckRecord(Base):
    __tablename__ = "symptom_checks"
    __table_args__ = (Index("ix_symptom_checks_pet_checked", "pet_id", "checked_at"),)

    id = Column(String(64), primary_key=True)
    pet_id = Column(String(64), nullable=False, default="general", index=True)
    pet_name = Column(String(80), nullable=False, default="未指定宠物")
    symptom_ids_json = Column(Text, nullable=False, default="[]")
    symptom_names_json = Column(Text, nullable=False, default="[]")
    level = Column(String(24), nullable=False, default="watch")
    score = Column(Float, nullable=False, default=0.0)
    headline = Column(Text, nullable=False, default="")
    reasoning_json = Column(Text, nullable=False, default="[]")
    advice_json = Column(Text, nullable=False, default="[]")
    checked_at = Column(String(64), nullable=False, default=utc_now_iso)

