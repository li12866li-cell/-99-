import re
from typing import Any, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator

EMAIL_REGEX = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def validate_email_format(value: str) -> str:
    cleaned = (value or "").strip().lower()
    if not cleaned or not EMAIL_REGEX.match(cleaned):
        raise ValueError("请输入有效的电子邮箱地址")
    return cleaned


def validate_password_strength(value: str) -> str:
    if not value or len(value) < 8:
        raise ValueError("密码长度至少为 8 位")
    if not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise ValueError("密码需同时包含字母和数字")
    return value


# ========================
# Auth & User Schemas
# ========================
class RegisterRequest(BaseModel):
    fullName: str = Field(..., min_length=1, max_length=100)
    email: str
    password: str
    confirmPassword: Optional[str] = None
    agreedToTerms: bool = True

    @field_validator("fullName")
    @classmethod
    def check_full_name(cls, v: str) -> str:
        cleaned = v.strip()
        if not cleaned:
            raise ValueError("姓名不能为空")
        return cleaned

    @field_validator("email")
    @classmethod
    def check_email(cls, v: str) -> str:
        return validate_email_format(v)

    @field_validator("password")
    @classmethod
    def check_password(cls, v: str) -> str:
        return validate_password_strength(v)


class LoginRequest(BaseModel):
    email: str
    password: str = Field(..., min_length=1)
    rememberMe: bool = True

    @field_validator("email")
    @classmethod
    def check_email(cls, v: str) -> str:
        return validate_email_format(v)


class UserProfileUpdate(BaseModel):
    fullName: Optional[str] = Field(default=None, min_length=1, max_length=100)
    avatarUrl: Optional[str] = None
    email: Optional[str] = None

    @field_validator("email")
    @classmethod
    def check_optional_email(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return None
        return validate_email_format(v)


class ChangePasswordRequest(BaseModel):
    currentPassword: str = Field(..., min_length=1)
    newPassword: str

    @field_validator("newPassword")
    @classmethod
    def check_new_password(cls, v: str) -> str:
        return validate_password_strength(v)


class ForgotPasswordRequest(BaseModel):
    email: str

    @field_validator("email")
    @classmethod
    def check_email(cls, v: str) -> str:
        return validate_email_format(v)


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., min_length=10)
    newPassword: str

    @field_validator("newPassword")
    @classmethod
    def check_new_password(cls, v: str) -> str:
        return validate_password_strength(v)


class UserResponse(BaseModel):
    id: str
    fullName: str
    email: str
    avatarUrl: Optional[str] = None
    isActive: bool
    emailVerified: bool
    createdAt: str
    updatedAt: str


class AuthResponse(BaseModel):
    accessToken: str
    tokenType: Literal["bearer"] = "bearer"
    expiresAt: str
    user: UserResponse


# ========================
# Pet / Health / Reminder Schemas
# ========================
PetSpecies = Literal["dog", "cat", "bunny", "other"]
PetGender = Literal["male", "female"]
HealthRecordType = Literal["vaccine", "activity", "diet", "medical"]
ReminderCategory = Literal["vaccine", "deworming", "medication", "checkup", "grooming"]
ReminderRepeat = Literal["once", "daily", "weekly", "monthly", "yearly"]


class PetCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    species: PetSpecies = "dog"
    breed: Optional[str] = ""
    gender: PetGender = "male"
    age: Optional[float] = None
    weight: Optional[float] = 0.0
    isNeutered: bool = False
    avatar: Optional[str] = None
    diet: Optional[str] = "[]"
    water: Optional[str] = "0ml"
    vaccineStatus: Optional[str] = ""
    companionStartDate: Optional[str] = None


class PetUpdate(BaseModel):
    name: Optional[str] = None
    species: Optional[PetSpecies] = None
    breed: Optional[str] = None
    gender: Optional[PetGender] = None
    age: Optional[float] = None
    weight: Optional[float] = None
    isNeutered: Optional[bool] = None
    avatar: Optional[str] = None
    diet: Optional[str] = None
    water: Optional[str] = None
    vaccineStatus: Optional[str] = None
    companionStartDate: Optional[str] = None


class PetResponse(BaseModel):
    id: str
    userId: str
    name: str
    species: PetSpecies
    breed: Optional[str] = ""
    gender: PetGender
    age: Optional[float] = None
    weight: Optional[float] = None
    isNeutered: bool
    avatar: Optional[str] = None
    diet: Optional[str] = "[]"
    water: Optional[str] = "0ml"
    vaccineStatus: Optional[str] = ""
    companionStartDate: Optional[str] = None
    isDemo: bool = False
    updatedAt: Optional[str] = None


class HealthRecordCreate(BaseModel):
    petId: str
    date: str
    type: HealthRecordType = "activity"
    title: str = Field(..., min_length=1, max_length=120)
    content: str = ""
    weightKg: Optional[float] = None


class HealthRecordResponse(BaseModel):
    id: str
    userId: str
    petId: str
    date: str
    type: HealthRecordType
    title: str
    content: str
    weightKg: Optional[float] = None
    isDemo: bool = False


MedicalRecordCategory = Literal["lab", "imaging", "vaccine", "prescription", "checkup", "other"]


class MedicalAttachmentSchema(BaseModel):
    id: str
    name: str
    mimeType: str
    sizeBytes: int = 0
    dataUrl: str


class MedicalRecordCreate(BaseModel):
    petId: str
    title: str = Field(..., min_length=1, max_length=160)
    date: str
    hospitalName: str = Field(default="", max_length=160)
    category: MedicalRecordCategory = "lab"
    results: str = ""
    attachments: List[MedicalAttachmentSchema] = []


class MedicalRecordResponse(BaseModel):
    id: str
    userId: str
    petId: str
    title: str
    date: str
    hospitalName: str
    category: MedicalRecordCategory
    results: str
    attachments: List[MedicalAttachmentSchema] = []
    createdAt: str


class ReminderCreate(BaseModel):
    petId: str
    title: str = Field(..., min_length=1, max_length=120)
    category: ReminderCategory = "checkup"
    dueDate: str
    dueTime: Optional[str] = None
    repeat: ReminderRepeat = "once"
    notes: Optional[str] = None


class ReminderPatch(BaseModel):
    title: Optional[str] = None
    category: Optional[ReminderCategory] = None
    dueDate: Optional[str] = None
    dueTime: Optional[str] = None
    repeat: Optional[ReminderRepeat] = None
    notes: Optional[str] = None
    completed: Optional[bool] = None


class ReminderResponse(BaseModel):
    id: str
    userId: str
    petId: str
    title: str
    category: ReminderCategory
    dueDate: str
    dueTime: Optional[str] = None
    repeat: ReminderRepeat
    notes: Optional[str] = None
    completed: bool = False
    createdAt: str
    isDemo: bool = False


class VetPetContext(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    species: Optional[str] = None
    breed: Optional[str] = None
    age: Optional[float] = None
    weight: Optional[float] = None
    gender: Optional[str] = None
    isNeutered: Optional[bool] = None


class VetHistoryTurn(BaseModel):
    role: str
    text: Optional[str] = None
    parts: Optional[List[dict[str, Any]]] = None


class VetChatRequest(BaseModel):
    history: Optional[List[VetHistoryTurn]] = None
    message: Any
    language: str = "zh"
    useSearch: Optional[bool] = True
    petContext: Optional[VetPetContext] = None
    petId: Optional[str] = None


class VetStatusResponse(BaseModel):
    deepseekConfigured: bool
    geminiConfigured: bool = False
    googleSearchAvailable: bool = False
    activeProvider: Literal["deepseek", "local-demo"]
    statusText: str


class VetChatResponse(BaseModel):
    response: str
    engine: Literal["deepseek", "local-demo"]
    deepseekConfigured: bool
    sources: List[dict[str, str]] = []


class HospitalResponse(BaseModel):
    id: str
    name: str
    city: str
    cityLabel: str
    district: str
    address: str
    phone: str
    lat: Optional[float] = None
    lng: Optional[float] = None
    distanceKm: Optional[float] = None
    distanceText: str
    kakaoMapUrl: str
    geocodedBy: Literal["kakao", "fallback", "none"]


class SymptomCheckRequest(BaseModel):
    symptomIds: List[str] = Field(..., min_length=1)
    petId: Optional[str] = None
    petName: Optional[str] = None


class SymptomHistoryCreate(BaseModel):
    petId: str = "general"
    petName: str = "未指定宠物"
    symptomIds: List[str] = Field(..., min_length=1)
    symptomNames: List[str] = []
    level: Literal["emergency", "urgent", "watch"]
    score: Optional[float] = 0
    headline: str
    reasoning: List[str] = []
    adviceList: List[str] = []

