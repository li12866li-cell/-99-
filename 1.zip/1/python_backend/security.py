import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pwdlib import PasswordHash
from sqlalchemy.orm import Session

from database import get_db
from models.db_models import RevokedToken, User

# 使用 Argon2id (pwdlib recommended) 进行不可逆密码哈希存储
password_hasher = PasswordHash.recommended()
bearer_scheme = HTTPBearer(auto_error=False)

# 若未通过环境变量设置 JWT_SECRET_KEY，则在进程启动时生成随机密钥（不硬编码固定密钥）
_DEV_FALLBACK_SECRET = secrets.token_urlsafe(48)


def get_jwt_secret() -> str:
    env_secret = os.getenv("JWT_SECRET_KEY", "").strip()
    if env_secret and env_secret not in {
        "CHANGE_ME_TO_A_RANDOM_64_CHAR_SECRET",
        "replace-with-strong-random-secret",
    }:
        return env_secret
    return _DEV_FALLBACK_SECRET


def get_jwt_expire_minutes() -> int:
    raw = os.getenv("JWT_EXPIRE_MINUTES", "10080").strip()
    try:
        minutes = int(raw)
        return max(5, minutes)
    except ValueError:
        return 10080


def hash_password(plain_password: str) -> str:
    return password_hasher.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    if not plain_password or not hashed_password:
        return False
    return password_hasher.verify(plain_password, hashed_password)


def create_access_token(
    user_id: str,
    email: str,
    expires_delta: Optional[timedelta] = None,
) -> Dict[str, Any]:
    now = datetime.now(timezone.utc)
    delta = expires_delta or timedelta(minutes=get_jwt_expire_minutes())
    expire = now + delta
    jti = secrets.token_urlsafe(24)

    payload = {
        "sub": user_id,
        "email": email,
        "jti": jti,
        "iat": int(now.timestamp()),
        "exp": int(expire.timestamp()),
    }
    token = jwt.encode(payload, get_jwt_secret(), algorithm="HS256")
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_at": expire.isoformat(),
        "jti": jti,
    }


def decode_access_token(token: str) -> Dict[str, Any]:
    try:
        payload = jwt.decode(token, get_jwt_secret(), algorithms=["HS256"])
        if not payload.get("sub") or not payload.get("jti"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的身份令牌载荷",
            )
        return payload
    except jwt.ExpiredSignatureError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="登录已过期，请重新登录",
        ) from exc
    except jwt.InvalidTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效的身份认证令牌",
        ) from exc


DEFAULT_WORKSPACE_USER_ID = "default_pet_owner"


def ensure_default_workspace_user(db: Session) -> User:
    user = db.query(User).filter(User.id == DEFAULT_WORKSPACE_USER_ID).first()
    if user:
        return user
    user = User(
        id=DEFAULT_WORKSPACE_USER_ID,
        full_name="PetCare Owner",
        email="owner@petcare.local",
        password_hash="",
        is_active=True,
        email_verified=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if not credentials or credentials.scheme.lower() != "bearer" or not credentials.credentials:
        return ensure_default_workspace_user(db)

    payload = decode_access_token(credentials.credentials)
    jti = str(payload["jti"])
    revoked = db.query(RevokedToken).filter(RevokedToken.jti == jti).first()
    if revoked is not None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="当前会话已退出登录，请重新登录",
        )

    user = db.query(User).filter(User.id == str(payload["sub"])).first()
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="账号不存在或已被停用",
        )
    return user
