import os
import smtplib
from email.message import EmailMessage
from typing import Any, Dict


def is_smtp_configured() -> bool:
    host = os.getenv("SMTP_HOST", "").strip()
    user = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    return bool(host and user and password)


def send_password_reset_email(recipient_email: str, reset_url: str) -> Dict[str, Any]:
    """
    若配置了真实 SMTP 环境变量则通过 SMTP 发送重置邮件；
    若未配置邮件服务，则严禁伪造成功，明确返回开发环境提示与未发送状态。
    """
    if not is_smtp_configured():
        return {
            "smtpConfigured": False,
            "emailSent": False,
            "devNotice": (
                "当前开发环境未配置 SMTP 邮件服务（需设置 SMTP_HOST、SMTP_USER、SMTP_PASSWORD）。"
                "系统不会伪造邮件发送成功；以下提供仅限本地开发测试使用的密码重置链接。"
            ),
            "devResetUrl": reset_url,
        }

    host = os.getenv("SMTP_HOST", "").strip()
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER", "").strip()
    password = os.getenv("SMTP_PASSWORD", "").strip()
    sender = os.getenv("SMTP_FROM", user).strip()

    msg = EmailMessage()
    msg["Subject"] = "PetCare AI — 重置您的登录密码"
    msg["From"] = sender
    msg["To"] = recipient_email
    msg.set_content(
        f"您好，\n\n请访问以下链接在 30 分钟内完成 PetCare AI 密码重置：\n{reset_url}\n\n"
        "如非本人操作，请忽略此邮件。"
    )

    with smtplib.SMTP(host, port, timeout=15) as server:
        server.starttls()
        server.login(user, password)
        server.send_message(msg)

    return {
        "smtpConfigured": True,
        "emailSent": True,
        "devNotice": None,
        "devResetUrl": None,
    }
