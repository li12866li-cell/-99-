import json
import sys
from pathlib import Path
from typing import Any, Dict, List

RULES_JSON_PATH = Path(__file__).resolve().parents[2] / "src" / "data" / "symptom_rules.json"

DANGER_IDS = {
    "dyspnea",
    "seizure",
    "poison_suspected",
    "bloat_distension",
    "urinary_blockage",
    "severe_bleeding",
}

LEVEL_LABEL_MAP = {
    "emergency": "紧急就医",
    "urgent": "需要尽快就医",
    "watch": "一般关注（居家观察）",
}

HEADLINE_MAP = {
    "emergency": "检测到高危急救指征，请立即前往 24 小时宠物急诊医院！",
    "urgent": "存在明显异常症状，建议 12–24 小时内预约线下兽医检查。",
    "watch": "目前主要为轻度常见表现，可先居家细致观察并记录变化。",
}

DISCLAIMER_TEXT = (
    "重要提示：本工具基于本地常见临床分诊规则库进行辅助参考，"
    "绝不能代替专业执业兽医的面对面临床诊断。若宠物精神迅速恶化或您感到不安，请立即就医。"
)


def load_symptom_rules() -> Dict[str, Any]:
    if not RULES_JSON_PATH.exists():
        raise FileNotFoundError(f"未找到症状规则知识库文件: {RULES_JSON_PATH}")
    with RULES_JSON_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def match_symptoms(selected_ids: List[str]) -> Dict[str, Any]:
    kb = load_symptom_rules()
    symptoms_list: List[Dict[str, Any]] = kb.get("symptoms", [])
    combo_rules: List[Dict[str, Any]] = kb.get("combinationRules", [])

    unique_ids: List[str] = []
    seen = set()
    for sid in selected_ids:
        if isinstance(sid, str) and sid and sid not in seen:
            seen.add(sid)
            unique_ids.append(sid)

    selected_set = set(unique_ids)
    matched_symptoms = [s for s in symptoms_list if s.get("id") in selected_set]
    matched_combos = [
        c
        for c in combo_rules
        if all(req_id in selected_set for req_id in c.get("required", []))
    ]

    has_high_danger_signal = any(s.get("id") in DANGER_IDS for s in matched_symptoms)
    total_score = sum(int(s.get("weight", 0)) for s in matched_symptoms)

    level = "watch"
    if (
        has_high_danger_signal
        or any(s.get("severity") == "emergency" for s in matched_symptoms)
        or any(c.get("level") == "emergency" for c in matched_combos)
        or total_score >= 130
    ):
        level = "emergency"
    elif (
        any(s.get("severity") == "urgent" for s in matched_symptoms)
        or any(c.get("level") == "urgent" for c in matched_combos)
        or total_score >= 50
        or len(matched_symptoms) >= 3
    ):
        level = "urgent"

    reasoning: List[str] = []
    for combo in matched_combos:
        reasoning.append(f"【组合规则命中 · {combo['title']}】{combo['reason']}")

    for sym in matched_symptoms:
        sev = sym.get("severity")
        tag = (
            "高危急症信号"
            if sev == "emergency"
            else "中度预警信号"
            if sev == "urgent"
            else "轻度观察信号"
        )
        reasoning.append(f"【{tag}】{sym['name']}：{sym['hint']}")

    advice_list: List[str] = []
    if level == "emergency":
        advice_list.append(
            "如出现呼吸困难、抽搐或疑似中毒，请立即联系最近动物医院并携宠前往急诊，切勿自行喂食人用药或强行灌水催吐。"
        )
        if "poison_suspected" in selected_set:
            advice_list.append(
                "疑似误食物品时，请一并带上残留包装袋/植物照片，并告知宠物体重与误食时间。"
            )
        if "seizure" in selected_set:
            advice_list.append(
                "抽搐发作时请移开周围坚硬物品防止撞伤，切勿把手伸入宠物口腔，记录发作时长送医。"
            )
        if "dyspnea" in selected_set:
            advice_list.append(
                "呼吸困难期间保持环境安静通风，减少抱持压迫胸腔，尽快吸氧评估。"
            )
    elif level == "urgent":
        advice_list.append(
            "建议今日内或次日尽早预约线下宠物医院进行体格检查、血常规或影像排查。"
        )
        advice_list.append(
            "就诊前可记下症状首次出现时间、呕吐/排便照片及近期饮食变化，方便医生快速判断。"
        )
        if "anorexia_24h" in selected_set:
            advice_list.append(
                "若超过 24 小时不吃不喝，尤其猫咪需尽早医院评估以防脱水或脂肪肝。"
            )
    else:
        advice_list.append(
            "保持环境安静温暖，提供洁净饮水并分次少量观察采食和排便情况。"
        )
        advice_list.append(
            "建议在「记录与提醒」中记录今日状态；如 24–48 小时内无好转或精神转差，请及时就医。"
        )

    for combo in matched_combos:
        advice = combo.get("advice", "")
        if advice and advice not in advice_list:
            advice_list.append(advice)

    return {
        "level": level,
        "levelLabel": LEVEL_LABEL_MAP[level],
        "headline": HEADLINE_MAP[level],
        "score": total_score,
        "matchedSymptoms": matched_symptoms,
        "matchedCombos": matched_combos,
        "reasoning": reasoning,
        "adviceList": advice_list,
        "hasHighDangerSignal": has_high_danger_signal,
        "disclaimer": DISCLAIMER_TEXT,
        "knowledgeBaseSource": kb.get("source", ""),
        "updatedAt": kb.get("updatedAt", ""),
        "engine": "python-rule-matcher",
    }


if __name__ == "__main__":
    try:
        raw_input = sys.stdin.read().strip()
        payload = json.loads(raw_input) if raw_input else {}
        action = payload.get("action", "check")
        if action == "rules":
            output = load_symptom_rules()
        else:
            symptom_ids = payload.get("symptomIds") or []
            if not isinstance(symptom_ids, list) or len(symptom_ids) == 0:
                raise ValueError("请至少选择一项观察到的症状")
            output = match_symptoms(symptom_ids)
        sys.stdout.write(json.dumps(output, ensure_ascii=False))
    except Exception as exc:
        sys.stderr.write(str(exc))
        sys.exit(1)
