# Services package for DeepSeek AI Vet and Kakao/Haversine hospital distance calculations
