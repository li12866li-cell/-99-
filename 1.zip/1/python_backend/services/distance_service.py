import json
import math
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote
import httpx

HOSPITAL_JSON_PATH = Path(__file__).resolve().parents[2] / "src" / "data" / "pet_hospital.json"
_geocode_cache: Dict[str, Tuple[float, float]] = {}


def is_kakao_configured() -> bool:
    key = os.getenv("KAKAO_MAP_API_KEY", "").strip()
    return bool(key and key != "MY_KAKAO_REST_API_KEY")


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    earth_radius_km = 6371.0
    d_lat = math.radians(lat2 - lat1)
    d_lng = math.radians(lng2 - lng1)
    a = (
        math.sin(d_lat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(d_lng / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return earth_radius_km * c


def format_distance_text(distance_km: Optional[float]) -> str:
    if distance_km is None:
        return "距离待定位"
    if distance_km < 1.0:
        return f"{round(distance_km * 1000)} m"
    return f"{distance_km:.1f} km"


async def geocode_with_kakao(
    client: httpx.AsyncClient,
    address: str,
    hospital_name: str,
    kakao_key: str,
) -> Optional[Tuple[float, float]]:
    cache_key = f"{address}|{hospital_name}"
    if cache_key in _geocode_cache:
        return _geocode_cache[cache_key]

    headers = {"Authorization": f"KakaoAK {kakao_key}"}
    try:
        resp = await client.get(
            "https://dapi.kakao.com/v2/local/search/address.json",
            params={"query": address},
            headers=headers,
        )
        if resp.status_code == 200:
            docs = resp.json().get("documents", [])
            if docs:
                lat, lng = float(docs[0]["y"]), float(docs[0]["x"])
                _geocode_cache[cache_key] = (lat, lng)
                return lat, lng
    except Exception:
        pass
    return None


def load_raw_hospitals() -> List[Dict[str, Any]]:
    if not HOSPITAL_JSON_PATH.exists():
        return []
    with HOSPITAL_JSON_PATH.open("r", encoding="utf-8") as f:
        data = json.load(f)
        return data if isinstance(data, list) else []


async def get_nearby_hospitals(
    lat: Optional[float] = None,
    lng: Optional[float] = None,
    city: str = "all",
) -> Dict[str, Any]:
    kakao_key = os.getenv("KAKAO_MAP_API_KEY", "").strip()
    kakao_configured = is_kakao_configured()
    has_user_coords = lat is not None and lng is not None

    raw_records = [
        item
        for item in load_raw_hospitals()
        if city == "all" or item.get("city") == city
    ]

    results: List[Dict[str, Any]] = []
    async with httpx.AsyncClient(timeout=10.0) as client:
        for item in raw_records:
            resolved: Optional[Tuple[float, float]] = None
            geocoded_by = "none"

            if kakao_configured:
                resolved = await geocode_with_kakao(
                    client, item.get("address", ""), item.get("name", ""), kakao_key
                )
                if resolved:
                    geocoded_by = "kakao"

            if not resolved and isinstance(item.get("fallbackLat"), (int, float)) and isinstance(
                item.get("fallbackLng"), (int, float)
            ):
                resolved = (float(item["fallbackLat"]), float(item["fallbackLng"]))
                geocoded_by = "fallback"

            distance_km = (
                haversine_km(lat, lng, resolved[0], resolved[1])
                if has_user_coords and resolved is not None
                else None
            )

            name_enc = quote(item.get("name", ""))
            kakao_map_url = (
                f"https://map.kakao.com/link/map/{name_enc},{resolved[0]},{resolved[1]}"
                if resolved
                else f"https://map.kakao.com/link/search/{quote(item.get('address') or item.get('name', ''))}"
            )

            results.append(
                {
                    "id": item.get("id", ""),
                    "name": item.get("name", ""),
                    "city": item.get("city", ""),
                    "cityLabel": item.get("cityLabel", ""),
                    "district": item.get("district", ""),
                    "address": item.get("address", ""),
                    "phone": item.get("phone", ""),
                    "lat": resolved[0] if resolved else None,
                    "lng": resolved[1] if resolved else None,
                    "distanceKm": distance_km,
                    "distanceText": format_distance_text(distance_km),
                    "kakaoMapUrl": kakao_map_url,
                    "geocodedBy": geocoded_by,
                }
            )

    results.sort(key=lambda x: (x["distanceKm"] is None, x["distanceKm"] or 0.0))

    return {
        "hospitals": results,
        "kakaoConfigured": kakao_configured,
        "total": len(results),
    }
