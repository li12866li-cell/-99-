import json
import os
from typing import Any, AsyncGenerator, Dict, List, Optional
import httpx

DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_MODEL = "deepseek-chat"


def get_deepseek_api_key() -> str:
    raw = os.getenv("DEEPSEEK_API_KEY", "").strip()
    if not raw or raw == "MY_DEEPSEEK_API_KEY":
        return ""
    return raw


def format_pet_context(pet_context: Optional[Dict[str, Any]]) -> str:
    if not pet_context:
        return ""
    species_map = {"dog": "狗狗", "cat": "猫咪", "bunny": "兔子", "other": "宠物"}
    parts = [
        pet_context.get("name"),
        species_map.get(pet_context.get("species") or "", pet_context.get("species")),
        pet_context.get("breed"),
        f"{pet_context['age']}岁" if pet_context.get("age") else None,
        f"{pet_context['weight']}kg" if pet_context.get("weight") else None,
        "公" if pet_context.get("gender") == "male" else ("母" if pet_context.get("gender") == "female" else None),
        "已绝育" if pet_context.get("isNeutered") is True else ("未绝育" if pet_context.get("isNeutered") is False else None),
    ]
    return " / ".join([str(p) for p in parts if p])


def build_system_prompt(language: str, pet_info: str) -> str:
    pet_clause = (
        f"\n当前关联宠物档案：{pet_info}。请结合宠物的物种、品种与体重给出针对性分诊与护理建议。"
        if pet_info
        else ""
    )
    if language == "en":
        return (
            "You are PetCare AI's Veterinary Assistant powered by DeepSeek. "
            "Respond in clear plain text without markdown syntax (no ** or #)."
            + (f"\nCurrent Pet Profile: {pet_info}." if pet_info else "")
        )
    return (
        "你是「宠爱脉动 PetCare AI」的在线 AI 兽医助手。"
        "请用清晰易懂的纯文本分段回答（不使用 ** 或 # 等 Markdown 符号），涵盖：可能原因、居家建议、就医提醒。"
        + pet_clause
    )


def extract_user_text(message: Any) -> str:
    if isinstance(message, str):
        return message.strip()
    if isinstance(message, list):
        texts = [str(p.get("text", "")).strip() for p in message if isinstance(p, dict) and p.get("text")]
        return "\n".join([t for t in texts if t]) or "请帮我看看宠物上传的图片或症状。"
    return str(message or "").strip()


def build_messages(
    system_prompt: str,
    history: Optional[List[Dict[str, Any]]],
    user_text: str,
) -> List[Dict[str, str]]:
    messages: List[Dict[str, str]] = [{"role": "system", "content": system_prompt}]
    if history:
        for turn in history[-12:]:
            role = "user" if turn.get("role") == "user" else "assistant"
            text = (turn.get("text") or "").strip()
            if not text and isinstance(turn.get("parts"), list):
                text = "\n".join(
                    [str(p.get("text", "")).strip() for p in turn["parts"] if isinstance(p, dict) and p.get("text")]
                )
            if not text:
                continue
            if len(messages) == 1 and role != "user":
                continue
            messages.append({"role": role, "content": text})
    messages.append({"role": "user", "content": user_text})
    return messages


def get_vet_status() -> Dict[str, Any]:
    configured = bool(get_deepseek_api_key())
    return {
        "deepseekConfigured": configured,
        "geminiConfigured": False,
        "googleSearchAvailable": False,
        "activeProvider": "deepseek" if configured else "local-demo",
        "statusText": (
            "Python FastAPI DeepSeek 服务已连接"
            if configured
            else "Python FastAPI 未检测到 DEEPSEEK_API_KEY，当前返回明确标注的离线演示分诊回答"
        ),
    }


async def chat_completion(
    history: Optional[List[Dict[str, Any]]],
    message: Any,
    language: str = "zh",
    pet_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    api_key = get_deepseek_api_key()
    pet_info = format_pet_context(pet_context)
    user_text = extract_user_text(message)

    if not api_key:
        demo_reply = (
            f"【离线 Demo 分诊提示】当前 Python 后端尚未配置 DEEPSEEK_API_KEY。\n"
            f"已关联档案：{pet_info or '未关联'}；您提问的内容为：「{user_text}」。\n"
            f"居家观察：注意记录精神状态、食欲、体温与排泄物变化；若出现持续呕吐、呼吸困难或便血，请立即前往正规宠物医院。"
        )
        return {
            "response": demo_reply,
            "engine": "local-demo",
            "deepseekConfigured": False,
            "sources": [],
        }

    system_prompt = build_system_prompt(language, pet_info)
    messages = build_messages(system_prompt, history, user_text)

    async with httpx.AsyncClient(timeout=45.0) as client:
        resp = await client.post(
            DEEPSEEK_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": DEEPSEEK_MODEL,
                "messages": messages,
                "temperature": 0.4,
                "stream": False,
            },
        )
        if resp.status_code != 200:
            raise RuntimeError(f"DeepSeek API 调用失败 ({resp.status_code}): {resp.text[:160]}")
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        return {
            "response": content,
            "engine": "deepseek",
            "deepseekConfigured": True,
            "sources": [],
        }


async def stream_chat_completion(
    history: Optional[List[Dict[str, Any]]],
    message: Any,
    language: str = "zh",
    pet_context: Optional[Dict[str, Any]] = None,
) -> AsyncGenerator[str, None]:
    api_key = get_deepseek_api_key()
    pet_info = format_pet_context(pet_context)
    user_text = extract_user_text(message)

    meta_payload = {
        "meta": {
            "engine": "deepseek" if api_key else "local-demo",
            "deepseekConfigured": bool(api_key),
            "sources": [],
        }
    }
    yield f"data: {json.dumps(meta_payload, ensure_ascii=False)}\n\n"

    if not api_key:
        result = await chat_completion(history, message, language, pet_context)
        yield f"data: {json.dumps({'chunk': result['response']}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"
        return

    system_prompt = build_system_prompt(language, pet_info)
    messages = build_messages(system_prompt, history, user_text)

    async with httpx.AsyncClient(timeout=60.0) as client:
        async with client.stream(
            "POST",
            DEEPSEEK_API_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": DEEPSEEK_MODEL,
                "messages": messages,
                "temperature": 0.4,
                "stream": True,
            },
        ) as resp:
            if resp.status_code != 200:
                err_text = (await resp.aread()).decode("utf-8", errors="ignore")
                yield f"data: {json.dumps({'error': f'DeepSeek API 失败 ({resp.status_code}): {err_text[:120]}'}, ensure_ascii=False)}\n\n"
                return

            async for line in resp.aiter_lines():
                trimmed = line.strip()
                if not trimmed or not trimmed.startswith("data:"):
                    continue
                payload = trimmed[5:].strip()
                if payload == "[DONE]":
                    yield "data: [DONE]\n\n"
                    return
                try:
                    parsed = json.loads(payload)
                    delta = parsed.get("choices", [{}])[0].get("delta", {}).get("content")
                    if delta:
                        yield f"data: {json.dumps({'chunk': delta}, ensure_ascii=False)}\n\n"
                except json.JSONDecodeError:
                    continue
