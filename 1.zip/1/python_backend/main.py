import os
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import init_db
from routers import auth, hospitals, medical_records, pets, records, reminders, symptoms, vet
from services.deepseek_service import get_vet_status
from services.distance_service import is_kakao_configured
from services.email_service import is_smtp_configured

load_dotenv()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="PetCare AI FastAPI Backend",
    description="独立 Python FastAPI 后端服务：用户认证与 JWT 鉴权、SQLite+SQLAlchemy 数据隔离、宠物档案 CRUD、DeepSeek AI 兽医代理、附近宠物医院距离计算、护理提醒管理。",
    version="2.0.0",
    lifespan=lifespan,
)

cors_raw = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000")
allow_origins = [origin.strip() for origin in cors_raw.split(",") if origin.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(pets.router, prefix="/api")
app.include_router(records.router, prefix="/api")
app.include_router(medical_records.router, prefix="/api")
app.include_router(reminders.router, prefix="/api")
app.include_router(symptoms.router, prefix="/api")
app.include_router(vet.router, prefix="/api")
app.include_router(hospitals.router, prefix="/api")


@app.get("/api/health")
def health_check():
    vet_info = get_vet_status()
    return {
        "ok": True,
        "runtime": "python-fastapi",
        "database": "sqlite+sqlalchemy",
        "smtpConfigured": is_smtp_configured(),
        **vet_info,
        "kakaoConfigured": is_kakao_configured(),
    }
