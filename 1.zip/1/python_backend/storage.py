import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

DATA_DIR = Path(__file__).resolve().parent / "data"
DB_PATH = DATA_DIR / "petcare_db.json"

_lock = threading.Lock()

SEED_STATE: Dict[str, Any] = {
    "pets": [
        {
            "id": "pet_bella",
            "name": "Bella",
            "species": "dog",
            "breed": "金毛寻回犬",
            "gender": "female",
            "age": 3,
            "weight": 28.0,
            "isNeutered": True,
            "avatar": "/src/assets/images/golden_retriever_dog_1794751022608.jpg",
            "diet": json.dumps(
                [
                    {"name": "天然三文鱼无谷成犬粮", "amount": "220"},
                    {"name": "冻干鸡肉粒", "amount": "30"},
                ],
                ensure_ascii=False,
            ),
            "water": "850ml",
            "vaccineStatus": "2026-12-15",
            "companionStartDate": "2024-03-10",
            "isDemo": True,
            "updatedAt": "2026-11-20T08:00:00Z",
        },
        {
            "id": "pet_mochi",
            "name": "Mochi",
            "species": "cat",
            "breed": "英国短毛猫",
            "gender": "male",
            "age": 2,
            "weight": 4.6,
            "isNeutered": True,
            "avatar": "/src/assets/images/british_shorthair_cat_1794751020533.jpg",
            "diet": json.dumps(
                [
                    {"name": "全价室内成猫粮", "amount": "55"},
                    {"name": "鸡肉主食罐头", "amount": "85"},
                ],
                ensure_ascii=False,
            ),
            "water": "240ml",
            "vaccineStatus": "2026-11-28",
            "companionStartDate": "2025-01-15",
            "isDemo": True,
            "updatedAt": "2026-11-20T08:00:00Z",
        },
    ],
    "records": [
        {
            "id": "rec_1",
            "petId": "pet_bella",
            "date": "2026-05-15",
            "type": "medical",
            "title": "常规称重与体检 (Weight)",
            "content": "26.4 kg，精神食欲良好，心肺听诊正常。",
            "weightKg": 26.4,
            "isDemo": True,
        },
        {
            "id": "rec_2",
            "petId": "pet_bella",
            "date": "2026-07-20",
            "type": "vaccine",
            "title": "年度狂犬及联苗加强",
            "content": "接种顺利，注射部位无硬结。",
            "weightKg": 27.1,
            "isDemo": True,
        },
        {
            "id": "rec_3",
            "petId": "pet_bella",
            "date": "2026-11-10",
            "type": "medical",
            "title": "11 月复称体重 (Weight)",
            "content": "28.0 kg，体况评分 BCS 5/9 理想范围。",
            "weightKg": 28.0,
            "isDemo": True,
        },
        {
            "id": "rec_4",
            "petId": "pet_mochi",
            "date": "2026-11-05",
            "type": "medical",
            "title": "11 月复称体重 (Weight)",
            "content": "4.6 kg，建议增加每天 2 次逗猫棒互动。",
            "weightKg": 4.6,
            "isDemo": True,
        },
    ],
    "reminders": [
        {
            "id": "rem_1",
            "petId": "pet_bella",
            "title": "每月体外驱虫滴剂",
            "category": "deworming",
            "dueDate": "2026-11-25",
            "dueTime": "20:00",
            "repeat": "monthly",
            "notes": "滴在肩胛骨后方皮肤处，用药后 48 小时内不洗澡。",
            "completed": False,
            "createdAt": "2026-11-01T09:00:00Z",
            "isDemo": True,
        },
        {
            "id": "rem_2",
            "petId": "pet_mochi",
            "title": "化毛膏喂食与梳毛护理",
            "category": "grooming",
            "dueDate": "2026-11-22",
            "dueTime": "19:30",
            "repeat": "weekly",
            "notes": "秋季换毛季每周 2-3 次梳理浮毛。",
            "completed": True,
            "createdAt": "2026-11-03T09:00:00Z",
            "isDemo": True,
        },
    ],
}

AVATAR_BY_SPECIES = {
    "dog": "/src/assets/images/golden_retriever_dog_1794751022608.jpg",
    "cat": "/src/assets/images/british_shorthair_cat_1794751020533.jpg",
    "bunny": "/src/assets/images/bunny_model_natural_1794231711465.jpg",
    "other": "/src/assets/images/golden_retriever_dog_1794751022608.jpg",
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_state() -> Dict[str, Any]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        try:
            with DB_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and isinstance(data.get("pets"), list):
                    return data
        except Exception:
            pass
    seeded = json.loads(json.dumps(SEED_STATE))
    _save_state(seeded)
    return seeded


def _save_state(state: Dict[str, Any]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with DB_PATH.open("w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def list_pets() -> List[Dict[str, Any]]:
    with _lock:
        return _load_state()["pets"]


def create_pet(payload: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        state = _load_state()
        species = payload.get("species", "dog")
        pet = {
            **payload,
            "id": f"pet_{int(time.time() * 1000)}",
            "avatar": payload.get("avatar") or AVATAR_BY_SPECIES.get(species, AVATAR_BY_SPECIES["dog"]),
            "companionStartDate": payload.get("companionStartDate") or datetime.now().strftime("%Y-%m-%d"),
            "isDemo": False,
            "updatedAt": _now_iso(),
        }
        state["pets"].append(pet)
        _save_state(state)
        return pet


def update_pet(pet_id: str, patch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    with _lock:
        state = _load_state()
        for idx, item in enumerate(state["pets"]):
            if item["id"] == pet_id:
                clean_patch = {k: v for k, v in patch.items() if v is not None}
                updated = {**item, **clean_patch, "id": pet_id, "updatedAt": _now_iso()}
                state["pets"][idx] = updated
                _save_state(state)
                return updated
        return None


def delete_pet(pet_id: str) -> bool:
    with _lock:
        state = _load_state()
        before = len(state["pets"])
        state["pets"] = [p for p in state["pets"] if p["id"] != pet_id]
        if len(state["pets"]) == before:
            return False
        state["records"] = [r for r in state["records"] if r["petId"] != pet_id]
        state["reminders"] = [rem for rem in state["reminders"] if rem["petId"] != pet_id]
        _save_state(state)
        return True


def list_records(pet_id: Optional[str] = None) -> List[Dict[str, Any]]:
    with _lock:
        records = _load_state()["records"]
        if pet_id:
            records = [r for r in records if r["petId"] == pet_id]
        return sorted(records, key=lambda r: r["date"], reverse=True)


def create_record(payload: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        state = _load_state()
        record = {
            **payload,
            "id": f"rec_{int(time.time() * 1000)}",
            "isDemo": False,
        }
        state["records"].append(record)
        weight_kg = record.get("weightKg")
        if isinstance(weight_kg, (int, float)) and weight_kg > 0:
            for idx, p in enumerate(state["pets"]):
                if p["id"] == record["petId"]:
                    state["pets"][idx] = {**p, "weight": weight_kg, "updatedAt": _now_iso()}
                    break
        _save_state(state)
        return record


def delete_record(record_id: str) -> bool:
    with _lock:
        state = _load_state()
        before = len(state["records"])
        state["records"] = [r for r in state["records"] if r["id"] != record_id]
        if len(state["records"]) == before:
            return False
        _save_state(state)
        return True


def list_reminders(pet_id: Optional[str] = None) -> List[Dict[str, Any]]:
    with _lock:
        reminders = _load_state()["reminders"]
        if pet_id:
            reminders = [r for r in reminders if r["petId"] == pet_id]
        return sorted(reminders, key=lambda r: r["dueDate"])


def create_reminder(payload: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        state = _load_state()
        reminder = {
            **payload,
            "id": f"rem_{int(time.time() * 1000)}",
            "completed": False,
            "createdAt": _now_iso(),
            "isDemo": False,
        }
        state["reminders"].append(reminder)
        _save_state(state)
        return reminder


def update_reminder(reminder_id: str, patch: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    with _lock:
        state = _load_state()
        for idx, item in enumerate(state["reminders"]):
            if item["id"] == reminder_id:
                clean_patch = {k: v for k, v in patch.items() if v is not None}
                updated = {**item, **clean_patch, "id": reminder_id}
                state["reminders"][idx] = updated
                _save_state(state)
                return updated
        return None


def delete_reminder(reminder_id: str) -> bool:
    with _lock:
        state = _load_state()
        before = len(state["reminders"])
        state["reminders"] = [r for r in state["reminders"] if r["id"] != reminder_id]
        if len(state["reminders"]) == before:
            return False
        _save_state(state)
        return True
