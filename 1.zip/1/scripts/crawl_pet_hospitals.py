#!/usr/bin/env python3
"""
独立离线爬虫脚本：采集韩国水原(수원시)、清州(청주시)公开宠物医院信息并保存为 src/data/pet_hospital.json。
说明：
1. 本脚本与网页 Node.js/React 运行代码完全分离，仅需在答辩前本地或 Replit Shell 手动运行一次。
2. 网页正式运行时仅读取生成的 pet_hospital.json，不会执行爬虫，规避现场网络与反爬风险。

使用方式：
  pip install requests
  export KAKAO_MAP_API_KEY="你的Kakao_REST_API_Key"   # 可选：优先通过 Kakao Local 公开接口采集最新营业医院
  python scripts/crawl_pet_hospitals.py
"""

import json
import os
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

import requests

OUTPUT_PATH = Path(__file__).resolve().parent.parent / "src" / "data" / "pet_hospital.json"

SEARCH_TARGETS = [
    ("suwon", "수원시", "영통구", "수원시 영통구 동물병원"),
    ("suwon", "수원시", "팔달구", "수원시 팔달구 동물병원"),
    ("suwon", "수원시", "장안구", "수원시 장안구 동물병원"),
    ("suwon", "수원시", "권선구", "수원시 권선구 동물병원"),
    ("cheongju", "청주시", "흥덕구", "청주시 흥덕구 동물병원"),
    ("cheongju", "청주시", "서원구", "청주시 서원구 동물병원"),
    ("cheongju", "청주시", "상당구", "청주시 상당구 동물병원"),
    ("cheongju", "청주시", "청원구", "청주시 청원구 동물병원"),
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.8",
}


def clean_text(val: Optional[str]) -> str:
    if not val:
        return ""
    return re.sub(r"\s+", " ", val).strip()


def fetch_from_kakao_local(api_key: str) -> List[Dict]:
    """通过 Kakao Local Keyword Search 公开 REST API 合法抓取水原/清州动物医院列表。"""
    results: List[Dict] = []
    seen_keys = set()
    url = "https://dapi.kakao.com/v2/local/search/keyword.json"
    headers = {"Authorization": f"KakaoAK {api_key}"}

    for city_code, city_label, district, query in SEARCH_TARGETS:
        try:
            resp = requests.get(
                url,
                headers=headers,
                params={"query": query, "category_group_code": "HP8", "size": 10},
                timeout=10,
            )
            if resp.status_code != 200:
                print(f"[WARN] Kakao API 返回 {resp.status_code} ({query}): {resp.text[:120]}")
                continue

            docs = resp.json().get("documents", [])
            for doc in docs:
                name = clean_text(doc.get("place_name"))
                address = clean_text(doc.get("road_address_name") or doc.get("address_name"))
                phone = clean_text(doc.get("phone")) or "전화문의"
                if not name or not address:
                    continue
                if city_label[:2] not in address:
                    continue

                dedup_key = f"{name}|{address}"
                if dedup_key in seen_keys:
                    continue
                seen_keys.add(dedup_key)

                results.append(
                    {
                        "id": f"{city_code}-{len(results) + 1}",
                        "name": name,
                        "city": city_code,
                        "cityLabel": city_label,
                        "district": district,
                        "address": address,
                        "phone": phone,
                        "fallbackLat": float(doc["y"]) if doc.get("y") else None,
                        "fallbackLng": float(doc["x"]) if doc.get("x") else None,
                    }
                )
            time.sleep(0.25)
        except Exception as exc:
            print(f"[WARN] 抓取 {query} 失败: {exc}")

    return results


def fetch_from_public_web() -> List[Dict]:
    """无 Kakao 密钥时的公开网页/OpenStreetMap Overpass API 备选采集器。"""
    results: List[Dict] = []
    seen_keys = set()
    overpass_url = "https://overpass-api.de/api/interpreter"
    # 查询水原、清州周边公开标注的兽医诊所 (amenity=veterinary)
    overpass_query = """
    [out:json][timeout:25];
    (
      node["amenity"="veterinary"](37.20,126.92,37.33,127.10);
      way["amenity"="veterinary"](37.20,126.92,37.33,127.10);
      node["amenity"="veterinary"](36.57,127.38,36.70,127.55);
      way["amenity"="veterinary"](36.57,127.38,36.70,127.55);
    );
    out center tags;
    """
    try:
        resp = requests.post(overpass_url, data={"data": overpass_query}, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        elements = resp.json().get("elements", [])
        for el in elements:
            tags = el.get("tags", {})
            name = clean_text(tags.get("name:ko") or tags.get("name"))
            if not name:
                continue
            lat = el.get("lat") or (el.get("center") or {}).get("lat")
            lng = el.get("lon") or (el.get("center") or {}).get("lon")
            if lat is None or lng is None:
                continue

            is_suwon = float(lat) > 37.0
            city_code = "suwon" if is_suwon else "cheongju"
            city_label = "수원시" if is_suwon else "청주시"
            street = clean_text(tags.get("addr:street"))
            housenumber = clean_text(tags.get("addr:housenumber"))
            full_addr = clean_text(tags.get("addr:full")) or clean_text(f"{city_label} {street} {housenumber}")
            phone = clean_text(tags.get("phone") or tags.get("contact:phone")) or "전화문의"

            dedup_key = f"{name}|{full_addr}"
            if dedup_key in seen_keys:
                continue
            seen_keys.add(dedup_key)

            results.append(
                {
                    "id": f"{city_code}-{len(results) + 1}",
                    "name": name,
                    "city": city_code,
                    "cityLabel": city_label,
                    "district": clean_text(tags.get("addr:district")) or "",
                    "address": full_addr,
                    "phone": phone,
                    "fallbackLat": float(lat),
                    "fallbackLng": float(lng),
                }
            )
    except Exception as exc:
        print(f"[WARN] Overpass 公开数据采集失败: {exc}")

    return results


def main() -> None:
    kakao_key = os.getenv("KAKAO_MAP_API_KEY", "").strip()
    hospitals: List[Dict] = []

    if kakao_key and kakao_key != "MY_KAKAO_REST_API_KEY":
        print("[INFO] 检测到 KAKAO_MAP_API_KEY，正在采集水原·清州宠物医院...")
        hospitals = fetch_from_kakao_local(kakao_key)

    if not hospitals:
        print("[INFO] 使用公开地理数据备选源采集水原·清州宠物医院...")
        hospitals = fetch_from_public_web()

    if not hospitals:
        print("[WARN] 本次在线采集未获取到新数据，保留现有 pet_hospital.json。")
        return

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(hospitals, f, ensure_ascii=False, indent=2)

    print(f"[SUCCESS] 已成功保存 {len(hospitals)} 家宠物医院至 {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
