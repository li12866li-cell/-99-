import fs from 'fs';
import path from 'path';

export interface StoreUser {
  id: string;
  fullName: string;
  email: string;
  passwordHash: string;
  avatarUrl: string | null;
  isActive: boolean;
  emailVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface StorePasswordResetToken {
  id: string;
  userId: string;
  tokenHash: string;
  expiresAt: string;
  usedAt: string | null;
  createdAt: string;
}

export interface StoreRevokedToken {
  jti: string;
  userId: string;
  expiresAt: string;
  revokedAt: string;
}

export interface StorePet {
  id: string;
  userId: string;
  name: string;
  species: 'dog' | 'cat' | 'bunny' | 'other';
  breed?: string;
  gender: 'male' | 'female';
  age?: number;
  weight?: number;
  isNeutered: boolean;
  avatar?: string;
  diet?: string;
  water?: string;
  vaccineStatus?: string;
  companionStartDate?: string;
  isDemo?: boolean;
  updatedAt?: string;
}

export interface StoreHealthRecord {
  id: string;
  userId: string;
  petId: string;
  date: string;
  type: 'vaccine' | 'activity' | 'diet' | 'medical';
  title: string;
  content: string;
  weightKg?: number;
  isDemo?: boolean;
}

export interface StoreReminder {
  id: string;
  userId: string;
  petId: string;
  title: string;
  category: 'vaccine' | 'deworming' | 'medication' | 'checkup' | 'grooming';
  dueDate: string;
  dueTime?: string;
  repeat: 'once' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  notes?: string;
  completed: boolean;
  createdAt: string;
  isDemo?: boolean;
}

export interface StoreMedicalAttachment {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  dataUrl: string;
}

export interface StoreMedicalRecord {
  id: string;
  userId: string;
  petId: string;
  title: string;
  date: string;
  hospitalName: string;
  category: 'lab' | 'imaging' | 'vaccine' | 'prescription' | 'checkup' | 'other';
  results: string;
  attachments: StoreMedicalAttachment[];
  createdAt: string;
}

export interface StoreChatMessage {
  id: string;
  userId: string;
  petId: string;
  role: 'user' | 'model';
  text: string;
  image?: string;
  engine?: string;
  sources?: Array<{ title: string; url: string }>;
  timestamp: string;
}

interface StoreState {
  users: StoreUser[];
  passwordResetTokens: StorePasswordResetToken[];
  revokedTokens: StoreRevokedToken[];
  pets: StorePet[];
  records: StoreHealthRecord[];
  medicalRecords: StoreMedicalRecord[];
  reminders: StoreReminder[];
  chatMessages: StoreChatMessage[];
}

const DATA_DIR = path.resolve(process.cwd(), 'server', '.data');
const STORE_PATH = path.join(DATA_DIR, 'petcare_store.json');

const EMPTY_STATE: StoreState = {
  users: [],
  passwordResetTokens: [],
  revokedTokens: [],
  pets: [],
  records: [],
  medicalRecords: [],
  reminders: [],
  chatMessages: [],
};

let memoryState: StoreState | null = null;

function loadState(): StoreState {
  if (memoryState) return memoryState;
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        memoryState = {
          users: Array.isArray(parsed.users) ? parsed.users : [],
          passwordResetTokens: Array.isArray(parsed.passwordResetTokens)
            ? parsed.passwordResetTokens
            : [],
          revokedTokens: Array.isArray(parsed.revokedTokens) ? parsed.revokedTokens : [],
          // Legacy unowned demo items (without userId) are dropped to guarantee strict per-user isolation
          pets: Array.isArray(parsed.pets) ? parsed.pets.filter((p: any) => Boolean(p?.userId)) : [],
          records: Array.isArray(parsed.records)
            ? parsed.records.filter((r: any) => Boolean(r?.userId))
            : [],
          medicalRecords: Array.isArray(parsed.medicalRecords)
            ? parsed.medicalRecords.filter((m: any) => Boolean(m?.userId))
            : [],
          reminders: Array.isArray(parsed.reminders)
            ? parsed.reminders.filter((r: any) => Boolean(r?.userId))
            : [],
          chatMessages: Array.isArray(parsed.chatMessages)
            ? parsed.chatMessages.filter((m: any) => Boolean(m?.userId))
            : [],
        };
        return memoryState;
      }
    }
  } catch (err) {
    console.warn('Could not read persisted store, initializing empty isolated store:', err);
  }
  memoryState = JSON.parse(JSON.stringify(EMPTY_STATE));
  persistState(memoryState!);
  return memoryState!;
}

function persistState(state: StoreState): void {
  memoryState = state;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(STORE_PATH, JSON.stringify(state, null, 2), 'utf-8');
  } catch (err) {
    console.warn('Could not persist store to disk (using memory):', err);
  }
}

export const DEFAULT_WORKSPACE_USER_ID = 'default_pet_owner';

export const petcareStore = {
  // ========================
  // Users & Tokens
  // ========================
  ensureDefaultWorkspaceUser(): StoreUser {
    const state = loadState();
    const existing = state.users.find((u) => u.id === DEFAULT_WORKSPACE_USER_ID);
    if (existing) return existing;

    const now = new Date().toISOString();
    const defaultUser: StoreUser = {
      id: DEFAULT_WORKSPACE_USER_ID,
      fullName: 'PetCare Owner',
      email: 'owner@petcare.local',
      passwordHash: '',
      avatarUrl: null,
      isActive: true,
      emailVerified: true,
      createdAt: now,
      updatedAt: now,
    };
    state.users.push(defaultUser);
    persistState(state);

    if (this.listPetsByUser(DEFAULT_WORKSPACE_USER_ID).length === 0) {
      this.seedDemoForUser(DEFAULT_WORKSPACE_USER_ID);
    }
    return defaultUser;
  },

  findUserByEmail(email: string): StoreUser | undefined {
    const target = email.trim().toLowerCase();
    return loadState().users.find((u) => u.email.toLowerCase() === target);
  },

  findUserById(id: string): StoreUser | undefined {
    return loadState().users.find((u) => u.id === id);
  },

  createUser(user: StoreUser): StoreUser {
    const state = loadState();
    state.users.push(user);
    persistState(state);
    return user;
  },

  updateUser(id: string, patch: Partial<StoreUser>): StoreUser | null {
    const state = loadState();
    const idx = state.users.findIndex((u) => u.id === id);
    if (idx === -1) return null;
    state.users[idx] = {
      ...state.users[idx],
      ...patch,
      id,
      updatedAt: new Date().toISOString(),
    };
    persistState(state);
    return state.users[idx];
  },

  createPasswordResetToken(entry: StorePasswordResetToken): StorePasswordResetToken {
    const state = loadState();
    state.passwordResetTokens.push(entry);
    persistState(state);
    return entry;
  },

  findPasswordResetByHash(tokenHash: string): StorePasswordResetToken | undefined {
    return loadState().passwordResetTokens.find((t) => t.tokenHash === tokenHash);
  },

  markPasswordResetUsed(id: string): void {
    const state = loadState();
    const idx = state.passwordResetTokens.findIndex((t) => t.id === id);
    if (idx !== -1) {
      state.passwordResetTokens[idx] = {
        ...state.passwordResetTokens[idx],
        usedAt: new Date().toISOString(),
      };
      persistState(state);
    }
  },

  isTokenRevoked(jti: string): boolean {
    return loadState().revokedTokens.some((t) => t.jti === jti);
  },

  revokeToken(entry: StoreRevokedToken): void {
    const state = loadState();
    if (!state.revokedTokens.some((t) => t.jti === entry.jti)) {
      state.revokedTokens.push(entry);
      // Clean up expired revoked entries
      const nowMs = Date.now();
      state.revokedTokens = state.revokedTokens.filter(
        (t) => new Date(t.expiresAt).getTime() > nowMs
      );
      persistState(state);
    }
  },

  // ========================
  // Pets (Scoped by userId)
  // ========================
  listPetsByUser(userId: string): StorePet[] {
    return loadState().pets.filter((p) => p.userId === userId);
  },

  findPetById(id: string): StorePet | undefined {
    return loadState().pets.find((p) => p.id === id);
  },

  createPet(userId: string, input: Omit<StorePet, 'id' | 'userId' | 'updatedAt'>): StorePet {
    const state = loadState();
    const avatarBySpecies: Record<string, string> = {
      dog: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
      cat: '/src/assets/images/british_shorthair_cat_1794751020533.jpg',
      bunny: '/src/assets/images/bunny_model_natural_1794231711465.jpg',
      other: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
    };
    const pet: StorePet = {
      ...input,
      id: `pet_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      userId,
      avatar: input.avatar || avatarBySpecies[input.species] || avatarBySpecies.dog,
      isDemo: Boolean(input.isDemo),
      updatedAt: new Date().toISOString(),
    };
    state.pets.push(pet);
    persistState(state);
    return pet;
  },

  updatePet(
    userId: string,
    id: string,
    patch: Partial<StorePet>
  ): { status: 'ok'; pet: StorePet } | { status: 'not_found' | 'forbidden' } {
    const state = loadState();
    const idx = state.pets.findIndex((p) => p.id === id);
    if (idx === -1) return { status: 'not_found' };
    if (state.pets[idx].userId !== userId) return { status: 'forbidden' };
    const updated: StorePet = {
      ...state.pets[idx],
      ...patch,
      id,
      userId,
      updatedAt: new Date().toISOString(),
    };
    state.pets[idx] = updated;
    persistState(state);
    return { status: 'ok', pet: updated };
  },

  deletePet(
    userId: string,
    id: string
  ): 'ok' | 'not_found' | 'forbidden' {
    const state = loadState();
    const target = state.pets.find((p) => p.id === id);
    if (!target) return 'not_found';
    if (target.userId !== userId) return 'forbidden';

    state.pets = state.pets.filter((p) => p.id !== id);
    state.records = state.records.filter((r) => !(r.petId === id && r.userId === userId));
    state.medicalRecords = state.medicalRecords.filter(
      (m) => !(m.petId === id && m.userId === userId)
    );
    state.reminders = state.reminders.filter((rem) => !(rem.petId === id && rem.userId === userId));
    state.chatMessages = state.chatMessages.filter(
      (msg) => !(msg.petId === id && msg.userId === userId)
    );
    persistState(state);
    return 'ok';
  },

  seedDemoForUser(userId: string): StorePet[] {
    const existing = this.listPetsByUser(userId);
    if (existing.length > 0) return existing;

    const bella = this.createPet(userId, {
      name: 'Bella',
      species: 'dog',
      breed: '金毛寻回犬',
      gender: 'female',
      age: 3,
      weight: 28,
      isNeutered: true,
      avatar: '/src/assets/images/golden_retriever_dog_1794751022608.jpg',
      diet: JSON.stringify([
        { name: '天然三文鱼无谷成犬粮', amount: '220' },
        { name: '冻干鸡肉粒', amount: '30' },
      ]),
      water: '850ml',
      vaccineStatus: '2026-12-15',
      companionStartDate: '2024-03-10',
      isDemo: true,
    });

    const mochi = this.createPet(userId, {
      name: 'Mochi',
      species: 'cat',
      breed: '英国短毛猫',
      gender: 'male',
      age: 2,
      weight: 4.6,
      isNeutered: true,
      avatar: '/src/assets/images/british_shorthair_cat_1794751020533.jpg',
      diet: JSON.stringify([
        { name: '全价室内成猫粮', amount: '55' },
        { name: '鸡肉主食罐头', amount: '85' },
      ]),
      water: '240ml',
      vaccineStatus: '2026-11-28',
      companionStartDate: '2025-01-15',
      isDemo: true,
    });

    this.createRecord(userId, {
      petId: bella.id,
      date: '2026-07-20',
      type: 'vaccine',
      title: '年度狂犬及联苗加强',
      content: '接种顺利，注射部位无硬结。',
      weightKg: 27.1,
      isDemo: true,
    });
    this.createRecord(userId, {
      petId: bella.id,
      date: '2026-11-10',
      type: 'medical',
      title: '11 月复称体重 (Weight)',
      content: '28.0 kg，体况评分 BCS 5/9 理想范围。',
      weightKg: 28,
      isDemo: true,
    });
    this.createRecord(userId, {
      petId: mochi.id,
      date: '2026-11-05',
      type: 'medical',
      title: '11 月复称体重 (Weight)',
      content: '4.6 kg，建议增加每天 2 次逗猫棒互动。',
      weightKg: 4.6,
      isDemo: true,
    });

    this.createReminder(userId, {
      petId: bella.id,
      title: '每月体外驱虫滴剂',
      category: 'deworming',
      dueDate: '2026-11-25',
      dueTime: '20:00',
      repeat: 'monthly',
      notes: '滴在肩胛骨后方皮肤处，用药后 48 小时内不洗澡。',
      isDemo: true,
    });
    this.createReminder(userId, {
      petId: mochi.id,
      title: '化毛膏喂食与梳毛护理',
      category: 'grooming',
      dueDate: '2026-11-22',
      dueTime: '19:30',
      repeat: 'weekly',
      notes: '秋季换毛季每周 2-3 次梳理浮毛。',
      isDemo: true,
    });

    return [bella, mochi];
  },

  // ========================
  // Health Records (Scoped by userId)
  // ========================
  listRecordsByUser(userId: string, petId?: string): StoreHealthRecord[] {
    const records = loadState().records.filter((r) => r.userId === userId);
    const filtered = petId ? records.filter((r) => r.petId === petId) : records;
    return [...filtered].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  },

  createRecord(
    userId: string,
    input: Omit<StoreHealthRecord, 'id' | 'userId'>
  ): StoreHealthRecord {
    const state = loadState();
    const record: StoreHealthRecord = {
      ...input,
      id: `rec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      userId,
      isDemo: Boolean(input.isDemo),
    };
    state.records.push(record);
    if (typeof record.weightKg === 'number' && record.weightKg > 0) {
      const petIdx = state.pets.findIndex((p) => p.id === record.petId && p.userId === userId);
      if (petIdx !== -1) {
        state.pets[petIdx] = {
          ...state.pets[petIdx],
          weight: record.weightKg,
          updatedAt: new Date().toISOString(),
        };
      }
    }
    persistState(state);
    return record;
  },

  deleteRecord(userId: string, id: string): 'ok' | 'not_found' | 'forbidden' {
    const state = loadState();
    const target = state.records.find((r) => r.id === id);
    if (!target) return 'not_found';
    if (target.userId !== userId) return 'forbidden';

    state.records = state.records.filter((r) => r.id !== id);
    persistState(state);
    return 'ok';
  },

  // ========================
  // Medical Records (Images / PDFs + Structured Clinical Notes, Scoped by userId)
  // ========================
  listMedicalRecordsByUser(userId: string, petId?: string): StoreMedicalRecord[] {
    const list = loadState().medicalRecords.filter((m) => m.userId === userId);
    const filtered = petId ? list.filter((m) => m.petId === petId) : list;
    return [...filtered].sort((a, b) => {
      const dateCmp = b.date.localeCompare(a.date);
      return dateCmp !== 0 ? dateCmp : b.createdAt.localeCompare(a.createdAt);
    });
  },

  createMedicalRecord(
    userId: string,
    input: Omit<StoreMedicalRecord, 'id' | 'userId' | 'createdAt'>
  ): StoreMedicalRecord {
    const state = loadState();
    const entry: StoreMedicalRecord = {
      ...input,
      id: `med_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      userId,
      createdAt: new Date().toISOString(),
    };
    state.medicalRecords.push(entry);
    persistState(state);
    return entry;
  },

  deleteMedicalRecord(userId: string, id: string): 'ok' | 'not_found' | 'forbidden' {
    const state = loadState();
    const target = state.medicalRecords.find((m) => m.id === id);
    if (!target) return 'not_found';
    if (target.userId !== userId) return 'forbidden';

    state.medicalRecords = state.medicalRecords.filter((m) => m.id !== id);
    persistState(state);
    return 'ok';
  },

  // ========================
  // Reminders (Scoped by userId)
  // ========================
  listRemindersByUser(userId: string, petId?: string): StoreReminder[] {
    const reminders = loadState().reminders.filter((r) => r.userId === userId);
    const filtered = petId ? reminders.filter((r) => r.petId === petId) : reminders;
    return [...filtered].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  },

  createReminder(
    userId: string,
    input: Omit<StoreReminder, 'id' | 'userId' | 'createdAt' | 'completed'>
  ): StoreReminder {
    const state = loadState();
    const reminder: StoreReminder = {
      ...input,
      id: `rem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      userId,
      completed: false,
      createdAt: new Date().toISOString(),
      isDemo: Boolean(input.isDemo),
    };
    state.reminders.push(reminder);
    persistState(state);
    return reminder;
  },

  updateReminder(
    userId: string,
    id: string,
    patch: Partial<StoreReminder>
  ): { status: 'ok'; reminder: StoreReminder } | { status: 'not_found' | 'forbidden' } {
    const state = loadState();
    const idx = state.reminders.findIndex((r) => r.id === id);
    if (idx === -1) return { status: 'not_found' };
    if (state.reminders[idx].userId !== userId) return { status: 'forbidden' };
    state.reminders[idx] = { ...state.reminders[idx], ...patch, id, userId };
    persistState(state);
    return { status: 'ok', reminder: state.reminders[idx] };
  },

  deleteReminder(userId: string, id: string): 'ok' | 'not_found' | 'forbidden' {
    const state = loadState();
    const target = state.reminders.find((r) => r.id === id);
    if (!target) return 'not_found';
    if (target.userId !== userId) return 'forbidden';

    state.reminders = state.reminders.filter((r) => r.id !== id);
    persistState(state);
    return 'ok';
  },

  // ========================
  // AI Vet Chat Messages (Scoped by userId + petId)
  // ========================
  listChatMessages(userId: string, petId = 'general'): StoreChatMessage[] {
    return loadState().chatMessages
      .filter((m) => m.userId === userId && m.petId === petId)
      .slice(-60);
  },

  appendChatMessages(messages: StoreChatMessage[]): void {
    const state = loadState();
    state.chatMessages.push(...messages);
    persistState(state);
  },

  clearChatMessages(userId: string, petId = 'general'): void {
    const state = loadState();
    state.chatMessages = state.chatMessages.filter(
      (m) => !(m.userId === userId && m.petId === petId)
    );
    persistState(state);
  },
};
