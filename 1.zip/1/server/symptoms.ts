import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const PYTHON_SERVICE_PATH = path.resolve(
  process.cwd(),
  'python_backend',
  'services',
  'symptom_service.py'
);
const HISTORY_FILE_PATH = path.resolve(process.cwd(), 'server', 'data', 'symptom_history.json');

export interface ServerSymptomHistoryItem {
  id: string;
  petId: string;
  petName: string;
  symptomIds: string[];
  symptomNames: string[];
  level: 'emergency' | 'urgent' | 'watch';
  score: number;
  headline: string;
  reasoning: string[];
  adviceList: string[];
  checkedAt: string;
}

function readHistoryFile(): ServerSymptomHistoryItem[] {
  try {
    if (!fs.existsSync(HISTORY_FILE_PATH)) return [];
    const raw = fs.readFileSync(HISTORY_FILE_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeHistoryFile(items: ServerSymptomHistoryItem[]): void {
  try {
    fs.mkdirSync(path.dirname(HISTORY_FILE_PATH), { recursive: true });
    fs.writeFileSync(HISTORY_FILE_PATH, JSON.stringify(items.slice(0, 50), null, 2), 'utf-8');
  } catch (err) {
    console.warn('Failed to persist symptom_history.json:', err);
  }
}

export function runPythonSymptomService(payload: Record<string, unknown>): Promise<any> {
  return new Promise((resolve, reject) => {
    const pythonCmd = process.env.PYTHON_BIN || 'python3';
    const child = spawn(pythonCmd, [PYTHON_SERVICE_PATH], {
      cwd: process.cwd(),
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error('Python 症状分析服务执行超时'));
    }, 10000);

    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString('utf-8');
    });

    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString('utf-8');
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      reject(
        new Error(
          `Python 症状分析服务未启动或无法执行 (${err.message})，请检查 Python 环境或启动 FastAPI 服务。`
        )
      );
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) {
        reject(new Error(stderr.trim() || `Python 症状分析脚本异常退出 (${code})`));
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch {
        reject(new Error('Python 症状分析服务返回了无效的 JSON 格式'));
      }
    });

    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

export const symptomServerService = {
  async getRules() {
    return runPythonSymptomService({ action: 'rules' });
  },

  async checkSymptoms(symptomIds: string[]) {
    return runPythonSymptomService({ action: 'check', symptomIds });
  },

  listHistory(petId?: string): ServerSymptomHistoryItem[] {
    const all = readHistoryFile();
    if (!petId) return all;
    return all.filter((item) => item.petId === petId);
  },

  addHistory(input: Omit<ServerSymptomHistoryItem, 'id' | 'checkedAt'>): ServerSymptomHistoryItem {
    const all = readHistoryFile();
    const created: ServerSymptomHistoryItem = {
      ...input,
      id: `sym_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
      checkedAt: new Date().toISOString(),
    };
    writeHistoryFile([created, ...all]);
    return created;
  },

  clearHistory(petId?: string): void {
    if (!petId) {
      writeHistoryFile([]);
      return;
    }
    const all = readHistoryFile().filter((item) => item.petId !== petId);
    writeHistoryFile(all);
  },
};
