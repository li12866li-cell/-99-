import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { petcareStore, StoreUser } from './store.ts';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const EPHEMERAL_FALLBACK_SECRET = crypto.randomBytes(48).toString('hex');

function getJwtSecret(): string {
  const envSecret = (process.env.JWT_SECRET_KEY || '').trim();
  if (
    envSecret &&
    envSecret !== 'CHANGE_ME_TO_A_RANDOM_64_CHAR_SECRET' &&
    envSecret !== 'replace-with-strong-random-secret'
  ) {
    return envSecret;
  }
  return EPHEMERAL_FALLBACK_SECRET;
}

export function isSmtpConfigured(): boolean {
  const host = (process.env.SMTP_HOST || '').trim();
  const user = (process.env.SMTP_USER || '').trim();
  const pass = (process.env.SMTP_PASSWORD || '').trim();
  return Boolean(host && user && pass);
}

export function validateEmail(email: string): string | null {
  const cleaned = (email || '').trim().toLowerCase();
  if (!cleaned || !EMAIL_REGEX.test(cleaned)) return null;
  return cleaned;
}

export function validatePasswordStrength(password: string): string | null {
  if (!password || password.length < 8) {
    return '密码长度至少为 8 位';
  }
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    return '密码需同时包含字母和数字';
  }
  return null;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!password || !storedHash) return false;
  const parts = storedHash.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const [, salt, originalHex] = parts;
  const derivedBuf = crypto.scryptSync(password, salt, 64);
  const originalBuf = Buffer.from(originalHex, 'hex');
  if (derivedBuf.length !== originalBuf.length) return false;
  return crypto.timingSafeEqual(derivedBuf, originalBuf);
}

function base64UrlEncode(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(input: string): string {
  const pad = 4 - (input.length % 4 || 4);
  const base64 = input.replace(/-/g, '+').replace(/_/g, '/') + (pad === 4 ? '' : '='.repeat(pad));
  return Buffer.from(base64, 'base64').toString('utf8');
}

export interface JwtPayload {
  sub: string;
  email: string;
  jti: string;
  iat: number;
  exp: number;
}

export function signAccessToken(
  user: StoreUser,
  rememberMe = true
): { accessToken: string; expiresAt: string; jti: string } {
  const nowSec = Math.floor(Date.now() / 1000);
  const defaultMinutes = parseInt(process.env.JWT_EXPIRE_MINUTES || '10080', 10) || 10080;
  const ttlSec = rememberMe ? defaultMinutes * 60 : 12 * 60 * 60;
  const expSec = nowSec + ttlSec;
  const jti = crypto.randomBytes(18).toString('hex');

  const header = base64UrlEncode(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = base64UrlEncode(
    JSON.stringify({
      sub: user.id,
      email: user.email,
      jti,
      iat: nowSec,
      exp: expSec,
    } satisfies JwtPayload)
  );
  const signature = base64UrlEncode(
    crypto.createHmac('sha256', getJwtSecret()).update(`${header}.${payload}`).digest()
  );

  return {
    accessToken: `${header}.${payload}.${signature}`,
    expiresAt: new Date(expSec * 1000).toISOString(),
    jti,
  };
}

export function verifyAccessToken(token: string): JwtPayload | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, payloadB64, sigB64] = parts;

  const expectedSig = base64UrlEncode(
    crypto.createHmac('sha256', getJwtSecret()).update(`${header}.${payloadB64}`).digest()
  );
  const sigBuf = Buffer.from(sigB64);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const parsed = JSON.parse(base64UrlDecode(payloadB64)) as JwtPayload;
    if (!parsed.sub || !parsed.jti || !parsed.exp) return null;
    if (Math.floor(Date.now() / 1000) >= parsed.exp) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function serializePublicUser(user: StoreUser) {
  return {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    avatarUrl: user.avatarUrl,
    isActive: user.isActive,
    emailVerified: user.emailVerified,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

export interface AuthenticatedRequest extends Request {
  authUser?: StoreUser;
  authTokenPayload?: JwtPayload;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    req.authUser = petcareStore.ensureDefaultWorkspaceUser();
    next();
    return;
  }

  const rawToken = header.slice(7).trim();
  const payload = verifyAccessToken(rawToken);
  if (!payload) {
    res.status(401).json({ error: '身份认证令牌无效或已过期，请重新登录' });
    return;
  }

  if (petcareStore.isTokenRevoked(payload.jti)) {
    res.status(401).json({ error: '当前会话已退出登录，请重新登录' });
    return;
  }

  const user = petcareStore.findUserById(payload.sub);
  if (!user || !user.isActive) {
    res.status(401).json({ error: '账号不存在或已被停用' });
    return;
  }

  req.authUser = user;
  req.authTokenPayload = payload;
  next();
}
