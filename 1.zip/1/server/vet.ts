import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { buildLocalVetReply } from "./localVet.ts";

const GEMINI_VET_MODEL = "gemini-4-hydrogen";
const DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions";
const DEEPSEEK_MODEL = "deepseek-chat";

function getDeepSeekApiKey(): string {
  const raw = (process.env.DEEPSEEK_API_KEY || "").trim();
  if (!raw || raw === "MY_DEEPSEEK_API_KEY") return "";
  return raw;
}

function getGeminiApiKey(): string {
  const raw = (process.env.GEMINI_API_KEY || process.env.API_KEY || "").trim();
  if (!raw || raw === "MY_GEMINI_API_KEY") return "";
  return raw;
}

function getGeminiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: getGeminiApiKey(),
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

export interface VetSource {
  title: string;
  url: string;
}

export interface PetContext {
  id?: string;
  name?: string;
  species?: string;
  breed?: string;
  age?: number;
  weight?: number;
  gender?: string;
  isNeutered?: boolean;
}

export interface VetPart {
  text?: string;
  inlineData?: { mimeType: string; data: string };
}

export interface VetHistoryTurn {
  role: "user" | "model" | "assistant";
  parts?: VetPart[];
  text?: string;
}

export interface VetSimpleInput {
  history?: VetHistoryTurn[];
  message: string | VetPart[];
  language?: string;
  useSearch?: boolean;
  petContext?: PetContext | null;
}

export type VetEngineType = "deepseek" | "gemini" | "local-demo";

function getSystemPrompt(language: string = "zh", petInfo: string = ""): string {
  const petSection = petInfo
    ? language === "en"
      ? `\nCurrent Pet Profile: ${petInfo}. Tailor dosage, breed risks, and care guidance specifically to this pet.`
      : language === "ko"
        ? `\n현재 반려동물 프로필: ${petInfo}. 이 반려동물의 체중과 상태에 맞춰 조언해 주세요.`
        : `\n当前关联宠物档案：${petInfo}。请结合该宠物的物种、品种、体重及绝育状态给出更具针对性的判断与护理建议。`
    : "";

  if (language === "en") {
    return `You are PetCare AI's Veterinary Assistant powered by DeepSeek.
Answer clearly in plain everyday English without markdown symbols (no **, no #).
When the user describes pet symptoms or emergencies, structure your answer in 3 concise lines:
Likely Cause: (1-2 clear sentences)
Home Care: (1-2 safe immediate steps)
See a Vet If: (clear red-flag symptoms requiring immediate clinic care)
When the user asks general pet care, diet, vaccine, or follow-up questions, answer directly and concisely in 2-4 plain sentences.${petSection}`;
  }
  if (language === "ko") {
    return `당신은 'PetCare AI'의 온라인 AI 수의사 도우미입니다.
어려운 마크다운 기호(**, #) 없이 쉬운 일상 한국어로 명확하게 답하세요.
반려동물의 증상이나 응급 상황 질문에는 아래 3줄 형식으로 간결히 답하세요:
예상 원인: (핵심 원인 1~2문장)
홈 케어: (집에서 할 수 있는 안전한 대처 1~2가지)
병원 방문: (즉시 내원이 필요한 위험 신호)
일반 양육, 사료, 예방접종 또는 후속 질문에는 2~4문장으로 친절하게 답하세요.${petSection}`;
  }
  return `你是「宠爱脉动 PetCare AI」的在线 AI 兽医助手。
请用通俗清晰的大白话直接回答，不要使用 Markdown 符号（不要输出 ** 或 #）。
如果用户咨询宠物不适症状或突发状况，请尽量按以下清晰分段回答（总字数约 120-200 字）：
可能原因：（用1-2句话说清常见诱因）
居家建议：（1-2条安全、可立即操作的护理方法）
就医提醒：（明确哪些危险信号必须立刻去宠物医院）
如果用户咨询日常喂养、疫苗驱虫、行为或连续追问，请结合上下文用 2-4 句简明段落直接回答。${petSection}`;
}

function formatPetContext(pet?: PetContext | null, language: string = "zh"): string {
  if (!pet || (!pet.name && !pet.species)) return "";
  const speciesMap: Record<string, Record<string, string>> = {
    zh: { dog: "狗狗", cat: "猫咪", bunny: "兔子", other: "宠物" },
    en: { dog: "Dog", cat: "Cat", bunny: "Rabbit", other: "Pet" },
    ko: { dog: "강아지", cat: "고양이", bunny: "토끼", other: "반려동물" },
  };
  const sp = speciesMap[language]?.[pet.species || "other"] || pet.species || "";
  const breedStr = pet.breed ? pet.breed : "";
  const ageStr = typeof pet.age === "number" && pet.age > 0 ? `${pet.age}岁` : "";
  const weightStr = pet.weight ? `${pet.weight}kg` : "";
  const genderStr = pet.gender
    ? pet.gender === "male"
      ? language === "en"
        ? "Male"
        : language === "ko"
          ? "수컷"
          : "公"
      : language === "en"
        ? "Female"
        : language === "ko"
          ? "암컷"
          : "母"
    : "";
  const neuterStr =
    typeof pet.isNeutered === "boolean"
      ? pet.isNeutered
        ? language === "en"
          ? "Neutered"
          : language === "ko"
            ? "중성화 완료"
            : "已绝育"
        : language === "en"
          ? "Intact"
          : language === "ko"
            ? "중성화 안 함"
            : "未绝育"
      : "";
  return [pet.name, sp, breedStr, ageStr, weightStr, genderStr, neuterStr].filter(Boolean).join(" / ");
}

function sanitizeParts(rawParts: VetPart[]): VetPart[] {
  const valid: VetPart[] = [];
  for (const p of rawParts) {
    if (p?.inlineData?.data && p?.inlineData?.mimeType) {
      valid.push({
        inlineData: {
          mimeType: p.inlineData.mimeType,
          data: p.inlineData.data,
        },
      });
    } else if (typeof p?.text === "string" && p.text.trim().length > 0) {
      valid.push({ text: p.text.trim() });
    }
  }
  return valid;
}

function extractTurnText(turn: VetHistoryTurn): string {
  if (typeof turn.text === "string" && turn.text.trim()) return turn.text.trim();
  if (Array.isArray(turn.parts)) {
    return turn.parts
      .map((p) => (typeof p?.text === "string" ? p.text.trim() : ""))
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

function buildMessageParts(message: VetSimpleInput["message"]): VetPart[] {
  const rawParts =
    typeof message === "string"
      ? [{ text: message }]
      : Array.isArray(message)
        ? message
        : [{ text: "" }];

  const parts = sanitizeParts(rawParts);
  if (parts.length === 0) {
    parts.push({ text: "请帮我看看宠物的情况。" });
  }
  return parts;
}

function normalizeGeminiHistory(history?: VetHistoryTurn[]): Array<{ role: "user" | "model"; parts: VetPart[] }> {
  if (!Array.isArray(history) || history.length === 0) return [];
  const cleaned: Array<{ role: "user" | "model"; parts: VetPart[] }> = [];
  for (const turn of history.slice(-12)) {
    const mappedRole = turn?.role === "user" ? "user" : turn?.role === "model" || turn?.role === "assistant" ? "model" : null;
    if (!mappedRole) continue;
    const text = extractTurnText(turn);
    const parts = Array.isArray(turn.parts) && turn.parts.length > 0 ? sanitizeParts(turn.parts) : text ? [{ text }] : [];
    if (parts.length === 0) continue;
    if (cleaned.length === 0 && mappedRole !== "user") continue;
    const prev = cleaned[cleaned.length - 1];
    if (prev && prev.role === mappedRole) {
      prev.parts.push(...parts);
    } else {
      cleaned.push({ role: mappedRole, parts });
    }
  }
  if (cleaned.length > 0 && cleaned[cleaned.length - 1].role === "user") {
    cleaned.pop();
  }
  return cleaned;
}

function buildDeepSeekMessages(
  systemPrompt: string,
  history: VetHistoryTurn[] | undefined,
  userMessageText: string
): Array<{ role: "system" | "user" | "assistant"; content: string }> {
  const msgs: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
    { role: "system", content: systemPrompt },
  ];

  if (Array.isArray(history)) {
    for (const turn of history.slice(-12)) {
      const text = extractTurnText(turn);
      if (!text) continue;
      const role = turn.role === "user" ? "user" : "assistant";
      if (msgs.length === 1 && role !== "user") continue;
      msgs.push({ role, content: text });
    }
  }

  msgs.push({ role: "user", content: userMessageText });
  return msgs;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function* streamLocalReply(text: string): AsyncGenerator<string> {
  const chunkSize = 8;
  for (let i = 0; i < text.length; i += chunkSize) {
    yield text.slice(i, i + chunkSize);
    await sleep(14);
  }
}

async function* streamDeepSeek(
  apiKey: string,
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>
): AsyncGenerator<string> {
  const response = await fetch(DEEPSEEK_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: DEEPSEEK_MODEL,
      messages,
      temperature: 0.4,
      stream: true,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text().catch(() => "");
    throw new Error(`DeepSeek API 请求失败 (${response.status})${errorBody ? `: ${errorBody.slice(0, 140)}` : ""}`);
  }

  if (!response.body) {
    throw new Error("DeepSeek API 未返回响应流");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || !line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (payload === "[DONE]") return;
      try {
        const parsed = JSON.parse(payload);
        const delta = parsed?.choices?.[0]?.delta?.content;
        if (typeof delta === "string" && delta.length > 0) {
          yield delta;
        }
      } catch {
        // ignore partial JSON chunk
      }
    }
  }
}

export const vetService = {
  getStatus() {
    const deepseekConfigured = Boolean(getDeepSeekApiKey());
    const geminiConfigured = Boolean(getGeminiApiKey());
    const activeProvider: VetEngineType = deepseekConfigured
      ? "deepseek"
      : geminiConfigured
        ? "gemini"
        : "local-demo";

    const statusText = deepseekConfigured
      ? "DeepSeek 后端 API 已连接（支持多轮对话与宠物档案关联）"
      : geminiConfigured
        ? "未配置 DEEPSEEK_API_KEY，当前后端暂由 Gemini 备选引擎提供问答"
        : "未配置 DEEPSEEK_API_KEY：当前使用本地离线分诊演示引擎（Demo Fallback），请在服务端环境变量配置真实密钥";

    return {
      deepseekConfigured,
      geminiConfigured,
      googleSearchAvailable: geminiConfigured,
      activeProvider,
      statusText,
    };
  },

  isConfigured(): boolean {
    return Boolean(getDeepSeekApiKey() || getGeminiApiKey());
  },

  async *chatSimpleStream(input: VetSimpleInput): AsyncGenerator<
    | { type: "meta"; engine: VetEngineType; deepseekConfigured: boolean; sources: VetSource[] }
    | { type: "chunk"; text: string }
  > {
    const language = input.language || "zh";
    const cleanRawParts = buildMessageParts(input.message);
    const hasImage = cleanRawParts.some((p) => Boolean(p.inlineData));
    const userText =
      cleanRawParts
        .map((p) => p.text || "")
        .filter(Boolean)
        .join("\n") || "请帮我分析这张宠物照片。";

    const petInfo = formatPetContext(input.petContext, language);
    const systemPrompt = getSystemPrompt(language, petInfo);
    const deepseekKey = getDeepSeekApiKey();
    const geminiKey = getGeminiApiKey();

    // 1. Primary requested provider: DeepSeek API (server-side proxy)
    if (deepseekKey && !hasImage) {
      yield {
        type: "meta",
        engine: "deepseek",
        deepseekConfigured: true,
        sources: [],
      };

      const dsMessages = buildDeepSeekMessages(systemPrompt, input.history, userText);
      for await (const chunk of streamDeepSeek(deepseekKey, dsMessages)) {
        yield { type: "chunk", text: chunk };
      }
      return;
    }

    // 2. Multimodal / secondary provider: Gemini API (when key exists)
    if (geminiKey) {
      const normalizedHistory = normalizeGeminiHistory(input.history);
      const ai = getGeminiClient();
      const contents = [...normalizedHistory, { role: "user" as const, parts: cleanRawParts }];

      yield {
        type: "meta",
        engine: "gemini",
        deepseekConfigured: Boolean(deepseekKey),
        sources: [],
      };

      const collectedSources: VetSource[] = [];
      const seenUrls = new Set<string>();
      const shouldTrySearch = input.useSearch !== false && !hasImage;

      const runGemini = async function* (enableSearch: boolean) {
        const stream = await ai.models.generateContentStream({
          model: GEMINI_VET_MODEL,
          contents,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction: systemPrompt,
            ...(enableSearch ? { tools: [{ googleSearch: {} }] } : {}),
          },
        });

        for await (const chunk of stream) {
          const rawChunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
          for (const gc of rawChunks as any[]) {
            const uri = gc?.web?.uri;
            const title = gc?.web?.title;
            if (uri && !seenUrls.has(uri)) {
              seenUrls.add(uri);
              collectedSources.push({ title: title || uri, url: uri });
            }
          }
          if (chunk.text) yield chunk.text;
        }
      };

      let emitted = false;
      try {
        for await (const text of runGemini(shouldTrySearch)) {
          emitted = true;
          yield { type: "chunk", text };
        }
      } catch (err) {
        if (shouldTrySearch && !emitted) {
          for await (const text of runGemini(false)) {
            emitted = true;
            yield { type: "chunk", text };
          }
        } else if (!emitted) {
          throw err;
        }
      }

      if (collectedSources.length > 0) {
        yield {
          type: "meta",
          engine: "gemini",
          deepseekConfigured: Boolean(deepseekKey),
          sources: collectedSources.slice(0, 4),
        };
      }
      if (emitted) return;
    }

    // 3. Honest Local Demo Fallback (only when no external AI key is configured)
    const normalizedHistory = normalizeGeminiHistory(input.history);
    yield {
      type: "meta",
      engine: "local-demo",
      deepseekConfigured: false,
      sources: [],
    };

    const reply = buildLocalVetReply({
      messageParts: cleanRawParts,
      history: normalizedHistory,
      language,
      petContext: input.petContext,
    });

    for await (const chunk of streamLocalReply(reply)) {
      yield { type: "chunk", text: chunk };
    }
  },

  async chatSimple(input: VetSimpleInput): Promise<{
    response: string;
    engine: VetEngineType;
    deepseekConfigured: boolean;
    sources: VetSource[];
  }> {
    let response = "";
    let engine: VetEngineType = "local-demo";
    let deepseekConfigured = false;
    let sources: VetSource[] = [];

    for await (const event of this.chatSimpleStream(input)) {
      if (event.type === "meta") {
        engine = event.engine;
        deepseekConfigured = event.deepseekConfigured;
        if (event.sources.length > 0) sources = event.sources;
      } else if (event.type === "chunk") {
        response += event.text;
      }
    }

    return { response, engine, deepseekConfigured, sources };
  },
};
