import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { buildLocalVetReply } from "./localVet.ts";

function getGeminiApiKey(): string {
  return (process.env.GEMINI_API_KEY || process.env.API_KEY || '').trim();
}

function getAiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: getGeminiApiKey(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function normalizeVetHistory(history: { role: 'user' | 'model'; parts: any[] }[] = []) {
  const cleaned: { role: 'user' | 'model'; parts: any[] }[] = [];
  for (const h of history) {
    if (h?.role !== 'user' && h?.role !== 'model') continue;
    const parts = (Array.isArray(h.parts) ? h.parts : []).filter(
      (p) => p?.inlineData?.data || (typeof p?.text === 'string' && p.text.trim().length > 0)
    );
    if (parts.length === 0) continue;
    if (cleaned.length === 0 && h.role !== 'user') continue;
    const prev = cleaned[cleaned.length - 1];
    if (prev && prev.role === h.role) {
      prev.parts.push(...parts);
    } else {
      cleaned.push({ role: h.role, parts });
    }
  }
  if (cleaned.length > 0 && cleaned[cleaned.length - 1].role === 'user') {
    cleaned.pop();
  }
  return cleaned;
}

const FAST_MULTIMODAL_MODEL = "gemini-4-hydrogen";

export const geminiService = {
  async chatWithVet(history: { role: 'user' | 'model', parts: any[] }[], message: string | any[], language: string = 'zh') {
    const sanitizedHistory = normalizeVetHistory(history || []);
    const userParts = typeof message === 'string' ? [{ text: message }] : Array.isArray(message) ? message : [{ text: '' }];
    if (!getGeminiApiKey()) {
      return buildLocalVetReply({ messageParts: userParts, history: sanitizedHistory, language });
    }
    try {
      const ai = getAiClient();
      const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
      const result = await ai.models.generateContent({
        model: FAST_MULTIMODAL_MODEL,
        contents: [...sanitizedHistory, { role: 'user', parts: userParts }],
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction: `你是一位专业且高效的AI兽医。你的任务是提供清晰、专业且实用的建议。如果是紧急情况，立即提醒就医。回答要直接且有针对性，避免废话。请使用${langNames[language] || '中文'}回答。`,
        },
      });
      return result.text || buildLocalVetReply({ messageParts: userParts, history: sanitizedHistory, language });
    } catch (err) {
      console.warn('chatWithVet falling back to local vet engine:', err);
      return buildLocalVetReply({ messageParts: userParts, history: sanitizedHistory, language });
    }
  },

  async *chatWithVetStream(history: { role: 'user' | 'model', parts: any[] }[], message: string | any[], language: string = 'zh') {
    const sanitizedHistory = normalizeVetHistory(history || []);
    const userParts = typeof message === 'string' ? [{ text: message }] : Array.isArray(message) ? message : [{ text: '' }];
    let yielded = false;

    if (getGeminiApiKey()) {
      try {
        const ai = getAiClient();
        const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
        const stream = await ai.models.generateContentStream({
          model: FAST_MULTIMODAL_MODEL,
          contents: [...sanitizedHistory, { role: 'user', parts: userParts }],
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction: `你是一位专业高效的AI兽医。针对用户问题提供专业、实用且直接的建议。紧急情况提示就医。使用${langNames[language] || '中文'}。`,
          },
        });
        for await (const chunk of stream) {
          try {
            const text = chunk.text;
            if (text) {
              yielded = true;
              yield text;
            }
          } catch (e) {
            console.warn('Chunk text access error (possibly blocked):', e);
          }
        }
      } catch (err) {
        console.warn('chatWithVetStream falling back to local vet engine:', err);
      }
    }

    if (!yielded) {
      const localText = buildLocalVetReply({ messageParts: userParts, history: sanitizedHistory, language });
      for (let i = 0; i < localText.length; i += 8) {
        yield localText.slice(i, i + 8);
        await new Promise((r) => setTimeout(r, 15));
      }
    }
  },

  async transcribeAudio(audioData: { mimeType: string, data: string }) {
    const response = await getAiClient().models.generateContent({
      model: "gemini-3.5-transcribe",
      contents: {
        parts: [
          { inlineData: audioData },
          { text: "请将这段语音转录为文字。只需返回转录结果，不要有任何其他解释。" }
        ]
      }
    });
    return response.text;
  },

  async analyzeFood(imageParts: { mimeType: string, data: string }[], language: string = 'zh') {
    const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
    const response = await getAiClient().models.generateContent({
      model: FAST_MULTIMODAL_MODEL,
      contents: {
        parts: [
          ...imageParts.map(p => ({ inlineData: p })),
          { text: `快速分析宠物食品配料表或包装照片。识别产品名称、主要成分、潜在有害或争议成分、营养评分(1-10)、购买建议及简短原因。使用${langNames[language] || '中文'}回答。` }
        ]
      },
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            productName: { type: Type.STRING },
            ingredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            harmfulIngredients: { type: Type.ARRAY, items: { type: Type.STRING } },
            nutritionScore: { type: Type.INTEGER },
            recommendation: { type: Type.STRING },
            reason: { type: Type.STRING },
          },
          required: ["productName", "nutritionScore", "recommendation", "reason"]
        }
      }
    });
    
    try {
      const text = response.text || '{}';
      return JSON.parse(text);
    } catch (e) {
      console.error('JSON parse error:', e, response.text);
      return { 
        productName: 'Unknown Product',
        nutritionScore: 0,
        recommendation: 'Error analyzing food',
        reason: 'Failed to parse AI response'
      };
    }
  },

  async evaluateOutfit({ petName, species, outfitTitle, outfitStyle, language = 'zh' }: any) {
    const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
    try {
      const response = await getAiClient().models.generateContent({
        model: FAST_MULTIMODAL_MODEL,
        contents: {
          parts: [
            {
              text: `你是一位顶级宠物时尚造型师。请为宠物"${petName}"（品种/类型: ${species}）试穿的服饰"${outfitTitle}"（风格: ${outfitStyle}）生成一份专业且趣味十足的穿搭点评。
使用${langNames[language] || '中文'}。以JSON格式返回：
fitScore (85-99整数),
comfortLevel (如"极高 98%", "舒适透气"),
sceneRecommendation (推荐出行或打卡场景，一句话),
weatherMatch (适合天气或温度),
stylistComment (2-3句风趣热情的专业点评，夸赞毛孩子的穿搭魅力).`
            }
          ]
        },
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              fitScore: { type: Type.INTEGER },
              comfortLevel: { type: Type.STRING },
              sceneRecommendation: { type: Type.STRING },
              weatherMatch: { type: Type.STRING },
              stylistComment: { type: Type.STRING },
            },
            required: ["fitScore", "comfortLevel", "sceneRecommendation", "weatherMatch", "stylistComment"]
          }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (e) {
      console.error('Stylist review error:', e);
      return {
        fitScore: 96,
        comfortLevel: "极高 98%",
        sceneRecommendation: "草坪日光浴、户外野餐与亲子出街",
        weatherMatch: "适宜 15°C ~ 25°C 晴好天气",
        stylistComment: `${petName || '宝贝'} 穿上这套简直是量身定做！立体剪裁凸显可爱气质，走在路上回头率百分百！`
      };
    }
  },

  async analyzeClothing({ image, species = '宠物', language = 'zh' }: { image: { mimeType: string, data: string }, species?: string, language?: string }) {
    const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
    try {
      const response = await getAiClient().models.generateContent({
        model: FAST_MULTIMODAL_MODEL,
        contents: {
          parts: [
            { inlineData: image },
            {
              text: `你是专业的虚拟试衣视觉识别专家。请精确识别这张衣服照片（目标穿戴对象：${species}），使用${langNames[language] || '中文'}返回JSON。
注意：所有坐标均使用 0-1000 整数归一化坐标（0=最上/最左，1000=最下/最右）：
- garmentBox: 衣服主体紧致边界框 { ymin, xmin, ymax, xmax }，严格排除衣架、模特头部/手脚、背景杂物。
- garmentPolygon: 沿着衣服最外缘轮廓的 8-14 个顺时针点 [{ x, y }, ...]（依次经过左领口、左肩、左袖外沿、左腋下、左下摆、下摆中点、右下摆、右腋下、右袖外沿、右肩、右领口），用于精准抠出衣服本体。
- collarCenter: 衣服前领口中心点 { x, y }。
- leftShoulder: 衣服左肩端点 { x, y }。
- rightShoulder: 衣服右肩端点 { x, y }。
- garmentType: 'vest' | 'sweater' | 'shirt' | 'hoodie' | 'cape' | 'dress' | 'raincoat' | 'tang_suit' | 'jacket'
- collarDepth: 领口凹陷深度百分比 (5-25 整数)
- 其余描述字段：name, category ('chic'|'festive'|'function'|'fun'), categoryLabel, tag (4字以内), tagColor, emoji, description (35字以内), material, cutDesign, hygieneDesign, fitScore (88-99), comfortLevel, defaultScene, defaultWeather, stylistAdvice。`
            }
          ]
        },
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              category: { type: Type.STRING },
              categoryLabel: { type: Type.STRING },
              tag: { type: Type.STRING },
              tagColor: { type: Type.STRING },
              emoji: { type: Type.STRING },
              description: { type: Type.STRING },
              material: { type: Type.STRING },
              cutDesign: { type: Type.STRING },
              hygieneDesign: { type: Type.STRING },
              fitScore: { type: Type.INTEGER },
              comfortLevel: { type: Type.STRING },
              defaultScene: { type: Type.STRING },
              defaultWeather: { type: Type.STRING },
              stylistAdvice: { type: Type.STRING },
              garmentType: { type: Type.STRING },
              collarDepth: { type: Type.INTEGER },
              collarCenter: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 normalized X" },
                  y: { type: Type.INTEGER, description: "0-1000 normalized Y" },
                },
                required: ["x", "y"]
              },
              leftShoulder: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 normalized X" },
                  y: { type: Type.INTEGER, description: "0-1000 normalized Y" },
                },
                required: ["x", "y"]
              },
              rightShoulder: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 normalized X" },
                  y: { type: Type.INTEGER, description: "0-1000 normalized Y" },
                },
                required: ["x", "y"]
              },
              garmentBox: {
                type: Type.OBJECT,
                properties: {
                  ymin: { type: Type.INTEGER, description: "0-1000 top edge" },
                  xmin: { type: Type.INTEGER, description: "0-1000 left edge" },
                  ymax: { type: Type.INTEGER, description: "0-1000 bottom edge" },
                  xmax: { type: Type.INTEGER, description: "0-1000 right edge" },
                },
                required: ["ymin", "xmin", "ymax", "xmax"]
              },
              garmentPolygon: {
                type: Type.ARRAY,
                description: "8-14 clockwise boundary points of the garment in 0-1000 space",
                items: {
                  type: Type.OBJECT,
                  properties: {
                    x: { type: Type.INTEGER },
                    y: { type: Type.INTEGER },
                  },
                  required: ["x", "y"]
                }
              }
            },
            required: ["name", "category", "tag", "description", "material", "cutDesign", "hygieneDesign", "fitScore", "comfortLevel", "defaultScene", "stylistAdvice", "garmentBox", "garmentPolygon"]
          }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (e) {
      console.error('Analyze clothing error:', e);
      return {
        name: '自选时尚服饰',
        category: 'chic',
        categoryLabel: '潮流高定',
        tag: '独家定制',
        tagColor: 'bg-teal-100 text-teal-800',
        emoji: '👕',
        description: '用户自选上传的精美服饰，舒适亲肤，色彩协调，兼顾日常活动与拍照出片。',
        material: '亲肤柔软织物 + 弹性领口',
        cutDesign: '贴合肩胸曲线，四肢活动自如无束缚',
        hygieneDesign: '穿脱便捷，版型利落舒适',
        fitScore: 98,
        comfortLevel: '亲肤透气 98%',
        defaultScene: '日常出街、居家打卡、聚会穿搭',
        defaultWeather: '四季皆宜',
        stylistAdvice: '这套自选服饰颜色非常提气色！上身版型挺括自然，日常穿搭与拍照都很出片！',
        garmentType: 'sweater',
        collarDepth: 12,
        garmentBox: { ymin: 50, xmin: 50, ymax: 950, xmax: 950 }
      };
    }
  },

  async analyzePet({ image }: { image: { mimeType: string, data: string } }) {
    try {
      const response = await getAiClient().models.generateContent({
        model: FAST_MULTIMODAL_MODEL,
        contents: {
          parts: [
            { inlineData: image },
            {
              text: `你是虚拟试衣人体与宠物姿态识别专家。请精确定位这张照片中的主试穿对象（可能是人物，也可能是猫/狗/兔等宠物），用于直接把衣服穿到人物或宠物身上。
所有坐标均使用 0-1000 整数归一化坐标（0=最上/最左，1000=最下/最右）：
- species: 如果是人则填 'person'，否则填 'dog' | 'cat' | 'bunny' | 'other'
- speciesLabel: '人物' | '狗狗' | '猫咪' | '兔兔' | '萌宠'
- pose: 'front' | 'three_quarter' | 'side'
- headBox: 头部、面部和下巴区域 { ymin, xmin, ymax, xmax }（确保下巴和头发位于此框内，不会被衣领遮挡）
- neckPoint: 脖子正前方/锁骨领口中心点 { x, y }
- leftShoulder: 画面中主体的左肩外侧点 { x, y }（对人物即为左肩关节外缘，对宠物即为左前肩胛外缘）
- rightShoulder: 画面中主体的右肩外侧点 { x, y }（对人物即为右肩关节外缘，对宠物即为右前肩胛外缘）
- torsoBox: 适合穿戴上衣/服饰的躯干区域 { ymin, xmin, ymax, xmax }（top 从脖子根部/双肩上方开始，left/right 包含双肩与袖宽，bottom 到腰腹/胯部下摆，绝不遮挡面部与下巴）
- bodyAngleDeg: 躯干/双肩倾斜角度整数 (-35 到 35，水平正对为 0)`
            }
          ]
        },
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              species: { type: Type.STRING },
              speciesLabel: { type: Type.STRING },
              pose: { type: Type.STRING },
              headBox: {
                type: Type.OBJECT,
                properties: {
                  ymin: { type: Type.INTEGER, description: "0-1000 head top" },
                  xmin: { type: Type.INTEGER, description: "0-1000 head left" },
                  ymax: { type: Type.INTEGER, description: "0-1000 chin bottom" },
                  xmax: { type: Type.INTEGER, description: "0-1000 head right" },
                },
                required: ["ymin", "xmin", "ymax", "xmax"]
              },
              torsoBox: {
                type: Type.OBJECT,
                properties: {
                  ymin: { type: Type.INTEGER, description: "0-1000 shoulder top" },
                  xmin: { type: Type.INTEGER, description: "0-1000 torso left" },
                  ymax: { type: Type.INTEGER, description: "0-1000 waist/hem bottom" },
                  xmax: { type: Type.INTEGER, description: "0-1000 torso right" },
                },
                required: ["ymin", "xmin", "ymax", "xmax"]
              },
              neckPoint: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 collar center X" },
                  y: { type: Type.INTEGER, description: "0-1000 collar center Y" },
                },
                required: ["x", "y"]
              },
              leftShoulder: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 left shoulder X" },
                  y: { type: Type.INTEGER, description: "0-1000 left shoulder Y" },
                },
                required: ["x", "y"]
              },
              rightShoulder: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.INTEGER, description: "0-1000 right shoulder X" },
                  y: { type: Type.INTEGER, description: "0-1000 right shoulder Y" },
                },
                required: ["x", "y"]
              },
              bodyAngleDeg: { type: Type.INTEGER }
            },
            required: ["species", "speciesLabel", "headBox", "torsoBox", "neckPoint", "leftShoulder", "rightShoulder", "bodyAngleDeg"]
          }
        }
      });
      return JSON.parse(response.text || '{}');
    } catch (e) {
      console.error('Analyze pet error:', e);
      return {
        species: 'person',
        speciesLabel: '人物',
        pose: 'front',
        headBox: { ymin: 60, xmin: 360, ymax: 300, xmax: 640 },
        torsoBox: { ymin: 290, xmin: 240, ymax: 780, xmax: 760 },
        neckPoint: { x: 500, y: 300 },
        leftShoulder: { x: 290, y: 330 },
        rightShoulder: { x: 710, y: 330 },
        bodyAngleDeg: 0
      };
    }
  },

  async recommendOutfits({
    subjectType,
    species,
    subjectName,
    anatomy,
    outfits,
    image,
    language = 'zh',
  }: {
    subjectType: string;
    species: string;
    subjectName?: string;
    anatomy?: any;
    outfits: Array<{
      id: string;
      name: string;
      species: string;
      categoryLabel?: string;
      tag?: string;
      description?: string;
      material?: string;
      cutDesign?: string;
      defaultScore?: number;
      isCustom?: boolean;
    }>;
    image?: { mimeType: string; data: string } | null;
    language?: string;
  }) {
    const langNames: Record<string, string> = { zh: '中文', en: 'English', ko: 'Korean' };
    const safeOutfits = Array.isArray(outfits) ? outfits : [];

    // Compute simple anatomical proportions for Gemini prompt context
    let anatomySummary = '标准正面站姿体态';
    if (anatomy?.torsoBox && anatomy?.headBox) {
      const torsoW = Math.max(1, (anatomy.torsoBox.xmax ?? 650) - (anatomy.torsoBox.xmin ?? 350));
      const torsoH = Math.max(1, (anatomy.torsoBox.ymax ?? 750) - (anatomy.torsoBox.ymin ?? 350));
      const headW = Math.max(1, (anatomy.headBox.xmax ?? 600) - (anatomy.headBox.xmin ?? 360));
      const shoulderW =
        anatomy.leftShoulder && anatomy.rightShoulder
          ? Math.round(Math.hypot(anatomy.rightShoulder.x - anatomy.leftShoulder.x, anatomy.rightShoulder.y - anatomy.leftShoulder.y))
          : torsoW;
      const ratio = (torsoW / torsoH).toFixed(2);
      const headRatio = (shoulderW / headW).toFixed(2);
      anatomySummary = `姿态=${anatomy.pose || 'front'}，躯干宽高比=${ratio}，肩头比=${headRatio}，倾斜角=${anatomy.bodyAngleDeg ?? 0}°`;
    }

    const buildFallback = () => {
      const scored = [...safeOutfits].sort((a, b) => {
        const aExact = a.species === species ? 20 : a.species === 'other' ? 14 : 0;
        const bExact = b.species === species ? 20 : b.species === 'other' ? 14 : 0;
        const aCustom = a.isCustom ? 5 : 0;
        const bCustom = b.isCustom ? 5 : 0;
        return (bExact + bCustom + (b.defaultScore || 92)) - (aExact + aCustom + (a.defaultScore || 92));
      });
      const top3 = scored.slice(0, 3);
      return {
        bodyProfileSummary: `当前试穿对象为「${subjectType}」（${anatomySummary}），建议优先选择肩线利落、领口不卡颈且贴合躯干比例的剪裁版型。`,
        styleDirection: species === 'person' ? '立体肩线 · 质感日常穿搭' : '立体护胸 · 灵动无束缚穿搭',
        recommendations: top3.map((o, idx) => ({
          outfitId: o.id,
          rank: idx + 1,
          matchScore: Math.max(88, Math.min(99, (o.defaultScore || 96) - idx)),
          fitHighlight: idx === 0 ? '肩颈轮廓黄金契合' : idx === 1 ? '躯干比例修身平衡' : '质感配色氛围出众',
          reason: `${o.name} 采用「${o.cutDesign || '立体贴身剪裁'}」，对当前${subjectType}体态兼容性极佳，兼具上身美观度与活动舒适度。`,
        })),
      };
    };

    if (safeOutfits.length === 0) {
      return buildFallback();
    }

    try {
      const catalogText = safeOutfits
        .map(
          (o, i) =>
            `${i + 1}. [id=${o.id}] 名称:${o.name} | 适用:${o.species} | 风格:${o.categoryLabel || ''} | 标签:${o.tag || ''} | 剪裁:${o.cutDesign || ''} | 面料:${o.material || ''} | 描述:${o.description || ''}`
        )
        .join('\n');

      const parts: any[] = [];
      if (image?.data && image?.mimeType) {
        parts.push({ inlineData: image });
      }
      parts.push({
        text: `你是一位资深 AI 时尚造型与人体/宠物体态适配专家。
请根据当前试穿对象的类型、体态数据和可选衣橱清单，使用${langNames[language] || '中文'}给出全身穿搭分析，并严格从衣橱清单中挑选契合度最高的 **3套** 服装（outfitId 必须原样来自清单中的 id，不可重复，不足3套则按实际数量返回）。

当前试穿对象信息：
- 对象名称: ${subjectName || subjectType}
- 对象类型: ${subjectType} (species=${species})
- 体态测量数据: ${anatomySummary}

衣橱候选服装清单：
${catalogText}

筛选与评分原则：
1. 若当前是人物 (species=person)，优先挑选「other (人物/通用)」或自选定制的服饰，若清单中通用/定制服饰不足3件，可按造型搭配潜力与视觉契合度补足3件并说明穿搭适配方式。
2. 若当前是猫咪/狗狗/兔兔，优先挑选对应物种及「other」通用款式中与当前姿态（正对/侧身/倾斜角）、肩宽及领口最匹配的服装。
3. 结合肩宽比例、领口深浅、面料垂坠感给出具体且有说服力的体态契合点评。`
      });

      const response = await getAiClient().models.generateContent({
        model: FAST_MULTIMODAL_MODEL,
        contents: { parts },
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              bodyProfileSummary: { type: Type.STRING },
              styleDirection: { type: Type.STRING },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    outfitId: { type: Type.STRING },
                    rank: { type: Type.INTEGER },
                    matchScore: { type: Type.INTEGER },
                    fitHighlight: { type: Type.STRING },
                    reason: { type: Type.STRING },
                  },
                  required: ["outfitId", "rank", "matchScore", "fitHighlight", "reason"],
                },
              },
            },
            required: ["bodyProfileSummary", "styleDirection", "recommendations"],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      const validIds = new Set(safeOutfits.map(o => o.id));
      const seen = new Set<string>();
      const validRecs = (Array.isArray(parsed.recommendations) ? parsed.recommendations : [])
        .filter((r: any) => r?.outfitId && validIds.has(r.outfitId) && !seen.has(r.outfitId) && (seen.add(r.outfitId), true))
        .slice(0, 3);

      // Fill up to 3 if Gemini returned fewer valid IDs
      if (validRecs.length < Math.min(3, safeOutfits.length)) {
        const fallback = buildFallback().recommendations;
        for (const fb of fallback) {
          if (validRecs.length >= 3) break;
          if (!seen.has(fb.outfitId)) {
            seen.add(fb.outfitId);
            validRecs.push({ ...fb, rank: validRecs.length + 1 });
          }
        }
      }

      return {
        bodyProfileSummary: parsed.bodyProfileSummary || buildFallback().bodyProfileSummary,
        styleDirection: parsed.styleDirection || buildFallback().styleDirection,
        recommendations: validRecs.map((r: any, idx: number) => ({
          ...r,
          rank: idx + 1,
          matchScore: Math.max(85, Math.min(99, Number(r.matchScore) || 95)),
        })),
      };
    } catch (e) {
      console.error('Recommend outfits error:', e);
      return buildFallback();
    }
  }
};


