import fs from 'fs';
import path from 'path';

export interface LocalPetContext {
  name?: string;
  species?: string;
  weight?: number;
  gender?: string;
  isNeutered?: boolean;
}

export interface LocalVetTurn {
  role: 'user' | 'model';
  parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }>;
}

interface BreedEntry {
  id: string;
  species: 'cat' | 'dog';
  name: string;
  englishName: string;
  lifespan: string;
  temperament: string[];
  geneticDiseases: string[];
  careTips: string[];
}

let cachedBreeds: BreedEntry[] | null = null;

function loadBreeds(): BreedEntry[] {
  if (cachedBreeds) return cachedBreeds;
  try {
    const filePath = path.resolve(process.cwd(), 'src/data/pet_breed.json');
    if (fs.existsSync(filePath)) {
      cachedBreeds = JSON.parse(fs.readFileSync(filePath, 'utf-8')) as BreedEntry[];
      return cachedBreeds;
    }
  } catch {
    // ignore read failure
  }
  cachedBreeds = [];
  return cachedBreeds;
}

function getPetLabel(pet?: LocalPetContext | null, lang: string = 'zh'): string {
  if (!pet || (!pet.name && !pet.species)) {
    return lang === 'en' ? 'your pet' : lang === 'ko' ? '반려동물' : '毛孩子';
  }
  if (pet.name) return pet.name;
  if (lang === 'en') return pet.species === 'cat' ? 'your cat' : pet.species === 'dog' ? 'your dog' : 'your pet';
  if (lang === 'ko') return pet.species === 'cat' ? '고양이' : pet.species === 'dog' ? '강아지' : '반려동물';
  return pet.species === 'cat' ? '猫咪' : pet.species === 'dog' ? '狗狗' : '毛孩子';
}

function getDailyWaterHint(pet?: LocalPetContext | null, lang: string = 'zh'): string {
  if (!pet?.weight || pet.weight <= 0) return '';
  const minMl = Math.round(pet.weight * 45);
  const maxMl = Math.round(pet.weight * 60);
  if (lang === 'en') return ` (about ${minMl}-${maxMl} ml/day for ${pet.weight}kg)`;
  if (lang === 'ko') return ` (${pet.weight}kg 기준 하루 약 ${minMl}~${maxMl}ml 권장)`;
  return `（按当前 ${pet.weight}kg 体重估算，每日基础饮水约 ${minMl}-${maxMl}ml）`;
}

function extractText(parts: Array<{ text?: string; inlineData?: any }> | string): { text: string; hasImage: boolean } {
  if (typeof parts === 'string') {
    return { text: parts.trim(), hasImage: false };
  }
  if (!Array.isArray(parts)) {
    return { text: '', hasImage: false };
  }
  let text = '';
  let hasImage = false;
  for (const p of parts) {
    if (typeof p?.text === 'string' && p.text.trim()) {
      text += (text ? ' ' : '') + p.text.trim();
    }
    if (p?.inlineData?.data) {
      hasImage = true;
    }
  }
  return { text: text.trim(), hasImage };
}

function findBreedMatch(query: string): BreedEntry | null {
  const q = query.toLowerCase();
  const breeds = loadBreeds();
  for (const b of breeds) {
    const shortZh = b.name.replace(/(猫|犬)$/u, '');
    if (
      q.includes(b.name.toLowerCase()) ||
      (shortZh.length >= 2 && q.includes(shortZh.toLowerCase())) ||
      q.includes(b.englishName.toLowerCase())
    ) {
      return b;
    }
  }
  return null;
}

interface TopicRule {
  id: string;
  keywords: RegExp;
  respond: (ctx: { query: string; lang: string; pet?: LocalPetContext | null; isFollowUp: boolean }) => string;
}

const TOPIC_RULES: TopicRule[] = [
  {
    id: 'medical-record-scan',
    keywords: /(病历|化验单|疫苗本|体检报告|血常规|生化)/i,
    respond: ({ lang }) => {
      if (lang === 'en') {
        return `Report Checklist: Check CBC (WBC/RBC/PLT), liver & kidney values (ALT, BUN, CREA), and vaccine/deworming due dates.
Home Care: Keep pets resting with fresh water if mild abnormalities appear, and save previous reports for trend comparison.
See a Vet If: High white blood cells, elevated creatinine/liver enzymes, or signs like fever, jaundice, or repeated vomiting occur.`;
      }
      return `重点指标核对：建议优先查看血常规（白细胞 WBC 判断感染/炎症、红细胞与血小板判断贫血或凝血）、肝肾生化（ALT、BUN、CREA）以及疫苗/驱虫下次到期日。
居家建议：若指标仅轻度波动且宠物精神食欲正常，可多饮水清淡喂养并拍照留存历史报告，方便复查对比趋势。
就医提醒：若出现白细胞显著升高或偏低、肌酐/转氨酶大幅超标，或伴随发热、精神萎靡、频繁呕吐，请携带原件尽快复诊。`;
    },
  },
  {
    id: 'poison-chocolate',
    keywords: /(巧克力|可可|咖啡|茶碱|chocolate|cocoa|theobromine|초콜릿)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      const weightNote = pet?.weight ? `（当前 ${pet.weight}kg，体重越小风险越高）` : '';
      if (lang === 'en') {
        return `Likely Cause: Theobromine and caffeine in chocolate are toxic to pets and cannot be metabolized quickly.
Home Care: Keep the wrapper to check cocoa percentage and amount eaten, do NOT force home vomiting blindly, and note the exact ingestion time for ${name}.
See a Vet If: Chocolate ingestion is always urgent—head to an emergency vet immediately (ideally within 1-2 hours) if ${name} ate dark/baking chocolate or shows panting, tremors, or vomiting.`;
      }
      if (lang === 'ko') {
        return `예상 원인: 초콜릿의 테오브로민과 카페인은 반려동물에게 심각한 중독을 일으킵니다.
홈 케어: 섭취한 초콜릿 종류(다크/밀크), 먹은 양, 섭취 시간을 메모해 두고 억지로 구토시키지 마세요.
병원 방문: 소량이라도 1~2시간 이내에 즉시 동물병원에 내원해 위세척 또는 활성탄 처치를 받는 것이 안전합니다.`;
      }
      return `可能原因：巧克力中的可可碱和咖啡因无法被宠物正常代谢，易引起中毒及心律失常${weightNote}。
居家建议：立刻保留包装袋核对黑巧/牛奶巧浓度与大致克数，记下误食时间，切勿盲目灌盐水或强行催吐以免误吸。
就医提醒：误食巧克力属于急症，建议在 1-2 小时黄金窗口内尽快带${name}去医院催吐或服用活性炭；若出现喘气、心跳快、发抖或呕吐须立刻急诊。`;
    },
  },
  {
    id: 'poison-toxic-food',
    keywords: /(葡萄|提子|洋葱|大葱|大蒜|韭菜|木糖醇|百合|老鼠药|杀虫剂|grape|raisin|onion|garlic|xylitol|lily|포도|양파)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Grapes/raisins (kidney failure), onions/garlic (hemolytic anemia), xylitol (hypoglycemia), and lilies (cat kidney toxicity) are highly dangerous.
Home Care: Immediately remove remaining food/plants, keep packaging for weight/dose estimation, and monitor ${name} closely.
See a Vet If: Go to an emergency vet right away without waiting for symptoms—early decontamination within 1-2 hours is critical.`;
      }
      return `可能原因：葡萄/提子易诱发急性肾衰竭，葱蒜类会破坏红细胞导致溶血性贫血，木糖醇可致剧烈低血糖，百合花对猫咪有极强肾毒性。
居家建议：立即清理剩余食物或植物防止二次误食，拍照保留残留物与包装，记录大概摄入量与时间，切勿自行喂人用药。
就医提醒：此类毒物潜伏期可能达数小时，不要等出现症状才去医院，建议立即带${name}到最近宠物医院做催吐、洗胃及护肝肾支持治疗。`;
    },
  },
  {
    id: 'foreign-body',
    keywords: /(骨头|鸡骨|鱼刺|塑料|线头|头发|橡皮筋|袜子|异物|吞了|卡住|bone|swallow|foreign|삼켰|뼈)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Sharp bones or linear objects (thread, hair ties) can scratch or obstruct the esophagus and intestines.
Home Care: Check the mouth gently if visible without forcing jaws open; never pull a hanging thread from the mouth or anus, and do NOT give laxatives blindly.
See a Vet If: Seek immediate X-ray/endoscopy if ${name} gags, paws at the mouth, vomits repeatedly, has abdominal pain, or stops passing stool.`;
      }
      return `可能原因：尖锐禽类骨头或长条异物（线头、皮筋、塑料）容易划伤食道或引起胃肠道梗阻、肠套叠。
居家建议：切勿强行伸手抠喉咙，若口腔或肛门外露出线头绝对不要硬拽；先禁食观察 4-6 小时，不要盲目喂泻药或强行催吐（尖锐骨头二次划伤风险高）。
就医提醒：如果${name}出现干呕、不停挠嘴、流口水、肚子发硬疼痛、反复吐水或超过 24 小时不排便，需立刻就医拍片或内窥镜取出。`;
    },
  },
  {
    id: 'urinary-urgent',
    keywords: /(尿频|尿血|尿闭|尿不出|排尿困难|蹲猫砂|乱尿|闭尿|urin|pee|litter|혈뇨|배뇨)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      const isMaleCat = pet?.species === 'cat' && pet?.gender === 'male';
      if (lang === 'en') {
        return `Likely Cause: Feline lower urinary tract disease (FLUTD), bladder crystals/stones, stress cystitis, or urinary tract infection${isMaleCat ? ' (male cats face high blockage risk)' : ''}.
Home Care: Keep the litter area quiet and clean, encourage warm water/wet food intake, and check litter clumps for size and blood traces.
See a Vet If: Straining with zero urine output for over 12 hours, crying in the litter box, or licking genitals nonstop is a life-threatening emergency—go immediately.`;
      }
      return `可能原因：常见于自发性膀胱炎、尿路结晶/结石或泌尿道感染${isMaleCat ? '（公猫尿道狭窄，极易发生致命性尿闭）' : ''}。
居家建议：立即检查猫砂盆或尿垫排尿量，保持环境安静减少应激，增加湿粮与清洁饮水${getDailyWaterHint(pet, lang)}，勿挤压膀胱。
就医提醒：如果${name}频繁蹲盆却一滴尿都排不出、排尿嚎叫、尿液带血或超过 12 小时未排尿，属于高危急症，必须立刻送医导尿！`;
    },
  },
  {
    id: 'vomiting',
    keywords: /(呕吐|吐黄水|吐白沫|吐狗粮|吐猫粮|吐毛|反胃|vomit|throw up|bile|구토|토)/i,
    respond: ({ lang, pet, isFollowUp }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: ${isFollowUp ? 'Following up on the vomiting: ' : ''}Empty-stomach bile reflux, eating too fast, mild gastritis, hairballs, or dietary indiscretion.
Home Care: Fast from food for 6-8 hours (4 hours for kittens/puppies), offer small sips of lukewarm water every 30-60 minutes, then resume bland food in tiny portions.
See a Vet If: Vomiting occurs more than 3 times in 24 hours, contains blood/coffee-ground material, or comes with severe lethargy, fever, or diarrhea.`;
      }
      if (lang === 'ko') {
        return `예상 원인: 공복성 담즙 역류(노란 위액), 급한 식사, 헤어볼, 또는 가벼운 위장염일 수 있습니다.
홈 케어: 6~8시간 금식(어린 개체는 4시간) 후 소량의 미지근한 물을 조금씩 급여하고, 토하지 않으면 소량씩 부드러운 식사를 시작하세요.
병원 방문: 하루 3회 이상 반복 구토하거나 피/거품이 섞이고, 무기력함·설사·열이 동반되면 즉시 내원하세요.`;
      }
      return `可能原因：${isFollowUp ? '结合前面的呕吐情况，' : ''}常见为空腹时间过长导致胃酸反流（吐黄水）、吃得太急未消化、猫咪吐毛球或轻度急性胃炎。
居家建议：先暂停喂食 6-8 小时（幼宠 3-4 小时防低血糖），期间少量多次提供温水观察；若不再呕吐，用温水泡软主粮或清淡易消化食物分多次少喂。
就医提醒：若${name} 24 小时内连续呕吐超过 3 次、连喝水都吐、呕吐物带血或咖啡色，或伴随发烧、拉稀、精神瘫软，须立刻去医院排查胰腺炎、细小或异物梗阻。`;
    },
  },
  {
    id: 'diarrhea',
    keywords: /(拉稀|腹泻|软便|拉水|拉血|便血|稀便|肠胃炎|diarrhea|loose stool|bloody stool|설사|묽은변)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Sudden food change, spoiled snacks, intestinal parasites, stress colitis, or viral/bacterial gastroenteritis.
Home Care: Pause treats and oily foods, feed small bland meals with pet probiotics, and keep ${name} hydrated${getDailyWaterHint(pet, lang)}.
See a Vet If: Watery or bloody diarrhea lasts over 24 hours, smells foul/fishy, or affects an unvaccinated puppy/kitten or lethargic pet.`;
      }
      return `可能原因：多与突然换粮、误食油腻/变质食物、体内寄生虫、着凉应激或急性肠胃炎有关。
居家建议：立即停掉零食和罐头，喂食平时主粮的 7 分量并配合宠物专用益生菌调理肠道，保证干净饮水防脱水${getDailyWaterHint(pet, lang)}。
就医提醒：若水样稀便超过 24 小时、大便带血或呈腥臭番茄酱样、伴随呕吐拒食，或${name}尚未完成免疫，请立刻就医化验粪便及传染病试纸。`;
    },
  },
  {
    id: 'appetite-lethargy',
    keywords: /(不吃|食欲|绝食|挑食|没精神|精神差|嗜睡|发呆|打蔫|不爱动|appetite|not eating|letharg|밥을 안|식욕)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      const isCat = pet?.species === 'cat';
      if (lang === 'en') {
        return `Likely Cause: Stress, dental/oral pain, mild fever, digestive upset, or picky eating habits${isCat ? ' (note: cats develop fatty liver quickly if starved >48h)' : ''}.
Home Care: Check gums/teeth for redness, measure body warmth (ears/paw pads), try warming wet food slightly to boost aroma, and record water and litter output.
See a Vet If: Complete refusal to eat lasts over 24 hours in cats (or 48 hours in dogs), or ${name} hides, breathes rapidly, or refuses even favorite treats.`;
      }
      if (lang === 'ko') {
        return `예상 원인: 환경 변화 스트레스, 구강/치아 통증, 발열, 또는 초기 소화기 불편감일 수 있습니다.
홈 케어: 잇몸 색과 체온(귀/발바닥 열감)을 확인하고, 습식 사료를 살짝 데워 향을 높여 기호성을 테스트해 보세요.
병원 방문: 고양이가 24시간 이상(강아지는 48시간) 전혀 먹지 않거나 숨고 구토·열이 동반되면 바로 진료를 받으세요.`;
      }
      return `可能原因：常见于环境应激、天气炎热、挑食厌食，也可能是口腔疼痛（牙龈炎/口炎）、轻度发烧或早期消化道不适${isCat ? '（猫咪连续绝食超过 48 小时有脂肪肝风险）' : ''}。
居家建议：先检查口腔牙龈是否红肿流涎、摸耳朵和鼻头是否异常发烫；可尝试把湿粮稍微温热提香，或喂一点平时最爱的冻干/肉泥观察是否有吞咽意愿。
就医提醒：如果${name}对最爱零食也毫无兴趣、躲在角落不动、呼吸急促，或猫咪完全禁食超过 24 小时、狗狗超过 48 小时，请尽快带去医院做血常规和基础体检。`;
    },
  },
  {
    id: 'constipation',
    keywords: /(便秘|不拉屎|几天没拉|排便困难|大便干|constipat|변비)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Insufficient water intake, hairball buildup (in cats), lack of fiber/exercise, or swallowing indigestible material.
Home Care: Increase moisture with wet food or warm water, add a small pinch of plain pumpkin/fiber or hairball gel, and encourage gentle play.
See a Vet If: ${name} strains repeatedly in vain for over 48-72 hours, vomits, or cries out with a swollen belly.`;
      }
      return `可能原因：饮水量不足、运动量偏少、猫咪毛球积聚或膳食纤维摄入不够。
居家建议：增加湿粮与温水摄入${getDailyWaterHint(pet, lang)}，可适量拌入少许宠物化毛膏、南瓜泥或益生菌，并引导适度走动促进肠蠕动。
就医提醒：如果${name}超过 48-72 小时仍未排便、反复用力努责却拉不出、伴随呕吐或腹部胀硬疼痛，须就医拍片排查巨结肠或梗阻。`;
    },
  },
  {
    id: 'respiratory-cold',
    keywords: /(咳嗽|打喷嚏|流鼻涕|鼻塞|鼻支|发烧|呼吸|喘|感冒|cough|sneez|fever|breath|기침|재채기)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Upper respiratory infection (cat flu / kennel cough), dust/pollen allergy, cold air irritation, or airway sensitivity.
Home Care: Keep indoor air warm and dust-free, wipe nasal/eye discharge gently with warm saline gauze, and avoid drafts or strenuous exercise.
See a Vet If: Open-mouth breathing, resting breathing rate over 40 breaths/min, bluish gums, persistent fever, or thick yellow-green nasal pus require prompt vet care.`;
      }
      return `可能原因：常见于受凉引发的上呼吸道感染（如猫咪鼻支、狗狗窝咳）、粉尘/冷空气刺激或支气管敏感。
居家建议：保持室内温暖避风与空气湿度（避免香薰或烟尘），用温生理盐水轻拭鼻周和眼角分泌物，暂时停洗澡并减少剧烈跑跳。
就医提醒：一旦发现${name}张口呼吸、安静睡眠时胸腹呼吸超过 40 次/分钟、鼻涕呈黄绿色脓状或持续高烧精神差，需立刻就医听诊拍胸片。`;
    },
  },
  {
    id: 'skin-itch-hairloss',
    keywords: /(掉毛|猫癣|皮肤|瘙痒|挠|红疹|结痂|皮屑|湿疹|脓皮|螨虫|itch|scratch|skin|ringworm|rash|피부|탈모|가려움)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Fungal ringworm, bacterial/yeast dermatitis, food or seasonal allergies, mites, or excessive shedding.
Home Care: Put on an E-collar to stop scratching/licking, keep coat dry and clean, avoid human skin creams, and disinfect bedding in sunlight.
See a Vet If: Circular bald patches, oozing sores, foul skin odor, or spreading redness need a vet skin scraping/Wood's lamp test for targeted medication.`;
      }
      return `可能原因：常见于真菌感染（猫癣/狗癣）、湿疹脓皮症、食物或环境过敏、体外寄生虫/螨虫或季节性换毛。
居家建议：先为${name}戴上伊丽莎白圈防止抓挠舔舐加重破溃，保持患处干燥透气并做好体内外驱虫，切勿涂抹人用皮炎平或激素药膏。
就医提醒：若出现圆形局部脱毛伴皮屑结痂、皮肤渗液发臭或红斑快速扩散，建议就医做伍德氏灯或皮屑镜检，确诊后再针对性用药。`;
    },
  },
  {
    id: 'ear-problem',
    keywords: /(耳朵|耳螨|甩头|挠耳朵|耳垢|耳臭|中耳炎|ear|mite|head shaking|귀|귓병)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Ear mites (dark coffee-ground debris), yeast/bacterial otitis, or trapped water after bathing.
Home Care: Gently wipe only the visible outer ear flap with pet ear cleaner—never probe deep into the ear canal with cotton swabs.
See a Vet If: Head tilting, loss of balance, foul ear odor, or painful swollen ear flaps require otoscopic exam and prescription ear drops.`;
      }
      return `可能原因：黑色咖啡渣样分泌物多提示耳螨，黄褐色油脂伴酸臭味常见于马拉色菌或细菌性外耳炎，也可能是洗澡进水未擦干所致。
居家建议：可用宠物专用洗耳液轻柔清洁外耳廓，切忌用棉签深入耳道捅拭，以免把耳垢推进鼓膜或划伤耳道。
就医提醒：如果${name}持续歪头、走路打转失去平衡、耳廓肿胀发热或一碰就疼叫，需尽快去医院做耳道镜检并使用对症滴耳液。`;
    },
  },
  {
    id: 'eye-problem',
    keywords: /(眼睛|眼屎|流泪|泪痕|红眼|睁不开|眨眼|角膜|eye|tear|squint|눈|눈꼽)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Conjunctivitis, dust irritation, blocked tear ducts, or corneal scratch from playing/rubbing.
Home Care: Rinse gently with sterile saline eye wash, wipe corners with soft damp gauze, and use an E-collar if ${name} keeps pawing the eye.
See a Vet If: Squinting shut, cloudy/bluish cornea, thick pus, or sudden swelling should be checked urgently by a vet (never use human steroid eye drops).`;
      }
      return `可能原因：常见于灰尘毛发刺激、结膜炎、鼻泪管敏感或玩耍/抓挠导致的角膜轻微擦伤。
居家建议：用宠物专用生理盐水或无刺激洗眼液轻轻冲洗擦净眼屎，若频繁搓眼建议戴上伊丽莎白圈，绝对不要给宠物乱滴含激素的人用眼药水。
就医提醒：若${name}出现单眼或双眼紧闭睁不开、眼白发红充血、眼球表面发白混浊或流出黄绿色脓液，须立即就医做荧光素钠角膜染色检查。`;
    },
  },
  {
    id: 'parasites',
    keywords: /(跳蚤|蜱虫|虱子|虫子|黑点|寄生虫|flea|tick|parasite|진드기|벼룩)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Flea or tick infestation picked up from grass, soil, or other animals.
Home Care: Apply a species- and weight-appropriate spot-on or oral preventive (never use dog permethrin products on cats!), and wash bedding in hot water. If a tick is attached, remove straight out at the skin line with fine tweezers without twisting or crushing it.
See a Vet If: Pale gums, fever, weakness, or a tick head left embedded in the skin requires prompt veterinary attention.`;
      }
      return `可能原因：户外草丛接触或未按期体外驱虫，导致跳蚤、蜱虫寄生（毛发根部见遇水变红的小黑点多为跳蚤粪便）。
居家建议：按${name}物种和体重选用正规宠物体外驱虫药（严禁把含菊酯的狗狗驱虫药用在猫咪身上），并高温清洗窝垫；发现蜱虫叮咬时用镊子紧贴皮肤垂直缓慢拔出，切勿硬扯或直接捏爆。
就医提醒：若蜱虫口器断在皮肤里红肿化脓，或宠物出现牙龈发白、发热、尿色深黄、精神萎靡，请立即就医排查血液寄生虫。`;
    },
  },
  {
    id: 'vaccine',
    keywords: /(疫苗|打针|免疫|猫三联|狂犬|联苗|抗体|vaccin|shot|백신|접종)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Vaccination Guide: Puppies and kittens typically start core vaccines at 8 weeks old (3 doses spaced 3-4 weeks apart) plus rabies, followed by annual/scheduled boosters.
Before & After Care: Only vaccinate when ${name} is healthy, eating normally, and dewormed; avoid bathing or changing food for 7 days after the shot, and wait 20-30 minutes at the clinic to watch for allergic swelling.
See a Vet If: Facial swelling, hives, repeated vomiting, or collapse after vaccination requires immediate emergency care.`;
      }
      if (lang === 'ko') {
        return `예방접종 안내: 건강한 상태에서 구충 후 접종하며, 접종 후 20~30분간 병원에서 알레르기 반응을 관찰하는 것이 안전합니다.
접종 전후 관리: 접종 후 7일간 목욕, 사료 변경, 장거리 외출을 피하고 충분한 휴식을 주세요.
병원 방문: 접종 후 얼굴 부종, 두드러기, 반복 구토 또는 호흡 곤란이 나타나면 즉시 병원으로 돌아가세요.`;
      }
      return `接种核心原则：幼犬幼猫通常满 8 周龄且精神食欲正常、完成驱虫后开始首免（核心联苗通常 3 针，每针间隔 21-28 天，加 1 针狂犬），之后按医嘱定期加强。
打疫苗前后注意：打针前 1 周确认无软便打喷嚏，接种后在医院留观 20-30 分钟防急性过敏；回家后 7 天内不要洗澡、不要换粮、减少剧烈玩耍与外出受凉。
就医提醒：接种后 1-2 天轻微嗜睡或食欲略减属正常反应；若出现脸部嘴唇肿胀、全身红疹、呼吸急促或持续呕吐，须立刻回医院抗过敏急救。`;
    },
  },
  {
    id: 'deworming',
    keywords: /(驱虫|体内驱虫|体外驱虫|球虫|心丝虫|拜耳|大宠爱|海乐妙|deworm|구충)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      const weightText = pet?.weight ? `（当前体重约 ${pet.weight}kg，请按该体重选对应规格）` : '';
      if (lang === 'en') {
        return `Deworming Schedule: Generally external deworming monthly and internal deworming every 1-3 months depending on outdoor exposure and raw diet.
Home Care: Dose strictly by species and weight; apply spot-on to the back of the neck where ${name} cannot lick, and avoid bathing 2 days before and after topical drops.
See a Vet If: Persistent worms in stool, severe diarrhea, or excessive drooling/tremors after accidental licking require veterinary advice.`;
      }
      return `常规驱虫周期：经常外出或吃生肉建议每月体外驱虫 1 次、每 1-3 个月体内驱虫 1 次；纯室内猫咪也建议至少每月体外/每季度体内各 1 次。
用药护理要点：严格区分猫狗专用药并按体重足量使用${weightText}；外用滴剂滴在后颈舔不到的皮肤上，用药前后 48 小时不洗澡；内服驱虫药建议饭后 2 小时喂服减少肠胃刺激。
就医提醒：若驱虫后大便持续出现大量虫体、剧烈腹泻呕吐，或误舔滴剂引发流涎抽搐，请及时带包装联系兽医处理。`;
    },
  },
  {
    id: 'neuter-spay',
    keywords: /(绝育|去势|发情|乱叫|踩奶|手术|拆线|伊丽莎白圈|neuter|spay|중성화)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Pre- & Post-Care: Complete core vaccines first and fast for 6-8 hours before anesthesia; pre-op bloodwork reduces anesthesia risk.
Home Care: Keep the E-collar or surgical suit on ${name} 24/7 until healing (usually 7-10 days), restrict jumping, and check the incision daily for redness or discharge.
See a Vet If: Wound opening, pus/bleeding, refusal to eat over 24 hours, or no urination post-op requires immediate recheck.`;
      }
      return `绝育时机与术前准备：建议完成基础疫苗、避开急性发情期，术前做血常规/生化评估降低麻醉风险，并遵医嘱术前禁食禁水 6-8 小时。
术后护理要点：24 小时全天佩戴伊丽莎白圈或穿绝育服（一般需 7-10 天），限制跳跃爬高以防伤口撕裂，每天检查切口是否干燥平整。
就医提醒：若发现${name}术后切口红肿渗液、开裂出血、超过 24 小时拒绝进食喝水或未排尿，请及时回医院复查。`;
    },
  },
  {
    id: 'injury-limp',
    keywords: /(瘸|跛|摔伤|扭伤|流血|伤口|爪子|指甲劈|limp|sprain|bleed|wound|절뚝|상처)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Likely Cause: Paw pad cut, torn nail, soft-tissue sprain, joint luxation, or fracture from jumping/impact.
Home Care: Restrict movement immediately in a small crate/room; for minor paw bleeding, press gently with sterile gauze and clean with saline (no alcohol directly on open wounds).
See a Vet If: Refusal to put any weight on the leg, visible bone deformity, deep bleeding that won't stop in 5 minutes, or intense pain needs an X-ray/sutures.`;
      }
      return `可能原因：常见于脚垫被玻璃/石子划伤、指甲劈裂、高处跳落引起的软组织扭伤、髌骨脱位或骨折。
居家建议：立刻限制${name}跑跳并检查四肢脚垫和指甲缝；轻微渗血可用无菌纱布按压止血并用生理盐水冲洗（不要用酒精直接涂抹开放伤口），戴好伊丽莎白圈防舔。
就医提醒：若肢体完全悬空不敢着地、关节明显变形肿大、按压超过 5 分钟仍止不住血，或触碰时尖叫抗拒，须尽快就医拍 X 光片排查骨折。`;
    },
  },
  {
    id: 'diet-feeding',
    keywords: /(喂食|吃多少|狗粮|猫粮|换粮|喝水|饮水|零食|营养|罐头|feed|food|diet|water|사료|급여)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      const waterHint = getDailyWaterHint(pet, lang);
      if (lang === 'en') {
        return `Feeding & Hydration: Feed by target body weight and life stage, transitioning new foods gradually over 7-10 days (start at 25% new / 75% old).
Daily Care: Ensure fresh water daily${waterHint}; avoid heavily salted human food, cooked bones, grapes, onions, and chocolate, and keep treats under 10% of daily calories.
See a Vet If: Rapid unexplained weight gain/loss, excessive thirst, or persistent soft stool after changing food warrants a checkup.`;
      }
      return `科学喂养原则：根据${name}年龄与理想体重定时定量喂食（按包装推荐克数微调，保持肋骨可轻触但看不明显突出为佳），换新粮务必采用“7-10 天渐进换粮法”。
饮水与零食建议：全天提供新鲜干净饮水${waterHint}，零食热量控制在每日总热量的 10% 以内，避免喂食高盐人类饭菜及洋葱、葡萄、巧克力、禽类熟骨。
健康观察：若短期内体重骤增/骤减、突然暴饮暴尿或换粮后持续软便，建议结合体检评估调整饮食方案。`;
    },
  },
  {
    id: 'grooming-bath',
    keywords: /(洗澡|刷牙|剪指甲|梳毛|泪痕|口臭|牙结石|bath|brush|teeth|nail|목욕|양치)/i,
    respond: ({ lang, pet }) => {
      const name = getPetLabel(pet, lang);
      if (lang === 'en') {
        return `Daily Grooming: Bathe dogs every 2-4 weeks (indoor cats rarely need baths unless dirty) with pet-specific pH shampoo and blow-dry the undercoat thoroughly to prevent damp skin issues.
Oral & Nail Care: Brush teeth 3+ times weekly with enzymatic pet toothpaste, trim nail tips every 2-3 weeks avoiding the pink quick, and brush long coats regularly.
See a Vet If: Severe bad breath, bleeding gums, or painful matted skin warrants a dental or dermatology check.`;
      }
      return `清洁护理频率：狗狗一般 2-4 周洗一次澡即可，室内猫咪有强自洁能力，非必要不用频繁水洗；洗后务必彻底吹干底层绒毛防潮湿皮炎，严禁使用人用沐浴露。
口腔与指甲：建议每周用宠物专用牙膏刷牙 2-3 次预防牙结石与口炎，每 2-3 周修剪一次指甲透明尖端（避开粉色血线），长毛品种勤梳防打结。
健康提示：若${name}出现严重口臭流口水、牙龈出血或皮肤大面积毛发打结紧贴皮肉，建议到宠物医院做口腔或洗护检查。`;
    },
  },
];

export function buildLocalVetReply(input: {
  messageParts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }>;
  history?: LocalVetTurn[];
  language?: string;
  petContext?: LocalPetContext | null;
}): string {
  const lang = input.language || 'zh';
  const { text, hasImage } = extractText(input.messageParts);
  const name = getPetLabel(input.petContext, lang);

  // Check if user only uploaded a photo or asked to look at a photo without specifying symptoms
  const genericPhotoPrompt = /^(请帮我看看这张照片。?|看看这张照片|帮我看看|analyze|check this photo|photo)$/i.test(text);

  // Combine current query with recent user turns if it looks like a short follow-up
  const isShortFollowUp =
    text.length <= 28 &&
    /(怎么办|怎么办呢|吃什么药|喂什么|多久|可以吗|需要|要紧吗|严重吗|怎么处理|注意什么|还有|继续|what|how|should i|medicine|어떻게)/i.test(text);

  let matchedRule: TopicRule | undefined = TOPIC_RULES.find((r) => r.keywords.test(text));
  let usedFollowUpContext = false;

  if (!matchedRule && isShortFollowUp && Array.isArray(input.history)) {
    const recentUserText = [...input.history]
      .reverse()
      .filter((t) => t.role === 'user')
      .slice(0, 3)
      .map((t) => extractText(t.parts).text)
      .join(' ');
    if (recentUserText) {
      matchedRule = TOPIC_RULES.find((r) => r.keywords.test(recentUserText));
      if (matchedRule) usedFollowUpContext = true;
    }
  }

  // Check breed-specific encyclopedia knowledge if user mentions a breed
  const breedMatch = findBreedMatch(text);
  if (!matchedRule && breedMatch) {
    if (lang === 'en') {
      return `Breed Profile (${breedMatch.englishName}): Typical lifespan is ${breedMatch.lifespan}, temperament tends to be ${breedMatch.temperament.join(', ')}.
Genetic Watchlist: Monitor for ${breedMatch.geneticDiseases.join(', ')}.
Care Tips: ${breedMatch.careTips.slice(0, 2).join(' ')}`;
    }
    return `品种健康要点（${breedMatch.name} / ${breedMatch.englishName}）：平均寿命约 ${breedMatch.lifespan}，常见性格特点为${breedMatch.temperament.join('、')}。
重点遗传病排查：日常体检建议重点关注${breedMatch.geneticDiseases.join('、')}。
护理建议：${breedMatch.careTips.slice(0, 2).join(' ')}`;
  }

  if (matchedRule) {
    const body = matchedRule.respond({
      query: text,
      lang,
      pet: input.petContext,
      isFollowUp: usedFollowUpContext,
    });
    if (hasImage && !genericPhotoPrompt) {
      const note =
        lang === 'en'
          ? `\nPhoto Observation Tip: Check the photographed area for redness, swelling, discharge color, or spreading, and share a clear close-up with your vet if visiting.`
          : lang === 'ko'
            ? `\n사진 확인 팁: 촬영한 부위의 발적, 부기, 분비물 색깔 변화 여부를 함께 기록해 두면 진료 시 큰 도움이 됩니다.`
            : `\n照片辅助核查：请重点观察照片部位是否有红肿、渗液、破溃或分泌物颜色变化，若需线下就诊请保留不同角度的清晰照片供医生对比。`;
      return `${body}${note}`;
    }
    return body;
  }

  if (hasImage || genericPhotoPrompt) {
    if (lang === 'en') {
      return `Photo Received: Local AI Vet has recorded the photo for ${name} and recommends a quick visual self-check.
What to Check: Note whether there is redness, swelling, oozing, hair loss, foul odor, or whether ${name} is scratching/licking the spot, plus appetite and energy level.
Next Step: Type a brief symptom description (for example: vomiting, skin rash, ear redness, eye discharge) and I can give targeted triage steps immediately.`;
    }
    return `照片已接收：离线智能兽医已记录${name}的影像问诊请求，建议结合画面细节做快速自查。
重点观察：请留意照片部位是否有红肿发热、渗液结痂、异味或脱毛范围扩大，同时观察${name}当前食欲、精神和大小便是否正常。
进一步咨询：你可以直接补充文字描述具体部位或症状（例如“皮肤红疹发痒”、“吐黄水”、“眼睛流泪”或“化验单指标”），我将立刻为你生成针对性护理与就医建议。`;
  }

  // General fallback for greetings or unrecognized questions
  if (/^(你好|您好|hi|hello|在吗|有人吗|안녕)/i.test(text)) {
    if (lang === 'en') {
      return `Hello! I am PetPal Health's built-in AI Vet assistant (ready anytime without an API key).
How I Can Help: Ask about vomiting, diarrhea, loss of appetite, toxic foods (chocolate/grapes), vaccines, deworming, skin/ear/eye issues, or daily feeding for ${name}.
Urgent Tip: If ${name} has breathing difficulty, collapse, seizures, or poisoning, please head to the nearest vet clinic immediately.`;
    }
    return `你好！我是“宠爱脉动”内置 AI 兽医助手（无需配置密钥即可全天候实时问答）。
我可以帮${name}解答：呕吐拉稀、不吃东西、误食巧克力/异物急救、尿频尿闭、皮肤猫癣/耳螨眼疾、疫苗驱虫以及日常喂养水量计算等问题。
贴心提醒：你可以直接输入具体症状（如“猫咪打喷嚏流眼泪两天了”），我将立即为你分析可能原因、居家护理方法和就医指征。`;
  }

  if (lang === 'en') {
    return `Initial Assessment: For ${name}, watch closely for changes in appetite, energy, drinking, vomiting/stool, and breathing over the next 12-24 hours.
Home Care: Provide fresh water${getDailyWaterHint(input.petContext, lang)}, keep the resting area warm and calm, avoid human medications, and share specific symptoms (like vomiting, diarrhea, itching, coughing, or diet) for targeted advice.
See a Vet If: High fever, repeated vomiting, bloody stool/urine, difficulty breathing, or severe lethargy lasts over 24 hours.`;
  }

  return `综合评估建议：针对你提到的情况，建议先重点观察${name}未来 12-24 小时的精神状态、食欲、饮水量${getDailyWaterHint(input.petContext, lang)}以及大小便是否正常。
居家护理：保持环境温暖安静、提供充足洁净饮水并暂停陌生零食，切勿自行喂食人用药物；若你能补充更具体的表现（如“呕吐/拉稀/咳嗽/抓痒/尿频/绝育护理”等关键词），我可以给出更精准的对症建议。
就医提醒：一旦出现持续精神沉郁、呼吸急促、反复呕吐腹泻、便血尿血或超过 24 小时不进食，请及时带往正规宠物医院面诊检查。`;
}
