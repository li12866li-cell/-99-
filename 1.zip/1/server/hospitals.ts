import fs from 'fs';
import path from 'path';

export interface RawHospitalRecord {
  id: string;
  name: string;
  city: 'suwon' | string;
  cityLabel?: string;
  district?: string;
  address: string;
  phone: string;
  fallbackLat?: number | null;
  fallbackLng?: number | null;
}

export interface NearbyHospitalItem {
  id: string;
  name: string;
  city: string;
  cityLabel: string;
  district: string;
  address: string;
  phone: string;
  lat: number | null;
  lng: number | null;
  distanceKm: number | null;
  distanceText: string;
  kakaoMapUrl: string;
  geocodedBy: 'kakao' | 'fallback' | 'none';
}

const HOSPITAL_DATA_PATH = path.resolve(process.cwd(), 'src', 'data', 'pet_hospital.json');

// 服务端地址转经纬度内存缓存，避免每次刷新重复消耗 Kakao API 配额
const geocodeCache = new Map<string, { lat: number; lng: number }>();

function loadHospitalRecords(): RawHospitalRecord[] {
  try {
    const raw = fs.readFileSync(HOSPITAL_DATA_PATH, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to read pet_hospital.json:', err);
    return [];
  }
}

function cleanKoreanAddress(address: string): string {
  return address
    .replace(/\([^)]*\)/g, '') // 去除括号内补充说明
    .replace(/,.*$/, '') // 去除逗号后楼层/室号
    .replace(/\s+\d+층.*$/g, '')
    .replace(/\s+\d+호.*$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

async function geocodeWithKakao(
  address: string,
  hospitalName: string,
  cityLabel: string,
  kakaoKey: string
): Promise<{ lat: number; lng: number } | null> {
  const cacheKey = `${address}|${hospitalName}`;
  if (geocodeCache.has(cacheKey)) {
    return geocodeCache.get(cacheKey)!;
  }

  const headers = { Authorization: `KakaoAK ${kakaoKey}` };
  const cleanedAddr = cleanKoreanAddress(address);

  // 1. 优先调用 Kakao 地址转经纬度接口 (Address Search)
  for (const candidate of Array.from(new Set([address, cleanedAddr].filter(Boolean)))) {
    try {
      const url = `https://dapi.kakao.com/v2/local/search/address.json?query=${encodeURIComponent(candidate)}`;
      const res = await fetch(url, { headers });
      if (res.ok) {
        const data: any = await res.json();
        const doc = data?.documents?.[0];
        if (doc?.y && doc?.x) {
          const coords = { lat: parseFloat(doc.y), lng: parseFloat(doc.x) };
          if (!Number.isNaN(coords.lat) && !Number.isNaN(coords.lng)) {
            geocodeCache.set(cacheKey, coords);
            return coords;
          }
        }
      } else {
        console.warn(`Kakao address search HTTP ${res.status} for "${candidate}"`);
      }
    } catch (err) {
      console.warn('Kakao address search error:', err);
    }
  }

  // 2. 若地址带老旧地番或门牌解析不到，使用 Kakao Keyword 兜底检索
  try {
    const keywordQuery = `${cityLabel} ${hospitalName}`.trim();
    const url = `https://dapi.kakao.com/v2/local/search/keyword.json?query=${encodeURIComponent(keywordQuery)}&size=1`;
    const res = await fetch(url, { headers });
    if (res.ok) {
      const data: any = await res.json();
      const doc = data?.documents?.[0];
      if (doc?.y && doc?.x) {
        const coords = { lat: parseFloat(doc.y), lng: parseFloat(doc.x) };
        if (!Number.isNaN(coords.lat) && !Number.isNaN(coords.lng)) {
          geocodeCache.set(cacheKey, coords);
          return coords;
        }
      }
    }
  } catch (err) {
    console.warn('Kakao keyword fallback error:', err);
  }

  return null;
}

function calcDistanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371; // 地球半径 (km)
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function formatDistanceText(distanceKm: number | null): string {
  if (distanceKm === null || Number.isNaN(distanceKm)) return '距离待定位';
  if (distanceKm < 1) {
    return `${Math.round(distanceKm * 1000)} m`;
  }
  return `${distanceKm.toFixed(1)} km`;
}

export const hospitalService = {
  isKakaoConfigured(): boolean {
    const key = process.env.KAKAO_MAP_API_KEY;
    return Boolean(key && key !== 'MY_KAKAO_REST_API_KEY');
  },

  async getNearbyHospitals(params: {
    lat?: number | null;
    lng?: number | null;
    city?: string;
  }): Promise<{
    hospitals: NearbyHospitalItem[];
    kakaoConfigured: boolean;
    total: number;
  }> {
    const { lat, lng, city = 'all' } = params;
    const kakaoKey = process.env.KAKAO_MAP_API_KEY || '';
    const kakaoConfigured = this.isKakaoConfigured();
    const hasUserCoords =
      typeof lat === 'number' &&
      typeof lng === 'number' &&
      Number.isFinite(lat) &&
      Number.isFinite(lng);

    const records = loadHospitalRecords().filter((item) => {
      if (city === 'all') return true;
      return item.city === city;
    });

    const enriched = await Promise.all(
      records.map(async (item): Promise<NearbyHospitalItem> => {
        const cityLabel = item.cityLabel || '수원시';
        let resolved: { lat: number; lng: number } | null = null;
        let geocodedBy: 'kakao' | 'fallback' | 'none' = 'none';

        if (kakaoConfigured) {
          resolved = await geocodeWithKakao(item.address, item.name, cityLabel, kakaoKey);
          if (resolved) geocodedBy = 'kakao';
        }

        if (!resolved && typeof item.fallbackLat === 'number' && typeof item.fallbackLng === 'number') {
          resolved = { lat: item.fallbackLat, lng: item.fallbackLng };
          geocodedBy = 'fallback';
        }

        const distanceKm =
          hasUserCoords && resolved
            ? calcDistanceKm(lat!, lng!, resolved.lat, resolved.lng)
            : null;

        const kakaoMapUrl = resolved
          ? `https://map.kakao.com/link/map/${encodeURIComponent(item.name)},${resolved.lat},${resolved.lng}`
          : `https://map.kakao.com/link/search/${encodeURIComponent(item.address || item.name)}`;

        return {
          id: item.id,
          name: item.name,
          city: item.city,
          cityLabel,
          district: item.district || '',
          address: item.address,
          phone: item.phone,
          lat: resolved?.lat ?? null,
          lng: resolved?.lng ?? null,
          distanceKm,
          distanceText: formatDistanceText(distanceKm),
          kakaoMapUrl,
          geocodedBy,
        };
      })
    );

    // 按距离由近到远排序；未获取到距离的排在后面
    enriched.sort((a, b) => {
      if (a.distanceKm === null && b.distanceKm === null) return 0;
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });

    return {
      hospitals: enriched,
      kakaoConfigured,
      total: enriched.length,
    };
  },
};
