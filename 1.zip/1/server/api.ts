import crypto from 'crypto';
import express from 'express';
import {
  AuthenticatedRequest,
  hashPassword,
  isSmtpConfigured,
  requireAuth,
  serializePublicUser,
  signAccessToken,
  validateEmail,
  validatePasswordStrength,
  verifyPassword,
} from './auth.ts';
import { geminiService } from './gemini.ts';
import { vetService } from './vet.ts';
import { hospitalService } from './hospitals.ts';
import { petcareStore } from './store.ts';
import { symptomServerService } from './symptoms.ts';

const router = express.Router();

// Health & System Capabilities
router.get('/health', (_req, res) => {
  const vetStatus = vetService.getStatus();
  res.json({
    ok: true,
    runtime: 'nodejs-express',
    pythonFastApiReserved: true,
    smtpConfigured: isSmtpConfigured(),
    ...vetStatus,
    kakaoConfigured: hospitalService.isKakaoConfigured(),
  });
});

// ========================
// Authentication & Profile
// ========================
router.post('/auth/register', (req, res) => {
  const body = req.body || {};
  const fullName = typeof body.fullName === 'string' ? body.fullName.trim() : '';
  const email = validateEmail(String(body.email || ''));
  const password = String(body.password || '');
  const confirmPassword = body.confirmPassword !== undefined ? String(body.confirmPassword) : undefined;
  const agreedToTerms = body.agreedToTerms !== false;

  if (!fullName) {
    res.status(400).json({ error: '姓名不能为空' });
    return;
  }
  if (!email) {
    res.status(400).json({ error: '请输入有效的电子邮箱地址' });
    return;
  }
  const pwErr = validatePasswordStrength(password);
  if (pwErr) {
    res.status(400).json({ error: pwErr });
    return;
  }
  if (confirmPassword !== undefined && password !== confirmPassword) {
    res.status(400).json({ error: '两次输入的密码不一致' });
    return;
  }
  if (!agreedToTerms) {
    res.status(400).json({ error: '请阅读并同意服务条款和隐私政策' });
    return;
  }

  if (petcareStore.findUserByEmail(email)) {
    res.status(409).json({ error: '该电子邮箱已被注册，请直接登录或更换邮箱' });
    return;
  }

  const now = new Date().toISOString();
  const user = petcareStore.createUser({
    id: `usr_${crypto.randomBytes(8).toString('hex')}`,
    fullName,
    email,
    passwordHash: hashPassword(password),
    avatarUrl: null,
    isActive: true,
    emailVerified: false,
    createdAt: now,
    updatedAt: now,
  });

  const token = signAccessToken(user, true);
  res.status(201).json({
    accessToken: token.accessToken,
    tokenType: 'bearer',
    expiresAt: token.expiresAt,
    user: serializePublicUser(user),
  });
});

router.post('/auth/login', (req, res) => {
  const body = req.body || {};
  const email = validateEmail(String(body.email || ''));
  const password = String(body.password || '');
  const rememberMe = body.rememberMe !== false;

  if (!email) {
    res.status(400).json({ error: '请输入有效的电子邮箱地址' });
    return;
  }
  if (!password) {
    res.status(400).json({ error: '请输入登录密码' });
    return;
  }

  const user = petcareStore.findUserByEmail(email);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    res.status(401).json({ error: '邮箱或密码不正确，请核对后重试' });
    return;
  }
  if (!user.isActive) {
    res.status(403).json({ error: '该账号已被停用，请联系管理员' });
    return;
  }

  const token = signAccessToken(user, rememberMe);
  res.json({
    accessToken: token.accessToken,
    tokenType: 'bearer',
    expiresAt: token.expiresAt,
    user: serializePublicUser(user),
  });
});

router.get('/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ user: serializePublicUser(req.authUser!) });
});

router.put('/auth/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.authUser!;
  const body = req.body || {};
  const patch: Record<string, any> = {};
  let emailReverificationRequired = false;

  if (body.fullName !== undefined) {
    const cleaned = String(body.fullName).trim();
    if (!cleaned) {
      res.status(400).json({ error: '姓名不能为空' });
      return;
    }
    patch.fullName = cleaned;
  }

  if (body.avatarUrl !== undefined) {
    patch.avatarUrl = body.avatarUrl ? String(body.avatarUrl) : null;
  }

  if (body.email !== undefined) {
    const nextEmail = validateEmail(String(body.email));
    if (!nextEmail) {
      res.status(400).json({ error: '请输入有效的电子邮箱地址' });
      return;
    }
    if (nextEmail !== user.email) {
      const existing = petcareStore.findUserByEmail(nextEmail);
      if (existing && existing.id !== user.id) {
        res.status(409).json({ error: '该邮箱已被其他账号占用' });
        return;
      }
      patch.email = nextEmail;
      patch.emailVerified = false;
      emailReverificationRequired = true;
    }
  }

  const updated = petcareStore.updateUser(user.id, patch);
  if (!updated) {
    res.status(404).json({ error: '用户不存在' });
    return;
  }

  res.json({
    user: serializePublicUser(updated),
    emailReverificationRequired,
    message: emailReverificationRequired
      ? '资料已保存。由于您修改了邮箱地址，需要重新完成邮箱验证。'
      : '个人资料已更新',
  });
});

router.post('/auth/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = req.authUser!;
  const body = req.body || {};
  const currentPassword = String(body.currentPassword || '');
  const newPassword = String(body.newPassword || '');

  if (!verifyPassword(currentPassword, user.passwordHash)) {
    res.status(400).json({ error: '当前密码不正确' });
    return;
  }
  const pwErr = validatePasswordStrength(newPassword);
  if (pwErr) {
    res.status(400).json({ error: pwErr });
    return;
  }
  if (currentPassword === newPassword) {
    res.status(400).json({ error: '新密码不能与当前密码相同' });
    return;
  }

  petcareStore.updateUser(user.id, { passwordHash: hashPassword(newPassword) });
  res.json({ updated: true, message: '密码已修改成功' });
});

router.post('/auth/forgot-password', (req, res) => {
  const body = req.body || {};
  const email = validateEmail(String(body.email || ''));
  if (!email) {
    res.status(400).json({ error: '请输入有效的电子邮箱地址' });
    return;
  }

  const smtpConfigured = isSmtpConfigured();
  const user = petcareStore.findUserByEmail(email);

  if (!user) {
    if (!smtpConfigured) {
      res.json({
        requested: true,
        smtpConfigured: false,
        emailSent: false,
        devNotice:
          '当前开发环境未配置 SMTP 邮件服务（需设置 SMTP_HOST、SMTP_USER、SMTP_PASSWORD），且未找到该邮箱对应的注册账户，因此未生成重置链接。',
      });
      return;
    }
    res.json({
      requested: true,
      smtpConfigured: true,
      emailSent: false,
      message: '如果该邮箱已注册，我们已向其发送密码重置指引。',
    });
    return;
  }

  const rawToken = crypto.randomBytes(24).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

  petcareStore.createPasswordResetToken({
    id: `rst_${crypto.randomBytes(8).toString('hex')}`,
    userId: user.id,
    tokenHash,
    expiresAt,
    usedAt: null,
    createdAt: new Date().toISOString(),
  });

  if (!smtpConfigured) {
    const devResetUrl = `/reset-password?token=${rawToken}`;
    res.json({
      requested: true,
      smtpConfigured: false,
      emailSent: false,
      devResetToken: rawToken,
      devResetUrl,
      devNotice:
        '当前开发环境未配置 SMTP 邮件服务（需配置 SMTP_HOST、SMTP_USER、SMTP_PASSWORD）。系统不会伪造邮件发送成功；以下提供仅限本地开发演示使用的重置令牌入口。',
      message: '开发环境提示：未配置邮件服务，未实际发送邮件。',
    });
    return;
  }

  // Note: Production Node runtime should configure nodemailer or delegate to Python SMTP service
  res.json({
    requested: true,
    smtpConfigured: true,
    emailSent: false,
    devNotice:
      '已检测到 SMTP 环境变量，但内置 Node.js 预览服务未包含 SMTP 发信客户端（独立部署请启动 Python FastAPI 后端发送 SMTP 邮件）。',
  });
});

router.get('/auth/reset-password/verify', (req, res) => {
  const token = String(req.query.token || '').trim();
  if (!token || token.length < 10) {
    res.status(400).json({ error: '缺少或无效的重置令牌' });
    return;
  }
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const entry = petcareStore.findPasswordResetByHash(tokenHash);
  if (!entry || entry.usedAt) {
    res.status(400).json({ error: '重置令牌无效或已被使用' });
    return;
  }
  if (new Date(entry.expiresAt).getTime() < Date.now()) {
    res.status(400).json({ error: '重置令牌已过期，请重新申请' });
    return;
  }
  res.json({ valid: true });
});

router.post('/auth/reset-password', (req, res) => {
  const body = req.body || {};
  const token = String(body.token || '').trim();
  const newPassword = String(body.newPassword || '');

  if (!token || token.length < 10) {
    res.status(400).json({ error: '重置令牌无效' });
    return;
  }
  const pwErr = validatePasswordStrength(newPassword);
  if (pwErr) {
    res.status(400).json({ error: pwErr });
    return;
  }

  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const entry = petcareStore.findPasswordResetByHash(tokenHash);
  if (!entry || entry.usedAt) {
    res.status(400).json({ error: '重置令牌无效或已被使用' });
    return;
  }
  if (new Date(entry.expiresAt).getTime() < Date.now()) {
    res.status(400).json({ error: '重置令牌已过期，请重新申请' });
    return;
  }

  const user = petcareStore.findUserById(entry.userId);
  if (!user) {
    res.status(404).json({ error: '关联用户不存在' });
    return;
  }

  petcareStore.updateUser(user.id, { passwordHash: hashPassword(newPassword) });
  petcareStore.markPasswordResetUsed(entry.id);
  res.json({ reset: true, message: '密码重置成功，请使用新密码登录' });
});

router.post('/auth/logout', requireAuth, (req: AuthenticatedRequest, res) => {
  const payload = req.authTokenPayload!;
  petcareStore.revokeToken({
    jti: payload.jti,
    userId: payload.sub,
    expiresAt: new Date(payload.exp * 1000).toISOString(),
    revokedAt: new Date().toISOString(),
  });
  res.json({ loggedOut: true });
});

// ========================
// Pet Profiles CRUD (Authenticated + Strict user_id Isolation)
// ========================
router.get('/pets', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ pets: petcareStore.listPetsByUser(req.authUser!.id) });
});

router.post('/pets/seed-demo', requireAuth, (req: AuthenticatedRequest, res) => {
  const pets = petcareStore.seedDemoForUser(req.authUser!.id);
  res.status(201).json({ pets });
});

router.post('/pets', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const body = req.body || {};
    if (!body.name || typeof body.name !== 'string' || !body.name.trim()) {
      res.status(400).json({ error: '宠物名称不能为空' });
      return;
    }
    const created = petcareStore.createPet(req.authUser!.id, {
      name: body.name.trim(),
      species: body.species || 'dog',
      breed: body.breed ? String(body.breed).trim() : '',
      gender: body.gender === 'female' ? 'female' : 'male',
      age: body.age !== undefined && body.age !== '' ? Number(body.age) : undefined,
      weight: body.weight !== undefined && body.weight !== '' ? Number(body.weight) : 0,
      isNeutered: Boolean(body.isNeutered),
      avatar: body.avatar,
      diet: body.diet || '[]',
      water: body.water || '0ml',
      vaccineStatus: body.vaccineStatus || '',
      companionStartDate: body.companionStartDate || new Date().toISOString().split('T')[0],
    });
    res.status(201).json({ pet: created });
  } catch (error: any) {
    res.status(500).json({ error: error?.message || '创建宠物档案失败' });
  }
});

router.put('/pets/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const result = petcareStore.updatePet(req.authUser!.id, req.params.id, req.body || {});
  if (result.status !== 'ok') {
    if (result.status === 'not_found') {
      res.status(404).json({ error: '未找到该宠物档案' });
      return;
    }
    res.status(403).json({ error: '无权修改其他用户的宠物档案' });
    return;
  }
  res.json({ pet: result.pet });
});

router.delete('/pets/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const status = petcareStore.deletePet(req.authUser!.id, req.params.id);
  if (status === 'not_found') {
    res.status(404).json({ error: '未找到该宠物档案' });
    return;
  }
  if (status === 'forbidden') {
    res.status(403).json({ error: '无权删除其他用户的宠物档案' });
    return;
  }
  res.json({ deleted: true, id: req.params.id });
});

// ========================
// Health Records CRUD (Authenticated + Strict user_id Isolation)
// ========================
router.get('/records', requireAuth, (req: AuthenticatedRequest, res) => {
  const petId = req.query.petId ? String(req.query.petId) : undefined;
  if (petId) {
    const pet = petcareStore.findPetById(petId);
    if (pet && pet.userId !== req.authUser!.id) {
      res.status(403).json({ error: '无权查看其他用户的健康记录' });
      return;
    }
  }
  res.json({ records: petcareStore.listRecordsByUser(req.authUser!.id, petId) });
});

router.post('/records', requireAuth, (req: AuthenticatedRequest, res) => {
  const body = req.body || {};
  if (!body.petId || !body.title) {
    res.status(400).json({ error: 'petId 与记录标题不能为空' });
    return;
  }
  const pet = petcareStore.findPetById(String(body.petId));
  if (!pet) {
    res.status(404).json({ error: '关联宠物档案不存在' });
    return;
  }
  if (pet.userId !== req.authUser!.id) {
    res.status(403).json({ error: '无权为其他用户的宠物添加健康记录' });
    return;
  }

  const created = petcareStore.createRecord(req.authUser!.id, {
    petId: String(body.petId),
    date: body.date || new Date().toISOString().split('T')[0],
    type: body.type || 'activity',
    title: String(body.title).trim(),
    content: String(body.content || '').trim(),
    weightKg: body.weightKg !== undefined && body.weightKg !== '' ? Number(body.weightKg) : undefined,
  });
  res.status(201).json({ record: created });
});

router.delete('/records/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const status = petcareStore.deleteRecord(req.authUser!.id, req.params.id);
  if (status === 'not_found') {
    res.status(404).json({ error: '未找到该健康记录' });
    return;
  }
  if (status === 'forbidden') {
    res.status(403).json({ error: '无权删除其他用户的健康记录' });
    return;
  }
  res.json({ deleted: true, id: req.params.id });
});

// ========================
// Medical Records CRUD (Images/PDFs + Hospital Findings, Authenticated + Strict user_id Isolation)
// ========================
router.get('/medical-records', requireAuth, (req: AuthenticatedRequest, res) => {
  const petId = req.query.petId ? String(req.query.petId) : undefined;
  if (petId) {
    const pet = petcareStore.findPetById(petId);
    if (pet && pet.userId !== req.authUser!.id) {
      res.status(403).json({ error: '无权查看其他用户的医疗记录' });
      return;
    }
  }
  res.json({ records: petcareStore.listMedicalRecordsByUser(req.authUser!.id, petId) });
});

router.post('/medical-records', requireAuth, (req: AuthenticatedRequest, res) => {
  const body = req.body || {};
  const petId = body.petId ? String(body.petId) : '';
  const title = typeof body.title === 'string' ? body.title.trim() : '';
  if (!petId || !title) {
    res.status(400).json({ error: '请关联宠物并填写医疗记录标题' });
    return;
  }

  const pet = petcareStore.findPetById(petId);
  if (!pet) {
    res.status(404).json({ error: '关联宠物档案不存在' });
    return;
  }
  if (pet.userId !== req.authUser!.id) {
    res.status(403).json({ error: '无权为其他用户的宠物添加医疗记录' });
    return;
  }

  const attachments = Array.isArray(body.attachments)
    ? body.attachments.slice(0, 8).map((att: any, idx: number) => ({
        id: String(att?.id || `att_${Date.now()}_${idx}`),
        name: String(att?.name || `附件_${idx + 1}`),
        mimeType: String(att?.mimeType || 'application/octet-stream'),
        sizeBytes: Number(att?.sizeBytes || 0),
        dataUrl: String(att?.dataUrl || ''),
      }))
    : [];

  const created = petcareStore.createMedicalRecord(req.authUser!.id, {
    petId,
    title,
    date: body.date ? String(body.date) : new Date().toISOString().split('T')[0],
    hospitalName: body.hospitalName ? String(body.hospitalName).trim() : '',
    category: body.category || 'lab',
    results: body.results ? String(body.results).trim() : '',
    attachments,
  });
  res.status(201).json({ record: created });
});

router.delete('/medical-records/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const status = petcareStore.deleteMedicalRecord(req.authUser!.id, req.params.id);
  if (status === 'not_found') {
    res.status(404).json({ error: '未找到该医疗记录' });
    return;
  }
  if (status === 'forbidden') {
    res.status(403).json({ error: '无权删除其他用户的医疗记录' });
    return;
  }
  res.json({ deleted: true, id: req.params.id });
});

// ========================
// Reminders CRUD (Authenticated + Strict user_id Isolation)
// ========================
router.get('/reminders', requireAuth, (req: AuthenticatedRequest, res) => {
  const petId = req.query.petId ? String(req.query.petId) : undefined;
  if (petId) {
    const pet = petcareStore.findPetById(petId);
    if (pet && pet.userId !== req.authUser!.id) {
      res.status(403).json({ error: '无权查看其他用户的护理提醒' });
      return;
    }
  }
  res.json({ reminders: petcareStore.listRemindersByUser(req.authUser!.id, petId) });
});

router.post('/reminders', requireAuth, (req: AuthenticatedRequest, res) => {
  const body = req.body || {};
  if (!body.petId || !body.title || !body.dueDate) {
    res.status(400).json({ error: 'petId、提醒标题和日期不能为空' });
    return;
  }
  const pet = petcareStore.findPetById(String(body.petId));
  if (!pet) {
    res.status(404).json({ error: '关联宠物档案不存在' });
    return;
  }
  if (pet.userId !== req.authUser!.id) {
    res.status(403).json({ error: '无权为其他用户的宠物创建提醒' });
    return;
  }

  const created = petcareStore.createReminder(req.authUser!.id, {
    petId: String(body.petId),
    title: String(body.title).trim(),
    category: body.category || 'checkup',
    dueDate: String(body.dueDate),
    dueTime: body.dueTime ? String(body.dueTime) : undefined,
    repeat: body.repeat || 'once',
    notes: body.notes ? String(body.notes).trim() : undefined,
  });
  res.status(201).json({ reminder: created });
});

router.patch('/reminders/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const result = petcareStore.updateReminder(req.authUser!.id, req.params.id, req.body || {});
  if (result.status !== 'ok') {
    if (result.status === 'not_found') {
      res.status(404).json({ error: '未找到该提醒事项' });
      return;
    }
    res.status(403).json({ error: '无权修改其他用户的护理提醒' });
    return;
  }
  res.json({ reminder: result.reminder });
});

router.delete('/reminders/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const status = petcareStore.deleteReminder(req.authUser!.id, req.params.id);
  if (status === 'not_found') {
    res.status(404).json({ error: '未找到该提醒事项' });
    return;
  }
  if (status === 'forbidden') {
    res.status(403).json({ error: '无权删除其他用户的护理提醒' });
    return;
  }
  res.json({ deleted: true, id: req.params.id });
});

// ========================
// AI Vet (Authenticated + Chat History Scoped by user_id & pet_id)
// ========================
router.get('/vet/status', (_req, res) => {
  res.json(vetService.getStatus());
});

router.get('/vet/history', requireAuth, (req: AuthenticatedRequest, res) => {
  const petId = req.query.petId ? String(req.query.petId) : 'general';
  if (petId !== 'general') {
    const pet = petcareStore.findPetById(petId);
    if (pet && pet.userId !== req.authUser!.id) {
      res.status(403).json({ error: '无权查看其他用户的问诊记录' });
      return;
    }
  }
  res.json({ messages: petcareStore.listChatMessages(req.authUser!.id, petId) });
});

router.delete('/vet/history', requireAuth, (req: AuthenticatedRequest, res) => {
  const petId = req.query.petId ? String(req.query.petId) : 'general';
  if (petId !== 'general') {
    const pet = petcareStore.findPetById(petId);
    if (pet && pet.userId !== req.authUser!.id) {
      res.status(403).json({ error: '无权清除其他用户的问诊记录' });
      return;
    }
  }
  petcareStore.clearChatMessages(req.authUser!.id, petId);
  res.json({ cleared: true, petId });
});

function extractTextFromMessagePayload(message: any): string {
  if (typeof message === 'string') return message.trim();
  if (Array.isArray(message)) {
    return (
      message
        .map((p) => (typeof p?.text === 'string' ? p.text.trim() : ''))
        .filter(Boolean)
        .join('\n') || '请帮我查看这张照片。'
    );
  }
  return String(message || '').trim();
}

router.post('/vet/chat', requireAuth, async (req: AuthenticatedRequest, res) => {
  try {
    const { history, message, language, useSearch, petContext, petId: bodyPetId } = req.body;
    const petKey = String(bodyPetId || petContext?.id || 'general');
    if (petKey !== 'general') {
      const pet = petcareStore.findPetById(petKey);
      if (pet && pet.userId !== req.authUser!.id) {
        res.status(403).json({ error: '无权使用其他用户的宠物档案进行问诊' });
        return;
      }
    }

    const result = await vetService.chatSimple({
      history,
      message,
      language,
      useSearch,
      petContext,
    });

    const now = new Date().toISOString();
    petcareStore.appendChatMessages([
      {
        id: `msg_${Date.now()}_u`,
        userId: req.authUser!.id,
        petId: petKey,
        role: 'user',
        text: extractTextFromMessagePayload(message),
        timestamp: now,
      },
      {
        id: `msg_${Date.now()}_m`,
        userId: req.authUser!.id,
        petId: petKey,
        role: 'model',
        text: result.response,
        engine: result.engine,
        sources: result.sources,
        timestamp: now,
      },
    ]);

    res.json(result);
  } catch (error: any) {
    console.error('Chat error:', error);
    res.status(500).json({ error: error?.message || 'AI 兽医请求失败，请检查服务端配置或稍后重试' });
  }
});

router.post('/vet/chat/stream', requireAuth, async (req: AuthenticatedRequest, res) => {
  let clientClosed = false;
  res.on('close', () => {
    if (!res.writableFinished) {
      clientClosed = true;
    }
  });

  try {
    const { history, message, language, useSearch, petContext, petId: bodyPetId } = req.body;
    const petKey = String(bodyPetId || petContext?.id || 'general');
    if (petKey !== 'general') {
      const pet = petcareStore.findPetById(petKey);
      if (pet && pet.userId !== req.authUser!.id) {
        res.status(403).json({ error: '无权使用其他用户的宠物档案进行问诊' });
        return;
      }
    }

    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const stream = vetService.chatSimpleStream({
      history,
      message,
      language,
      useSearch,
      petContext,
    });
    let fullReply = '';
    let detectedEngine: string | undefined;
    let detectedSources: Array<{ title: string; url: string }> = [];

    for await (const event of stream) {
      if (clientClosed || res.writableEnded) break;
      if (event.type === 'meta') {
        detectedEngine = event.engine;
        detectedSources = event.sources || [];
        res.write(
          `data: ${JSON.stringify({
            meta: {
              engine: event.engine,
              deepseekConfigured: event.deepseekConfigured,
              sources: event.sources,
            },
          })}\n\n`
        );
      } else if (event.type === 'chunk') {
        fullReply += event.text;
        res.write(`data: ${JSON.stringify({ chunk: event.text })}\n\n`);
      }
    }

    if (fullReply.trim()) {
      const now = new Date().toISOString();
      petcareStore.appendChatMessages([
        {
          id: `msg_${Date.now()}_u`,
          userId: req.authUser!.id,
          petId: petKey,
          role: 'user',
          text: extractTextFromMessagePayload(message),
          timestamp: now,
        },
        {
          id: `msg_${Date.now()}_m`,
          userId: req.authUser!.id,
          petId: petKey,
          role: 'model',
          text: fullReply,
          engine: detectedEngine,
          sources: detectedSources,
          timestamp: now,
        },
      ]);
    }

    if (!clientClosed && !res.writableEnded) {
      res.write('data: [DONE]\n\n');
      res.end();
    }
  } catch (error: any) {
    console.error('Streaming chat error:', error);
    if (!clientClosed && !res.writableEnded) {
      res.write(`data: ${JSON.stringify({ error: error?.message || 'AI 兽医响应失败' })}\n\n`);
      res.end();
    }
  }
});

// ========================
// Nearby Pet Hospitals (Public reference data)
// ========================
router.get('/hospitals/nearby', async (req, res) => {
  try {
    const latRaw = req.query.lat ? parseFloat(String(req.query.lat)) : null;
    const lngRaw = req.query.lng ? parseFloat(String(req.query.lng)) : null;
    const city = req.query.city ? String(req.query.city) : 'all';

    const result = await hospitalService.getNearbyHospitals({
      lat: latRaw !== null && Number.isFinite(latRaw) ? latRaw : null,
      lng: lngRaw !== null && Number.isFinite(lngRaw) ? lngRaw : null,
      city,
    });
    res.json(result);
  } catch (error: any) {
    console.error('Nearby hospitals error:', error);
    res.status(500).json({ error: error?.message || '获取附近宠物医院失败' });
  }
});

// ========================
// Symptom Checker (Executes Python rule engine)
// ========================
router.get('/symptoms/rules', async (_req, res) => {
  try {
    const rules = await symptomServerService.getRules();
    res.json(rules);
  } catch (error: any) {
    res.status(503).json({
      error: error?.message || 'Python 症状知识库读取失败，请确认 Python 服务已就绪',
    });
  }
});

router.post('/symptoms/check', async (req, res) => {
  try {
    const body = req.body || {};
    const rawIds = Array.isArray(body.symptomIds) ? body.symptomIds : [];
    const cleanedIds = rawIds
      .filter((id: unknown): id is string => typeof id === 'string' && id.trim().length > 0)
      .map((id: string) => id.trim());

    if (cleanedIds.length === 0) {
      res.status(400).json({ error: '请至少选择一项观察到的症状' });
      return;
    }

    const result = await symptomServerService.checkSymptoms(cleanedIds);
    if (!result?.matchedSymptoms || result.matchedSymptoms.length === 0) {
      res.status(400).json({ error: '未匹配到有效症状编号，请重新选择' });
      return;
    }
    res.json(result);
  } catch (error: any) {
    console.error('Python symptom check error:', error);
    res.status(503).json({
      error: error?.message || 'Python 健康分析服务未启动或执行失败，请检查后端服务状态',
    });
  }
});

router.get('/symptoms/history', (req, res) => {
  const petId = req.query.petId ? String(req.query.petId) : undefined;
  res.json({ history: symptomServerService.listHistory(petId) });
});

router.post('/symptoms/history', (req, res) => {
  const body = req.body || {};
  const symptomIds = Array.isArray(body.symptomIds) ? body.symptomIds.map(String) : [];
  if (symptomIds.length === 0) {
    res.status(400).json({ error: 'symptomIds 不能为空' });
    return;
  }
  const item = symptomServerService.addHistory({
    petId: body.petId ? String(body.petId) : 'general',
    petName: body.petName ? String(body.petName) : '未指定宠物',
    symptomIds,
    symptomNames: Array.isArray(body.symptomNames) ? body.symptomNames.map(String) : [],
    level:
      body.level === 'emergency' || body.level === 'urgent' || body.level === 'watch'
        ? body.level
        : 'watch',
    score: Number(body.score || 0),
    headline: String(body.headline || ''),
    reasoning: Array.isArray(body.reasoning) ? body.reasoning.map(String) : [],
    adviceList: Array.isArray(body.adviceList) ? body.adviceList.map(String) : [],
  });
  res.status(201).json({ item });
});

router.delete('/symptoms/history', (req, res) => {
  const petId = req.query.petId ? String(req.query.petId) : undefined;
  symptomServerService.clearHistory(petId);
  res.json({ cleared: true, petId: petId ?? null });
});

// ========================
// Multimodal Audio, Food Scan & Wardrobe (Require Auth)
// ========================
router.post('/audio/transcribe', requireAuth, async (req, res) => {
  try {
    const { audio } = req.body;
    const text = await geminiService.transcribeAudio(audio);
    res.json({ text });
  } catch (error) {
    console.error('Transcription error:', error);
    res.status(500).json({ error: '语音转文字失败（需要服务端配置 GEMINI_API_KEY）' });
  }
});

router.post('/food/analyze', requireAuth, async (req, res) => {
  try {
    const { images, language } = req.body;
    const result = await geminiService.analyzeFood(images, language);
    res.json(result);
  } catch (error) {
    console.error('Food analysis error:', error);
    res.status(500).json({ error: '食品成分分析失败（需要服务端配置 GEMINI_API_KEY）' });
  }
});

router.post('/wardrobe/evaluate', requireAuth, async (req, res) => {
  try {
    const { petName, species, outfitTitle, outfitStyle, language } = req.body;
    const review = await geminiService.evaluateOutfit({
      petName,
      species,
      outfitTitle,
      outfitStyle,
      language,
    });
    res.json(review);
  } catch (error) {
    console.error('Wardrobe evaluate error:', error);
    res.status(500).json({ error: 'Failed to evaluate outfit' });
  }
});

router.post('/wardrobe/analyze-clothing', requireAuth, async (req, res) => {
  try {
    const { image, species, language } = req.body;
    const analysis = await geminiService.analyzeClothing({ image, species, language });
    res.json(analysis);
  } catch (error) {
    console.error('Wardrobe analyze clothing error:', error);
    res.status(500).json({ error: 'Failed to analyze clothing' });
  }
});

router.post('/wardrobe/analyze-pet', requireAuth, async (req, res) => {
  try {
    const { image } = req.body;
    if (!image?.data) {
      return res.status(400).json({ error: 'Missing pet image' });
    }
    const analysis = await geminiService.analyzePet({ image });
    res.json(analysis);
  } catch (error) {
    console.error('Wardrobe analyze pet error:', error);
    res.status(500).json({ error: 'Failed to analyze pet anatomy' });
  }
});

router.post('/wardrobe/recommend', requireAuth, async (req, res) => {
  try {
    const { subjectType, species, subjectName, anatomy, outfits, image, language } = req.body;
    if (!Array.isArray(outfits) || outfits.length === 0) {
      return res.status(400).json({ error: 'Missing wardrobe outfits list' });
    }
    const result = await geminiService.recommendOutfits({
      subjectType,
      species,
      subjectName,
      anatomy,
      outfits,
      image,
      language,
    });
    res.json(result);
  } catch (error) {
    console.error('Wardrobe recommend error:', error);
    res.status(500).json({ error: 'Failed to generate wardrobe recommendations' });
  }
});

export default router;
